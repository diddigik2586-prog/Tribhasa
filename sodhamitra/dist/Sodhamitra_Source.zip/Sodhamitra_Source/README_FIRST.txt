Śodhamitra — Research Planner : complete source project
=======================================================
Open  sodhamitra/README.md  first. In short:

  Needs: JDK 17 or newer, the Android SDK (platform 36, build-tools 36.0.0), internet access for the first Gradle run.
  Testing build :  cd sodhamitra/android && ./gradlew :app:assembleDebug
                   -> app/build/outputs/apk/debug/app-debug.apk   (signed with the PUBLIC testing key android/testing.keystore)
  Release build :  needs the PRIVATE release key, which is not in this archive. Put it outside the project and describe it in
                   sodhamitra/android/release-signing.properties (see README.md, "Release build"), then
                   ./gradlew :app:assembleRelease
                   -> app/build/outputs/apk/release/app-release.apk  (without the key the result is an UNSIGNED, uninstallable APK)
  Tests         :  ./gradlew :app:testDebugUnitTest

This archive contains no private signing key, no password and no build output.
