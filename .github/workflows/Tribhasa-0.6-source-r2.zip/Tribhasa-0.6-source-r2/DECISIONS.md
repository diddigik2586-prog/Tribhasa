# Tribhāṣā — Decision Log

## 2026-10-18 — No source recovery assumed
**Decision:** Create a separate starter scaffold rather than editing/reconstructing a source project that was not found.  
**Reason:** The runtime contained no files and Library searches found only an infographic relevant to Tribhāṣā.  
**Trade-off:** This is new baseline work, not a continuation of any unprovided external repository.

## 2026-10-18 — Native Android client (SUPERSEDED 2026-10-19: the UI is plain Android views, no Compose)
**Decision:** Kotlin + Jetpack Compose + Material 3 with a ViewModel state holder.  
**Reason:** Fits the requested native Android direction and Unicode UI requirements.  
**Trade-off:** Dependency/build compatibility is not verified because the environment lacks Gradle/Android SDK and cannot resolve external hosts.

## 2026-10-18 — API disabled by default (SUPERSEDED 2026-10-20: no backend and no provider key exist any more)
**Decision:** Blank client API URL and `ENABLE_SARVAM_API=false` on backend.  
**Reason:** No backend or API key supplied; user prohibits unapproved charges and embedding secrets in APK.  
**Trade-off:** No live translation until operator configures and approves a provider.

## 2026-10-18 — Translation adapter only (SUPERSEDED: Sarvam and the backend were retired)
**Decision:** Integrate a Sarvam Translate adapter for translation only; advanced modes return a clear unavailable response until a suitable provider/model is validated.  
**Reason:** Official Sarvam docs identify Sanskrit, Kannada and English in the Sarvam Translate language set, while this does not by itself validate Sanskrit scholarly commentary or advanced grammatical analysis.  
**Trade-off:** Only six-way basic translation is in the first provider slice; broader features remain blocked.

## 2026-10-18 — No actual fallback provider yet
**Decision:** Implement a generic eligibility/router seam and test simulated failover. Do not claim live multi-provider failover.  
**Reason:** No alternative has been configured, authorised, and tested; fake providers are not production providers.  
**Trade-off:** Current live configuration has no automatic real-provider alternative.

## 2026-10-20 — The AI runs on the phone by default
**Decision:** Gemma 4 E2B through Google's LiteRT-LM, downloaded once on first use; online services stay as an optional, labelled source.  
**Reason:** The owner requires zero mandatory API keys, paid calls or hosting, and wants everything free. Both pieces are Apache-2.0.  
**Trade-off:** A 2.59 GB download; needs a reasonably modern phone; a small model whose Sanskrit and Kannada quality is **untested**.

## 2026-10-20 — Model selection criteria
**Decision:** Chosen on licence (Apache-2.0), ungated download, being published for this runtime by its maintainers, size, and the publisher's memory figure — **not** on Sanskrit quality, which could not be tested.  
**Trade-off:** The choice may change after `docs/SANSKRIT_EVALUATION_PLAN.md` is carried out; any new model needs the same licence / checksum / memory verification.

## 2026-10-20 — No silent fallback, no quality claim
**Decision:** In on-phone mode the online services are never constructed; if the phone model cannot do something, the user is told why. Every on-device result says it is low-confidence and untested for Sanskrit.  
**Reason:** Owner requirement; honesty about an unmeasured model.  
**Trade-off:** Some tasks (comparison, long analyses) are refused or marked experimental on the phone.

## 2026-10-20 — Build choices
**Decision:** Kotlin 2.4.21 (the library is built with Kotlin 2.4), AGP 8.13.2, Gradle 8.13, no Compose, one dependency, arm64-v8a only, `targetSdk 34`, debug id `org.tribhasa.app.dev`.  
**Reason:** Compatibility with the library; small APK; the view-based UI is not designed for forced edge-to-edge (target 35+); the debug build must never replace the signed APK.  
**Trade-off:** No x86 emulator or 32-bit phone support; raising the target SDK is future UI work. None of this has been confirmed by a real Gradle run.

## Still unapproved
- Any API credit purchase, paid usage, or hosted backend.
- Production identity/trial accounting and Google Play Billing plan/pricing.
- Production release, publication, or switching the project phase to `Final`.
