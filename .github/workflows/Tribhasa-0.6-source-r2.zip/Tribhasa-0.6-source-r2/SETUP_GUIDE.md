# Tribhāṣā — Setup Guide (0.6)

## Current state
The source is complete and tested on a computer with stand-ins, but **no Gradle build, APK or phone test has been done yet**
(the workspace that wrote it could not reach Gradle's or Google's package servers). The first real build is the GitHub workflow.

## A. Get the APK with GitHub Actions (no computer, free, works from a phone)
Full steps in Kannada: `docs/KANNADA_PHONE_GUIDE.md`. In short:
1. New **Public** GitHub repository (do not tick "Add a README").
2. Add file → Upload files → the project **.zip** (kept as a zip) → Commit to `main`. Or upload the unpacked folders instead.
3. Add file → Create new file → `.github/workflows/build-testing-apk.yml` → paste the workflow text → Commit to `main`. This starts the build.
4. Actions → open the run (a first run downloads the Android tools; expect 10–25 minutes):
   * green: the run summary shows the APK size and SHA-256; under **Artifacts** download **Tribhasa-testing-debug-apk**, unzip, install on the phone;
   * red: the reason is shown at the top of the run page; send it. The first run may need a fix, because these build files have never been run.
5. To fix a failure, upload the corrected zip (any file name; if several zips are in the repository the most recently uploaded one is used); the push starts a new run.
6. The step "Check the model address, size and checksum" compares the app's values with the model publisher's server (headers only).
7. Optional: Run workflow with "draft_release" ticked prepares a **draft** release holding the APK. It is not published unless you press Publish.

## B. Build on your own computer (Android Studio)
Open the `android/` folder in Android Studio (a recent version that supports AGP 8.13 and JDK 17), let it sync, choose Build → Build APK(s).
Command line, with Gradle 8.13 and JDK 17 installed: `cd android && gradle :app:assembleDebug`. The APK appears under
`android/app/build/outputs/apk/debug/`. Check that the file really exists before installing.

## C. Tests on a computer (no phone needed)
`bash tools/run_tests.sh` (core) · `bash tools/run_ui_tests.sh` (screens on fake Android) · `bash tools/typecheck_litertlm.sh`
(whole app against the real library sources; needs git and network access to GitHub). `tools/setup_toolchain.sh` prepares the
Kotlin compiler and Android jar these scripts use. Gradle runs the core checks as `:app:testDebugUnitTest`.

## D. First run on a phone
Follow the phone test sheet in `docs/TEST_REPORT_0.6.md`. Use Wi-Fi for the 2.59 GB download and keep the phone charged.

## Nothing to configure
No API key, account, backend address or paid service is needed. The optional online mode (Settings → Where the AI runs → Online)
uses a one-time OpenRouter sign-in and free models.

## ಕನ್ನಡ ಸಾರಾಂಶ
- ಮೊದಲು ಈ ಪ್ರಾಜೆಕ್ಟ್ ಅನ್ನು GitHub repositoryಗೆ ಹಾಕಿ; ನಂತರ Actions → Build Tribhāṣā Testing APK → Run workflow ಒತ್ತಿ.
- ಹಸಿರು ಬಂದರೆ Artifactsನಿಂದ APK ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ ಫೋನ್‌ನಲ್ಲಿ install ಮಾಡಿ. ಕೆಂಪು ಬಂದರೆ ವಿಫಲವಾದ ಹಂತದ log ಅನ್ನು ಕಳುಹಿಸಿ.
- ಮೊದಲ ಬಾರಿ Wi-Fi ಮೂಲಕ ಸುಮಾರು 2.59 GB ಮಾದರಿಯನ್ನು ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ. ನಂತರ ಇಂಟರ್ನೆಟ್ ಇಲ್ಲದೆ ಬಳಸಬಹುದು.
- API key ಅಥವಾ ಹಣ ಪಾವತಿ ಬೇಡ.
