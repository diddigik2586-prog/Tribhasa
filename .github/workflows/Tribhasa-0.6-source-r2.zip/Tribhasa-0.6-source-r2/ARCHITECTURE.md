# Tribhāṣā — Architecture (0.6)

## Layers
* **`core/` (pure Kotlin, no Android imports, tested on a computer):** languages and scripts, transliteration, prompts, the translation
  service (segmenting, polish, glossary), refine and scholarly tasks, quality-control reports, history, the offline metre scanner,
  HTTP and retry helpers, and the on-device pieces: `LocalModels`, `ModelDownloader`, `LocalModelRuntime`, `LocalLlm`, `LocalChecks`.
* **`local/` (needs Android or the library):** `LiteRtEngineFactory` (the only file using Google's LiteRT-LM), `DeviceInfo`,
  `DownloadService` (foreground service), `LocalModelController` (app-level state for the download and the loaded model).
* **`ui/` and the activity (plain Android views):** the six tabs, Settings (model card, source selector), About.
* No Compose, no AndroidX, no backend. The only library is `litertlm-android`.

## Where the AI runs
`AiSource` is stored in settings: **LOCAL** (default) or **ONLINE**.
* **LOCAL:** `ServiceFactory` builds only `LocalLlmProvider`, and a translator that uses only it. The online engines (IndicTrans2
  services, OpenRouter) are not created, so no request can be sent and none can replace a failed local one.
* **ONLINE:** the earlier path (optional IndicTrans2 services and OpenRouter free models, with the retry / fail-over rules).
The app never changes the source by itself.

## Request flow on the phone
1. A screen starts a task; `App.launch` runs it off the main thread and keeps status, error and cancel handle in a model object.
2. The task is cut into parts of at most 450 characters (translation, polish); each part is one request.
3. `LocalLlmProvider` refuses the request if the model file is missing, unfinished or unchecked (with what to do), or if prompt +
   answer cannot fit the 4096-token context; otherwise it asks `LocalModelRuntime`.
4. `LocalModelRuntime` loads the model on first use, serves one task at a time, forwards cancel, stops an engine that goes silent,
   maps out-of-memory and load errors to plain messages, and reports a GPU → CPU fall-back.
5. `LiteRtEngineFactory` opens `Engine(EngineConfig(modelPath, Backend.CPU() | Backend.GPU(), cacheDir))`, creates a conversation
   with the system instruction, sends the user message with `sendMessageAsync`, and streams pieces back.
6. Replies are parsed; a single plain-text answer from a small model is accepted but flagged; checks for loops, unchanged text and
   cut-off answers run; `LocalChecks.standing` adds the "done on this phone / low confidence" notices to the quality report.

## Model lifecycle
Download (resumable, checksum) → `.verified` mark → ready. Loaded on first task; released by `onTrimMemory`, "Free memory now",
a stall, or an out-of-memory error. Deleted from Settings (refused while a task is using it).

## Testing architecture
`NativeEngineFactory` is the seam: tests use `FakeNativeFactory`; a local HTTPS server (`BlobServer`) serves a small test file in
place of the 2.59 GB model; a `ProxySelector` tripwire shows that no connection is made in on-phone mode; the real screens run on
the JVM against fake Android classes, with three Android-dependent files replaced by stand-ins of the same name. These show that the
app's own code is wired and behaves; they cannot show what the real engine or model does.
