# Tribhāṣā — Persistent Project Memory

## Binding user requirements
- App name exactly `Tribhāṣā`. Attribution exactly `by Dr. Diddigi Vamsi Krishna`, only on the main-screen footer, the splash and About; never in translations, copies or scholarly output.
- Sanskrit, Kannada, English; six directions (SA→KN, SA→EN, KN→SA, KN→EN, EN→SA, EN→KN). Interface in Sanskrit, Kannada and English.
- No Vedic-related features. No PDF/DOCX/TXT export (direct copy only). No mandatory Google sign-in.
- Testing build: free, no usage cap, no expiry, no Play Billing; this lasts until the owner declares "Final". Production-only: Google sign-in, 10 free translations per eligible account, Play Billing (not to be built or enabled without approval).
- **Zero cost, on-device AI (latest instruction):** no mandatory external AI API, key, paid call or paid hosting; the AI runs on the phone via LiteRT-LM; the model is downloaded on first use, never bundled; show progress and errors; allow retry and delete; work offline afterwards; never silently fall back to a paid API; report unsupported tasks, failures and low confidence.
- Do not claim Sanskrit translation quality is verified until a documented Sanskrit evaluation set has been run.
- Do not claim a build succeeded without real build evidence. Do not claim files, tests or device checks that were not done.
- No secrets in the APK, source, repository or archives; never ask the user to paste a secret key into chat; do not overwrite the existing signed APK without approval.
- No paid service, billing, credits or hosting without explicit approval. No proprietary (Claude/Gemini) inference and no claim of equivalence to any proprietary model.
- Scholarly features: Sanskrit-to-Sanskrit commentary, grammatical analysis, IAST, padaccheda, pratipadārtha, śloka and prose analysis, task-specific quality-control report listing only checks that actually ran. Default Kannada is polished Granthika; English is Indian English with British spelling. Never invent citations; distinguish model commentary from verified evidence. Do not silently replace submitted text.
- Technical explanations to the user in simple Kannada (an English version beside it is fine). Avoid needless questions; preserve working code.
- The user is Dr. Diddigi Vamsi Krishna, a Sanskrit scholar and manuscriptologist, not an engineer; wants everything free.

## Current technical decisions
See `DECISIONS.md`. In short: view-based Android app, Kotlin 2.4.21, one dependency (`litertlm-android:0.18.0`), Gemma 4 E2B (Apache-2.0, 2.59 GB, SHA-256 pinned) downloaded to private storage, CPU by default with optional GPU, on-phone mode builds no online service, optional online mode kept and labelled, debug application id `org.tribhasa.app.dev`, `targetSdk 34`.
