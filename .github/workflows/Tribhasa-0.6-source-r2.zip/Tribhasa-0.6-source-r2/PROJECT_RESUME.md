# Tribhāṣā — Resume Instructions

Read in order: `PROJECT_RESUME.md`, `PROJECT_STATUS.md`, `PROJECT_MEMORY.md`, `TASK_TRACKER.md`, `docs/TEST_REPORT_0.6.md`.
Then inspect the actual files; do not assume the notes equal the current state.

## Exact resume point (20 October 2026)
1. Code, tests and docs for 0.6 (on-device AI) are written. Core tests: 573 passed; headless UI tests: 498 passed; type-check
   against the real LiteRT-LM v0.18.0 sources passed. All on a computer, with stand-ins.
2. **Never done:** a Gradle build, the GitHub workflow run, installing on a phone, downloading the real model, running it.
3. Next required external step: put the project in a GitHub repository and run Actions → Build Tribhāṣā Testing APK. Read the real
   log. The rewritten Gradle files may need fixes (Kotlin 2.4.21 + AGP 8.13.2 + Gradle 8.13 + `litertlm-android:0.18.0` have never been resolved together).
4. Then the phone test sheet in `docs/TEST_REPORT_0.6.md`, then the Sanskrit evaluation (`docs/SANSKRIT_EVALUATION_PLAN.md`).

## Safe resume rules
Testing mode stays on until the owner says "Final": no usage cap, no billing. Do not enable any paid service, key, credit or hosting
without explicit approval. Do not overwrite the signed 0.5 APK. Do not claim quality, a build or a device test that has not happened.
Keep the signing key and passwords out of every archive.
