# Tribhāṣā — Task Tracker (20 October 2026)

| ID | Task | Status | Next step |
|---|---|---|---|
| T-001 | Six directions through one pipeline | Done in code; tested with stand-ins (core + screens) | Real-phone test; Sanskrit evaluation |
| T-002 | Refinement tools (eight) | Done in code; tested with stand-ins | Real-phone test |
| T-003 | Śloka / prose / grammatical analysis, Sanskrit commentary | Done in code; marked experimental on the phone | Real-phone test; evaluation |
| T-004 | Offline metre check | Done; tested; needs no AI | — |
| T-005 | Glossary, history, copy / clear | Done; tested | — |
| T-006 | Remove every mandatory external AI dependency | Done in code (default mode builds no online service) | Confirm on a phone with airplane mode |
| T-007 | LiteRT-LM integration | Written; type-checked against real v0.18.0 sources; **never run** | First device run |
| T-008 | Model download, progress, retry, pause, check, delete | Done; tested against a local test server | Real 2.59 GB download on a phone |
| T-009 | Offline use after download | Done in code; no connection attempted in tests | Confirm on a phone |
| T-010 | Honest reporting: failures, unsupported tasks, low confidence | Done; tested | — |
| T-011 | Sanskrit evaluation | **Not started** (plan only: `docs/SANSKRIT_EVALUATION_PLAN.md`) | Scholar prepares reference set |
| T-012 | Gradle / AGP build | Files rewritten; **never run** | Run the GitHub workflow |
| T-013 | Testing APK via GitHub Actions | Workflow extended; **not run** | Put project on GitHub, run it |
| T-014 | Install / device tests | **Not done** | Phone test sheet |
| T-015 | Raise `targetSdk` above 34 (edge-to-edge UI) | Not started | Separate UI task |
| T-016 | Google sign-in, trial counting, Play Billing | Not implemented, by instruction (free until "Final") | Only after the owner says so |
