# The on-device model — source, licence, size, checks

Facts below were read on **20 October 2026** from the model publisher's own repository pages and from the LiteRT-LM
library's source and package index. They are recorded in code in `core/LocalModels.kt` (the app uses exactly these values).

## The model

| | |
|---|---|
| Name | Gemma 4 E2B, instruction-tuned, converted for LiteRT-LM |
| Publisher / repository | LiteRT Community on Hugging Face — `litert-community/gemma-4-E2B-it-litert-lm` (base model `google/gemma-4-E2B-it`) |
| Page | https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm |
| Pinned revision | `b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1` (the app downloads from this exact revision, so the file cannot change under it) |
| File | `gemma-4-E2B-it.litertlm` |
| **Download size** | **2,588,147,712 bytes (2.59 GB)** |
| SHA-256 (as published) | `181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c` |
| **Licence** | **Apache-2.0** (the repository's licence field). Apache-2.0 permits use and redistribution. The app does not redistribute the model: each phone downloads it directly from the publisher. |
| Access | Not gated: no login or licence-acceptance wall for the file |
| Context used | 4096 tokens (prompt + answer), set by the app |
| Memory | The model card states **no minimum RAM**. Its own benchmark on one flagship phone (Galaxy S26 Ultra, 2048-token context, CPU) measured about **1.7 GB** of memory. The app's rule of thumb (warning below 5 GB, strong warning below 3.5 GB of phone memory) is the app's own judgement, **not a measured limit**. |

## The runtime

`com.google.ai.edge.litertlm:litertlm-android:0.18.0` — Google's LiteRT-LM, Apache-2.0, built with Kotlin 2.4, which is why
the project uses Kotlin 2.4.21. Version 0.18.0 is listed with a release date of 6 October 2026 in the mvnrepository.com
index (a third-party index; Google's Maven could not be fetched from the build workspace). Only
`local/LiteRtEngineFactory.kt` touches the library. It uses the CPU by default; an optional Settings switch tries the
GPU and falls back to the CPU, telling the user, if the GPU cannot load the model.

## What was verified, and what was not

Verified:
* The licence field, file name, size and SHA-256 above, as published by the repository.
* The address is pinned to a 40-character revision and the app refuses any file whose SHA-256 differs.
* The library's public API (`Engine`, `EngineConfig`, `Conversation`, `ConversationConfig`, `MessageCallback`, …) as used
  by `LiteRtEngineFactory` compiles against the library's real v0.18.0 sources (`tools/typecheck_litertlm.sh`).

**Not** verified (nothing here could download the 2.6 GB file or run a phone):
* That this exact file loads and runs with library 0.18.0 on a real phone. The first run on a phone is the real proof.
* The checksum was **not** computed by us from a downloaded copy; it is the publisher's value. The GitHub build compares it
  with the publisher's live headers (`tools/check_model_source.py`; the header names it reads are Hugging Face's
  `X-Linked-Size` / `X-Linked-ETag`, which were not observed live here, and the script says "could not compare" rather than
  passing if they are absent). The phone itself recomputes the SHA-256 after every download.
* Speed, memory use and battery on any real phone.
* **Quality.** Nothing has been measured for Sanskrit or Kannada. The model is a small general model. See
  `SANSKRIT_EVALUATION_PLAN.md`. Until a documented evaluation has been run, every result carries the warning
  "Low confidence by default … not tested with a Sanskrit evaluation set", and no document may claim otherwise.

## How the app handles the file

* **Where:** the app's private storage (`files/models/gemma-4-e2b-it/`), never backed up, removed on uninstall.
* **Download:** HTTPS only, resumable (HTTP Range, `.part` file), Wi-Fi only by default (a switch allows mobile data),
  free-space check before starting (missing bytes plus a margin), automatic retry with back-off while progress is being
  made, cancel/pause keeps the partial file, a foreground-service notification with a Pause button keeps it alive with the
  screen off, and a notification permission is asked once.
* **Check:** after the last byte the whole file's SHA-256 must equal the published one, otherwise it is deleted and the
  user is told. A `.verified` mark (checksum + size + date) lets later starts avoid re-reading 2.6 GB; if the file changes,
  the mark no longer matches and the file is treated as damaged and not used. **Check the file** re-reads and re-hashes it.
* **Errors:** every failure (server, missing file, disk full, mobile data blocked, wrong checksum, out of memory, stall)
  has its own plain message, and **Retry** where retrying makes sense.
* **Delete:** Settings → **Delete from this phone** (asks first; refused while a task is using the model).
* **Offline:** once the file is on the phone and marked verified, tasks need no internet. In tests with the network
  watched, no connection is attempted in this mode.
* **Memory:** the model is loaded when first needed and released when Android asks apps to trim memory
  (`onTrimMemory`), or by **Free memory now**.

## Limits of the small model on the phone (by design)

Translations are sent in parts of at most 450 characters, one part per request, with up to 1024 answer tokens; the Kannada
polish step is sized the same way (one part per request). Śloka analysis, prose analysis and commentary are marked experimental
on the phone: they can take minutes and may be incomplete or wrong. If a model answers in plain text instead of the requested
format, a single-part answer is accepted but flagged. Cut-off answers, repeated text, unchanged text and over-long input are
detected and reported (simple checks, not judgements of correctness).
