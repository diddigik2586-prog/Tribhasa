> **Historical record.** This is the report for version 0.5 (the signed APK built outside Gradle, with the AI reached through online services). It is kept unchanged below. For the current version see `../TEST_REPORT_0.6.md`.

# Tribhāṣā 0.5 testing build — what was tested, and what was not

Made on 20 October 2026 in a cloud Linux workspace with no Android emulator, no phone, and a network allowlist that
blocked Maven, Google's Maven, Gradle, Hugging Face and openrouter.ai.

> A compiling project is not proof of working AI. A working screen is not proof of successful inference.
> Nothing below shows that a real model translates Sanskrit or Kannada well.

## Run, and passed

| What | Result | What it proves | What it does not prove |
|---|---|---|---|
| Core logic on the JVM (`build/run_tests.sh`): scripts, IAST↔Devanagari↔Kannada, prompts, reply parsing, retries, error classes, glossary, history, sign-in (PKCE) protocol, free-model rules, QC report, metre | 361 checks, 0 failed | The logic behaves as written against mock HTTPS servers | Anything about real model output |
| Reference proxy (`backend/`) | 38 checks, 0 failed | The optional Node proxy behaves as written | It is not used by the app |
| Headless UI run (`build/run_ui_tests.sh`): the app's real `MainActivity` and all screens, driven by taps and typing, on the JVM against fake Android classes, with a mock HTTPS "model" returning canned answers | 372 checks, 0 failed | Screens, navigation, Back button, rotation, drafts, history, glossary, settings, sign-in flow and failure handling are wired correctly and keep working when the service fails | Real layout, fonts, rendering, touch feel, the real Android framework, or translation quality |
| Compile against `android-26.jar` (the minimum supported version) | 379 classes, no errors | The code uses no API newer than Android 8.0 | That it runs on every Android 8–15 phone |
| APK build, signature check | built; `verified=true v2=true v3=true`; signer SHA-256 `43C69389FDA85360559E585404A5C79963F34AE13CD35803521C339CF9AD8011`, identical to the earlier build | Updates over the earlier build will be accepted | Installation on a device |
| Package facts | `org.tribhasa.app`, versionCode 5, minSdk 26, targetSdk 34, permissions INTERNET and ACCESS_NETWORK_STATE only | | |
| Scan of the APK | no key-like strings, no `.p12/.jks/.pem/.env` files; web addresses inside: openrouter.ai, bhashini.gov.in / ULCA, api.cloudflare.com (optional extras), localhost (sign-in return) | No secret is in the APK | |

The UI run covers: start-up and splash, attribution placement (exactly splash, main-screen footer, About), six tabs,
Back, About, keyboard handling; **all six directions** through the real Translate screen (model asked for the right
target language, received exactly the source text, answer shown, QC report shown, Copy gives exactly the translation
with no attribution, saved to history); progress, Cancel (including 8 immediate cancels), wrong key, quota used up,
offline, retry; IAST / Kannada / Devanagari views; swap; Refine tools; śloka, prose and commentary; offline metre;
glossary add / edit / delete / search / persistence and its use in translation; history; the one-time sign-in with the
browser and OpenRouter replaced by test doubles (success, cancel, denied, refused, no browser, offline, return link);
settings; Compare models; rotation mid-task; drafts and language choices across restarts; ZWJ / ZWNJ Kannada, IAST
(composed and decomposed) to Devanagari, verses with daṇḍa and numerals, a 60-sentence text split and rejoined in
order; crash report, start-up failure screen, a failed screen, keystore failure, damaged stored key, damaged history.

## Defects the new tests found, now fixed

1. Cancel pressed while a connection was still being opened was sometimes ignored. Fixed in `core/Http.kt`.
2. The personal glossary was never sent to the AI translator (only used afterwards). Now sent and tested.
3. The crash handler was wrapped again each time the screen was recreated. Now installed once.
4. The Refine output-language dialog had the wrong title.
5. The app said the saved access was "encrypted" even where the keystore had failed and it was only kept in private
   storage; three screens made that claim unconditionally. They now say what is actually true.

## NOT verified — please treat as untested

* **Any real model response.** No genuine Sanskrit / Kannada / English output from a real model was obtained, for any of
  the six directions, for grammar tools, śloka, prose or commentary. The canned replies in the tests prove plumbing only.
* **The "no key to find or enter" goal.** The one-time browser sign-in follows OpenRouter's documented PKCE flow, but it
  was only run against test doubles. It has not been run against the real OpenRouter, nor on a phone. Until it is,
  this goal is **not** confirmed. A hand-entered key under Advanced is the fallback.
* **Model choice.** Selected on licence, free variant and context only. No Sanskrit or Kannada comparison was run.
  It is not claimed to equal any proprietary model.
* **Installing and running on a phone or emulator**: real layout, font shaping of Kannada / Devanagari, keyboard,
  system Back gesture, the real return from the browser to the app, battery / background behaviour.
* **The real Android Keystore.** The tests use a stand-in that proves how the app uses it, not that every phone's
  hardware behaves.
* **The free tier in practice**: 20 requests a minute and 50 a day were read from OpenRouter's documentation; the
  app's handling of a real "limit reached" reply is tested only with a simulated one.
* **Compose / Material 3 / Gradle.** Not used or built (hosts unreachable). The UI uses framework Views.

## Why the old code was kept

The earlier build was inspected rather than trusted. Its logic was re-tested, and the faults above were found in it by
the new UI run and fixed. A rewrite to Compose and a Gradle project could not be built or tested here, so it would
have replaced code that had been exercised with code that could not be. That is why the structure stayed: pure
logic in `core/`, task state held outside screens (so rotation does not lose work), and plain Views.
