# Sanskrit (and Kannada) evaluation plan — a plan only, nothing has been run

**Status: not started. No result exists.** Until the evaluation below has been carried out and written down, the app and every
document must say that the on-device model's quality for Sanskrit and Kannada has not been tested with a Sanskrit evaluation
set. The self-test button in Settings checks wiring only, not quality. A working screen is not evidence of good translation.

## Purpose
Find out, with documented evidence, which tasks the on-device model can be trusted for, which need careful reading, and which
it should not be used for. The outcome decides what the app may claim and which tasks it should mark "experimental".

## Who and what
* **Reference answers and judging:** by a Sanskrit scholar (Dr. Diddigi Vamsi Krishna or people he names). A second judge for at
  least part of the set is strongly advised, to see how much judges disagree.
* **Test items:** texts whose reference translation or analysis is prepared **before** the model is run, from sources that may be
  used (public-domain texts, or the scholar's own). The reference set must not be given to the app as glossary or examples.
* **Directions:** all six — SA→KN, SA→EN, KN→SA, KN→EN, EN→SA, EN→KN — plus Refine (the eight tools), śloka analysis, prose
  analysis, grammatical analysis and Sanskrit commentary, each as its own list.

## Suggested composition (to be decided by the scholar)
| Kind of text | Why |
|---|---|
| Short simple sentences | Floor: does it work at all |
| Subhāṣita / nīti verses | Common, short, metre-bound |
| Gītā / Upaniṣad-style verses | Well-known: shows memorisation versus translation |
| Kāvya verses (long compounds, alaṅkāra) | Samāsa and figure handling |
| Śāstra prose with sandhi and technical terms | Terminology, precision |
| Kannada Granthika passages | Register of the Kannada output |
| English academic sentences | The EN→SA and EN→KN direction |
| Texts with numbers, names, citations | Checks that nothing is invented or dropped |
A first round of roughly 30 items per direction is a workable start; more is better. These numbers are a suggestion, not a standard.

## What is recorded for each item
Item id · direction or task · source text · reference answer · model answer · app version and model file checksum · phone model ·
CPU or GPU · time taken · warnings shown by the app · scores (below) · judge's notes. A spreadsheet is enough
(template header: `docs/sanskrit_evaluation_template.csv`).

## Scoring (0 = unusable, 1 = poor, 2 = usable after editing, 3 = good), per item
1. **Faithfulness** — meaning kept; nothing added, nothing dropped.
2. **Language correctness** — grammar, sandhi, case and number; correct Kannada or English.
3. **Register** — Granthika Kannada; Indian English with British spelling; appropriate Sanskrit style.
4. **Script and form** — correct Unicode / IAST; no stray characters; verse lines and numbering kept.
5. **Invention** — a yes/no flag: any invented fact, citation, name or number.
For analysis tasks add: **padaccheda correct**, **pratipadārtha correct**, **metre named correctly** (the app's offline scan gives a
second opinion), **commentary distinguishes the model's view from verified evidence**.

## Automatic checks (cheap, do not replace the judge)
Script of the output; numbers preserved; untranslated or unchanged text; repetition loops; answer cut off; format ignored.
The app already reports several of these. Record how often each fires.

## Decision rules (to be set by the scholar before running)
Write down, **before** the run, what mean score and what maximum invention rate would count as "usable with checking" for each
direction and task. Record the result per direction. A direction can pass while another fails.

## After the run
* Save the filled spreadsheet and a one-page summary in this folder, with the date, app version, model checksum and phone.
* Only then may the standing notice be changed — and the new wording must cite the evaluation (date, set, result), say which
  directions and tasks it covers, and keep a warning for everything outside them.
* If results are poor, options include: a larger or different model (a new on-device model needs the same licence / checksum /
  memory verification as the current one), shorter parts, better prompts, or marking tasks as unsupported. None is assumed.
* Repeat after any change of model, runtime version or prompts.
