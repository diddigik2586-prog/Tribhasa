# Evidence

Raw output of the checks quoted in `../TEST_REPORT_0.6.md`, produced on 20 October 2026 on a Linux computer
(`tools/run_tests.sh`, `tools/run_ui_tests.sh`, `tools/typecheck_litertlm.sh`).

These are **not** Gradle build logs and **not** logs from a phone. No Gradle build, APK, workflow run, model download or model run
is evidenced here, because none happened. The run of the GitHub workflow will produce the first real build log.
