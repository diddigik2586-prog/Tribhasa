# Tribhāṣā 0.6 (on-device model) — what was tested, and what was not

Made on 20 October 2026 in a cloud Linux workspace with no Android emulator, no phone, and a network allowlist that blocked
Maven, Google's Maven, Gradle's plugin portal, Hugging Face and openrouter.ai.

> A compiling project is not proof of working AI. A working screen is not proof of successful inference.
> **No Gradle build, no APK, no GitHub Actions run, no model download and no on-device inference happened in this work.**
> Nothing below shows that the model translates Sanskrit or Kannada well.

## Run here, and passed

Raw output of the three runs below is in `evidence/`.

| What | Command | Result | What it proves | What it does not prove |
|---|---|---|---|---|
| Core logic on the JVM, compiled for JDK 17 (`-Xjdk-release=17`) | `bash tools/run_tests.sh` | **573 checks, 0 failed** (re-run after the last code change) | The app's own logic behaves as written: scripts and IAST, metre, prompts, reply parsing, retries, glossary, history, sign-in protocol, **and the on-device parts: model facts, download (resume / checksum / retry / cancel / disk / mobile data), runtime (load once, one task at a time, cancel, stall, out-of-memory, GPU fall-back note), provider (fit check, markers, truncation, never another model), standing quality notices, and the six directions end to end in on-phone mode with a network tripwire** | That the real library or the real model behaves like the stand-in engine |
| The app's real screens on the JVM against fake Android classes (`MainActivity` and every screen, driven by taps and typing) | `bash tools/run_ui_tests.sh` | **498 checks, 0 failed**; 5 consecutive runs after the last fix | Screens, navigation, the first-run question, the Settings card, download progress / pause / resume / rotation, failures with Retry, Check / Delete, gating when the model is missing, the source selector, all six directions through the real Translate screen on the phone-model path with the phone offline, Refine / Analyse on the phone, cancel, memory trim, GPU switch | Real layout, fonts, the real foreground service and notification, the real model engine, a real phone |
| Whole app compiled against the **real LiteRT-LM v0.18.0 sources** and `android-34.jar` with Kotlin 2.4.21 | `bash tools/typecheck_litertlm.sh` | **TYPE-CHECK OK: 206 classes** (after the r2 changes) | `LiteRtEngineFactory` uses the library's API correctly as published | That it runs (no native code, no model) and that Android's Gradle build works |
| Model-source check script, against a local mock server (match; wrong size; wrong checksum; no checksum header; 404) | `tools/check_model_source.py` | exit codes 0 / 1 / 1 / 2 / 1 as designed | The script's parsing and verdicts | What Hugging Face really sends — the real server was not reachable |
| Workflow file (r2) | actionlint 1.7.7 with shellcheck 0.10.0 | **no findings** | The file is valid for GitHub's schema and its shell steps have no common mistakes | That GitHub accepts and runs it, or that the action versions behave as documented |
| Workflow shell logic (r2) | the "Find the project" step run on toy projects; `tools/ci/build_apk.sh` and `run_unit_tests.sh` run with a stand-in `gradle` | folders → used directly; one zip → unpacked; two zips → the newest name; wrong zip and no project → clear error; failing build → one error annotation with the compiler lines, exit 1; successful stand-in build → size and SHA-256 reported; "success but no APK" → error | The project-finding and failure-reporting logic | A real Gradle build |
| Gradle (8.14.3 available here) | `gradle --offline projects` | Parsed `settings.gradle.kts`, then stopped: the Android plugin could not be fetched (no network). **No build happened.** | Nothing about the build | — |

Network behaviour in on-phone mode: with a `ProxySelector` tripwire installed, six translations, refine and analyse through
the real screens attempted **no** network connection, with online keys saved and with the phone set offline.

## Defects found by these tests and fixed

1. A progress line posted by the model's own thread could arrive after "Cancelled" and overwrite it (`App.launch`). It is now ignored once the task has stopped.
2. The history label read "… (not IndicTrans2) (not IndicTrans2)" when the translator's own description already said so (`TranslateScreen`).
3. Straight quotes wrapped around a model's plain-text answer were not removed (`PlainText.clean`).
4. Cancel hooks could run twice (`CancelToken`).
5. The Kannada polish step was too large for the phone model's working memory; it is now sized for the phone.
6. A GPU → CPU fall-back was not reported to the user; it now is, on every task while it applies.
7. (r2, found by reading the code, not by a failing test.) `DownloadService` could be stopped before it had called `startForeground`, which makes Android end the app ("did not call startForeground"); stopping is now delayed and re-checked, and the service stops itself if no download is running. A Pause tap could throw if no download was running; it is now guarded. Google's library was created while the app started; it is now created on first model use.
Findings from earlier versions are in `history/TEST_REPORT_0.5.md`.

## NOT done — please treat as untested

* **A Gradle / AGP build and an APK.** The build files were rewritten (Kotlin 2.4.21, AGP 8.13.2, Gradle 8.13, no Compose,
  `litertlm-android:0.18.0`, arm64-v8a, compileSdk 36, targetSdk 34, minSdk 26) but have never been run. The first run of
  the GitHub workflow will show whether they are right. Expect that it may need fixes.
* **The GitHub Actions run.** No repository was reachable from here (no GitHub account was linked to this workspace). The workflow has therefore never been executed by GitHub.
* **A real download** of the 2.59 GB file, its checksum on a real copy, and the foreground service / notification on a phone.
* **Loading the model and any real answer**, on CPU or GPU, and with it any real speed, memory or battery figure.
* **Quality**: no Sanskrit or Kannada evaluation of any kind (see `SANSKRIT_EVALUATION_PLAN.md`).
* `LiteRtEngineFactory`, `DownloadService` and `DeviceInfo` run only on a phone; the tests use stand-ins with the same names.
* The Kannada / Devanagari rendering on a real screen; Android 13+ notification permission behaviour; low-memory kills.

## Phone test sheet (first real test)

1. Run the workflow, download the APK artifact, install it. Note any build or install error exactly.
2. Open the app. Say **Download now** on Wi-Fi. Watch the notification; try **Pause** and **Resume**; lock the screen.
3. When Settings says "✓ On this phone and checked", tap **Check the file** and note the result.
4. Switch on aeroplane mode. Translate one short text in each of the six directions. For each, note: did it load (and how
   long), was the answer in the right language and script, was it usable, what warnings were shown.
5. Try Refine → Correct Grammar, and Analyse → Śloka analysis on one verse. Note time and whether the result is complete.
6. Note the phone model, its memory, Android version, and whether the app was closed by Android at any point.
7. If anything fails, Settings → Last error report → Copy, and send it.
