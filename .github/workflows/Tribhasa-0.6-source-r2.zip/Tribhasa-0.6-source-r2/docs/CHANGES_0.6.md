# Changes in 0.6 — on-device AI (versionCode 6, versionName 0.6.0-dev)

Nothing was removed from the app's features. Compared with the version before (0.5, the signed APK delivered earlier), the
app now runs its AI on the phone by default; the online services stay as an optional, clearly labelled choice.

## Implementation steps (in order)
1. Inspected the project, Gradle files, SDK settings and workflow (`compileSdk 36`, JDK 17, Gradle 8.13, AGP 8.13.2; the
   original used Compose and Kotlin 2.2.20).
2. Read the LiteRT-LM Kotlin API from the library's own v0.18.0 sources; checked the candidate model's licence, file, size,
   checksum and memory notes on the publisher's pages (`ON_DEVICE_MODEL.md`).
3. Added the model description and source selector (`LocalModels.kt`) and the download manager (`ModelDownloader.kt`):
   resumable, Wi-Fi-only by default, free-space check, SHA-256 verification, retry, cancel, delete.
4. Added the runtime wrapper (`LocalModelRuntime.kt`): load once, one task at a time, cancel, stall detection, out-of-memory
   handling, GPU option with CPU fall-back reported to the user. Only `LiteRtEngineFactory.kt` touches Google's library.
5. Added the provider (`LocalLlm.kt`), local quality notices (`LocalChecks.kt`), and phone-sized requests for translation,
   Kannada polish, refine and analysis.
6. Made on-phone the default source; in that mode the online services are never built, so nothing can be sent and nothing
   can silently replace the phone model. Every failure is shown with its reason.
7. Added the screens: first-run question, "AI on this phone" card (download / pause / resume / retry / check / delete, memory
   advice, Wi-Fi-only and GPU switches, source selector), gating messages in Translate / Refine / Analyse, About text.
8. Added a foreground service with a notification and Pause so a download survives the screen turning off.
9. Rewrote the build: Kotlin 2.4.21 (needed by the library), no Compose, one dependency, arm64-v8a, new manifest entries.
10. Extended the workflow: model-source check, build, APK description, upload, unit tests, test-report upload. Later (r2) it was made
    to work from a project uploaded as one .zip, to explain a failed build on the run page, and to offer an optional DRAFT release;
    build and test logic moved into `tools/ci/build_apk.sh` and `tools/ci/run_unit_tests.sh`.
11. Wrote tests: on-device groups for the core (JVM), a stand-in engine, a local HTTPS test server, a network tripwire, new
    headless-UI scenarios, a type-check against the real library sources.
12. Replaced stale design documents (they described Compose, a FastAPI backend, Sarvam and "no offline AI").

## App files compared with the 0.5 delivery (`android/app/src/main/…`)

**New (10)**
| File | Purpose |
|---|---|
| `kotlin/org/tribhasa/app/core/LocalModels.kt` | The model (address, size, SHA-256, licence), `AiSource`, memory advice, space needed |
| `…/core/ModelDownloader.kt` | Resumable HTTPS download, checksum, `LocalModelFiles` state, verified mark |
| `…/core/LocalModelRuntime.kt` | Load / run / cancel / stall / out-of-memory / GPU fall-back around a native engine interface |
| `…/core/LocalLlm.kt` | On-device `LlmProvider`, token estimate, plain-text cleaning |
| `…/core/LocalChecks.kt` | Standing "done on this phone / low confidence" notices; loop and unchanged-text checks |
| `…/local/LiteRtEngineFactory.kt` | The adapter to Google's LiteRT-LM (the only file that uses the library) |
| `…/local/DeviceInfo.kt` | Phone memory, free space, metered network, notification permission |
| `…/local/DownloadService.kt` | Foreground service + notification with Pause (r2: stopping is delayed 1.5 s and re-checked, so it can never be stopped before it has gone to the foreground; a Pause tap cannot throw) |
| `…/local/LocalModelController.kt` | App-level download state, verify, delete, memory release (r2: the adapter to Google's library is created only when a model is first loaded, so the library is not touched while the app starts) |
| `res/drawable/ic_stat_download.xml` | Notification icon |

**Modified (16)**
| File | Change |
|---|---|
| `AndroidManifest.xml` | `package=` removed (namespace is in Gradle); foreground-service and notification permissions; the service; optional GPU libraries |
| `kotlin/org/tribhasa/app/App.kt` | Local runtime started; blocking rules and messages for each source; progress lines ignored after a task stops; build label 0.6 |
| `…/MainActivity.kt` | First-run "Download the AI model" question; releases memory on `onTrimMemory` |
| `…/Store.kt` | New settings: AI source, GPU choice, Wi-Fi-only |
| `…/core/Engines.kt` | `Credentials.aiSource`; `Trace` on-device fields; configurable part size / answer length for the model translator |
| `…/core/Http.kt` | `FailKind.LOCAL`; `CancelToken.onCancel`, hooks run once |
| `…/core/Llm.kt` | Reply notes; progress reporting; on-device provider marked in the trace |
| `…/core/Report.kt` | Standing notices for on-device answers |
| `…/core/Scholar.kt` | Progress reporting; on-device notices on refine / analysis / commentary; no duplicate notices |
| `…/core/TranslationService.kt` | Phone-sized parts and polish, flagged plain-text acceptance, on-device checks, phone-only translator in on-phone mode |
| `…/ui/AboutScreen.kt` | Text rewritten for on-device use (model, licence, honesty about quality) |
| `…/ui/AnalyseScreen.kt` · `RefineScreen.kt` | Gating and an "experimental on the phone" notice |
| `…/ui/CompareScreen.kt` | Says plainly that comparing models needs the online models |
| `…/ui/SettingsScreen.kt` | "AI on this phone" card, source selector, updated summary and self-test |
| `…/ui/TranslateScreen.kt` | Gating and messages; fixed doubled "(not IndicTrans2)" in the history label |

**Unchanged (31):** the other 13 core files (comparison, glossary, history, languages, models list, sign-in, offline metre,
policy, prompts, prosody, segmenter, spelling, transliteration), the other 5 screens/helpers (`Common`, `GlossaryScreen`,
`HistoryScreen`, `ResultViews`, `Ui`), and 13 resource files (icons, colours, strings, styles, night styles).

## Build, manifest and workflow files compared with the original upload
| File | Original | Now |
|---|---|---|
| `android/settings.gradle.kts` | root name `Tribhāṣā` | root name `Tribhasa` (ASCII); repositories unchanged |
| `android/build.gradle.kts` | Kotlin 2.2.20 + Compose plugin | Kotlin 2.4.21, no Compose plugin |
| `android/app/build.gradle.kts` | Compose, AndroidX, DataStore, coroutines, `targetSdk 36`, `kotlinOptions` | no Compose / AndroidX; `litertlm-android:0.18.0`; `targetSdk 34`; `compilerOptions`; arm64-v8a; versionCode 6; JUnit + org.json for unit tests; test logging |
| `android/app/proguard-rules.pro` | comment only | keep rules for the library (inactive while minify is off) |
| `android/gradle.properties` | — | unchanged |
| `android/app/src/main/AndroidManifest.xml` | INTERNET, ACCESS_NETWORK_STATE | + FOREGROUND_SERVICE, FOREGROUND_SERVICE_DATA_SYNC, POST_NOTIFICATIONS; service; GPU libraries (optional) |
| `.github/workflows/build-testing-apk.yml` | build + unit tests in one step | finds the project (folders, or the most recently uploaded .zip, which it unpacks); model-source check; build (reason shown on the run page if it fails); describe + upload APK; then tests; test-report upload; optional DRAFT release. Triggers: push and manual. No secrets, `contents: read` (write only in the draft-release job). |
| `tools/ci/build_apk.sh`, `tools/ci/run_unit_tests.sh` | — | the build and test steps of the workflow, kept as scripts so they can be tried with a stand-in Gradle |

`targetSdk 34` is deliberate: from Android 15 (target 35) every app is forced edge-to-edge, which this view-based UI was
not designed for. Raising it is a separate UI task. Debug builds use the id `org.tribhasa.app.dev`, so they never replace the
earlier signed APK (`org.tribhasa.app`).

## Tests and tools
New: `tools/ci/*.sh`; `android/app/src/test/kotlin/LocalTests.kt`, `GradleCoreTest.kt`; `tools/ui-harness/LocalUiTests.kt`;
`tools/ui-harness/fakes/…` (three stand-ins); `tools/typecheck_litertlm.sh`; `tools/check_model_source.py`.
Changed: `Support.kt` (test server for the model file, stand-in engine, network tripwire, JDK's own keytool), `CoreTests.kt`
(isolated groups, one entry point), `tools/run_tests.sh`, `tools/run_ui_tests.sh`, `UiHarness.kt`, `UiTests.kt`, the fake
Android classes.

## Files of the original skeleton that this tree replaces (delete them if they are still in your repository)
`android/app/src/main/java/org/tribhasa/app/{MainActivity.kt, ProcessApi.kt, Models.kt, TribhāṣāViewModel.kt}` (Compose
sources; they would clash with the current `MainActivity`) and `backend/` (FastAPI + Sarvam proxy: it needed a server, a paid
API key and hosting; the app never used it). Neither is part of this tree. `android/app/src/main/res/values/styles.xml` is
replaced by the one here.

## Cost
No paid service, key, credit, hosting or sign-in is required. The only network use is the one-time model download from
Hugging Face (free) and, if the user chooses Online, OpenRouter's free models.
