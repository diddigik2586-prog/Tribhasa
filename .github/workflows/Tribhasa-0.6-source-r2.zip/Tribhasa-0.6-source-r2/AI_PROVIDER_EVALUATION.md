# Tribhāṣā — AI Provider Evaluation

> **Status update, 20 October 2026.** This file is a **historical record** from 18 October. Sarvam is no longer part of the project, and no
> provider is needed for the default mode: the AI runs on the phone. The on-device model's source, licence, size and checks are in
> `docs/ON_DEVICE_MODEL.md`. Nothing below describes the current app, except that the optional online engines still exist.
> The IndicTrans2 note at the end remains accurate as a candidate (not integrated on the phone).

## Original evaluation (18 October 2026)

## Sarvam Translate v1
**Official docs checked:**
- Model/language support: https://docs.sarvam.ai/api/getting-started/models and https://docs.sarvam.ai/api/getting-started/models/sarvam-translate
- Text translation endpoint: https://docs.sarvam.ai/api-reference/text/translate-text
- Pricing: https://docs.sarvam.ai/api/getting-started/pricing and https://www.sarvam.ai/api-pricing
- Authentication: https://docs.sarvam.ai/api-reference/authentication

### Verified from current documentation
- Sarvam Translate v1 lists 23 languages, including Sanskrit (`sa-IN`), Kannada (`kn-IN`) and English (`en-IN`), with bidirectional translation support.
- Short-text endpoint is `POST https://api.sarvam.ai/translate`.
- Authentication uses the server-side `api-subscription-key` header.
- Input limit is up to 2,000 characters for Sarvam Translate v1.
- API use is paid per usage. Official pricing page describes a ₹100 signup credit, not unlimited free usage. Pricing pages can change and must be rechecked before running tests or shipping.

### Suitability assessment
- **Promising candidate for plain translation** in all six directions; not yet tested against Tribhāṣā's scholarly test set.
- It is not, by itself, a validated solution for grammar correction, complex verse/prose parsing, exact morphological analyses, Sanskrit-to-Sanskrit commentary or task-specific QC. Do not infer advanced mode suitability from translation language coverage.
- No API key was supplied and no API requests were made. The adapter is disabled by default.
- The code rejects requests over 2,000 characters; it does not truncate or silently send partial text.

### Cost and approval safeguards
- No costs were incurred in this checkpoint.
- Before enabling, confirm current price, remaining credits, quota, retention and commercial-use terms on the account dashboard and approve the test explicitly.
- Unlimited app test usage is separate from external provider quotas/costs. No quota evasion or account rotation is implemented.

### Provider failover status
- Routing interface supports eligibility, retries and trying another eligible provider.
- Only Sarvam Translate is implemented as a real provider adapter. Therefore real-provider failover is **not yet operational**; router fallover tests use simulated adapters solely to verify logic.
- A second real provider must be evaluated, authorised, configured, and tested before being listed as an actual fallback.

## Open-source candidate: AI4Bharat IndicTrans2
Official repository inspected: https://github.com/AI4Bharat/IndicTrans2 (18 October 2026).

- The repository lists Sanskrit (`san_Deva`), Kannada (`kan_Knda`) and English (`eng_Latn`) in its supported language set, and publishes En–Indic, Indic–En and Indic–Indic model variants. This makes it a candidate for all six app translation directions, subject to real pair-level tests.
- The repository and released model checkpoints state the MIT licence. Its datasets do not all share one licence: the repository lists both CC0 and CC BY 4.0 among data artefacts. Model/checkpoint permission does not automatically relicense datasets or other components.
- The project supplies inference/training code and separately downloaded model checkpoints; it is not currently integrated into Tribhāṣā and is not an Android SDK. We have not downloaded the weights, run inference, measured CPU/RAM/GPU needs, checked Android feasibility, or evaluated classical Sanskrit/kāvya, terminology and IAST preservation.
- Preferred next feasibility path: test the model in a separately authorised development environment or self-managed backend before deciding whether it is suitable. Do not bundle model weights into the APK or represent scholarly modes as supported until tested.
- Official references: repository/architecture/language list and model variants at https://github.com/AI4Bharat/IndicTrans2; licence file at https://github.com/AI4Bharat/IndicTrans2/blob/main/LICENSE.
