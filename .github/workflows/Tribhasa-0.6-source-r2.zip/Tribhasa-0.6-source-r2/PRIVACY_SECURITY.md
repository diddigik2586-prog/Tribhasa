# Tribhāṣā — Privacy and Security Snapshot (0.6)

## What stays on the phone
* In the default mode (**on this phone**) the text you translate, refine or analyse is processed by the model on the phone and is
  not sent anywhere. In tests with the network watched, no connection was attempted in this mode (stand-in engine; the real engine
  was not run).
* History, glossary, settings and the model file are in the app's private storage. Backup is switched off (`allowBackup=false`), so
  the 2.6 GB model and the history are not copied to cloud backup. Uninstalling removes them.
* Quality reports and the crash report stay on the phone; the crash report is shown, and copied only if the user taps Copy.

## What leaves the phone
* **The model download:** a request to Hugging Face (the model's publisher) for the model file. Hugging Face can see the phone's
  IP address and the request, as with any download. No text is involved.
* **Online mode (optional, off by default):** the text is sent to OpenRouter and on to whoever hosts the chosen model, and the optional
  IndicTrans2 services if set up. The app asks before switching to it, and says so on the Settings card and in the reports.

## Keys and secrets
* No secret is in the APK, the source, the workflow or the repository. The workflow uses no secrets.
* The default mode needs no key. The optional OpenRouter access is obtained by a one-time browser sign-in; it is kept in private
  storage, encrypted with an Android Keystore key where the phone allows it, and the app says when it could not.
* The debug APK is signed with Android's standard debug key, generated on the build machine. No release keystore is involved, and the
  earlier signed APK is not touched.

## Permissions
INTERNET and ACCESS_NETWORK_STATE (download, optional online mode, Wi-Fi-only rule) · FOREGROUND_SERVICE and
FOREGROUND_SERVICE_DATA_SYNC (keep a download alive with the screen off) · POST_NOTIFICATIONS (download progress; asked once).
No storage, contacts, location, camera or microphone permission.

## Integrity of the model
The address is pinned to a repository revision; the file must match the published SHA-256 or it is deleted; a `.verified` mark is
invalidated if the file changes. This protects against a corrupt or altered download. It does not make the model's answers correct.

## Not audited / not done
No independent security review. No privacy policy has been published. The real foreground service, Keystore behaviour and file
handling have not been exercised on a phone.

## Never do
* Never place a key or keystore in app source, resources, BuildConfig, Git, an APK, a zip or a log.
* Never switch to an online or paid service without telling the user and getting their choice; never fall back silently.
* Never claim the on-device model's Sanskrit or Kannada quality is verified before a documented evaluation exists.
* Never add the attribution to translations, copied text or scholarly output.
