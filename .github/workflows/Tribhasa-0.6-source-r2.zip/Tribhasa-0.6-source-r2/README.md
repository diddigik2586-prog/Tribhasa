# Tribhāṣā — Sanskrit · Kannada · English, on your phone

Tribhāṣā translates between Sanskrit, Kannada and English (all six directions), refines text, and analyses Sanskrit
(śloka, prose, grammar, Sanskrit-to-Sanskrit commentary). The interface is in Sanskrit, Kannada and English.

**The AI now runs on the phone itself.** The app downloads one open model once (Gemma 4 E2B, Apache-2.0, 2.59 GB, free,
no account, no key) and then works without internet. Nothing needs an API key, a paid service or hosting.

> **Honest status (20 October 2026).** The code is complete and tested on a computer with stand-ins for the phone and the
> model. It has **not** been built with Gradle here, **not** installed on a phone, and the model has **not** been run.
> The quality of its Sanskrit and Kannada has **not** been tested with a Sanskrit evaluation set, and the app says so on
> every result. Details: [`docs/TEST_REPORT_0.6.md`](docs/TEST_REPORT_0.6.md).

## How the AI works

| | On this phone (default) | Online (optional) |
|---|---|---|
| Where the text goes | Nowhere. It stays on the phone. | Over the internet to OpenRouter and the company hosting the model |
| Needs | The one-time model download | The one-time OpenRouter sign-in |
| Cost | Free | Free models only, unless you allow paid ones |

Settings → **Where the AI runs** switches between them. The app **never switches by itself**: if the chosen source fails
you are told, and you decide. In "on this phone" mode the online services are not even created, so nothing can be sent.

## First use

1. Install the APK and open it. The app offers to download the model (**Download now** / **Later**).
2. Download it on Wi-Fi (about 2.59 GB). A notification shows progress and has a **Pause** button. The download can be
   paused, can resume after an interruption, and is checked against the publisher's checksum when it finishes.
3. After that, translating, refining and analysing work in aeroplane mode.
4. Settings → **AI on this phone** shows the model, licence, size and memory advice, and has **Check the file** and
   **Delete from this phone**.

A phone with about 5 GB of memory or more is the app's own rule of thumb (the model's publisher states no minimum). On a
smaller phone the app warns you before downloading, and may fail to load the model.

## What is kept from earlier versions

Six translation directions · polished Granthika Kannada · Indian English with British spelling · accurate IAST/Unicode ·
eight refinement tools · śloka analysis with an offline metre check · prose analysis · grammatical analysis ·
Sanskrit-to-Sanskrit commentary · personal glossary · history with search · copy and clear · honest quality-control report
for every task · optional online engines (IndicTrans2 services, OpenRouter models, model comparison). No Vedic/svara
features, no PDF/DOCX/TXT export, no mandatory Google sign-in, no billing or limits in this testing build.
The attribution "by Dr. Diddigi Vamsi Krishna" appears only on the main-screen footer, the splash and About, never in
translations or copied text.

## Get the testing APK (GitHub Actions, free, from a phone)

The workflow `.github/workflows/build-testing-apk.yml` builds a **debug** APK. It uses no secrets and does not touch the
earlier signed APK; the debug build has a different application id (`org.tribhasa.app.dev`), so both can be installed.
It starts by itself when files are pushed to the repository, or by hand (Actions → Build Tribhāṣā Testing APK → Run workflow).

**Phone-only route** (step-by-step in Kannada: [`docs/KANNADA_PHONE_GUIDE.md`](docs/KANNADA_PHONE_GUIDE.md)):
1. Make a free GitHub account and a new **Public** repository (public repositories have no build-minute limit).
2. In the repository: Add file → Upload files → choose the project **.zip** as it is (GitHub does not unpack it; the workflow does) → Commit.
3. Add file → Create new file → name it `.github/workflows/build-testing-apk.yml` (typing `/` makes the folders), paste the workflow text, Commit directly to `main`.
4. Open **Actions**. When the run turns green, open it, and under **Artifacts** download **Tribhasa-testing-debug-apk**; unzip it and install the APK.
5. If the run is red, the reason is written at the top of the run page (the red "Build failed - the reason" box). Send it; upload the fixed zip the same way (if several zips are in the repository, the most recently uploaded one is used).

If the repository holds the project as ordinary folders (`android/`, `tools/`, …) the workflow uses them directly instead of a zip.
Do not assume the APK exists until a run is green and the artifact is listed.

The build runs `tools/check_model_source.py`, which asks the model publisher's server (headers only, nothing is
downloaded) whether the address, size and checksum written in the app are still correct.

## Developer notes

* `android/` — the app (plain Android views, Kotlin; the only library is Google's LiteRT-LM 0.18.0).
  `core/` is pure Kotlin and tested on a computer; `local/` is the on-device model code; `ui/` the screens.
* `bash tools/run_tests.sh` — core checks on the JVM (573 checks). Also run by Gradle as `:app:testDebugUnitTest`.
* `bash tools/run_ui_tests.sh` — the real screens on the JVM against fake Android classes (498 checks).
* `bash tools/typecheck_litertlm.sh` — compiles the whole app against the real LiteRT-LM v0.18.0 sources.
* `tools/check_model_source.py` — model address / size / checksum against the publisher.
* Docs: [`docs/ON_DEVICE_MODEL.md`](docs/ON_DEVICE_MODEL.md) · [`docs/TEST_REPORT_0.6.md`](docs/TEST_REPORT_0.6.md) ·
  [`docs/SANSKRIT_EVALUATION_PLAN.md`](docs/SANSKRIT_EVALUATION_PLAN.md) · [`docs/CHANGES_0.6.md`](docs/CHANGES_0.6.md) ·
  [`ARCHITECTURE.md`](ARCHITECTURE.md) · [`PRIVACY_SECURITY.md`](PRIVACY_SECURITY.md) · [`DECISIONS.md`](DECISIONS.md).

## ಕನ್ನಡದಲ್ಲಿ ಸಾರಾಂಶ

- ಈ ಆ್ಯಪ್ ಸಂಸ್ಕೃತ, ಕನ್ನಡ ಮತ್ತು ಇಂಗ್ಲಿಷ್ ನಡುವೆ ಆರು ದಿಕ್ಕಿನಲ್ಲಿ ಅನುವಾದಿಸುತ್ತದೆ. AI ಮಾದರಿ (Gemma 4 E2B) ನಿಮ್ಮ ಫೋನ್‌ನಲ್ಲೇ ಓಡುತ್ತದೆ.
- ಮೊದಲ ಬಾರಿ ಒಮ್ಮೆ ಮಾತ್ರ ಸುಮಾರು 2.59 GB ಡೌನ್‌ಲೋಡ್ ಮಾಡಬೇಕು (ಉಚಿತ; ಖಾತೆ ಅಥವಾ ಕೀ ಬೇಡ). ನಂತರ ಇಂಟರ್ನೆಟ್ ಇಲ್ಲದೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
- ಸಂಸ್ಕೃತ ಮತ್ತು ಕನ್ನಡ ಅನುವಾದದ ಗುಣಮಟ್ಟವನ್ನು ಇನ್ನೂ ಪರೀಕ್ಷಿಸಿಲ್ಲ. ಪ್ರತಿ ಫಲಿತಾಂಶವನ್ನು ನೀವೇ ಪರಿಶೀಲಿಸಿ.
- ಈ ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ ನಿಜವಾದ Gradle build ಮಾಡಲಾಗಿಲ್ಲ; APK ಅನ್ನು GitHub Actions ಮೂಲಕ ಮಾಡಬೇಕು. ಅದು ಯಶಸ್ವಿಯಾಗುವವರೆಗೆ APK ಸಿದ್ಧ ಎಂದು ಹೇಳಲಾಗದು.
