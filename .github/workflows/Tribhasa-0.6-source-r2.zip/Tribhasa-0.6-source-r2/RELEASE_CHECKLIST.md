# Tribhāṣā — Release Checklist

## Testing build (current phase: free, no limits, no billing)
- [ ] GitHub workflow run is green; APK artifact downloaded; checksum from the run summary recorded.
- [ ] APK installs and launches on a real phone; package `org.tribhasa.app.dev`, version 0.6.0-dev; the signed 0.5 APK is not overwritten.
- [ ] Model-source check step is green (address, size, checksum match the publisher's server).
- [ ] Model downloads on Wi-Fi; pause / resume / interruption / retry work; notification appears; checksum verified on the phone.
- [ ] "Check the file" and "Delete from this phone" work; deleting while a task runs is refused.
- [ ] Aeroplane mode: all six directions, Refine, Analyse work; record time, memory and any app kill per phone.
- [ ] Low-memory phone: the warning appears; failure messages are understandable.
- [ ] GPU switch: works or falls back to CPU with the message; record the phone.
- [ ] Attribution "by Dr. Diddigi Vamsi Krishna" appears only on the splash, main footer and About; never in copied text.
- [ ] Unicode / IAST / Kannada render correctly on the real screen; long text; rotation.
- [ ] Sanskrit evaluation run and written down **before** any text says quality is acceptable.
- [ ] Scan the source zip and the APK for secrets before sharing.

## Production (disabled until the owner declares "Final")
- [ ] Owner approves pricing, terms and the release plan explicitly.
- [ ] Google sign-in, trial accounting (10 free translations per eligible account) and Play Billing: design, build and test — none exists now.
- [ ] Raise `targetSdk` to the current requirement and redo the UI for edge-to-edge.
- [ ] Release signing set up securely; the existing signing key never goes into a repository, zip or log.
- [ ] Privacy policy and data-deletion description published; model licence notices shown (Apache-2.0 for the model and the runtime).
- [ ] Accessibility, screen sizes, large text, keyboard, low-storage and low-memory checks.
- [ ] Production AAB tested in Play internal testing; published only after explicit approval.
