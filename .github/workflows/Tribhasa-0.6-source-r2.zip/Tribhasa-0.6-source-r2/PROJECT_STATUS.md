# Tribhāṣā — Project Status

**Checkpoint:** 20 October 2026 (Asia/Kolkata) · version 0.6.0-dev (versionCode 6) · **on-device AI**

## Implemented (in source, tested with stand-ins on a computer)
- AI runs on the phone: LiteRT-LM 0.18.0 + Gemma 4 E2B (Apache-2.0, 2.59 GB), downloaded once; resumable, Wi-Fi-only by default, SHA-256 checked, retry / pause / check / delete; foreground notification; offline afterwards.
- Source selector: On this phone (default) or Online (optional). No silent fallback; in on-phone mode no online service is built.
- Six directions, Granthika Kannada polish, refinement (eight tools), śloka / prose / grammatical analysis, commentary, offline metre check, glossary, history, copy / clear.
- Honest reports: standing "Low confidence by default … not tested with a Sanskrit evaluation set", loop / unchanged / cut-off checks, plain failure messages.
- Build files rewritten for Kotlin 2.4.21 / AGP 8.13.2 / Gradle 8.13; workflow extended.

## Verified (on a computer only)
- Core checks: **573 passed, 0 failed** (`tools/run_tests.sh`, JDK 17 target).
- Headless screens: **498 passed, 0 failed** (`tools/run_ui_tests.sh`), five consecutive runs.
- Whole app compiles against the real LiteRT-LM v0.18.0 sources with Kotlin 2.4.21 (205 classes).
- Model facts (licence, file, size, checksum) read from the publisher's pages; the model-source check script behaves correctly against a mock server.

## NOT done
- **No Gradle / AGP build; no APK from this version; the GitHub workflow has not run.**
- No install or test on a phone or emulator; no real model download; the real engine, the foreground service and the notification have never run.
- **No Sanskrit or Kannada quality evaluation of any kind.** Plan only: `docs/SANSKRIT_EVALUATION_PLAN.md`.
- Google sign-in, trial counting and Play Billing do not exist (testing phase, by instruction).

## Risks to expect on the first real build
Plugin / library version resolution; AGP 8.13.2 with Kotlin 2.4.21 (a version combination not run before); the model file format versus library 0.18.0;
phone memory (the publisher gives no minimum); speed of a 2B-parameter-class model on CPU.

## Next action
Put the project on GitHub → run **Build Tribhāṣā Testing APK** → read the log → fix → install → phone test sheet → Sanskrit evaluation.
The earlier signed 0.5 APK is untouched.
