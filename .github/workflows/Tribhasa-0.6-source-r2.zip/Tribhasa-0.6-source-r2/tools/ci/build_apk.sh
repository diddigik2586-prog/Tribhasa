#!/usr/bin/env bash
# Used by the GitHub workflow. Builds the debug APK; if the build fails, copies the reason into the run's annotations and
# summary (so it can be read without opening the full log) and fails; if it succeeds, describes the APK.
# Usage: tools/ci/build_apk.sh <project root>     (the folder that contains android/)
set -uo pipefail
root="${1:-.}"
tmp="${RUNNER_TEMP:-/tmp}"
summary="${GITHUB_STEP_SUMMARY:-/dev/null}"
log="$tmp/build.log"

( cd "$root/android" && gradle --no-daemon --stacktrace :app:assembleDebug ) 2>&1 | tee "$log"
status="${PIPESTATUS[0]}"

if [ "$status" -ne 0 ]; then
  {
    echo "== Gradle's own explanation =="
    awk '/^\* What went wrong:/{p=1} /^\* Try:/{p=0} p' "$log" | head -n 30
    echo "== Compiler and dependency messages =="
    grep -E "^e: |: error:|Could not resolve|Could not find|Could not get|Unresolved reference|Execution failed for task|was not found in any of|Unsupported class|Incompatible|incompatible" "$log" | sort -u | head -n 40
    echo "== Last lines of the log =="
    tail -n 25 "$log"
  } > "$tmp/explain.txt"
  { echo '### Build failed'; echo '```'; cat "$tmp/explain.txt"; echo '```'; } >> "$summary"
  msg=$(head -c 6000 "$tmp/explain.txt" | sed ':a;N;$!ba;s/%/%25/g;s/\r/%0D/g;s/\n/%0A/g')
  echo "::error title=Build failed - the reason::$msg"
  exit "$status"
fi

apk=$(find "$root/android/app/build/outputs/apk/debug" -maxdepth 1 -name '*.apk' | head -n 1)
if [ -z "$apk" ]; then
  echo "::error title=No APK::Gradle reported success but no .apk file was found in android/app/build/outputs/apk/debug."
  exit 1
fi
echo "APK: $apk"
ls -l "$apk"
size=$(stat -c %s "$apk"); sum=$(sha256sum "$apk" | cut -d' ' -f1)
aapt2="${ANDROID_HOME:-/nonexistent}/build-tools/36.0.0/aapt2"
if [ -x "$aapt2" ]; then "$aapt2" dump badging "$apk" | grep -E "^(package|sdkVersion|targetSdkVersion|uses-permission|native-code)" || true; fi
echo "Native libraries inside the APK:"
unzip -l "$apk" | grep -E "lib/.*\.so" | head -n 30 || true
{
  echo "### Testing APK was built"
  echo '```'
  echo "file:   $(basename "$apk")"
  echo "size:   $size bytes"
  echo "sha256: $sum"
  echo '```'
} >> "$summary"
echo "::notice title=APK built::$(basename "$apk"), $size bytes, sha256 $sum"
