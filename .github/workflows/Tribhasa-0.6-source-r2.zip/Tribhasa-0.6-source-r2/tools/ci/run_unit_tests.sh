#!/usr/bin/env bash
# Used by the GitHub workflow. Runs the unit tests (stand-ins for the network and the model engine; not the real model).
# A failure is reported as a warning with the failing checks; the APK is not affected.
# Usage: tools/ci/run_unit_tests.sh <project root>
set -uo pipefail
root="${1:-.}"
tmp="${RUNNER_TEMP:-/tmp}"
log="$tmp/tests.log"
( cd "$root/android" && gradle --no-daemon :app:testDebugUnitTest ) 2>&1 | tee "$log"
status="${PIPESTATUS[0]}"
if [ "$status" -ne 0 ]; then
  msg=$(grep -E "^ +FAIL |^PASSED:|^Failures:|^ - |AssertionError|FAILED|What went wrong|e: " "$log" | head -n 40 | head -c 5000 | sed ':a;N;$!ba;s/%/%25/g;s/\r/%0D/g;s/\n/%0A/g')
  echo "::warning title=Unit tests did not pass (the APK is still available)::$msg"
fi
exit "$status"
