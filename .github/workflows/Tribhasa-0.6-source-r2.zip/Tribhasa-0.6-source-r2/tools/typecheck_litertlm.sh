#!/bin/bash
# Type-checks the WHOLE app, including the one file that uses the LiteRT-LM library, with the same Kotlin compiler
# version the Gradle build uses (2.4.21), against android-34.jar and the library's REAL v0.18.0 Kotlin sources
# (compiled here on the JVM; their native part is not needed to type-check). This is not an Android Gradle build:
# it proves the Kotlin compiles against the published API source, nothing more.
#   needs: git, java, kotlinc (build/setup_toolchain.sh), android-34.jar, gson + kotlinx-coroutines jars
set -e
P=$(cd "$(dirname "$0")/.." && pwd); T=${TRIBHASA_TOOLCHAIN:-$P/../toolchain}; T=$(cd "$T" && pwd)
SRC=$P/android/app/src/main; O=$P/build/typecheck
LIB_TAG=${LITERTLM_TAG:-v0.18.0}
GSON=${GSON_JAR:-$(ls /opt/gradle-*/lib/gson-*.jar 2>/dev/null | head -1)}
[ -f "$GSON" ] || { echo "Set GSON_JAR to a gson-2.x jar"; exit 1; }
rm -rf "$O"; mkdir -p "$O/lib-src" "$O/lib" "$O/gen" "$O/rcls" "$O/app"
if [ -n "$LITERTLM_SRC" ]; then cp -r "$LITERTLM_SRC"/. "$O/lib-src/"; else
  git clone --depth 1 --branch "$LIB_TAG" -q https://github.com/google-ai-edge/LiteRT-LM.git "$O/lib-clone"
  cp -r "$O/lib-clone/kotlin/java/." "$O/lib-src/"; fi
K=$T/kotlinc/lib
LIBCP="$K/kotlin-stdlib.jar:$K/kotlin-reflect.jar:$K/kotlinx-coroutines-core-jvm.jar:$GSON"
$T/kotlinc/bin/kotlinc -jvm-target 17 -nowarn -Xskip-prerelease-check -cp "$LIBCP" -d "$O/lib/litertlm.jar" $(find "$O/lib-src" -name '*.kt' -path '*litertlm/*' -not -path '*/example/*') 2>&1 | grep -v JAVA_TOOL | grep -v "^warning" || true
test -f "$O/lib/litertlm.jar" || { echo "LIBRARY SOURCES DID NOT COMPILE"; exit 1; }
$T/aapt2 compile --dir "$SRC/res" -o "$O/res.zip"
# Gradle takes the package name from `namespace` in app/build.gradle.kts; aapt2 used on its own needs it written into the manifest, so a copy gets it.
sed 's|<manifest |<manifest package="org.tribhasa.app" |' "$SRC/AndroidManifest.xml" > "$O/AndroidManifest.xml"
$T/aapt2 link -o "$O/base.apk" -I "$T/android-34.jar" --manifest "$O/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 34 --java "$O/gen" "$O/res.zip"
javac -nowarn -cp "$T/android-34.jar" -d "$O/rcls" $(find "$O/gen" -name '*.java') 2>&1 | grep -v "Picked up" || true
$T/kotlinc/bin/kotlinc -jvm-target 17 -nowarn -no-jdk -cp "$T/android-34.jar:$LIBCP:$O/lib/litertlm.jar:$O/rcls:$T/jsonclasses" -d "$O/app" $(find "$SRC/kotlin" -name '*.kt') 2>&1 | grep -v JAVA_TOOL || true
test -f "$O/app/org/tribhasa/app/MainActivity.class" || { echo "TYPE-CHECK FAILED"; exit 1; }
echo "TYPE-CHECK OK: $(find "$O/app" -name '*.class' | wc -l) classes compiled against litertlm $LIB_TAG sources"
