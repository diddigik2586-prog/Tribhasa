#!/bin/bash
# Recreates the build tools (no Android SDK and no Gradle are needed). Needs only: java, python3, git, curl, unzip.
# Everything is downloaded from GitHub. Run once; run_tests.sh and the other tools then work.
set -euo pipefail
P=$(cd "$(dirname "$0")/.." && pwd)
T=${TRIBHASA_TOOLCHAIN:-$P/../toolchain}
mkdir -p "$T"; T=$(cd "$T" && pwd)
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
cd "$W"

echo "== aapt2 (from the Apktool release)"
curl -fsSL -o apktool.jar https://github.com/iBotPeaches/Apktool/releases/download/v2.9.3/apktool_2.9.3.jar
unzip -o -q apktool.jar 'prebuilt/linux/*'
cp prebuilt/linux/aapt2_64 "$T/aapt2"; chmod +x "$T/aapt2"

echo "== bundletool (contains the D8 dex compiler and Google's apksig signer)"
curl -fsSL -o "$T/bundletool.jar" https://github.com/google/bundletool/releases/download/1.18.3/bundletool-all-1.18.3.jar

echo "== Android platform jars (API 34 to build against, API 26 to check the minimum version)"
git clone --depth 1 --filter=blob:none --sparse -q https://github.com/Sable/android-platforms.git sable
(cd sable && git sparse-checkout set android-34 android-26)
cp sable/android-34/android.jar "$T/android-34.jar"
cp sable/android-26/android.jar "$T/android-26.jar"

echo "== Kotlin compiler 2.4.21"
curl -fsSL -o kotlin.zip https://github.com/JetBrains/kotlin/releases/download/v2.4.21/kotlin-compiler-2.4.21.zip
rm -rf "$T/kotlinc"; unzip -q kotlin.zip -d kotlin; cp -r kotlin/kotlinc "$T/kotlinc"

echo "== org.json for the PC tests"
rm -rf "$T/jsonjava" "$T/jsonclasses"; git clone --depth 1 -q https://github.com/stleary/JSON-java.git "$T/jsonjava"
mkdir -p "$T/jsonclasses"; javac -nowarn -d "$T/jsonclasses" $(find "$T/jsonjava/src/main/java/org/json" -name '*.java') 2>&1 | grep -v "JAVA_TOOL\|warning\|Note:" || true

"$T/aapt2" version
echo "Toolchain ready in $T"
