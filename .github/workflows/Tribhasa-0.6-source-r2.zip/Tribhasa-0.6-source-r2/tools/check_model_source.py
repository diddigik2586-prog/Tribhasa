#!/usr/bin/env python3
"""
Checks the model facts written into the app (android/.../core/LocalModels.kt: address, size, SHA-256) against what the
publisher's server reports right now. It asks for headers only (HEAD requests); it does NOT download the 2.6 GB model.

Hugging Face reports the size and the SHA-256 of a large file in the headers X-Linked-Size and X-Linked-ETag on the
redirect that leads to the file. This script reads those. If a server does not send them, the script says so and exits
with 2 ("could not compare"); it never calls that a pass.

Exit codes: 0 = everything that could be compared matches; 1 = a mismatch or the address does not work;
            2 = reachable, but the server did not report enough to compare.
Set MODEL_URL to test against another address (used by the self-test). Usage: check_model_source.py [path/to/LocalModels.kt]
"""
import os, re, sys, urllib.request, urllib.error

SRC = sys.argv[1] if len(sys.argv) > 1 else "android/app/src/main/kotlin/org/tribhasa/app/core/LocalModels.kt"
text = open(SRC, encoding="utf-8").read()

def grab(pattern, what):
    m = re.search(pattern, text, re.S)
    if not m:
        print(f"CANNOT READ {what} from {SRC}"); sys.exit(1)
    return m.group(1)

m = re.search(r'url\s*=\s*"([^"]+)"\s*\+\s*"([^"]+)"', text) or re.search(r'url\s*=\s*"([^"]+)"()', text)
if not m:
    print(f"CANNOT READ the model address from {SRC}"); sys.exit(1)
url = os.environ.get("MODEL_URL") or (m.group(1) + m.group(2))
want_size = int(grab(r'sizeBytes\s*=\s*([0-9_]+)L', "the size").replace("_", ""))
want_sha = grab(r'sha256\s*=\s*"([0-9a-f]{64})"', "the SHA-256")

lines = []
def say(s): print(s); lines.append(s)

say(f"Model address : {url}")
say(f"App expects   : {want_size:,} bytes, SHA-256 {want_sha}")
if not os.environ.get("MODEL_URL") and not re.search(r"/resolve/[0-9a-f]{40}/", url):
    say("FAIL: the address is not pinned to a 40-character repository revision, so the file behind it could change.")
    sys.exit(1)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None
opener = urllib.request.build_opener(NoRedirect)

linked_size = None; linked_etag = None; final_len = None; final_status = None
cur = url
for hop in range(6):
    req = urllib.request.Request(cur, method="HEAD", headers={"User-Agent": "tribhasa-model-check", "Accept-Encoding": "identity"})
    try:
        r = opener.open(req, timeout=60); status, h = r.status, r.headers
    except urllib.error.HTTPError as e:
        status, h = e.code, e.headers
    except Exception as e:
        say(f"FAIL: could not reach the address ({type(e).__name__}: {e})"); sys.exit(1)
    say(f"  hop {hop}: HTTP {status}")
    if h.get("x-linked-size"): linked_size = int(h["x-linked-size"])
    if h.get("x-linked-etag"): linked_etag = h["x-linked-etag"].strip().removeprefix("W/").strip('"')
    if status in (301, 302, 303, 307, 308) and h.get("location"):
        cur = urllib.request.urljoin(cur, h["location"]); continue
    final_status = status
    if h.get("content-length"): final_len = int(h["content-length"])
    break

ok = True; compared = 0
if final_status != 200:
    say(f"FAIL: the address did not lead to a file (last answer HTTP {final_status})."); sys.exit(1)
size = linked_size if linked_size is not None else final_len
if size is None:
    say("NOTE: the server did not report a size.")
else:
    compared += 1
    if size == want_size: say(f"OK   size matches: {size:,} bytes")
    else: say(f"FAIL size differs: server says {size:,}, app expects {want_size:,}"); ok = False
if linked_etag and re.fullmatch(r"[0-9a-f]{64}", linked_etag):
    compared += 1
    if linked_etag == want_sha: say("OK   SHA-256 matches the publisher's own value")
    else: say(f"FAIL SHA-256 differs: server says {linked_etag}, app expects {want_sha}"); ok = False
else:
    say("NOTE: the server did not report a SHA-256 in its headers, so the checksum could not be compared here.")

summary = os.environ.get("GITHUB_STEP_SUMMARY")
if summary:
    with open(summary, "a", encoding="utf-8") as f:
        f.write("### Model source check (headers only, nothing downloaded)\n```\n" + "\n".join(lines) + "\n```\n")
if not ok: sys.exit(1)
if compared < 2: say("RESULT: no mismatch found, but not everything could be compared."); sys.exit(2)
say("RESULT: the address, size and checksum in the app match the publisher's server."); sys.exit(0)
