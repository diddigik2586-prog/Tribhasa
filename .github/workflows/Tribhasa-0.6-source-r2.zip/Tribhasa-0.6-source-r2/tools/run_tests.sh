#!/bin/bash
# Compiles the app's core logic for the JVM and runs the core tests against local mock servers.
# The same test sources also run under Gradle (android/app/src/test, task :app:testDebugUnitTest).
# Compiled for JDK 17 (-Xjdk-release=17) because the GitHub workflow builds with JDK 17.
set -e
P=$(cd "$(dirname "$0")/.." && pwd); T=${TRIBHASA_TOOLCHAIN:-$P/../toolchain}; T=$(cd "$T" && pwd)
SRC=$P/android/app/src; O=$P/build/jvm
rm -rf "$O" && mkdir -p "$O"
$T/kotlinc/bin/kotlinc -jvm-target 17 -Xjdk-release=17 -nowarn -cp $T/jsonclasses -d $O/core $SRC/main/kotlin/org/tribhasa/app/core/*.kt 2>&1 | grep -v JAVA_TOOL || true
test -d $O/core/org/tribhasa/app/core || { echo "COMPILE FAILED (core)"; exit 1; }
$T/kotlinc/bin/kotlinc -jvm-target 17 -Xjdk-release=17 -nowarn -cp "$T/jsonclasses:$O/core" -d $O/tests $SRC/test/kotlin/Support.kt $SRC/test/kotlin/LocalTests.kt $SRC/test/kotlin/CoreTests.kt 2>&1 | grep -v JAVA_TOOL || true
test -f $O/tests/CoreTestsKt.class || { echo "COMPILE FAILED (core tests)"; exit 1; }
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -cp "$O/tests:$O/core:$T/jsonclasses:$T/kotlinc/lib/kotlin-stdlib.jar" CoreTestsKt 2>&1 | grep -v JAVA_TOOL
