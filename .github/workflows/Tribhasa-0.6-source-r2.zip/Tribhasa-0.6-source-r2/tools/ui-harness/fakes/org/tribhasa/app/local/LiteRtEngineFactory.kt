package org.tribhasa.app.local

import org.tribhasa.app.core.LocalBackend
import org.tribhasa.app.core.NativeEngine
import org.tribhasa.app.core.NativeEngineFactory
import org.tribhasa.app.core.NativeFailure

/**
 * Stand-in for the real LiteRtEngineFactory (which needs Google's native library) in the headless screen tests only.
 * The tests put a scripted engine into [HarnessEngine.delegate]. This file is never part of the APK.
 */
object HarnessEngine { @Volatile var delegate: NativeEngineFactory? = null }

class LiteRtEngineFactory : NativeEngineFactory {
    override fun open(modelPath: String, backend: LocalBackend, contextTokens: Int, cacheDir: String): NativeEngine =
        (HarnessEngine.delegate ?: throw NativeFailure(NativeFailure.Kind.LOAD, "no engine is set in this test")).open(modelPath, backend, contextTokens, cacheDir)
}
