package org.tribhasa.app.local

import android.content.Context
import org.tribhasa.app.core.DownloadProgress

/** Stand-in for the real foreground service in the headless screen tests: it only records what the app asked for. Never part of the APK. */
object DownloadKeepAlive {
    val events = java.util.concurrent.CopyOnWriteArrayList<String>()
    fun start(ctx: Context) { events.add("start") }
    fun stop(ctx: Context) { events.add("stop") }
    fun update(ctx: Context, p: DownloadProgress) { if (events.lastOrNull() != "update") events.add("update") }
}
