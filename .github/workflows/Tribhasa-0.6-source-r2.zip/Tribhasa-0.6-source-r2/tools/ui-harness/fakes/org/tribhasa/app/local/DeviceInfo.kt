package org.tribhasa.app.local

import android.app.Activity
import android.content.Context
import java.io.File

/** Stand-in for the real DeviceInfo in the headless screen tests: the test sets the phone's memory, free space and connection. Never part of the APK. */
object DeviceInfo {
    @Volatile var totalRam: Long = 8L * 1024 * 1024 * 1024
    @Volatile var availRam: Long = 3L * 1024 * 1024 * 1024
    @Volatile var free: Long = Long.MAX_VALUE / 4
    @Volatile var metered: Boolean = false
    @Volatile var notificationAsks = 0
    fun reset() { totalRam = 8L * 1024 * 1024 * 1024; availRam = 3L * 1024 * 1024 * 1024; free = Long.MAX_VALUE / 4; metered = false; notificationAsks = 0 }

    fun totalRamBytes(ctx: Context): Long = totalRam
    fun availableRamBytes(ctx: Context): Long = availRam
    fun freeSpace(dir: File): Long = free
    fun isMetered(ctx: Context): Boolean = metered
    fun askForNotificationPermission(activity: Activity) { notificationAsks++ }
}
