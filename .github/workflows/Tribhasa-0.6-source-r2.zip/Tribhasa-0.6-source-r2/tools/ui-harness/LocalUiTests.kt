import android.app.AlertDialog
import android.os.Looper
import android.widget.ProgressBar
import android.widget.Switch
import org.json.JSONObject
import org.tribhasa.app.App
import org.tribhasa.app.MainActivity
import org.tribhasa.app.core.*
import org.tribhasa.app.local.DeviceInfo
import org.tribhasa.app.local.DownloadKeepAlive
import org.tribhasa.app.local.HarnessEngine
import org.tribhasa.app.local.Local
import android.content.Context

// =====================================================================================================
// Screen tests for the model on this phone. As in the other UI scenarios the real screens run on the JVM against fake
// Android classes. The "download" comes from a local HTTPS server with a small test file, and the "model" is a scripted
// stand-in engine: these tests show that the screens, the download, retry, delete and the no-fallback rules are wired
// correctly. They say nothing about the real model, the real 2.6 GB file, or the quality of any translation.
// =====================================================================================================

private class Rig(size: Int = 2_000_000) {
    val blob = TestBlob(size)
    val server = BlobServer(blob.data)
    val fake = FakeNativeFactory()
    init { fake.answer = { sys, usr -> Phone.cannedText(sys, usr) } }
    /** Points the app at the test file and the stand-in engine. Call right after Phone.fresh(). */
    fun install(sha: String = blob.sha256) { LocalModels.active = blob.spec(server.url, sha = sha); HarnessEngine.delegate = fake }
    /** As if the model had already been downloaded and checked. */
    fun preinstalled() { install(); val f = Local.files(); f.dir.mkdirs(); f.finalFile.writeBytes(blob.data); f.markVerified() }
    fun stop() = server.stop()
}

private fun switchNamed(c: android.view.View, start: String): Switch = c.all().filterIsInstance<Switch>().first { it.text.toString().startsWith(start) }
private fun bars(c: android.view.View) = c.all().filterIsInstance<ProgressBar>().filter { it.isShown }.toList()

val LOCAL_SCENARIOS = listOf<Pair<String, () -> Unit>>(
    "local: first start and the Settings card" to ::testLocalSettingsCard,
    "local: download, pause, resume" to ::testLocalDownload,
    "local: download failures and retry" to ::testLocalDownloadFailures,
    "local: check and delete" to ::testLocalCheckAndDelete,
    "local: six directions on the phone" to ::testLocalSixDirections,
    "local: no model, no fallback" to ::testLocalNoModel,
    "local: source selector" to ::testLocalSourceSelector,
    "local: refine, analyse, errors, cancel" to ::testLocalOtherTasks,
    "local: memory and GPU" to ::testLocalMemoryAndGpu,
)

fun testLocalSettingsCard() {
    section("UI (on-device) — first start and the Settings card")
    Phone.fresh(); val rig = Rig(); rig.install()
    try {
        val a = Phone.open(intro = true)
        val d = Phone.decor(a)
        until("splash to go") { d.countText(ATTR) == 1 }
        check("the first start offers the model download, and says what it costs and what it is", dialogTitle() == "Download the AI model" && dialogMessage().let { it.contains("one-time download") && it.contains("no account or key") && it.contains("has not been tested") }, dialogMessage())
        tapDialog("Later")
        check("Later starts no download", DownloadKeepAlive.events.isEmpty() && !Local.download.running && rig.server.log.isEmpty())
        val b = Phone.restartApp(a)
        check("the question is not asked again", AlertDialog.openCount() == 0)
        Phone.tapTab(b, "Settings"); val c = Phone.content(b)
        check("the card is there, with the source selector set to this phone", c.hasText("AI on this phone — free, private, works offline") && c.hasText("On this phone (default)"))
        check("it says the model is not on the phone yet and offers the download", c.hasTextContaining("Not on this phone yet") && c.tapTargets("Download the model", contains = true).isNotEmpty())
        check("there is no Check or Delete button before anything is downloaded", c.tapTargets("Check the file").isEmpty() && c.tapTargets("Delete from this phone").isEmpty())
        check("Wi-Fi only is on by default, the GPU option off", switchNamed(c, "Download on Wi-Fi only").isChecked && !switchNamed(c, "Use the phone's GPU").isChecked)
        check("the card names the model, the licence and the exact checksum the app will insist on", c.hasTextContaining("Apache-2.0") && c.hasTextContaining(rig.blob.sha256) && c.hasTextContaining("Test model"))
        check("the card is honest about quality", c.hasTextContaining("NOT been tested with a Sanskrit evaluation set") && c.hasTextContaining("never switches to an online service by itself"))
        check("the card gives the phone's memory advice", c.hasTextContaining("8.0 GB of memory"))
        check("the summary says where the AI runs and that the model is missing", c.hasTextContaining("Where the AI runs: on this phone (default)") && c.hasTextContaining("✗ Model on this phone: not downloaded yet"))
        check("the online section is titled optional", c.hasTextContaining("Online AI (optional)") && c.hasTextContaining("Used only when “Where the AI runs” above is set to Online"))
        check("attribution is still only on the splash, the footer and About", Phone.decor(b).countText(ATTR) == 1)
    } finally { rig.stop() }
}

fun testLocalDownload() {
    section("UI (on-device) — download with progress, pause, resume, rotation, notification")
    Phone.fresh(); val rig = Rig(3_000_000); rig.install()
    try {
        var a = Phone.open(); Phone.tapTab(a, "Settings"); var c = Phone.content(a)
        rig.server.chunkDelayMs = 40
        tap(c, "Download the model", contains = true)
        check("tapping Download starts it, asks once for the notification permission, and starts the keep-alive service", until("running") { Local.download.running } && DeviceInfo.notificationAsks == 1 && DownloadKeepAlive.events.first() == "start")
        check("progress shows: a bar, megabytes and a Pause button", until("progress") { bars(c).isNotEmpty() && c.hasTextContaining("Downloading…") && c.hasTextContaining("MB of") } && c.hasText("Pause the download"), c.shownTexts().filter { it.contains("MB") || it.contains("Start") }.toString())
        check("the other buttons are hidden while downloading", c.tapTargets("Delete from this phone").isEmpty() && c.tapTargets("Check the file").isEmpty())
        // rotate in the middle: the download goes on and the new screen picks up its progress
        a = Phone.rotate(a); Phone.tapTab(a, "Settings"); c = Phone.content(a)
        check("after rotating the download is still running and shown", Local.download.running && until("shown") { c.hasTextContaining("Downloading…") })
        // pause
        tap(c, "Pause the download")
        check("Pause keeps what arrived and offers Resume", until("paused") { !Local.download.running } && until("label") { c.hasTextContaining("Unfinished:") } && c.hasText("Resume the download"), c.shownTexts().take(40).toString())
        val kept = Local.files().partialBytes()
        check("some bytes are kept, but not all", kept > 0 && kept < rig.blob.data.size, "$kept")
        check("the keep-alive service was stopped", until("stop") { DownloadKeepAlive.events.last() == "stop" }, DownloadKeepAlive.events.toString())
        rig.server.log.clear(); rig.server.chunkDelayMs = 0
        tap(c, "Resume the download")
        check("Resume finishes the download", until("ready", 15000) { Local.uiState() == Local.UiState.READY })
        check("…using a Range request from the kept bytes, not starting again", rig.server.log.first().first.startsWith("bytes=") && rig.server.log.first().first != "bytes=0-", rig.server.log.toString())
        check("the screen now says the model is on the phone and checked", until("status") { c.hasTextContaining("✓ On this phone and checked") && c.hasTextContaining("Works without internet") })
        check("the model file is exactly the published file", Local.files().finalFile.readBytes().contentEquals(rig.blob.data))
        check("Check and Delete appear; the main button is gone", c.tapTargets("Check the file").isNotEmpty() && c.tapTargets("Delete from this phone").isNotEmpty() && c.tapTargets("Download the model", contains = true).isEmpty())
        check("the summary shows the model as ready", c.hasTextContaining("✓ Model on this phone: Test model, ready"))
        check("the service was stopped again at the end", until("stop") { DownloadKeepAlive.events.last() == "stop" }, DownloadKeepAlive.events.toString())
        val a2 = Phone.restartApp(a); Phone.tapTab(a2, "Settings")
        check("after restarting the app the model is still ready (no checking of 2.6 GB at start)", Phone.content(a2).hasTextContaining("✓ On this phone and checked"))
        check("no model memory is used until a task needs it", !Local.runtime.isLoaded && rig.fake.opens.get() == 0)
    } finally { rig.stop() }
}

fun testLocalDownloadFailures() {
    section("UI (on-device) — download failures: server, disk, mobile data, wrong file; Retry")
    Phone.fresh(); val rig = Rig(); rig.install()
    try {
        val a = Phone.open(); Phone.tapTab(a, "Settings"); val c = Phone.content(a)
        // file gone on the server
        rig.server.status = 404
        tap(c, "Download the model", contains = true)
        check("a missing file is explained and Retry is offered", until("err") { !Local.download.running && Local.download.error != null } && until("shown") { c.hasTextContaining("no longer has this file") && c.hasText("Retry") })
        rig.server.status = null
        tap(c, "Retry")
        check("Retry works once the server has the file again", until("ready", 15000) { Local.uiState() == Local.UiState.READY } && Local.download.error == null)
        Local.deleteModel(); Phone.restartApp(a)

        // disk full
        val b = Phone.open(); Phone.tapTab(b, "Settings"); var c2 = Phone.content(b)
        DeviceInfo.free = 5_000_000
        val before = rig.server.log.size
        tap(c2, "Download the model", contains = true)
        check("too little room is reported before downloading, with the amount needed", until("err") { c2.hasTextContaining("not enough free space") } && rig.server.log.size == before)
        DeviceInfo.free = Long.MAX_VALUE / 4
        tap(c2, "Retry")
        check("after freeing space, Retry works", until("ready", 15000) { Local.uiState() == Local.UiState.READY })
        Local.deleteModel()

        // mobile data
        DeviceInfo.metered = true
        val n = rig.server.log.size
        tap(Phone.content(b), "Download the model", contains = true)
        c2 = Phone.content(b)
        check("on mobile data with Wi-Fi only on, nothing is downloaded and the screen says why", until("err") { c2.hasTextContaining("“Download on Wi-Fi only” is switched on") } && rig.server.log.size == n)
        switchNamed(c2, "Download on Wi-Fi only").performClick(); Looper.pump()
        check("switching Wi-Fi only off is remembered", !App.store.localWifiOnly())
        tap(c2, "Retry")
        check("then the download goes ahead on mobile data", until("ready", 15000) { Local.uiState() == Local.UiState.READY })
        Local.deleteModel(); DeviceInfo.metered = false

        // wrong file: the checksum does not match
        Phone.fresh(); rig.install(sha = "0".repeat(64))
        val d = Phone.open(); Phone.tapTab(d, "Settings"); val c3 = Phone.content(d)
        tap(c3, "Download the model", contains = true)
        check("a complete file with the wrong checksum is refused and the screen says so", until("err", 15000) { c3.hasTextContaining("checksum does not match") } && Local.uiState() == Local.UiState.NOT_ON_PHONE)
        check("…and nothing is left on the phone", !Local.files().finalFile.exists() && !Local.files().partFile.exists())
        check("…and the translate screen will not use it", App.localBlockReason(App.store.credentials()) != null)
    } finally { rig.stop() }
}

fun testLocalCheckAndDelete() {
    section("UI (on-device) — Check the file, Delete, and what happens to a task that is running")
    Phone.fresh(); val rig = Rig(); rig.preinstalled()
    try {
        val a = Phone.open(); Phone.tapTab(a, "Settings"); val c = Phone.content(a)
        check("a downloaded model shows as ready", c.hasTextContaining("✓ On this phone and checked"))
        tap(c, "Check the file")
        check("Check the file reads the whole file and confirms the checksum", until("checked", 15000) { c.hasTextContaining("SHA-256 matches") }, c.shownTexts().filter { it.contains("check", true) }.toString())
        // the file changes behind the app's back
        val f = Local.files()
        f.finalFile.writeBytes(rig.blob.data.copyOf().also { it[5] = (it[5] + 1).toByte() })
        Phone.restartApp(a); val a2 = Phone.open(); Phone.tapTab(a2, "Settings"); val c2 = Phone.content(a2)
        check("a changed file is not trusted: the screen says it is not confirmed", c2.hasTextContaining("has not been confirmed to be the published one") && Local.uiState() == Local.UiState.DAMAGED)
        check("…and no task will use it", App.localBlockReason(App.store.credentials())!!.contains("Check the file"))
        tap(c2, "Check the file", last = true)
        check("checking it finds that it does not match", until("mismatch", 15000) { c2.hasTextContaining("does NOT match") } && Local.uiState() == Local.UiState.DAMAGED)
        // delete
        tap(c2, "Delete from this phone")
        check("Delete asks first", dialogTitle() == "Delete the model from this phone?")
        tapDialog("Keep it")
        check("Keep it keeps it", Local.files().finalFile.exists())
        tap(c2, "Delete from this phone"); tapDialog("Delete")
        check("Delete removes the model and every part of it", !Local.files().finalFile.exists() && !Local.files().partFile.exists() && Local.files().dir.listFiles().orEmpty().isEmpty())
        check("…and says so", toasts().any { it.contains("removed from this phone") } && c2.hasTextContaining("Not on this phone yet"))
        check("…and the Download button is back", c2.tapTargets("Download the model", contains = true).isNotEmpty())
        check("…and the summary says it is gone", c2.hasTextContaining("✗ Model on this phone: not downloaded yet"))
    } finally { rig.stop() }

    // Delete while a task is using the model
    Phone.fresh(); val r2 = Rig(); r2.preinstalled()
    try {
        val a = Phone.open(); val c = Phone.content(a)
        r2.fake.answer = { _, _ -> "{\"translations\":[\"x\"]}" + " ".repeat(2000) }; r2.fake.pieceDelayMs = 30
        setDirection(a, Lang.SA, Lang.EN); typeInto(c.shownEdits().first(), "विद्या परमं धनम्।"); tap(c, "Translate")
        until("running") { App.translate.running && r2.fake.starts.get() > 0 }
        Phone.tapTab(a, "Settings"); val s = Phone.content(a)
        tap(s, "Delete from this phone"); tapDialog("Delete")
        check("deleting while a task uses the model is refused, and the model stays", toasts().any { it.contains("A task is using the model") } && Local.files().finalFile.exists())
        Phone.tapTab(a, "Translate"); tap(Phone.content(a), "Cancel")
        until("cancelled") { !App.translate.running }
        r2.fake.pieceDelayMs = 0
        Phone.tapTab(a, "Settings"); tap(Phone.content(a), "Delete from this phone"); tapDialog("Delete")
        check("once the task has been cancelled, Delete works", !Local.files().finalFile.exists())
    } finally { r2.stop() }
}

fun testLocalSixDirections() {
    section("UI (on-device) — all six directions on the phone, offline, nothing sent anywhere")
    Phone.fresh(); val rig = Rig(); rig.preinstalled()
    try {
        val a = Phone.open()
        Context.connectivity.online = false   // the phone has no internet at all
        val texts = mapOf(Lang.SA to "विद्या परमं धनम्।", Lang.KN to "ವಿದ್ಯೆಯೇ ಪರಮ ಧನ.", Lang.EN to "Knowledge is the supreme wealth.")
        val serverHits = rig.server.log.size
        NetTripwire.watching {
            for (d in Direction.ALL) {
                val before = rig.fake.requestsSeen.size
                val out = translateVia(a, d.src, d.tgt, texts[d.src]!!)
                val (sys, usr, _) = rig.fake.requestsSeen[before]
                check("${d.label}: the on-phone model is asked for the right language and gets the text", sys.contains("into ${d.tgt.english}.") && usr.contains(texts[d.src]!!))
                check("${d.label}: the answer is shown", out == Phone.translationFor(d.tgt.english), out)
                val c = Phone.content(a)
                check("${d.label}: the report says it was done on the phone and is low-confidence", c.hasTextContaining("Done on this phone by Test model") && c.hasTextContaining("Low confidence by default"), c.shownTexts().filter { it.contains("phone") }.toString())
                check("${d.label}: Copy gives exactly the translation, no attribution", run { tap(c, "Copy"); clipboardText() == out && clipboardText()?.contains("Diddigi") == false })
            }
        }
        check("with the phone offline all six worked and no connection was attempted", NetTripwire.seen.isEmpty(), NetTripwire.seen.toString())
        check("the online mock model was never asked, and the download server was not touched again", Phone.requests() == 0 && rig.server.log.size == serverHits)
        check("the history recorded them with the on-phone model's name", until("hist") { App.store.history().size == 6 } && App.store.history().all { it.madeWith.contains("Test model") && it.madeWith.split("not IndicTrans2").size == 2 }, "n=${App.store.history().size} " + App.store.history().map { it.madeWith }.toString())
        check("one model load served all six tasks", rig.fake.opens.get() == 1)
        // a plain-text answer from the small model is accepted, but flagged
        rig.fake.answer = { _, _ -> "Learning is the highest wealth." }
        val out = translateVia(a, Lang.SA, Lang.EN, "विद्या परमं धनम्।")
        check("a plain-text answer is shown and flagged as low-confidence", out == "Learning is the highest wealth." && Phone.content(a).hasTextContaining("did not answer in the requested format"))
        // glossary reaches the on-phone model
        App.store.saveGlossary(listOf(GlossaryEntry(1, sa = "विद्या", en = "learning")))
        rig.fake.answer = { _, _ -> "Learning is supreme wealth." }
        translateVia(a, Lang.SA, Lang.EN, "विद्या परमं धनम्।")
        check("the glossary is sent to the on-phone model too", rig.fake.requestsSeen.last().second.contains("विद्या => learning"))
        // online source is blocked while offline, local is not
        Phone.tapTab(a, "Translate")
        App.store.setAiSource(AiSource.ONLINE)
        tap(Phone.content(a), "Translate")
        check("with Online chosen and no internet the screen says the phone is offline", until("err") { App.translate.error != null } && Phone.content(a).hasTextContaining("The phone is offline"))
    } finally { rig.stop(); Context.connectivity.online = true }
}

fun testLocalNoModel() {
    section("UI (on-device) — without the model every AI tool says so; nothing goes online")
    Phone.fresh(); val rig = Rig(); rig.install()
    try {
        // saved online keys must not matter in this mode
        App.store.setLlmKey("sk-or-saved-earlier"); App.store.setLlmModel(MODEL); App.store.setLlmBase(Phone.mock.base + "/api/v1")
        val a = Phone.open(); var c = Phone.content(a)
        setDirection(a, Lang.EN, Lang.KN); typeInto(c.shownEdits().first(), "Knowledge is wealth.")
        NetTripwire.watching { tap(c, "Translate") }
        check("Translate explains that the model is not on the phone, with an Open Settings button", until("err") { App.translate.error != null } && c.hasTextContaining("The AI model is not on this phone yet") && c.hasText("Open Settings"))
        check("…and the text is kept", c.shownEdits().first().text.toString() == "Knowledge is wealth.")
        check("…and nothing was sent to the online model although a key is saved", Phone.requests() == 0 && NetTripwire.seen.isEmpty())
        tap(c, "Open Settings")
        check("Open Settings goes to the model card", Phone.title(a) == "Settings" && Phone.content(a).hasText("AI on this phone — free, private, works offline"))

        Phone.tapTab(a, "Refine"); c = Phone.content(a)
        typeInto(c.shownEdits().first(), "The color of the center were analyzed.")
        tap(c, "Correct Grammar", last = true)
        check("Refine says the same", until("err") { App.refine.error != null } && c.hasTextContaining("not on this phone yet") && Phone.requests() == 0)
        Phone.tapTab(a, "Analyse"); c = Phone.content(a)
        check("Analyse shows the experimental-on-phone notice", c.hasTextContaining("experimental here"))
        typeInto(c.shownEdits().first(), "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः ।\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥ १.१ ॥")
        tap(c, "Analyse the śloka")
        check("Analyse says the same", until("err") { App.analyse.error != null } && c.hasTextContaining("not on this phone yet") && Phone.requests() == 0)
        tap(c, "Check metre offline", contains = true)
        check("the offline metre check needs neither the model nor the internet", (c.hasTextContaining("Anuṣṭubh") || c.hasTextContaining("anuṣṭubh")) && Phone.requests() == 0, c.shownTexts().take(40).toString())

        // an unfinished download is described as such
        val f = Local.files(); f.dir.mkdirs(); f.partFile.writeBytes(ByteArray(1000))
        Phone.tapTab(a, "Translate"); c = Phone.content(a); tap(c, "Translate")
        check("an unfinished download is described as unfinished, with Resume", until("err") { c.hasTextContaining("unfinished") && c.hasTextContaining("Resume") })

        // Compare is online-only
        f.deleteAll()
        Phone.tapTab(a, "Settings"); c = Phone.content(a); tap(c, "Compare models side by side")
        val panel = Phone.compare(a)!!
        typeInto(panel.shownEdits().first(), "Knowledge is wealth.")
        tap(panel, "Run the comparison")
        check("Compare models is switched off in this mode, and says why", until("err") { App.compare.error != null } && panel.hasTextContaining("would send your text over the internet") && Phone.requests() == 0)
    } finally { rig.stop() }
}

fun testLocalSourceSelector() {
    section("UI (on-device) — Where the AI runs: this phone (default) or Online (optional)")
    Phone.fresh(); val rig = Rig(); rig.preinstalled()
    try {
        val a = Phone.open(); Phone.tapTab(a, "Settings"); val c = Phone.content(a)
        check("a new install runs on the phone", App.store.credentials().aiSource == AiSource.LOCAL)
        tap(c, "On this phone (default)")
        check("the chooser explains both options", dialogTexts().any { it.contains("Free and private") } && dialogTexts().any { it.contains("Your texts are sent over the internet") })
        tapDialog("Online (optional)")
        check("choosing Online asks first and explains what is sent", dialogTitle() == "Send my texts over the internet?")
        tapDialog("Stay on this phone")
        check("Stay on this phone changes nothing", App.store.credentials().aiSource == AiSource.LOCAL)
        tap(c, "On this phone (default)"); tapDialog("Online (optional)"); tapDialog("Use online")
        check("Use online switches the source, and the screen says so", App.store.credentials().aiSource == AiSource.ONLINE && c.hasTextContaining("Texts are sent over the internet to OpenRouter") && c.hasTextContaining("Where the AI runs: online (optional)"))
        // with Online chosen and a key, the mock online model is used and the phone's model is not
        Phone.useMockModel()
        val out = translateVia(a, Lang.EN, Lang.SA, "Knowledge is wealth.")
        check("with Online chosen the online model answers", out == Phone.translationFor("Sanskrit") && Phone.requests() >= 1 && rig.fake.starts.get() == 0)
        check("…and the report does not claim it was done on the phone", !Phone.content(a).hasTextContaining("Done on this phone"))
        // the key fails: the app must NOT fall back to the phone's model silently
        Phone.respondWith { Resp(401, """{"error":{"message":"No auth credentials found"}}""") }
        Phone.tapTab(a, "Translate"); tap(Phone.content(a), "Translate")
        until("err") { App.translate.error != null }
        check("when the online service fails the phone's model is not used instead, and the error is shown", rig.fake.starts.get() == 0 && Phone.content(a).hasTextContaining("could not be completed"))
        // back to the phone: the phone's model works and nothing is sent online
        Phone.tapTab(a, "Settings"); tap(Phone.content(a), "Online (optional)"); tapDialog("On this phone (default)")
        check("switching back is immediate and needs no question", App.store.credentials().aiSource == AiSource.LOCAL)
        val hits = Phone.requests()
        val out2 = translateVia(a, Lang.EN, Lang.SA, "Knowledge is wealth.")
        check("back on the phone the phone's model answers and the online model is not asked", out2 == Phone.translationFor("Sanskrit") && rig.fake.starts.get() >= 1 && Phone.requests() == hits)
    } finally { rig.stop() }
}

fun testLocalOtherTasks() {
    section("UI (on-device) — Refine, śloka analysis, failure, retry and cancel on the phone")
    Phone.fresh(); val rig = Rig(); rig.preinstalled()
    try {
        val a = Phone.open()
        Phone.tapTab(a, "Refine"); var c = Phone.content(a)
        check("Refine shows the short-passages notice", c.hasTextContaining("use short passages"))
        val box = c.shownEdits().first()
        typeInto(box, "The color of the center were analyzed.")
        tap(c, "Correct Grammar", last = true); until("run") { !App.refine.running && App.refine.text != null }
        check("Correct Grammar runs on the phone and shows the model's text", App.refine.text == Phone.canned.refinedText && c.hasTextContaining(Phone.canned.refinedText))
        check("its report says it was done on the phone and is low-confidence", c.hasTextContaining("Done on this phone") && c.hasTextContaining("Low confidence by default"))

        Phone.tapTab(a, "Analyse"); c = Phone.content(a)
        typeInto(c.shownEdits().first(), "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥")
        tap(c, "Analyse the śloka"); until("analysis") { !App.analyse.running && App.analyse.doc != null }
        check("śloka analysis runs on the phone and shows its sections", App.analyse.doc != null && c.hasTextContaining("Low confidence by default"))

        // the engine fails: clear message, Retry, then success
        Phone.tapTab(a, "Translate"); c = Phone.content(a)
        setDirection(a, Lang.SA, Lang.EN); typeInto(c.shownEdits().first(), "विद्या परमं धनम्।")
        Local.runtime.unload()
        rig.fake.failLoad = NativeFailure(NativeFailure.Kind.OUT_OF_MEMORY, "alloc")
        tap(c, "Translate")
        check("running out of memory while loading is explained, and the text is kept", until("err") { App.translate.error != null } && c.hasTextContaining("ran out of memory") && c.hasTextContaining("nothing was sent anywhere"))
        check("…nothing was sent online", Phone.requests() == 0)
        rig.fake.failLoad = null
        tap(c, "Retry")
        check("Retry succeeds once the problem is gone", until("ok") { !App.translate.running && App.translate.output.isNotBlank() })
        // a mid-answer error
        rig.fake.errorAfterPieces = 2; rig.fake.errorToSend = NativeFailure(NativeFailure.Kind.OTHER, "boom")
        tap(c, "Translate")
        check("an error in the middle of an answer is shown, not a half answer", until("err") { App.translate.error != null } && c.hasTextContaining("boom") && App.translate.output.isBlank())
        rig.fake.errorAfterPieces = -1
        // a stall
        // cancel while writing
        rig.fake.answer = { _, _ -> "z".repeat(3000) }; rig.fake.pieceDelayMs = 20
        val startsBefore = rig.fake.starts.get()
        tap(c, "Retry"); until("running") { App.translate.running && rig.fake.starts.get() > startsBefore }
        val cancelsBefore = rig.fake.cancels.get()
        check("a task on the phone shows its progress line", c.hasText("Cancel") && App.translate.status.isNotBlank())
        tap(c, "Cancel")
        val stopped = until("cancelled") { !App.translate.running }
        check("Cancel stops the model and keeps the text", stopped && rig.fake.cancels.get() > cancelsBefore && App.translate.status.startsWith("Cancelled") && c.shownEdits().first().text.toString() == "विद्या परमं धनम्।",
            "stopped=$stopped cancels=${rig.fake.cancels.get()} (before $cancelsBefore) status='${App.translate.status}' text='${c.shownEdits().first().text}'")
        check("…and the engine's turns are all closed", rig.fake.turnsClosed.get() == rig.fake.starts.get())
        rig.fake.pieceDelayMs = 0
        check("nothing at all went online during these tasks", Phone.requests() == 0)
    } finally { rig.stop() }
}

fun testLocalMemoryAndGpu() {
    section("UI (on-device) — memory pressure, the GPU option, small phones")
    Phone.fresh(); val rig = Rig(); rig.preinstalled()
    try {
        val a = Phone.open()
        translateVia(a, Lang.EN, Lang.SA, "Knowledge is wealth.")
        check("after a task the model is loaded", Local.runtime.isLoaded && rig.fake.backendsOpened.toList() == listOf(LocalBackend.CPU))
        Phone.tapTab(a, "Settings"); val c = Phone.content(a)
        check("Settings says so and offers to free the memory", c.hasTextContaining("In memory now: Test model loaded (CPU)") && c.tapTargets("Free memory now").isNotEmpty())
        a.performTrimMemory(20)
        check("when Android asks apps to trim memory the idle model is unloaded", until("unload") { !Local.runtime.isLoaded } && rig.fake.enginesClosed.get() == 1)
        check("the Settings line follows (after a redraw)", run { Phone.tapTab(a, "Translate"); Phone.tapTab(a, "Settings"); Phone.content(a).hasTextContaining("In memory now: not loaded") })
        translateVia(a, Lang.EN, Lang.SA, "Knowledge is wealth.")
        check("the next task loads it again", rig.fake.opens.get() == 2)
        // GPU option
        Phone.tapTab(a, "Settings")
        switchNamed(Phone.content(a), "Use the phone's GPU").performClick(); Looper.pump()
        check("the GPU switch is remembered and unloads the model", App.store.localBackend() == "GPU" && until("unload") { !Local.runtime.isLoaded })
        rig.fake.failGpuLoad = NativeFailure(NativeFailure.Kind.LOAD, "no OpenCL")
        translateVia(a, Lang.EN, Lang.SA, "Knowledge is wealth.")
        check("the GPU could not load the model: the CPU was used and the report says so", rig.fake.backendsOpened.toList().takeLast(2) == listOf(LocalBackend.GPU, LocalBackend.CPU) && Phone.content(a).hasTextContaining("GPU could not load the model"), Phone.content(a).shownTexts().filter { it.contains("GPU") }.toString())

        // a phone that is too small is warned before the download, and not blocked
        Phone.fresh(); rig.install(); DeviceInfo.totalRam = 3L * 1024 * 1024 * 1024
        val b = Phone.open(); Phone.tapTab(b, "Settings"); val s = Phone.content(b)
        check("the card warns that this phone looks too small", s.hasTextContaining("likely to fail to load"))
        tap(s, "Download the model", contains = true)
        check("a warning dialog comes first", dialogTitle() == "This phone may be too small" && !Local.download.running)
        tapDialog("Not now")
        check("Not now starts nothing", !Local.download.running && rig.server.log.isEmpty())
        tap(s, "Download the model", contains = true); tapDialog("Download anyway")
        check("Download anyway goes ahead", until("ready", 15000) { Local.uiState() == Local.UiState.READY })
    } finally { rig.stop() }
}
