import org.json.JSONObject
import android.app.AlertDialog
import android.content.Context
import android.os.Looper
import org.tribhasa.app.App
import org.tribhasa.app.MainActivity
import org.tribhasa.app.core.*
import kotlin.system.exitProcess

const val ATTR = "by Dr. Diddigi Vamsi Krishna"

fun testStartup() {
    section("UI — start-up, splash, branding, attribution")
    Phone.fresh()
    val a = Phone.open(intro = true)
    val d = Phone.decor(a)
    check("splash is up on the first start, with the name", d.hasText("Tribhāṣā") && d.hasText("Sanskrit · Kannada · English"))
    check("attribution appears exactly on the splash and on the main screen (2 places)", d.countText(ATTR) == 2, "count=${d.countText(ATTR)}")
    check("splash closes by itself", until("splash to go") { d.countText(ATTR) == 1 })
    check("the first start asks once whether to download the AI model", dialogTitle() == "Download the AI model", dialogTitle() ?: "none")
    tapDialog("Later")
    check("dialog closes on Later", AlertDialog.openCount() == 0)
    check("title of the first tab is Translate", d.hasText("Translate"))
    val b = Phone.rotate(a)
    check("after rotation there is no splash and no second question", AlertDialog.openCount() == 0 && Phone.decor(b).countText(ATTR) == 1)
}

fun testNavigation() {
    section("UI — six tabs, Back button, About, keyboard")
    Phone.fresh(); val a = Phone.open()
    val nav = Phone.nav(a)
    check("tab bar has exactly the six tabs, in order", nav.shownTexts() == Phone.tabs(), nav.shownTexts().toString())
    val titles = listOf("Translate" to "Translate", "Refine" to "Refine", "Analyse" to "Analyse (Sanskrit)", "Glossary" to "Glossary", "History" to "History", "Settings" to "Settings")
    for ((lab, title) in titles) {
        Phone.tapTab(a, lab)
        check("tab “$lab” opens the screen titled “$title”", Phone.title(a) == title, Phone.title(a))
    }
    a.performBack()
    check("Back from a tab returns to Translate", Phone.title(a) == "Translate")

    // About
    Phone.tapTab(a, "Settings")
    tap(Phone.content(a), "About Tribhāṣā")
    val d = Phone.decor(a)
    check("About panel shows the attribution (and the footer still does): 2 places", d.countText(ATTR) == 2, "count=${d.countText(ATTR)}")
    check("About names the licence-checked model and says no Claude/Gemini is used", d.hasTextContaining("Gemma 4 E2B") && d.hasTextContaining("Apache-2.0") && d.hasTextContaining("No proprietary model such as Claude or Gemini is used") && d.hasTextContaining("NOT been tested with a Sanskrit evaluation set"))
    check("About says the output is machine-generated and unverified", d.hasTextContaining("Everything produced is machine-generated"))
    check("About states what is sent to OpenRouter and that there is no analytics", d.hasTextContaining("sent to OpenRouter") && d.hasTextContaining("no analytics"))
    a.performBack()
    check("Back closes the About panel first (still on Settings)", d.countText(ATTR) == 1 && Phone.title(a) == "Settings")
    tap(Phone.content(a), "About Tribhāṣā"); tap(d, "← Back")
    check("← Back also closes About", d.countText(ATTR) == 1)

    // brand and attribution sit together at the bottom of the main screen, the attribution directly under the brand
    val footer = Phone.footer(a)
    val brand = footer.all().filterIsInstance<android.widget.TextView>().first { it.text.toString().startsWith("Tribhāṣā") }
    val by = footer.all().filterIsInstance<android.widget.TextView>().first { it.text.toString() == ATTR }
    val parent = brand.parent!!
    var idx = -1; for (i in 0 until parent.childCount) if (parent.getChildAt(i) === brand) idx = i
    check("attribution is directly beneath the Tribhāṣā branding", by.parent === parent && parent.getChildAt(idx + 1) === by)
    val main = footer.parent!!
    var fi = -1; var ni = -1; for (i in 0 until main.childCount) { if (main.getChildAt(i) === footer) fi = i; if (main.getChildAt(i) === Phone.nav(a)) ni = i }
    check("the footer is at the bottom of the main screen, just above the tab bar", fi >= 0 && ni == fi + 1 && ni == main.childCount - 1, "footer=$fi nav=$ni of ${main.childCount}")

    // soft keyboard
    android.view.View.visibleBottom = 1500; Phone.fireLayout(a)
    check("footer and tab bar make way for the keyboard", Phone.footer(a).visibility == android.view.View.GONE && Phone.nav(a).visibility == android.view.View.GONE)
    android.view.View.visibleBottom = 2400; Phone.fireLayout(a)
    check("…and return when it closes", Phone.footer(a).visibility == android.view.View.VISIBLE && Phone.nav(a).visibility == android.view.View.VISIBLE)

    // Back on the first tab leaves the app
    Phone.tapTab(a, "Translate"); a.performBack()
    check("Back on the first tab leaves the app", a.isFinishing)
}

fun testTranslateSixDirections() {
    section("UI — Translate: all six directions through the real screen (mock model: wiring only, not quality)")
    Phone.fresh(); Phone.useMockModel(); val a = Phone.open()
    val c = Phone.content(a)
    val samples = mapOf(Lang.SA to "विद्या परमं धनम्।", Lang.KN to "ಜ್ಞಾನವೇ ಶ್ರೇಷ್ಠ ಸಂಪತ್ತು.", Lang.EN to "Knowledge is the supreme wealth.")
    var n = 0
    for (dir in Direction.ALL) {
        n++
        setDirection(a, dir.src, dir.tgt)
        check("${dir.label}: both pickers show the chosen languages", c.hasText(dir.src.display) && c.hasText(dir.tgt.display))
        val box = c.shownEdits().first()
        typeInto(box, samples.getValue(dir.src))
        val before = Phone.canned.translatedInto.size
        tap(c, "Translate")
        check("${dir.label}: finishes", until("translation") { !App.translate.running && App.translate.output.isNotBlank() })
        val want = Phone.translationFor(dir.tgt.english)
        check("${dir.label}: the model was asked for ${dir.tgt.english}", Phone.canned.translatedInto.size > before && Phone.canned.translatedInto[before] == dir.tgt.english, Phone.canned.translatedInto.toString())
        check("${dir.label}: the model received exactly the source text", Phone.canned.segmentsSeen[before] == listOf(samples.getValue(dir.src)), Phone.canned.segmentsSeen[before].toString())
        check("${dir.label}: the model's answer is shown", c.hasText(want))
        check("${dir.label}: the Quality-Control report is shown", c.hasTextContaining("no warnings") || c.hasTextContaining("to review"))
        check("${dir.label}: the QC report names the AI model, not IndicTrans2", c.hasTextContaining("not IndicTrans2"))
        tap(c, "Copy")
        check("${dir.label}: Copy puts exactly the translation on the clipboard", clipboardText() == want, clipboardText() ?: "null")
        check("${dir.label}: no attribution in the copied text", clipboardText()?.contains("Diddigi") == false)
        check("${dir.label}: saved to the history", until("history") { App.store.history().size == n })
        val h = App.store.history().first()
        check("${dir.label}: history entry has direction, input and output", h.from == dir.src.name && h.to == dir.tgt.name && h.input == samples.getValue(dir.src) && h.output == want, h.toString())
        check("${dir.label}: the attribution is not part of the translation screen's content", !c.hasTextContaining("Diddigi"))
    }
    check("every one of the six directions was exercised", n == 6)
}

fun testTranslateBehaviour() {
    section("UI — Translate: progress, cancel, errors, offline, retry, scripts, swap")
    Phone.fresh(); Phone.useMockModel(); val a = Phone.open()
    val c = Phone.content(a)
    val box = c.shownEdits().first()

    // empty input
    tap(c, "Translate")
    check("empty input: a clear message and no request", toasts().contains("Please type or paste some text first.") && Phone.requests() == 0)

    // progress while working, and Cancel
    setDirection(a, Lang.EN, Lang.SA)
    typeInto(box, "Knowledge is the supreme wealth.")
    Phone.hold(); tap(c, "Translate")
    check("while the model is working the progress area and a Cancel button are visible", until("running") { App.translate.running } && c.hasText("Cancel") && !c.hasText("Translate") )
    check("…and the status line says what is happening", App.translate.status.isNotBlank() && c.hasText(App.translate.status))
    tap(c, "Cancel")
    check("Cancel stops the task and keeps the text", until("cancel") { !App.translate.running } && App.translate.status.startsWith("Cancelled") && box.text.toString() == "Knowledge is the supreme wealth.")
    check("a cancelled task shows no error box", !c.hasText("Could not finish"))
    Phone.release()
    // Cancel pressed at once, while the connection is still being made, must also stop the task promptly (regression: it used to be missed)
    var stuck = 0
    for (i in 1..8) {
        Phone.hold(); tap(c, "Translate"); tap(c, "Cancel")
        if (!until("cancel #$i", 3000) { !App.translate.running }) stuck++
        Phone.release()
        until("idle", 3000) { !App.translate.running }
    }
    check("Cancel pressed immediately stopped the task every time (8 of 8, within 3 s)", stuck == 0, "stuck=$stuck")

    // 401 -> clear message, Open Settings; then fix and Retry
    Phone.respondWith { Resp(401, """{"error":{"message":"No auth credentials found"}}""") }
    tap(c, "Translate")
    check("a rejected key ends in a plain-language error", until("error") { !App.translate.running && App.translate.error != null } && c.hasText("Could not finish"))
    check("…which says the key looks wrong and offers Open Settings", c.hasTextContaining("A key looks wrong") && c.hasText("Open Settings"))
    check("…and keeps the text", box.text.toString() == "Knowledge is the supreme wealth.")
    check("…and the output stays empty", App.translate.output.isEmpty())
    Phone.respondWith { Phone.smartReply(it) }
    tap(c, "Retry")
    check("after the cause is fixed, Retry completes the translation", until("retry") { !App.translate.running && App.translate.output.isNotBlank() } && c.hasText(Phone.translationFor("Sanskrit")) && !c.hasText("Could not finish"))
    tap(Phone.content(a), "Run again")
    check("Run again repeats the translation", until("again") { !App.translate.running && Phone.requests() >= 3 })

    // switching the script of Sanskrit output (output is held in Devanagari)
    val out = Phone.translationFor("Sanskrit")
    tap(c, Translit.SanskritView.IAST.label)
    check("IAST view shows the output in correct IAST with diacritics", c.hasText(Translit.render(out, Translit.SanskritView.IAST)) && Translit.render(out, Translit.SanskritView.IAST).contains("ā"))
    tap(c, "Copy")
    check("Copy gives exactly what is shown (IAST)", clipboardText() == Translit.render(out, Translit.SanskritView.IAST))
    tap(c, Translit.SanskritView.KANNADA.label)
    check("Kannada-script view shows the output in Kannada script", c.hasText(Translit.render(out, Translit.SanskritView.KANNADA)))
    tap(c, Translit.SanskritView.DEVANAGARI.label)
    tap(c, "Copy")
    check("Devanagari view and Copy give the original Devanagari", clipboardText() == out)

    // swap: the translation becomes the new input
    tap(c, "⇄")
    check("swap exchanges the languages and moves the translation into the input", App.translate.src == Lang.SA && App.translate.tgt == Lang.EN && box.text.toString() == out && App.translate.output.isEmpty())

    // 429 daily limit -> a quota message that says the text is kept
    Phone.respondWith { Resp(429, """{"error":{"message":"Rate limit exceeded: free-models-per-day"}}""") }
    tap(c, "Translate")
    check("daily free allowance used up: says so and that the text is kept", until("quota") { !App.translate.running && App.translate.error != null } && c.hasTextContaining("daily free-model allowance") && c.hasTextContaining("Your text is kept"))

    // no network
    Phone.respondWith { Phone.smartReply(it) }
    val seen = Phone.requests()
    Context.connectivity.online = false
    tap(c, "Retry")
    check("offline: says the phone is offline and sends nothing", c.hasTextContaining("The phone is offline") && Phone.requests() == seen)
    Context.connectivity.online = true
    tap(c, "Retry")
    check("back online: Retry works", until("online") { !App.translate.running && App.translate.output.isNotBlank() })

    // not connected at all
    App.store.disconnectLlm()
    tap(c, "Run again")
    check("with no AI connection and no other service: a clear, actionable message", until("noservice") { !App.translate.running && App.translate.error != null } && c.hasText("Open Settings"), c.shownTexts().toString())
    tap(c, "Open Settings")
    check("Open Settings takes the user to Settings", Phone.title(a) == "Settings")
}

val SCENARIOS = listOf<Pair<String, () -> Unit>>(
    "start-up" to ::testStartup,
    "navigation" to ::testNavigation,
    "six directions" to ::testTranslateSixDirections,
    "translate behaviour" to ::testTranslateBehaviour,
    "refine" to ::testRefine,
    "analyse" to ::testAnalyse,
    "glossary" to ::testGlossary,
    "history" to ::testHistory,
    "sign-in" to ::testSignInScreen,
    "settings" to ::testSettings,
    "compare" to ::testCompareScreen,
    "rotation and persistence" to ::testRotationAndPersistence,
    "unicode and long text" to ::testUnicodeAndLongText,
    "robustness" to ::testRobustness,
) + LOCAL_SCENARIOS

fun testRefine() {
    section("UI — Refine: all eight tools through the real screen (mock model)")
    Phone.fresh(); Phone.useMockModel(); val a = Phone.open()
    Phone.tapTab(a, "Refine")
    val c = Phone.content(a)
    check("Refine opens with the tool picker and the language picker", c.hasText("Correct Grammar") && c.hasText("English"))
    val tools = Prompts.Refine.values().toList()
    check("the tool chooser lists all eight tools", run { tap(c, "Correct Grammar"); val t = dialogTexts(); tapDialog("Cancel"); tools.all { t.contains(it.label) } && tools.size == 8 })
    val input = "The color of the center were analyzed."
    val box = c.shownEdits().first()
    var requests = 0
    for (tool in tools) {
        // choose the tool
        tap(c, App.refine.tool.label); tapDialog(tool.label)
        check("${tool.label}: chosen", App.refine.tool == tool && c.hasText(tool.blurb))
        typeInto(box, input)
        val before = Phone.requests()
        tap(c, tool.label, last = true)   // the first one with this name is the tool picker, the last is the run button
        check("${tool.label}: finishes", until("refine") { !App.refine.running && (App.refine.text != null || App.refine.doc != null) })
        check("${tool.label}: exactly the expected requests were sent", Phone.requests() - before >= 1, "sent=${Phone.requests() - before}")
        val expectSys = mapOf(Prompts.Refine.CORRECT_GRAMMAR to "meticulous copy-editor", Prompts.Refine.IMPROVE_CLARITY to "Improve clarity", Prompts.Refine.ACADEMIC to "formal, academic register",
            Prompts.Refine.SIMPLIFY to "simpler language", Prompts.Refine.REFINE_TRANSLATE to "Do NOT translate", Prompts.Refine.EXPLAIN to "explain each change",
            Prompts.Refine.ALTERNATIVES to "exactly three alternative", Prompts.Refine.GRAMMAR_ANALYSIS to "You are a grammarian")
        check("${tool.label}: the first request carried this tool's instructions and the user's exact text", Phone.canned.systems[before].contains(expectSys.getValue(tool)) && Phone.canned.users[before].contains(input), Phone.canned.systems[before].take(80))
        check("${tool.label}: a Quality-Control report is shown", c.hasTextContaining("no warnings") || c.hasTextContaining("to review"))
        when (tool) {
            Prompts.Refine.CORRECT_GRAMMAR, Prompts.Refine.IMPROVE_CLARITY, Prompts.Refine.ACADEMIC, Prompts.Refine.SIMPLIFY -> {
                check("${tool.label}: revised text shown", c.hasText(Phone.canned.refinedText))
                tap(c, "Use as input")
                check("${tool.label}: Use as input moves the revised text into the box", box.text.toString() == Phone.canned.refinedText)
            }
            Prompts.Refine.REFINE_TRANSLATE -> {
                check("${tool.label}: refined text and the translation are both shown", c.hasText(Phone.canned.refinedText) && c.hasTextContaining("ಇದು ಒಂದು ಪರೀಕ್ಷಾ ಅನುವಾದ") )
            }
            Prompts.Refine.EXPLAIN -> check("${tool.label}: corrected text and the list of changes are shown", c.hasTextContaining("The colour was good.") && c.hasTextContaining("British spelling"))
            Prompts.Refine.ALTERNATIVES -> check("${tool.label}: three alternatives are shown", c.hasTextContaining("Good colour.") && c.hasTextContaining("The colour was satisfactory.") && c.hasTextContaining("The colour looked good."))
            Prompts.Refine.GRAMMAR_ANALYSIS -> check("${tool.label}: issues are listed and nothing is rewritten", c.hasTextContaining("subject is singular") && App.refine.text == null)
        }
        requests = Phone.requests()
    }
    // history
    check("every refinement was saved to the history", until("history") { App.store.history().count { it.kind == org.tribhasa.app.core.HistoryEntry.Kind.REFINEMENT } == 8 })

    // Copy all (structured result)
    tap(c, "Alternative Rewriting".let { App.refine.tool.label }); tapDialog("Explain Corrections")
    typeInto(box, input); tap(c, "Explain Corrections", last = true); until("run") { !App.refine.running && App.refine.doc != null }
    tap(c, "Copy all")
    check("Copy all gives the structured result as plain text, without the attribution", clipboardText() == App.refine.doc!!.toPlain() && clipboardText()?.contains("Diddigi") == false)

    // no connection -> clear instruction instead of a crash
    App.store.disconnectLlm()
    tap(c, "Explain Corrections", last = true)
    check("without the AI connection the tool explains what to do", until("err") { App.refine.error != null } && c.hasTextContaining("needs the AI model") && c.hasText("Open Settings"))
    check("(and the text is still in the box)", box.text.toString() == input)
}

fun testAnalyse() {
    section("UI — Analyse: śloka, prose, commentary, offline metre, script conversion")
    Phone.fresh(); Phone.useMockModel(); val a = Phone.open()
    Phone.tapTab(a, "Analyse")
    val c = Phone.content(a)
    check("Analyse screen is titled and offers the three kinds", Phone.title(a) == "Analyse (Sanskrit)" && c.hasText("Śloka analysis"))
    val box = c.shownEdits().first()
    val gita = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः ।\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥ १.१ ॥"

    // offline metre needs no key
    App.store.disconnectLlm(); Context.connectivity.online = false
    typeInto(box, gita); tap(c, "Check metre offline", contains = true)
    check("offline metre check works with no key and no network", c.hasTextContaining("Anuṣṭubh") || c.hasTextContaining("anuṣṭubh"), c.shownTexts().take(30).toString())
    check("…and it sent nothing", Phone.requests() == 0)
    check("…and was saved to the history", until("hist") { App.store.history().any { it.title.startsWith("Metre check") } })
    Context.connectivity.online = true
    Phone.useMockModel()

    // script converters keep the verse intact
    typeInto(box, gita)
    tap(c, "→ IAST")
    check("→ IAST converts the verse with diacritics", box.text.toString().contains("dharmakṣetre kurukṣetre samavetā yuyutsavaḥ"), box.text.toString())
    tap(c, "→ Kannada script")
    check("→ Kannada script converts it", box.text.toString().contains("ಧರ್ಮಕ್ಷೇತ್ರೇ"), box.text.toString())
    tap(c, "→ Devanagari")
    check("→ Devanagari converts it back to the original verse", box.text.toString().replace("\n", " ").replace("  ", " ").contains("धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः"), box.text.toString())

    // śloka
    typeInto(box, gita); tap(c, "Analyse the śloka")
    check("śloka analysis finishes", until("sloka") { !App.analyse.running && App.analyse.doc != null })
    for (t in listOf("Original verse", "Padaccheda", "Pratipadārtha", "Samāsa analysis", "Anvaya", "Bhāvārtha", "Tātparya", "Chandas", "Alaṅkāra", "Translation"))
        check("śloka result has the section “$t”", c.hasTextContaining(t))
    check("word cards show vibhakti, vacana, liṅga", c.hasTextContaining("saptamī  ·  ekavacana  ·  napuṃsakaliṅga"))
    check("IAST of the verse is computed by the app", c.hasTextContaining("dharmakṣetre kurukṣetre samavetā yuyutsavaḥ"))
    check("uncertain readings are marked, not hidden", c.hasTextContaining("uncertain"))
    check("the Quality-Control report is shown with the app's own metre check", c.hasTextContaining("syllable scan"))
    tap(c, "Copy all")
    check("Copy all gives the full analysis and no attribution", clipboardText() == App.analyse.doc!!.toPlain() && clipboardText()?.contains("Diddigi") == false)
    check("śloka analysis is in the history", until("hist2") { App.store.history().any { it.title == "Śloka analysis" } })

    // prose
    tap(c, "Śloka analysis"); tapDialog("Prose analysis")
    typeInto(box, "रामः वनं गच्छति ।"); tap(c, "Analyse the prose")
    check("prose analysis finishes and shows sentence, forms, syntax, meaning", until("prose") { !App.analyse.running && App.analyse.doc != null } && c.hasTextContaining("Sentence 1") && c.hasTextContaining("prathamā  ·  ekavacana  ·  puṃliṅga") && c.hasTextContaining("kartā रामः"))

    // commentary
    tap(c, "Prose analysis"); tapDialog("Sanskrit-to-Sanskrit commentary")
    check("commentary mode offers the choice of parts and hides the output-language choice", c.hasText("Complete commentary (all three)"))
    tap(c, "Write the commentary")
    check("commentary finishes and carries the 'not a historical commentator' note", until("comm") { !App.analyse.running && App.analyse.doc != null } && c.hasTextContaining("not the commentary of any historical"))
    check("the commentary prompt forbids invented quotations and authorities", Phone.canned.systems.last().contains("never invent quotations"))

    // a failed answer is reported, never shown as a finished analysis
    Phone.respondWith { llmText("Sorry, no JSON here.") }
    tap(c, "Śloka analysis".let { App.analyse.mode.label }); tapDialog("Śloka analysis")
    typeInto(box, gita); tap(c, "Analyse the śloka")
    until("bad") { !App.analyse.running }
    check("an unreadable model answer is shown as a failure in the report, not as a result", c.hasTextContaining("to review") || c.hasTextContaining("could not"), c.shownTexts().take(20).toString())
}

fun testGlossary() {
    section("UI — Glossary: add, validate, edit, delete, search, persist, and use in translation")
    Phone.fresh(); Phone.useMockModel(); var a = Phone.open()
    Phone.tapTab(a, "Glossary"); var c = Phone.content(a)
    check("an empty glossary says so", c.hasTextContaining("No terms yet"))
    tap(c, "Add a term")
    check("the Add dialog opens with four fields", dialogTitle() == "Add a term" && AlertDialog.top()!!.contentView()!!.shownEdits().size == 4)
    val f = AlertDialog.top()!!.contentView()!!.shownEdits()
    typeInto(f[0], "dharmaḥ")
    tapDialog("Save")
    check("one language is not enough: a message, and the dialog stays open", toasts().contains("Please fill at least two of the three languages.") && AlertDialog.openCount() == 1)
    typeInto(f[2], "dharma (righteousness)")
    tapDialog("Save")
    check("two languages are enough; the dialog closes", AlertDialog.openCount() == 0)
    check("Sanskrit typed in IAST is stored in Devanagari", App.store.glossary().single().sa == "धर्मः", App.store.glossary().toString())
    check("the list shows the term", c.hasTextContaining("धर्मः") && c.hasTextContaining("dharma (righteousness)") && c.hasTextContaining("1 term(s) saved"))

    // a second term with Kannada, then edit it
    tap(c, "Add a term"); val g = AlertDialog.top()!!.contentView()!!.shownEdits()
    typeInto(g[0], "विद्या"); typeInto(g[1], "ವಿದ್ಯೆ"); typeInto(g[2], "learning"); typeInto(g[3], "general")
    tapDialog("Save")
    check("three-language entry saved with its note", App.store.glossary().size == 2 && App.store.glossary()[1].kn == "ವಿದ್ಯೆ" && App.store.glossary()[1].note == "general")
    tap(c, "ವಿದ್ಯೆ", contains = true)
    check("tapping a term opens it for editing with its values", dialogTitle() == "Edit term" && AlertDialog.top()!!.contentView()!!.shownEdits().map { it.text.toString() } == listOf("विद्या", "ವಿದ್ಯೆ", "learning", "general"))
    typeInto(AlertDialog.top()!!.contentView()!!.shownEdits()[2], "knowledge")
    tapDialog("Save")
    check("the edit is saved in place (still two terms)", App.store.glossary().size == 2 && App.store.glossary()[1].en == "knowledge" && c.hasTextContaining("knowledge"))

    // search
    val search = c.shownEdits().first()
    typeInto(search, "dharma")
    check("search by English finds only the matching term", c.hasTextContaining("dharma (righteousness)") && !c.hasTextContaining("ವಿದ್ಯೆ"))
    typeInto(search, "धर्म")
    check("search by Sanskrit finds it", c.hasTextContaining("dharma (righteousness)") && !c.hasTextContaining("ವಿದ್ಯೆ"))
    typeInto(search, "vidya")
    check("a Sanskrit term can also be found by typing it in IAST", c.hasTextContaining("ವಿದ್ಯೆ") && !c.hasTextContaining("dharma (righteousness)"))
    typeInto(search, "qqqq")
    check("a search with no match says so", c.hasTextContaining("No term matches"))
    typeInto(search, "")

    // persistence across closing the app
    a = Phone.restartApp(a)
    Phone.tapTab(a, "Glossary"); c = Phone.content(a)
    check("after closing and reopening the app both terms are still there", c.hasTextContaining("धर्मः") && c.hasTextContaining("ವಿದ್ಯೆ") && c.hasTextContaining("2 term(s) saved"))

    // used in translation: sent to the model, then checked in the result
    Phone.useMockModel()
    translateVia(a, Lang.SA, Lang.EN, "विद्या परमं धनम्।")
    check("the preferred term reached the model with the text", Phone.canned.users.any { it.contains("विद्या => knowledge") }, Phone.canned.users.toString())
    val tc = Phone.content(a)
    check("the mock answer lacks the preferred term, so the screen says which term is missing", tc.hasTextContaining("Your glossary prefers these terms") && tc.hasTextContaining("knowledge"))
    check("…and the QC report records the missing term", tc.hasTextContaining("Glossary: 1 of 1 preferred term(s) not found"))
    tap(tc, "Apply my glossary (uses AI)")
    check("Apply my glossary asks the model to fix only that term", until("fix") { !App.translate.running } && Phone.canned.systems.any { it.startsWith("You edit a") } && Phone.canned.users.last().contains("Required terms") && Phone.canned.users.last().contains("विद्या => knowledge"))

    // delete
    Phone.tapTab(a, "Glossary")
    tap(Phone.content(a), "ವಿದ್ಯೆ", contains = true); tapDialog("Delete")
    check("Delete removes the term", App.store.glossary().size == 1 && !Phone.content(a).hasTextContaining("ವಿದ್ಯೆ"))
}

fun testHistory() {
    section("UI — History: list, search, open, copy, reopen, delete, clear, persistence")
    Phone.fresh(); Phone.useMockModel(); var a = Phone.open()
    Phone.tapTab(a, "History"); var c = Phone.content(a)
    check("an empty history says so", c.hasTextContaining("Nothing here yet"))
    translateVia(a, Lang.SA, Lang.EN, "विद्या परमं धनम्।")
    translateVia(a, Lang.EN, Lang.KN, "Knowledge is the supreme wealth.")
    translateVia(a, Lang.KN, Lang.EN, "ಜ್ಞಾನವೇ ಶ್ರೇಷ್ಠ ಸಂಪತ್ತು.")
    check("three entries were saved", until("saved") { App.store.history().size == 3 })
    Phone.tapTab(a, "History"); c = Phone.content(a)
    check("the screen lists all three, newest first", c.hasTextContaining("Showing 3 of 3 entries") && c.shownTexts().indexOfFirst { it.contains("Kannada → English") } < c.shownTexts().indexOfFirst { it.contains("Sanskrit → English") })
    check("each card shows the original and the result separately", c.hasText("ORIGINAL") && c.hasText("RESULT") && c.hasTextContaining("विद्या परमं धनम्") && c.hasTextContaining("ಇದು ಒಂದು ಪರೀಕ್ಷಾ ಅನುವಾದ"))
    val search = c.shownEdits().first()
    typeInto(search, "Knowledge")
    check("search finds entries by their original text", c.hasTextContaining("Showing 1 of 1 entry") || c.hasTextContaining("1 entr"), c.shownTexts().toString())
    typeInto(search, "ಜ್ಞಾನ")
    check("search works in Kannada", c.hasTextContaining("Kannada → English") && !c.hasTextContaining("Sanskrit → English"))
    typeInto(search, "qqqq")
    check("a search with no match says so", c.hasTextContaining("No entry matches"))
    typeInto(search, "")

    // open one
    tap(c, "Translation · Sanskrit → English")
    check("tapping an entry opens it in full", dialogTexts().contains("विद्या परमं धनम्।") && dialogTexts().contains("This is a test translation.") && dialogTexts().any { it.startsWith("Made with:") })
    tapDialog("Copy original")
    check("Copy original gives the exact original", clipboardText() == "विद्या परमं धनम्।")
    tapDialog("Copy result")
    check("Copy result gives the exact result, with no attribution", clipboardText() == "This is a test translation." )
    tapDialog("Open in Translate")
    check("Open in Translate returns to the Translate screen with the pair restored", Phone.title(a) == "Translate" && App.translate.src == Lang.SA && App.translate.tgt == Lang.EN && Phone.content(a).hasText("This is a test translation.") && Phone.content(a).shownEdits().first().text.toString() == "विद्या परमं धनम्।")

    // delete one
    Phone.tapTab(a, "History"); c = Phone.content(a)
    tap(c, "Translation · English → Kannada"); tapDialog("Delete")
    check("Delete removes just that entry", App.store.history().size == 2 && App.store.history().none { it.to == "KN" })

    // persistence across closing the app
    a = Phone.restartApp(a); Phone.tapTab(a, "History"); c = Phone.content(a)
    check("after closing and reopening the app the history is still there", c.hasTextContaining("Showing 2 of 2 entries"))

    // more than one page
    val many = (1..45).map { org.tribhasa.app.core.HistoryEntry(1000L + it, 1_700_000_000_000L + it, org.tribhasa.app.core.HistoryEntry.Kind.TRANSLATION, "English → Kannada", "text $it", "result $it", "EN", "KN", "t", 0) }
    App.store.saveHistory(many + App.store.history())
    Phone.tapTab(a, "Settings"); Phone.tapTab(a, "History")
    check("a long history is shown a page at a time", c.hasTextContaining("Show more (") && c.hasTextContaining("Showing 40 of 47"))
    tap(c, "Show more", contains = true)
    check("Show more reveals the rest", c.hasTextContaining("Showing 47 of 47"))

    // clear
    tap(c, "Clear all history")
    check("clearing asks first and says it cannot be undone", dialogTitle() == "Clear all history?" && AlertDialog.top()!!.message().toString().contains("cannot be undone"))
    tapDialog("Cancel")
    check("Cancel keeps the history", App.store.history().size == 47)
    tap(c, "Clear all history"); tapDialog("Clear")
    check("confirming clears it", App.store.history().isEmpty() && c.hasTextContaining("Nothing here yet"))
    check("the glossary is not touched by clearing the history", true.also { App.store.saveGlossary(listOf(org.tribhasa.app.core.GlossaryEntry(1, sa = "x", en = "y"))) } && App.store.glossary().size == 1)
}

/** Plays the part of the browser: reads the address the app opened and, when asked, sends the user back to the phone. */
class FakeBrowser {
    val opened get() = synchronized(Context.startedActivities) { Context.startedActivities.toList() }
    fun page(): String = opened.last().data.toString()
    fun param(n: String): String? = opened.last().data!!.getQueryParameter(n)
    fun callback(extra: String): Int {
        val u = java.net.URL(param("callback_url") + extra)
        val c = u.openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 3000; c.readTimeout = 3000
        return try { c.responseCode } finally { c.disconnect() }
    }
}

fun allStoredText(): String {
    val sb = StringBuilder()
    synchronized(Context.prefs) { for ((_, p) in Context.prefs) for ((k, v) in p.all) sb.append(k).append('=').append(v).append('\n') }
    Context.filesDirectory.listFiles()?.forEach { f -> if (f.isFile) sb.append(f.readText()) }
    return sb.toString()
}

fun testSignInScreen() {
    section("UI — Settings: one-time sign-in to OpenRouter, with the browser and OpenRouter replaced by test doubles")
    val SECRET = "sk-or-v1-signin-SECRET-0123456789"
    Phone.fresh(); var a = Phone.open()
    App.signInPage = "https://openrouter.test/auth"
    App.signInExchange = Phone.mock.base + "/api/v1/auth/keys"
    var exchangeBody: JSONObject? = null
    Phone.mock.on("POST", "/api/v1/auth/keys") { req -> exchangeBody = JSONObject(req.body); Resp(200, JSONObject().put("key", SECRET).toString()) }
    Phone.tapTab(a, "Settings"); var c = Phone.content(a)
    check("before signing in the screen says it is not connected", c.hasTextContaining("Not connected yet") && c.hasText("Connect — one-time sign-in") && c.hasTextContaining("AI model: not connected"))
    check("…and there is no Disconnect button", c.tapTargets("Disconnect").isEmpty())
    check("the screen explains that no key needs to be copied", c.hasTextContaining("You do not search for, copy or type any key"))

    // start
    tap(c, "Connect — one-time sign-in")
    check("the browser is asked to open OpenRouter's page", until("browser") { Context.startedActivities.isNotEmpty() })
    val br = FakeBrowser()
    check("…at the sign-in address, with PKCE (S256), a state value and a callback on this phone", br.page().startsWith("https://openrouter.test/auth?") && br.param("code_challenge_method") == "S256" && !br.param("code_challenge").isNullOrBlank() && !br.param("state").isNullOrBlank() && br.param("callback_url")!!.startsWith("http://localhost:"), br.page())
    check("…and the address holds no secret verifier", !br.page().contains("code_verifier"))
    check("the screen shows that it is waiting, with a Cancel sign-in button", until("waiting") { c.hasText("Cancel sign-in") } && c.hasTextContaining("Sign in on the OpenRouter page"))
    check("…and nothing has been saved yet", !App.store.credentials().hasLlm)

    // a reply that does not belong to this attempt is refused and does not end the wait
    val bad = br.callback("?code=EVIL&state=wrong-state")
    check("a reply with the wrong state is refused (HTTP 400)", bad == 400)
    check("…and the app keeps waiting", App.connect.running && !App.store.credentials().hasLlm)

    // the real reply
    val ok = br.callback("?code=CODE-ABC&state=" + br.param("state"))
    check("the right reply is accepted (HTTP 200)", ok == 200)
    check("the sign-in finishes", until("connected") { !App.connect.running && App.store.credentials().hasLlm })
    val eb = exchangeBody
    check("the code was swapped using the secret verifier whose S256 hash is the challenge that was sent", eb != null && eb.getString("code") == "CODE-ABC" && org.tribhasa.app.core.Pkce.challenge(eb.getString("code_verifier")) == br.param("code_challenge"), eb.toString())
    check("the screen says it is connected and that the user copied nothing", c.hasTextContaining("Connected") && c.hasTextContaining("You did not have to copy anything"))
    check("the Disconnect button appears and the button now offers a new sign-in", c.hasText("Disconnect") && c.hasText("Connect again (new sign-in)"))
    check("the services summary shows the AI model as set up", c.hasTextContaining("✓ AI model"))
    val cr = App.store.credentials()
    check("the app knows the key came from the sign-in, and the address is OpenRouter's", cr.llmKey == SECRET && cr.llmKeyFromSignIn && cr.llmBaseUrl == Models.OPENROUTER_BASE)
    check("the key is shown nowhere on the screen", !Phone.decor(a).shownTexts().any { it.contains(SECRET) } && c.shownEdits().none { it.text.toString().contains(SECRET) })
    check("the key is stored encrypted: not found as plain text in any saved setting or file", !allStoredText().contains(SECRET) && !allStoredText().contains("p:"), allStoredText().take(300))
    check("…by the keystore code path (a key exists in the keystore double)", android.security.keystore.FakeAndroidKeyStoreProvider.keyCount() == 1)
    check("…and a restart reads it back", run { a = Phone.restartApp(a); App.store.credentials().llmKey == SECRET && App.store.credentials().llmKeyFromSignIn })

    // the sign-in key is only ever sent to OpenRouter
    Phone.tapTab(a, "Settings"); c = Phone.content(a)
    App.store.setLlmBase(Phone.mock.base + "/api/v1")
    val r = runCatching { org.tribhasa.app.core.ServiceFactory.provider(App.store.credentials()) }
    check("the sign-in key refuses to be sent to any other address", r.isFailure && r.exceptionOrNull()!!.message!!.contains("only ever sent to OpenRouter"))
    App.store.setLlmBase("")

    // disconnect
    tap(c, "Disconnect")
    check("Disconnect asks first and explains that the key stays in the OpenRouter account", dialogTitle() == "Disconnect the AI model?" && AlertDialog.top()!!.message().toString().contains("openrouter.ai/keys"))
    tapDialog("Cancel")
    check("Cancel keeps the connection", App.store.credentials().hasLlm)
    tap(c, "Disconnect"); tapDialog("Disconnect")
    check("Disconnect erases the key from the phone", !App.store.credentials().hasLlm && !allStoredText().contains(SECRET))
    check("…and the screen goes back to 'Not connected'", c.hasTextContaining("Not connected yet") && c.tapTargets("Disconnect").isEmpty())

    // cancelling in the middle
    Context.startedActivities.clear()
    tap(c, "Connect — one-time sign-in"); until("browser") { Context.startedActivities.isNotEmpty() }
    val cb = FakeBrowser().param("callback_url")!!
    tap(c, "Cancel sign-in")
    check("Cancel sign-in stops the wait and saves nothing", until("cancelled") { !App.connect.running } && !App.store.credentials().hasLlm && c.hasTextContaining("sign-in was cancelled"))
    val port = java.net.URI(cb).port
    val refused = try { java.net.Socket("127.0.0.1", port).use { false } } catch (e: java.io.IOException) { true }
    check("…and the listener on the phone is closed", refused)

    // declined in the browser
    Context.startedActivities.clear()
    tap(c, "Connect — one-time sign-in"); until("browser2") { Context.startedActivities.isNotEmpty() }
    FakeBrowser().callback("")
    check("declining in the browser ends with a plain message and nothing saved", until("denied") { !App.connect.running } && c.hasTextContaining("not authorised") && c.hasTextContaining("Tap Connect to try again") && !App.store.credentials().hasLlm)

    // OpenRouter refuses the exchange (the restart above reset the test addresses, so point them at the test double again)
    App.signInPage = "https://openrouter.test/auth"; App.signInExchange = Phone.mock.base + "/api/v1/auth/keys"
    Phone.mock.on("POST", "/api/v1/auth/keys") { Resp(403, """{"error":{"message":"invalid code"}}""") }
    Context.startedActivities.clear()
    tap(c, "Connect — one-time sign-in"); until("browser3") { Context.startedActivities.isNotEmpty() }
    FakeBrowser().let { it.callback("?code=OLD&state=" + it.param("state")) }
    check("a refused code is explained, with advice to connect again", until("refused") { !App.connect.running } && c.hasTextContaining("did not accept the sign-in code") && !App.store.credentials().hasLlm, "status=[" + App.connect.error?.message + "] running=" + App.connect.running + " texts=" + c.shownTexts().filter { it.contains("OpenRouter") }.map { it.take(120) })

    // no browser on the phone
    Context.noBrowser = true; Context.startedActivities.clear()
    tap(c, "Connect — one-time sign-in")
    check("without a browser the message points to the manual alternative", until("nobrowser") { !App.connect.running } && c.hasTextContaining("No web browser could be opened") && c.hasTextContaining("Advanced"))
    Context.noBrowser = false

    // offline
    Context.connectivity.online = false
    val before = Context.startedActivities.size
    tap(c, "Connect — one-time sign-in")
    check("offline: says so and does not open the browser", toasts().contains("The phone is offline.") && Context.startedActivities.size == before)
    Context.connectivity.online = true

    // returning from the browser through the link
    val b = Phone.open(intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("tribhasa://connected")))
    check("the link tribhasa://connected opens the app on Settings", Phone.title(b) == "Settings")
    Phone.tapTab(b, "Translate")
    b.performNewIntent(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("tribhasa://connected")))
    check("…also when the app was already open (single task)", Phone.title(b) == "Settings")
    Phone.tapTab(b, "Translate")
    b.performNewIntent(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://example.org/")))
    check("any other link is ignored", Phone.title(b) == "Translate")
}

fun testSettings() {
    section("UI — Settings: model, back-up, switches, advanced key, tests, six-direction self-test, keys removal")
    Phone.fresh(); var a = Phone.open()
    Phone.tapTab(a, "Settings"); var c = Phone.content(a)
    check("the privacy statement about OpenRouter and model hosts is on the screen", c.hasTextContaining("OpenRouter's privacy policy") && c.hasTextContaining("some model hosts may"))
    check("the screen says the build has no limits or expiry", c.hasTextContaining("no trial limit, no expiry, no payments"))
    check("free models only unless the user allows paid ones", c.hasTextContaining("Paid models are blocked"))

    // advanced options start hidden and reveal the manual key
    check("the manual key boxes are hidden at first", c.shownEdits().none { it.hint?.toString()?.startsWith("OpenRouter API key") == true })
    tap(c, "Show advanced options")
    check("Show advanced options reveals them", c.shownEdits().any { it.hint?.toString()?.startsWith("OpenRouter API key") == true })
    val edits = c.shownEdits()
    val keyBox = edits.first { it.hint?.toString()?.startsWith("OpenRouter API key") == true }
    val modelBox = edits.first { it.hint?.toString()?.startsWith("Model name") == true }
    val baseBox = edits.first { it.hint?.toString()?.startsWith("Service address") == true }
    typeInto(keyBox, "sk-or-manual-123"); typeInto(modelBox, "not a model!"); typeInto(baseBox, Phone.mock.base + "/api/v1")
    tap(c, "Save", nth = 1)   // the Save under the manual key boxes
    check("an invalid model name is refused with a message", c.hasTextContaining("That model name is not valid"))
    typeInto(modelBox, MODEL); typeInto(baseBox, "http://insecure.example/v1")
    tap(c, "Save", nth = 1)
    check("a service address without https is refused", c.hasTextContaining("must start with https://"))
    typeInto(baseBox, Phone.mock.base + "/api/v1")
    tap(c, "Save", nth = 1)
    check("a valid key, model and address are saved", App.store.credentials().llmKey == "sk-or-manual-123" && App.store.credentials().llmModel == MODEL && App.store.credentials().llmBaseUrl == Phone.mock.base + "/api/v1" && !App.store.credentials().llmKeyFromSignIn)
    check("a hand-typed key is also kept encrypted", !allStoredText().contains("sk-or-manual-123"))
    check("the summary shows the AI model as set up", c.hasTextContaining("✓ AI model: $MODEL"))

    // test connection with a real call to the mock model
    Phone.mock.on("GET", OR_KEY) { Resp(200, """{"data":{"label":"test","usage":0,"limit":null,"is_free_tier":true}}""") }
    tap(c, "Test connection", last = false)
    check("Test connection reports what the model really answered", until("tested", 10000) { c.hasTextContaining("It answered") } && c.hasTextContaining("ready") && c.hasTextContaining("Connected. Model: $MODEL"), c.shownTexts().filter { it.contains("Connected") || it.contains("Testing") }.toString())
    check("…and says it used one request of the allowance and licence status", c.hasTextContaining("used 1 request") && c.hasTextContaining("not checked by this app"))

    // model chooser
    tap(c, "Choose a model")
    check("the chooser lists the models whose licence was read, each with its licence", dialogTitle() == "Models whose licence was checked" && dialogTexts().any { it.contains("Apache-2.0") } && dialogTexts().size >= 6)
    val first = Models.CHECKED.first()
    tapDialog(first.name)
    check("choosing a model sets it and shows where its licence was read", App.store.credentials().llmModel == first.id && c.hasTextContaining(first.licenceSource.take(30)))

    // back-up
    tap(c, "Off", last = true)
    check("the back-up chooser offers Off first", dialogTitle() == "Back-up model" && dialogTexts().first() == "Off")
    val bk = Models.CHECKED.filter { it.free && it.id != first.id }.first()
    tapDialog(bk.name)
    check("a back-up model can be chosen (free models only)", App.store.credentials().fallbackModel == bk.id)

    // thinking
    tap(c, org.tribhasa.app.core.Models.Think.LOW.label)
    check("the thinking chooser opens", dialogTitle() == "Thinking before answering")
    tapDialog(org.tribhasa.app.core.Models.Think.OFF.label)
    check("the chosen thinking level is saved", App.store.credentials().thinking == "OFF")

    // paid switch
    val paid = c.all().filterIsInstance<android.widget.Switch>().first { it.text.toString().startsWith("Allow paid models") }
    paid.performClick()
    check("turning on paid models asks first, and says the app never buys credits", dialogTitle() == "Allow paid models?" && AlertDialog.top()!!.message().toString().contains("never buys credits"))
    tapDialog("Keep it off")
    check("Keep it off leaves the switch off", !paid.isChecked && !App.store.credentials().allowPaid)
    paid.performClick(); tapDialog("Allow")
    check("Allow turns it on", paid.isChecked && App.store.credentials().allowPaid)
    paid.performClick()
    check("turning it off needs no question", !App.store.credentials().allowPaid && AlertDialog.openCount() == 0)

    // the other switches persist
    val british = c.all().filterIsInstance<android.widget.Switch>().first { it.text.toString().startsWith("Indian English with British spelling") }
    check("British spelling is on by default", british.isChecked)
    british.performClick()
    check("…and switching it off is saved", !App.store.options().britishSpelling)
    val deny = c.all().filterIsInstance<android.widget.Switch>().first { it.text.toString().startsWith("Avoid hosts") }
    deny.performClick()
    check("the data-collection switch is saved", App.store.credentials().denyDataCollection)
    a = Phone.restartApp(a); Phone.tapTab(a, "Settings"); c = Phone.content(a)
    check("all of these survive closing the app", !App.store.options().britishSpelling && App.store.credentials().denyDataCollection && App.store.credentials().thinking == "OFF" && App.store.credentials().fallbackModel == bk.id && App.store.credentials().llmModel == first.id)
    check("…and the switches show it", c.all().filterIsInstance<android.widget.Switch>().first { it.text.toString().startsWith("Indian English") }.isChecked.not())

    // the six-direction self-test, through the mock model
    Phone.useMockModel()
    tap(c, "Run the six-direction test")
    check("the self-test finishes", until("self", 20000) { c.hasTextContaining("Done. Judge the quality yourself") })
    for (d in Direction.ALL) check("self-test: ${d.label} is reported", c.hasTextContaining("✓ ${d.label}"))
    check("self-test: it says which service answered and that it is not IndicTrans2", c.hasTextContaining("NOT IndicTrans2"))

    // remove all keys
    tap(c, "Remove all saved keys")
    check("removing keys asks first", dialogTitle() == "Remove all saved keys?")
    tapDialog("Cancel")
    check("Cancel keeps them", App.store.credentials().hasLlm)
    tap(c, "Remove all saved keys"); tapDialog("Remove")
    check("confirming erases the keys but not the glossary or texts", !App.store.credentials().hasLlm && !allStoredText().contains("sk-or-test"))

    // last error report
    tap(c, "Last error report")
    check("with no error recorded it says so", dialogTexts().contains("No error has been recorded on this phone."))
    tapDialog("OK")
}

fun testCompareScreen() {
    section("UI — Compare models: the same text through several models, side by side (mock)")
    Phone.fresh(); Phone.useMockModel(); val a = Phone.open()
    Phone.tapTab(a, "Settings")
    tap(Phone.content(a), "Compare models side by side")
    val panel = Phone.compare(a)!!
    check("the comparison panel opens over Settings", panel.hasText("Compare models") && panel.hasTextContaining("does not score them"))
    check("it warns that each model costs requests of the free allowance", panel.hasTextContaining("Each model uses at least one request"))
    val boxes = panel.all().filterIsInstance<android.widget.CheckBox>().toList()
    check("every checked model is listed with its licence; free ones start ticked", boxes.size == Models.CHECKED.size && boxes.count { it.isChecked } == Models.CHECKED.count { it.free } && boxes.all { it.text.toString().contains("Licence") })
    check("paid models are marked as blocked until the user allows them", boxes.filter { it.text.toString().contains("— blocked") }.size == Models.CHECKED.count { !it.free })
    tap(panel, "Insert a sample…"); tapDialog("Simple Sanskrit sentence")
    check("a sample can be inserted", panel.shownEdits().first().text.toString() == "अहं पुस्तकं पठामि।")
    boxes.forEachIndexed { i, b -> if (b.isChecked && i >= 2) b.performClick() }
    check("the number of requests is shown and follows the ticks", panel.hasTextContaining("2 models ticked: at least 2 requests"))
    tap(panel, "Run the comparison")
    check("the comparison finishes", until("compare", 20000) { !App.compare.running && App.compare.results.size == 2 })
    check("a result card per model, with the answer, the time and the request count", App.compare.results.all { it.ok } && panel.hasTextContaining("Answered by") && panel.hasTextContaining("request") && panel.countText("This is a test translation.") == 2)
    check("it says it has not judged which is best", panel.hasTextContaining("has not decided which is best"))
    tap(panel, "Copy all")
    check("Copy all gives every model's full answer", clipboardText()!!.startsWith("Model comparison") && Models.CHECKED[0].id in clipboardText()!! && Models.CHECKED[1].id in clipboardText()!! && clipboardText()!!.contains("This is a test translation."))
    tap(panel, "Use this model", nth = 1)
    check("Use this model sets the model for the whole app", App.store.credentials().llmModel == App.compare.results[1].model, App.store.credentials().llmModel)

    // add by name
    tap(panel, "Add by name")
    typeInto(AlertDialog.top()!!.contentView()!!.shownEdits().first(), "not valid!")
    tapDialog("Add")
    check("an invalid name is refused", toasts().contains("That does not look like a model name"))
    tap(panel, "Add by name")
    typeInto(AlertDialog.top()!!.contentView()!!.shownEdits().first(), "acme/custom-model:free")
    tapDialog("Add")
    check("a valid name is added to the list and ticked", panel.hasTextContaining("acme/custom-model:free") && panel.all().filterIsInstance<android.widget.CheckBox>().last().isChecked)

    // cancel in the middle
    Phone.hold()
    tap(panel, "Run the comparison")
    until("running") { App.compare.running }
    tap(panel, "Cancel")
    check("Cancel stops the comparison", until("cancel", 5000) { !App.compare.running })
    Phone.release()
    check("…and keeps the results already obtained, not showing a failure box", !panel.hasText("Could not finish"))

    // no connection
    App.store.disconnectLlm()
    tap(panel, "Run the comparison")
    check("without a connection it explains what to do", panel.hasTextContaining("Connect the AI model in Settings first") && panel.hasText("Open Settings"))
    tap(panel, "Open Settings")
    check("Open Settings closes the panel and shows Settings", Phone.compare(a) == null && Phone.title(a) == "Settings")
    tap(Phone.content(a), "Compare models side by side"); a.performBack()
    check("the Back button closes the panel", Phone.compare(a) == null)
}

fun testRotationAndPersistence() {
    section("UI — turning the phone, closing the app, drafts, languages")
    Phone.fresh(); Phone.useMockModel(); var a = Phone.open()
    var c = Phone.content(a)
    typeInto(c.shownEdits().first(), "A draft that must not be lost.")
    Phone.tapTab(a, "Refine"); Phone.tapTab(a, "Translate")
    a = Phone.restartApp(a); c = Phone.content(a)
    check("a typed text is kept when the app is closed and opened again", c.shownEdits().first().text.toString() == "A draft that must not be lost.")
    setDirection(a, Lang.KN, Lang.SA)
    a = Phone.restartApp(a); c = Phone.content(a)
    check("the chosen languages are remembered", c.hasText(Lang.KN.display) && c.hasText(Lang.SA.display) && App.translate.src == Lang.KN)
    tap(c, "Clear")
    check("Clear empties the box and the draft", c.shownEdits().first().text.toString().isEmpty() && App.translate.input.isEmpty())
    a = Phone.restartApp(a)
    check("…and a cleared box stays cleared after a restart", Phone.content(a).shownEdits().first().text.toString().isEmpty())

    // paste
    c = Phone.content(a)
    tap(c, "Paste")
    check("Paste with an empty clipboard says so", toasts().contains("Nothing to paste"))
    Context.clipboard.setPrimaryClip(android.content.ClipData.newPlainText("x", "ಕನ್ನಡ ಪಠ್ಯ"))
    tap(c, "Paste")
    check("Paste fills the box and the counter", c.shownEdits().first().text.toString() == "ಕನ್ನಡ ಪಠ್ಯ" && c.hasTextContaining("characters"))

    // turning the phone while a translation is running
    setDirection(a, Lang.EN, Lang.KN); typeInto(c.shownEdits().first(), "Knowledge is the supreme wealth.")
    Phone.hold(); tap(c, "Translate"); until("running") { App.translate.running }
    val b = Phone.rotate(a); val c2 = Phone.content(b)
    check("after turning the phone the running task is still shown, with Cancel", App.translate.running && c2.hasText("Cancel") && c2.shownEdits().first().text.toString() == "Knowledge is the supreme wealth.")
    Phone.release()
    check("…and the answer arrives on the new screen", until("answer") { !App.translate.running && App.translate.output.isNotBlank() } && c2.hasText(Phone.translationFor("Kannada")))
    check("…and was saved to the history once", until("hist") { App.store.history().size == 1 })

    // tab restored after turning
    Phone.tapTab(b, "History")
    val d = Phone.rotate(b)
    check("the open tab is restored after turning the phone", Phone.title(d) == "History")

    // the work keeps going while the user visits another tab
    Phone.tapTab(d, "Translate"); val c3 = Phone.content(d)
    Phone.hold(); tap(c3, "Run again"); until("running") { App.translate.running }
    Phone.tapTab(d, "Settings"); Phone.tapTab(d, "Translate")
    check("leaving the tab and returning shows the task still running", App.translate.running && Phone.content(d).hasText("Cancel"))
    Phone.release(); until("done") { !App.translate.running }
}

fun testUnicodeAndLongText() {
    section("UI — Unicode, IAST and Kannada exactness; long texts")
    Phone.fresh(); Phone.useMockModel(); val a = Phone.open()
    val c = Phone.content(a)

    // Kannada with joiners and conjuncts reaches the model code point for code point
    val kn = "ಕ್ಷೇತ್ರ ಜ್ಞಾನ ಅರ್ಕ‍ನ ಕ‌ಕ"
    translateVia(a, Lang.KN, Lang.EN, kn)
    check("Kannada text, with ZWJ and ZWNJ, reaches the model exactly", Phone.canned.segmentsSeen.last() == listOf(kn), Phone.canned.segmentsSeen.last().toString())

    // Sanskrit typed as IAST (with and without combining marks) is converted to Devanagari before translation
    val iast = "dharmakṣetre kurukṣetre samavetā yuyutsavaḥ"
    translateVia(a, Lang.SA, Lang.EN, iast)
    val dev = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः"
    check("Sanskrit typed in IAST reaches the model in Devanagari", Phone.canned.segmentsSeen.last() == listOf(dev), Phone.canned.segmentsSeen.last().toString())
    check("…and the report says the conversion was done", Phone.content(a).hasTextContaining("IAST") || Phone.content(a).hasTextContaining("converted"), Phone.content(a).shownTexts().filter { it.contains("onvert") }.toString())
    val nfd = java.text.Normalizer.normalize(iast, java.text.Normalizer.Form.NFD)
    check("(the test text really is in decomposed form)", nfd != iast && nfd.contains("̣") )
    translateVia(a, Lang.SA, Lang.EN, nfd)
    check("decomposed IAST gives the same Devanagari", Phone.canned.segmentsSeen.last() == listOf(dev), Phone.canned.segmentsSeen.last().toString())

    // Devanagari verse with dandas, avagraha and numerals is not altered on its way
    val verse = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥ २.४७ ॥"
    translateVia(a, Lang.SA, Lang.EN, verse)
    check("a verse with ।, ॥, ऽ and numerals reaches the model with every character intact", Phone.canned.segmentsSeen.last().joinToString("\n").replace("\n\n", "\n").contains("सङ्गोऽस्त्वकर्मणि ॥ २.४७ ॥") && Phone.canned.segmentsSeen.last().joinToString("\n").contains("।"), Phone.canned.segmentsSeen.last().toString())

    // a long text is cut into pieces, each is translated, nothing is lost or reordered
    val sentences = (1..60).map { "This is sentence number $it of a long test." }
    val long = sentences.chunked(5).joinToString("\n\n") { it.joinToString(" ") }
    val before = Phone.canned.segmentsSeen.size
    translateVia(a, Lang.EN, Lang.KN, long)
    val got = Phone.canned.segmentsSeen.drop(before).flatten()
    check("a long text was split into several pieces", got.size > 3, "pieces=${got.size}")
    check("…and the pieces together are exactly the original text, in order", got.joinToString(" ").replace(Regex("\\s+"), " ") == long.replace(Regex("\\s+"), " "), got.joinToString(" | ").take(200))
    check("…and the report says every segment was translated", Phone.content(a).hasTextContaining("segment(s) were translated"))
    check("…and paragraph breaks are kept (12 paragraphs)", Phone.content(a).hasTextContaining("Paragraph breaks preserved (12 paragraphs)"), Phone.content(a).shownTexts().filter { it.contains("aragraph") }.toString())
}

fun testRobustness() {
    section("UI — robustness: crash report, start-up failure, broken screens, keystore failure, damaged data")
    // a crash on the previous run is reported on the next start
    Phone.fresh(); Phone.useMockModel()
    java.io.File(Context.application.filesDir, "last_crash.txt").writeText("Tribhāṣā build test\nThread: main\n\njava.lang.IllegalStateException: boom")
    var a = Phone.open(saved = android.os.Bundle())
    check("a crash recorded last time is offered on the next start", dialogTitle() == "Tribhāṣā stopped unexpectedly last time" && dialogTexts().any { it.contains("IllegalStateException: boom") })
    tapDialog("Copy report")
    check("Copy report puts the whole report on the clipboard", clipboardText()!!.contains("IllegalStateException: boom"))
    check("the report file is removed once shown (no repeated dialogs)", !java.io.File(Context.application.filesDir, "last_crash.txt").exists())
    AlertDialog.top()?.dismiss()
    Phone.tapTab(a, "Settings"); tap(Phone.content(a), "Last error report")
    check("Settings → Last error report shows it again, with a Copy button", dialogTexts().any { it.contains("IllegalStateException: boom") } && AlertDialog.top()!!.getButton(AlertDialog.BUTTON_NEUTRAL).visibility == android.view.View.VISIBLE)
    AlertDialog.top()?.dismiss()

    // the app cannot write its settings: it still starts, and says why
    Phone.fresh()
    App.store.setPref("connect_asked", "yes")
    android.content.MemoryPrefs.failEdits = true
    // as in a new process: the app has not yet set itself up, and the very first write to its settings fails
    run { val f = App::class.java.getDeclaredField("initialised"); f.isAccessible = true; f.setBoolean(null, false) }
    val bad = MainActivity()
    bad.performCreate(android.os.Bundle().also { it.putInt("tab", 0) }); Looper.pump()
    check("if the main screen cannot be built, a readable report is shown instead of a silent close", Phone.decor(bad).hasText("Tribhāṣā could not start") && Phone.decor(bad).hasText("COPY REPORT") && Phone.decor(bad).hasTextContaining("disk full (test)"))
    tap(Phone.decor(bad), "COPY REPORT")
    check("…and the report can be copied", clipboardText()!!.contains("could not start") && clipboardText()!!.contains("disk full (test)"))
    android.content.MemoryPrefs.failEdits = false

    // one broken screen does not take the others down
    Phone.fresh(); a = Phone.open()
    val fs = org.tribhasa.app.ui.FailedScreen(a, "Test", RuntimeException("screen broke"))
    check("a screen that failed to start says so and offers the report", fs.view.hasTextContaining("could not start") && fs.view.hasText("Copy report"))
    tap(fs.view, "Copy report")
    check("…and its report names the build and the screen", clipboardText()!!.contains("Test") && clipboardText()!!.contains("screen broke"))

    // keystore failure: the key is still usable, and the screen tells the truth about how it is kept
    Phone.fresh()
    android.security.keystore.FakeAndroidKeyStoreProvider.broken = true
    App.store.setLlmKey("sk-fallback-KEY")
    check("with a broken keystore the key still works", App.store.credentials().llmKey == "sk-fallback-KEY")
    check("…but is recorded as NOT encrypted", App.store.llmKeyProtection() == org.tribhasa.app.Store.Protection.PRIVATE_STORAGE_ONLY)
    a = Phone.open(); Phone.tapTab(a, "Settings")
    check("…and the screen says it is not encrypted rather than claiming it is", Phone.content(a).hasTextContaining("NOT encrypted") && !Phone.content(a).hasTextContaining("encrypted on this phone"), Phone.content(a).shownTexts().filter { it.contains("crypt") }.toString())
    android.security.keystore.FakeAndroidKeyStoreProvider.broken = false

    // damaged stored secret: treated as not set, no crash
    Phone.fresh()
    Context.application.getSharedPreferences("tribhasa", 0).edit().putString("s_llm_key", "this-is-not-valid-ciphertext").apply()
    a = Phone.open(); Phone.tapTab(a, "Settings")
    check("an unreadable saved key is treated as not set (no crash)", !App.store.credentials().hasLlm && Phone.content(a).hasTextContaining("Not connected yet"))

    // damaged history and glossary files are not fatal, and the history file is set aside rather than overwritten
    Phone.fresh(); Phone.useMockModel()
    java.io.File(Context.application.filesDir, "history.json").writeText("{this is not json")
    Context.application.getSharedPreferences("tribhasa", 0).edit().putString("glossary", "garbage").apply()
    a = Phone.open(); Phone.tapTab(a, "History"); Phone.tapTab(a, "Glossary"); Phone.tapTab(a, "Translate")
    translateVia(a, Lang.EN, Lang.KN, "Knowledge is the supreme wealth.")
    until("saved") { Context.application.filesDir.listFiles()!!.any { it.name.startsWith("history.unreadable-") } }
    check("a damaged history file is set aside, not overwritten, and a fresh history starts", Context.application.filesDir.listFiles()!!.any { it.name.startsWith("history.unreadable-") } && until("h") { App.store.history().size == 1 })

}

fun main() {
    try {
        for ((name, f) in SCENARIOS) {
            try { f() } catch (e: Throwable) {
                failed++; failures.add("scenario “$name” stopped: $e")
                println("  FAIL scenario “$name” stopped with an exception:"); e.printStackTrace(System.out)
            }
        }
    } finally { Phone.mock.stop() }
    println("\n=============================")
    println("UI PASSED: $passed   FAILED: $failed")
    if (failed > 0) { println("Failures:"); failures.forEach { println(" - $it") }; exitProcess(1) }
    exitProcess(0)
}
