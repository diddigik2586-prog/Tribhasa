#!/bin/bash
# Builds the fake Android framework (JVM stand-ins used only by the headless UI tests; never part of the APK).
set -e
D=$(cd "$(dirname "$0")" && pwd)
rm -rf "$D/src" "$D/classes"; mkdir -p "$D/classes"
for b in "$D"/bundle*.java.txt; do python3 "$D/split.py" "$b" "$D/src"; done
javac -nowarn -d "$D/classes" $(find "$D/src" -name '*.java') 2>&1 | grep -v "Picked up" || true
test -f "$D/classes/android/app/Activity.class"
