#!/usr/bin/env python3
"""Splits a bundle of Java sources (marked by '//// path/File.java' lines) into separate files under the output directory."""
import sys, os
src, out = sys.argv[1], sys.argv[2]
cur = None; buf = []
def flush():
    if cur is not None:
        p = os.path.join(out, cur); os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, 'w', encoding='utf-8').write(''.join(buf))
for line in open(src, encoding='utf-8'):
    if line.startswith('//// '):
        flush(); cur = line[5:].strip(); buf = []
    else:
        buf.append(line)
flush()
