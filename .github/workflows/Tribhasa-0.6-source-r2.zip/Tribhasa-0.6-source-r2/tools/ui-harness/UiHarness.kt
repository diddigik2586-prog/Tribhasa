import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Looper
import android.security.keystore.FakeAndroidKeyStoreProvider
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.tribhasa.app.App
import org.tribhasa.app.MainActivity
import org.tribhasa.app.core.AiSource
import org.tribhasa.app.core.Lang
import org.tribhasa.app.core.LocalModels
import org.tribhasa.app.local.DeviceInfo
import org.tribhasa.app.local.DownloadKeepAlive
import org.tribhasa.app.local.HarnessEngine

/*
 * Headless UI harness.
 *
 * The app's real screens (the same Kotlin files that go into the APK) are run on the JVM against fake Android classes in
 * tests/fakeandroid. The test thread plays the Android main thread; any view touched from another thread fails loudly.
 * The "model" is a mock HTTPS server that returns canned answers: these tests prove that the screens, the wiring,
 * the storage and the error handling work. They say NOTHING about the quality of a real model's translations.
 */

// ------------------------------------------------------------------ looking at the screen
fun View.all(): Sequence<View> = sequence {
    yield(this@all)
    if (this@all is ViewGroup) for (i in 0 until childCount) yieldAll(getChildAt(i).all())
}

fun View.shownTexts(): List<String> = all().filter { it.isShown }.mapNotNull { (it as? TextView)?.text?.toString() }.filter { it.isNotEmpty() }.toList()
fun View.hasText(t: String): Boolean = shownTexts().any { it == t }
fun View.hasTextContaining(t: String): Boolean = shownTexts().any { it.contains(t) }
fun View.countText(t: String): Int = shownTexts().count { it == t }
fun View.shownEdits(): List<EditText> = all().filter { it.isShown }.filterIsInstance<EditText>().toList()

/** The nearest tappable view at or above a text, as a finger would reach it. */
private fun tappable(v: View): View? {
    var x: View? = v
    while (x != null) { if (x.isEnabled && x.hasOnClickListeners() && x.isShown) return x; x = x.parent }
    return null
}

fun View.tapTargets(text: String, contains: Boolean = false): List<View> =
    all().filter { it is TextView && it.isShown && (it.text.toString().let { s -> if (contains) s.contains(text) else s == text }) }.mapNotNull { tappable(it) }.toList()

/** Taps the first tappable view whose text is [text] inside [root]. Fails with what is on screen if there is none. */
fun tap(root: View, text: String, contains: Boolean = false, last: Boolean = false, nth: Int = 0) {
    val all = root.tapTargets(text, contains)
    val t = (if (last) all.lastOrNull() else all.getOrNull(nth))
        ?: throw AssertionError("nothing tappable says “$text”. On screen: ${root.shownTexts().map { it.take(40) }.take(60)}")
    t.performClick()
    Looper.pump()
}

/** Taps a row or button in the dialog that is open on top. */
fun tapDialog(text: String, contains: Boolean = false) {
    val d = AlertDialog.top() ?: throw AssertionError("no dialog is open")
    val v = d.contentView()
    val t = v?.tapTargets(text, contains)?.firstOrNull()
    if (t != null) { t.performClick(); Looper.pump(); return }
    val which = listOf(AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL).firstOrNull { w ->
        val b = d.getButton(w); b != null && b.visibility == View.VISIBLE && b.text.toString() == text
    } ?: throw AssertionError("the open dialog (“${d.title()}”) has no “$text”. Its text: ${v?.shownTexts()?.map { it.take(40) }}")
    d.tap(which)
    Looper.pump()
}

fun dialogTitle(): String? = AlertDialog.top()?.title()?.toString()
fun dialogTexts(): List<String> = AlertDialog.top()?.contentView()?.shownTexts() ?: emptyList()
fun dialogMessage(): String = AlertDialog.top()?.message()?.toString() ?: ""
fun toasts(): List<String> = synchronized(Toast.shown) { Toast.shown.toList() }
fun clipboardText(): String? = Context.clipboard.primaryClip?.getItemAt(0)?.coerceToText(null)?.toString()

/** Waits (running whatever the app posts to its main thread) until the condition holds. */
fun until(what: String, ms: Long = 8000, cond: () -> Boolean): Boolean {
    val ok = Looper.pumpUntil(cond, ms)
    if (!ok) println("  (timed out waiting for: $what)")
    return ok
}

fun waitIdle(ms: Long = 8000): Boolean = until("all tasks to finish", ms) {
    !App.translate.running && !App.refine.running && !App.analyse.running && !App.compare.running && !App.connect.running
}

// ------------------------------------------------------------------ the phone
object Phone {
    val mock = Mock(tls = true)
    private var started = false

    /** A model reply with no real model behind it: one canned translation per segment, canned JSON for the scholarly tasks. */
    class Canned {
        val translatedInto = java.util.concurrent.CopyOnWriteArrayList<String>()
        val segmentsSeen = java.util.concurrent.CopyOnWriteArrayList<List<String>>()
        val systems = java.util.concurrent.CopyOnWriteArrayList<String>()
        val users = java.util.concurrent.CopyOnWriteArrayList<String>()
        var refinedText = "The colour of the centre was analysed."
    }
    val canned = Canned()

    fun translationFor(target: String) = when (target) {
        "Kannada" -> "ಇದು ಒಂದು ಪರೀಕ್ಷಾ ಅನುವಾದ."
        "Sanskrit" -> "इदं परीक्षणानुवादः ।"
        else -> "This is a test translation."
    }

    fun smartReply(req: Req): Resp {
        val sys = systemPrompt(req); val usr = userPrompt(req)
        canned.systems.add(sys); canned.users.add(usr)
        fun segs(u: String): JSONArray = JSONArray(u.substringAfterLast("segments: ").substringAfterLast("segments to edit: "))
        return when {
            sys.contains("expert translator") -> {
                val tgt = Regex("into (\\w+)\\.").find(sys)!!.groupValues[1]
                val sg = segs(usr)
                canned.translatedInto.add(tgt); canned.segmentsSeen.add((0 until sg.length()).map { sg.getString(it) })
                val out = JSONArray(); for (i in 0 until sg.length()) out.put(translationFor(tgt))
                llmText(JSONObject().put("translations", out).toString())
            }
            sys.contains("polish Kannada translations") -> llmText(JSONObject().put("segments", segs(usr)).toString())
            sys.startsWith("You edit a") -> llmText(JSONObject().put("segments", segs(usr)).toString())
            sys.contains("analyse one Sanskrit verse") -> llmText(GITA_JSON)
            sys.contains("analyse a passage of Sanskrit prose") -> llmText(PROSE_JSON)
            sys.contains("modern explanatory commentary") -> llmText(COMMENTARY_JSON)
            sys.contains("\"corrected\": \"<the full corrected text") -> llmText(EXPLAIN_JSON)
            sys.contains("\"alternatives\"") -> llmText(ALTERNATIVES_JSON)
            sys.contains("\"overall\"") -> llmText(GRAMMAR_JSON)
            sys.contains("Return ONLY the") -> llmText(canned.refinedText)
            sys.contains("reply with the single word") || usr.contains("single word: ready") -> llmText("ready")
            else -> Resp(500, """{"error":{"message":"the test's mock model does not know this prompt: ${sys.take(60).replace("\"", "'")}"}}""")
        }
    }

    /** The canned answer the mock model would give to this prompt, as plain text (used to script the on-device engine). */
    fun cannedText(sys: String, usr: String): String {
        val body = JSONObject().put("messages", JSONArray()
            .put(JSONObject().put("role", "system").put("content", sys))
            .put(JSONObject().put("role", "user").put("content", usr))).toString()
        val r = smartReply(Req("POST", CHAT, emptyMap(), body))
        if (r.code != 200) return "NO CANNED ANSWER: ${r.body.take(120)}"
        return JSONObject(r.body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    /** A new install of the app on a new phone, with the mock model not yet switched on. */
    fun fresh() {
        if (!started) { started = true; FakeAndroidKeyStoreProvider.install(); TestTls.trustInClient() }
        Looper.pump()
        Looper.bindMainThreadToCurrent()
        Context.resetWorld()
        AlertDialog.reset()
        synchronized(Toast.shown) { Toast.shown.clear() }
        View.visibleBottom = 2400
        FakeAndroidKeyStoreProvider.broken = false
        FakeAndroidKeyStoreProvider.forgetKeys()
        mock.reset()
        // the model on this phone: no engine, a normal phone, the real model's description, nothing downloaded
        LocalModels.active = LocalModels.GEMMA4_E2B
        HarnessEngine.delegate = null
        DeviceInfo.reset()
        DownloadKeepAlive.events.clear()
        canned.translatedInto.clear(); canned.segmentsSeen.clear(); canned.systems.clear(); canned.users.clear(); canned.refinedText = "The colour of the centre was analysed."
        release()
        mock.on("POST", CHAT) { gate?.await(15, java.util.concurrent.TimeUnit.SECONDS); smartReply(it) }
        App.resetForTests(Context.application)
    }

    /** While held, the mock model does not answer, so the test can look at the screen while the app is waiting. */
    @Volatile private var gate: java.util.concurrent.CountDownLatch? = null
    fun hold() { gate = java.util.concurrent.CountDownLatch(1) }
    fun release() { gate?.countDown(); gate = null }
    /** Replaces the mock model's behaviour (for error cases). */
    fun respondWith(h: (Req) -> Resp) { mock.on("POST", CHAT) { gate?.await(15, java.util.concurrent.TimeUnit.SECONDS); h(it) } }
    fun requests() = mock.count("POST", CHAT)

    /** The scholar has saved a key by hand (Settings → Advanced) and pointed the app at the mock model. */
    fun useMockModel(key: String = "sk-or-test-KEY-123456") {
        App.store.setAiSource(AiSource.ONLINE)   // these scenarios test the optional online route
        App.store.setLlmKey(key); App.store.setLlmModel(MODEL); App.store.setLlmBase(mock.base + "/api/v1")
    }

    /** Opens the app. With [intro] = false the splash and the one-time Connect question are skipped, as on a later start. */
    fun open(saved: Bundle? = null, intent: Intent? = null, intro: Boolean = false): MainActivity {
        if (!intro) { App.store.setPref("connect_asked", "yes"); App.store.setPref("local_asked", "yes") }
        val a = MainActivity()
        if (intent != null) a.intent = intent
        a.performCreate(saved ?: if (intro) null else Bundle().also { it.putInt("tab", 0) })
        Looper.pump()
        return a
    }

    /** The app is closed and started again later: memory is gone; saved settings, glossary and history stay. */
    fun restartApp(a: MainActivity?): MainActivity {
        if (a != null) { a.performPause(); a.performDestroy() }
        Looper.pump()
        App.resetForTests(Context.application)
        return open()
    }

    /** What happens to the activity when the phone is turned: state saved, activity destroyed, a new one made. */
    fun rotate(a: MainActivity): MainActivity {
        a.performPause()
        val st = a.performSaveInstanceState()
        a.performDestroy()
        return open(saved = st)
    }

    private fun field(a: Activity, name: String): Any {
        val f = a.javaClass.getDeclaredField(name); f.isAccessible = true; return f.get(a)!!
    }
    fun content(a: MainActivity): View = field(a, "content") as View
    fun nav(a: MainActivity): View = field(a, "nav") as View
    fun footer(a: MainActivity): View = field(a, "footer") as View
    fun root(a: MainActivity): View = field(a, "root") as View
    fun compare(a: MainActivity): View? { val f = a.javaClass.getDeclaredField("comparePanel"); f.isAccessible = true; return f.get(a) as View? }
    fun decor(a: Activity): View = a.window.decorView
    fun title(a: MainActivity): String = (field(a, "titleView") as TextView).text.toString()
    fun fireLayout(a: MainActivity) = root(a).viewTreeObserver.fireLayout()

    fun tabs() = listOf("Translate", "Refine", "Analyse", "Glossary", "History", "Settings")
    fun tapTab(a: MainActivity, label: String) = tap(nav(a), label)
}

/** Shorthand for typing into the one text box on the current screen. */
fun typeInto(box: EditText, text: String) { box.setText(text); Looper.pump() }

fun Lang.pill() = display

/** Translates through the real screen and returns the output. */
fun translateVia(a: MainActivity, src: Lang, tgt: Lang, text: String): String {
    Phone.tapTab(a, "Translate"); val c = Phone.content(a)
    setDirection(a, src, tgt); typeInto(c.shownEdits().first(), text)
    tap(c, "Translate"); until("translation") { !App.translate.running && App.translate.output.isNotBlank() }
    return App.translate.output
}

/** Chooses the languages the way the user does: tap the pill, tap the language in the chooser. */
fun setDirection(a: MainActivity, src: Lang, tgt: Lang) {
    val c = Phone.content(a); val m = App.translate
    if (m.src != src) { tap(c, m.src.display); tapDialog(src.english) }
    if (m.tgt != tgt) { tap(c, m.tgt.display); tapDialog(tgt.english) }
}
