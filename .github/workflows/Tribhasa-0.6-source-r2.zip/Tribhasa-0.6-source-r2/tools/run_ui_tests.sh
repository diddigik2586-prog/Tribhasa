#!/bin/bash
# Runs the app's real screens (the Kotlin files that go into the APK) on the JVM against fake Android classes,
# with a mock HTTPS "model" server and a fake on-device engine. See tools/ui-harness/UiHarness.kt.
# This is NOT a test on a phone or emulator.
set -e
P=$(cd "$(dirname "$0")/.." && pwd); T=${TRIBHASA_TOOLCHAIN:-$P/../toolchain}; T=$(cd "$T" && pwd)
SRC=$P/android/app/src; O=$P/build/jvm-ui
FAKES=$P/tools/ui-harness/fakeandroid
rm -rf "$O"; mkdir -p "$O/gen" "$O/rcls" "$O/app" "$O/tests"
bash "$FAKES/build_fakes.sh"
$T/aapt2 compile --dir "$SRC/main/res" -o "$O/res.zip"
# Gradle takes the package name from `namespace` in app/build.gradle.kts; aapt2 used on its own needs it written into the manifest, so a copy gets it.
sed 's|<manifest |<manifest package="org.tribhasa.app" |' "$SRC/main/AndroidManifest.xml" > "$O/AndroidManifest.xml"
$T/aapt2 link -o "$O/base.apk" -I "$T/android-34.jar" --manifest "$O/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 34 --java "$O/gen" "$O/res.zip"
javac -nowarn -d "$O/rcls" $(find "$O/gen" -name '*.java') 2>&1 | grep -v "Picked up" || true
CP="$FAKES/classes:$T/jsonclasses:$O/rcls"
# Three files need the real Android system or Google's native library and are replaced by stand-ins with the same names
# (tools/ui-harness/fakes): LiteRtEngineFactory.kt (the model engine), DeviceInfo.kt (memory, storage, connection) and
# DownloadService.kt (the foreground service). Those three can only be exercised on a phone.
$T/kotlinc/bin/kotlinc -jvm-target 21 -nowarn -cp "$CP" -d "$O/app" \
  $(find "$SRC/main/kotlin" -name '*.kt' -not -name 'LiteRtEngineFactory.kt' -not -name 'DeviceInfo.kt' -not -name 'DownloadService.kt') \
  $(find "$P/tools/ui-harness/fakes" -name '*.kt') 2>&1 | grep -v JAVA_TOOL || true
test -f "$O/app/org/tribhasa/app/MainActivity.class" || { echo "COMPILE FAILED (app against fake framework)"; exit 1; }
$T/kotlinc/bin/kotlinc -jvm-target 21 -nowarn -cp "$CP:$O/app" -d "$O/tests" "$SRC/test/kotlin/Support.kt" "$P/tools/ui-harness/UiHarness.kt" "$P/tools/ui-harness/UiTests.kt" "$P/tools/ui-harness/LocalUiTests.kt" 2>&1 | grep -v JAVA_TOOL || true
test -f "$O/tests/UiTestsKt.class" || { echo "COMPILE FAILED (UI tests)"; exit 1; }
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 \
  -cp "$O/tests:$O/app:$CP:$T/kotlinc/lib/kotlin-stdlib.jar" UiTestsKt 2>&1 | grep -v JAVA_TOOL
