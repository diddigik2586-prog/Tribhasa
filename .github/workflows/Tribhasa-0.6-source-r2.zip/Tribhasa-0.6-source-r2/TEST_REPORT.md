# Test report

The current report is [`docs/TEST_REPORT_0.6.md`](docs/TEST_REPORT_0.6.md). The report for version 0.5 is kept in
[`docs/history/TEST_REPORT_0.5.md`](docs/history/TEST_REPORT_0.5.md).
