import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Lets Gradle's unit-test task (:app:testDebugUnitTest) run the same core checks that tools/run_tests.sh runs on a computer.
 * All the checks are in CoreTests.kt, LocalTests.kt and Support.kt; this only calls them and fails if any check failed.
 * The checks use stand-ins for the network and for the model engine. They do not run the real model.
 */
class GradleCoreTest {
    @Test
    fun everyCoreCheckPasses() {
        assertEquals("number of failed core checks (see the log above for which)", 0, runAllCoreTests())
    }
}
