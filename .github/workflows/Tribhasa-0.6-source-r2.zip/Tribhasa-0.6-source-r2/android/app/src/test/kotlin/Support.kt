import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import org.json.JSONArray
import org.json.JSONObject
import org.tribhasa.app.core.*
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ProxySelector
import java.net.SocketAddress
import java.net.URI
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.exitProcess

// ------------------------------------------------------------------ tiny test framework
var passed = 0
var failed = 0
val failures = ArrayList<String>()
fun check(name: String, cond: Boolean, extra: String = "") {
    if (cond) { passed++; println("  ok   $name") } else { failed++; failures.add(name); println("  FAIL $name  $extra") }
}
fun section(s: String) = println("\n== $s")
inline fun <reified T : Throwable> expectThrows(name: String, block: () -> Unit): T? {
    return try { block(); check(name, false, "no exception"); null } catch (e: Throwable) {
        if (e is T) { check(name, true); e } else { check(name, false, "wrong exception: $e"); null }
    }
}

// ------------------------------------------------------------------ mock server
class Req(val method: String, val path: String, val headers: Map<String, String>, val body: String)
class Resp(val code: Int, val body: String, val headers: Map<String, String> = emptyMap())

class Mock(private val tls: Boolean = false) {
    private val server: HttpServer = if (tls) TestTls.server() else HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    val handlers = ConcurrentHashMap<String, (Req) -> Resp>()
    val hits = ConcurrentHashMap<String, AtomicInteger>()
    val requests = ConcurrentHashMap<String, MutableList<Req>>()
    init {
        server.createContext("/") { ex: HttpExchange ->
            val body = ex.requestBody.readBytes().toString(Charsets.UTF_8)
            val hdr = HashMap<String, String>()
            for ((k, v) in ex.requestHeaders) hdr[k.lowercase()] = v.joinToString(",")
            val path = ex.requestURI.path
            val key = ex.requestMethod + " " + path
            hits.computeIfAbsent(key) { AtomicInteger() }.incrementAndGet()
            val req = Req(ex.requestMethod, path, hdr, body)
            requests.computeIfAbsent(key) { java.util.Collections.synchronizedList(ArrayList()) }.add(req)
            val h = handlers[key]
            val r = if (h == null) Resp(404, """{"error":{"message":"no handler for $key"}}""") else try { h(req) } catch (e: Exception) { Resp(500, "{\"error\":\"${e}\"}") }
            val bytes = r.body.toByteArray(Charsets.UTF_8)
            for ((k, v) in r.headers) ex.responseHeaders.add(k, v)
            ex.responseHeaders.add("Content-Type", "application/json; charset=utf-8")
            ex.sendResponseHeaders(r.code, if (bytes.isEmpty()) -1 else bytes.size.toLong())
            if (bytes.isNotEmpty()) ex.responseBody.use { it.write(bytes) } else ex.responseBody.close()
        }
        server.executor = java.util.concurrent.Executors.newCachedThreadPool { r -> Thread(r, "mock-http").also { it.isDaemon = true } }
        server.start()
    }
    val base get() = (if (tls) "https" else "http") + "://127.0.0.1:${server.address.port}"
    fun on(method: String, path: String, h: (Req) -> Resp) { handlers["$method $path"] = h }
    fun count(method: String, path: String) = hits["$method $path"]?.get() ?: 0
    fun last(method: String, path: String) = requests["$method $path"]?.lastOrNull()
    fun stop() = server.stop(0)
    fun reset() { handlers.clear(); hits.clear(); requests.clear() }
}

val NO_WAIT = RetryPolicy(maxAttempts = 3, baseDelayMs = 1000, sleeper = { })

const val B_CONFIG = "/ulca/apis/v0/model/getModelsPipeline"
const val B_COMPUTE = "/services/inference/pipeline"
const val CF_IT2 = "/client/v4/accounts/ACC/ai/run/@cf/ai4bharat/indictrans2-en-indic-1B"
const val CHAT = "/api/v1/chat/completions"
const val OR_MODELS = "/api/v1/models"
const val OR_KEY = "/api/v1/key"
const val MODEL = "test/open-model:free"

fun llmText(text: String, finish: String = "stop", model: String = MODEL, tokens: Int = 20) = Resp(200, JSONObject()
    .put("id", "gen-1").put("model", model)
    .put("choices", JSONArray().put(JSONObject().put("index", 0).put("finish_reason", finish)
        .put("message", JSONObject().put("role", "assistant").put("content", text))))
    .put("usage", JSONObject().put("prompt_tokens", 10).put("completion_tokens", tokens)).toString())

fun userPrompt(req: Req): String = JSONObject(req.body).getJSONArray("messages").getJSONObject(1).getString("content")
fun systemPrompt(req: Req): String = JSONObject(req.body).getJSONArray("messages").getJSONObject(0).getString("content")

/**
 * A throw-away HTTPS server certificate for 127.0.0.1, made with the JDK's keytool at test time (nothing is stored in the project).
 * The app refuses non-https model addresses, so the UI tests must talk to the mock over TLS like the real service.
 */
object TestTls {
    private val dir: java.io.File by lazy { java.nio.file.Files.createTempDirectory("tribhasa-tls").toFile().also { it.deleteOnExit() } }
    private val pass = "changeit".toCharArray()
    private val ks: java.security.KeyStore by lazy {
        val f = java.io.File(dir, "k.p12")
        // The keytool of the JDK that is running the tests; the bare name (found through PATH) is only the fallback.
        val kt = java.io.File(System.getProperty("java.home"), "bin/keytool").let { if (it.canExecute()) it.path else "keytool" }
        val p = ProcessBuilder(kt, "-genkeypair", "-alias", "t", "-keyalg", "RSA", "-keysize", "2048", "-storetype", "PKCS12", "-keystore", f.path,
            "-storepass", "changeit", "-keypass", "changeit", "-dname", "CN=127.0.0.1", "-validity", "2", "-ext", "SAN=ip:127.0.0.1,dns:localhost")
            .redirectErrorStream(true).start()
        val out = p.inputStream.readBytes().toString(Charsets.UTF_8)
        check(p.waitFor() == 0) { "keytool failed: $out" }
        java.security.KeyStore.getInstance("PKCS12").also { k -> f.inputStream().use { k.load(it, pass) } }
    }
    private val ctx: javax.net.ssl.SSLContext by lazy {
        val kmf = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm()).also { it.init(ks, pass) }
        val tmf = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm()).also { it.init(ks) }
        javax.net.ssl.SSLContext.getInstance("TLS").also { it.init(kmf.keyManagers, tmf.trustManagers, null) }
    }
    fun server(): HttpServer {
        val s = com.sun.net.httpserver.HttpsServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        s.httpsConfigurator = com.sun.net.httpserver.HttpsConfigurator(ctx)
        return s
    }
    /** Makes this JVM's HTTPS client trust only the test certificate (loopback only). */
    fun trustInClient() {
        javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(ctx.socketFactory)
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier { host, _ -> host == "127.0.0.1" }
    }
}

// ------------------------------------------------------------------ test doubles for the on-device model
/**
 * An HTTPS server for one file, with Range support, that can misbehave on purpose.
 * Used to test the model download without a real 2.6 GB file and without the internet.
 */
class BlobServer(val data: ByteArray) {
    private val server = TestTls.server()
    /** Every request answered: the Range header (or "") and the status sent. */
    val log = java.util.concurrent.CopyOnWriteArrayList<Pair<String, Int>>()
    @Volatile var ignoreRange = false
    @Volatile var failNext = 0                  // answer 503 this many times first
    @Volatile var status: Int? = null           // answer this status (404, 403 ...) with no body
    @Volatile var dropAfter = -1L               // close the connection after this many body bytes ...
    @Volatile var dropTimes = 0                 // ... this many times
    @Volatile var chunkDelayMs = 0L             // pause after each 64 KiB sent (to leave time to cancel)
    @Volatile var announceLength: Long? = null  // announce this length instead of the true one
    @Volatile var contentRangeStartShift = 0L   // lie about where a 206 starts
    init {
        server.createContext("/model.bin") { ex ->
            val range = ex.requestHeaders.getFirst("Range") ?: ""
            fun reply(code: Int, len: Long, headers: Map<String, String> = emptyMap()) {
                log.add(range to code)
                for ((k, v) in headers) ex.responseHeaders.add(k, v)
                ex.sendResponseHeaders(code, len)
            }
            if (failNext > 0) { failNext--; reply(503, -1, mapOf("Retry-After" to "0")); ex.close(); return@createContext }
            status?.let { reply(it, -1); ex.close(); return@createContext }
            val from = if (ignoreRange) 0L else Regex("bytes=(\\d+)-").find(range)?.groupValues?.get(1)?.toLong() ?: 0L
            if (from >= data.size) { reply(416, -1, mapOf("Content-Range" to "bytes */${data.size}")); ex.close(); return@createContext }
            val partial = from > 0
            val sendLen = (data.size - from)
            if (partial) reply(206, announceLength ?: sendLen, mapOf("Content-Range" to "bytes ${from + contentRangeStartShift}-${data.size - 1}/${data.size}"))
            else reply(200, announceLength ?: sendLen)
            var sent = 0L
            try {
                val out = ex.responseBody
                var pos = from.toInt()
                while (pos < data.size) {
                    val n = minOf(65536, data.size - pos)
                    out.write(data, pos, n); out.flush(); pos += n; sent += n
                    if (dropTimes > 0 && dropAfter in 0..sent) { dropTimes--; ex.close(); return@createContext }
                    if (chunkDelayMs > 0) Thread.sleep(chunkDelayMs)
                }
                out.close()
            } catch (_: Exception) { try { ex.close() } catch (_: Exception) {} }
        }
        server.executor = java.util.concurrent.Executors.newCachedThreadPool { r -> Thread(r, "blob-http").also { it.isDaemon = true } }
        server.start()
    }
    val url get() = "https://127.0.0.1:${server.address.port}/model.bin"
    fun stop() = server.stop(0)
}

/** A small deterministic "model file" for tests, its size and its real SHA-256. */
class TestBlob(size: Int = 3_000_000) {
    val data = ByteArray(size).also { java.util.Random(42).nextBytes(it) }
    val sha256: String = java.security.MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { String.format("%02x", it) }
    fun spec(url: String, sha: String = sha256, size: Long = data.size.toLong()) = LocalModels.GEMMA4_E2B.copy(
        id = "test-model", name = "Test model", shortName = "Test model", fileName = "test-model.litertlm", url = url,
        sizeBytes = size, sha256 = sha, contextTokens = 4096)
}

/** A stand-in for the library that runs the model: streams a scripted answer, and can fail or stall on purpose. */
class FakeNativeFactory : NativeEngineFactory {
    @Volatile var failLoad: NativeFailure? = null
    @Volatile var failGpuLoad: NativeFailure? = null
    @Volatile var failLoadRaw: Throwable? = null
    @Volatile var loadDelayMs = 0L
    @Volatile var answer: (String, String) -> String = { _, _ -> "A test answer from the fake on-device model." }
    @Volatile var pieceChars = 4
    @Volatile var pieceDelayMs = 0L
    @Volatile var errorAfterPieces = -1
    @Volatile var errorToSend: NativeFailure = NativeFailure(NativeFailure.Kind.OTHER, "engine error")
    @Volatile var silent = false
    val opens = AtomicInteger(); val starts = AtomicInteger(); val cancels = AtomicInteger()
    val enginesClosed = AtomicInteger(); val turnsClosed = AtomicInteger()
    val running = AtomicInteger(); val maxRunning = AtomicInteger()
    val backendsOpened = java.util.concurrent.CopyOnWriteArrayList<LocalBackend>()
    val requestsSeen = java.util.concurrent.CopyOnWriteArrayList<Triple<String, String, Int>>()

    override fun open(modelPath: String, backend: LocalBackend, contextTokens: Int, cacheDir: String): NativeEngine {
        opens.incrementAndGet(); backendsOpened.add(backend)
        if (loadDelayMs > 0) Thread.sleep(loadDelayMs)
        if (backend == LocalBackend.GPU) failGpuLoad?.let { throw it }
        failLoad?.let { throw it }
        failLoadRaw?.let { throw it }
        return object : NativeEngine {
            override fun start(system: String, user: String, maxOutputTokens: Int, temperature: Double, listener: NativeListener): NativeTurn {
                starts.incrementAndGet(); requestsSeen.add(Triple(system, user, maxOutputTokens))
                val cancelled = java.util.concurrent.atomic.AtomicBoolean(false)
                val n = running.incrementAndGet(); maxRunning.updateAndGet { maxOf(it, n) }
                val worker = Thread {
                    // "running" goes down before the end is announced, so a task that starts right afterwards is not counted as overlapping.
                    val ended = java.util.concurrent.atomic.AtomicBoolean(false)
                    fun end(): Boolean = ended.compareAndSet(false, true).also { if (it) running.decrementAndGet() }
                    try {
                        if (silent) { while (!cancelled.get()) Thread.sleep(20); end(); listener.onError(NativeFailure(NativeFailure.Kind.CANCELLED, "cancelled")); return@Thread }
                        val full = answer(system, user)
                        var i = 0; var pieces = 0
                        while (i < full.length) {
                            if (cancelled.get()) { end(); listener.onError(NativeFailure(NativeFailure.Kind.CANCELLED, "cancelled")); return@Thread }
                            if (pieces >= maxOutputTokens) break
                            if (errorAfterPieces in 0..pieces) { end(); listener.onError(errorToSend); return@Thread }
                            val e = minOf(full.length, i + pieceChars)
                            listener.onPiece(full.substring(i, e)); i = e; pieces++
                            if (pieceDelayMs > 0) Thread.sleep(pieceDelayMs)
                        }
                        end(); listener.onDone()
                    } finally { end() }
                }
                worker.isDaemon = true; worker.start()
                return object : NativeTurn {
                    override fun cancel() { cancels.incrementAndGet(); cancelled.set(true) }
                    override fun close() { turnsClosed.incrementAndGet() }
                }
            }
            override fun close() { enginesClosed.incrementAndGet() }
        }
    }
}

// Canned answers of a mock model, shaped like the JSON the app asks for (used by the core and the UI tests).
val GITA_JSON = """
{"verse_devanagari":"धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः । मामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥",
 "padaccheda":["धर्म-क्षेत्रे कुरु-क्षेत्रे समवेताः युयुत्सवः","मामकाः पाण्डवाः च एव किम् अकुर्वत सञ्जय"],
 "words":[
  {"word":"धर्मक्षेत्रे","pratipadartha":"in the field of dharma","lemma":"धर्मक्षेत्र","category":"noun","vibhakti":"saptamī","vacana":"ekavacana","linga":"napuṃsakaliṅga","verb_info":"","relation":"adhikaraṇa","confidence":"certain","note":""},
  {"word":"कुरुक्षेत्रे","pratipadartha":"in Kurukṣetra","lemma":"कुरुक्षेत्र","category":"noun","vibhakti":"saptamī","vacana":"ekavacana","linga":"napuṃsakaliṅga","verb_info":"","relation":"adhikaraṇa","confidence":"certain","note":""},
  {"word":"समवेताः","pratipadartha":"assembled","lemma":"समवेत","category":"participle/kṛdanta","vibhakti":"prathamā","vacana":"bahuvacana","linga":"puṃliṅga","verb_info":"सम्-अव-√इ, kta","relation":"viśeṣaṇa of युयुत्सवः","confidence":"probable","note":""},
  {"word":"युयुत्सवः","pratipadartha":"desiring to fight","lemma":"युयुत्सु","category":"adjective","vibhakti":"prathamā","vacana":"bahuvacana","linga":"puṃliṅga","verb_info":"","relation":"kartā","confidence":"certain","note":""},
  {"word":"अकुर्वत","pratipadartha":"did","lemma":"कृ","category":"verb","vibhakti":"","vacana":"","linga":"","verb_info":"√कृ (tanādi, ubhayapadī), laṅ, ātmanepada, prathama-puruṣa, bahuvacana","relation":"kriyā","confidence":"uncertain","note":"form of the root needs checking"}
 ],
 "samasa":[{"compound":"धर्मक्षेत्रे","type":"ṣaṣṭhī-tatpuruṣa","vigraha":"धर्मस्य क्षेत्रम्","meaning":"field of dharma","confidence":"certain"}],
 "anvaya":"सञ्जय, धर्मक्षेत्रे कुरुक्षेत्रे समवेताः युयुत्सवः मामकाः पाण्डवाः च एव किम् अकुर्वत ।",
 "bhavartha":"Dhṛtarāṣṭra asks what his sons and the Pāṇḍavas did when assembled on the field.",
 "tatparya":"The question opens the narrative.",
 "chandas":{"name":"Anuṣṭubh","evidence":"8 syllables per pāda; 5th laghu, 6th guru","confidence":"probable"},
 "alankara":[],
 "translation":"On the field of dharma, on the field of the Kurus, what did my sons and the Pāṇḍavas do, assembled and eager to fight, Sañjaya?",
 "uncertainties":["The reading of 'अकुर्वत' as ātmanepada should be confirmed."]}
""".trimIndent()

const val PROSE_JSON = """{"sentences":[{"text":"रामः वनं गच्छति ।","words":[{"word":"रामः","pratipadartha":"Rāma","lemma":"राम","category":"noun","vibhakti":"prathamā","vacana":"ekavacana","linga":"puṃliṅga","verb_info":"","relation":"kartā","confidence":"certain","note":""},{"word":"वनम्","pratipadartha":"forest","lemma":"वन","category":"noun","vibhakti":"dvitīyā","vacana":"ekavacana","linga":"napuṃsakaliṅga","verb_info":"","relation":"karma","confidence":"certain","note":""},{"word":"गच्छति","pratipadartha":"goes","lemma":"गम्","category":"verb","vibhakti":"","vacana":"","linga":"","verb_info":"√गम् (bhvādi, parasmaipada), laṭ, prathama, ekavacana","relation":"kriyā","confidence":"certain","note":""}],"samasa":[],"syntax":"kartā रामः, karma वनम्, kriyā गच्छति","anvaya":"","meaning":"Rāma goes to the forest.","translation":"Rama goes to the forest."}],"overall_meaning":"Rāma goes to the forest.","uncertainties":[]}"""
const val COMMENTARY_JSON = """{"paraphrase":"रामः अरण्यं प्रति गच्छति ।","grammar":[{"point":"वनं","explanation":"द्वितीया विभक्तिः, गमनकर्म","confidence":"certain"}],"words":[{"word":"वनं","artha":"अरण्यम्","confidence":"certain"}],"uncertainties":[]}"""
const val EXPLAIN_JSON = """{"corrected":"The colour was good.","corrections":[{"original":"color","corrected":"colour","category":"spelling","reason":"British spelling","confidence":"certain"}]}"""
const val ALTERNATIVES_JSON = """{"alternatives":[{"label":"Concise","text":"Good colour.","note":"shorter"},{"label":"Formal","text":"The colour was satisfactory.","note":"formal"},{"label":"Fluent","text":"The colour looked good.","note":"fluent"}]}"""
const val GRAMMAR_JSON = """{"overall":"Mostly fine.","issues":[{"quote":"were","category":"agreement","explanation":"subject is singular","suggestion":"was","confidence":"certain"}],"sentences":[{"text":"The color were good.","analysis":"subject: color"}]}"""

/** Records every network connection the JDK's HTTP client tries to make while [block] runs. */
object NetTripwire {
    val seen = CopyOnWriteArrayList<String>()
    fun <T> watching(block: () -> T): T {
        val old = ProxySelector.getDefault()
        seen.clear()
        ProxySelector.setDefault(object : ProxySelector() {
            override fun select(uri: URI?): List<Proxy> { seen.add(uri.toString()); return listOf(Proxy.NO_PROXY) }
            override fun connectFailed(uri: URI?, sa: SocketAddress?, ioe: java.io.IOException?) {}
        })
        try { return block() } finally { ProxySelector.setDefault(old) }
    }
}
