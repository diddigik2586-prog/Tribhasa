import org.tribhasa.app.core.*
import java.io.File
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ProxySelector
import java.net.SocketAddress
import java.net.URI
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

// =====================================================================================================
// Tests of the on-device model support, run on a computer with a stand-in for the library that runs the model.
// They show how the app's own code behaves around the model (download, loading, cancelling, failing, reporting).
// They say nothing about what the real model answers, or about how well it handles Sanskrit or Kannada.
// =====================================================================================================

private fun tempDir(name: String): File = java.nio.file.Files.createTempDirectory("tribhasa-$name").toFile().also { it.deleteOnExit() }

private fun failureOf(block: () -> Unit): DownloadFailure? = try { block(); null } catch (e: DownloadFailure) { e }

// ------------------------------------------------------------------------------------------ facts
fun testLocalModelFacts() {
    section("On-device model: the facts the app relies on")
    val s = LocalModels.GEMMA4_E2B
    check("the model address is https and pinned to one repository revision (40 hex digits)", s.url.startsWith("https://") && Regex("/resolve/[0-9a-f]{40}/").containsMatchIn(s.url), s.url)
    check("the address ends with the file name", s.url.endsWith("/" + s.fileName))
    check("the checksum is 64 hex digits", Regex("[0-9a-f]{64}").matches(s.sha256))
    check("the size is the published 2,588,147,712 bytes (2.59 GB)", s.sizeBytes == 2_588_147_712L && LocalModels.gb(s.sizeBytes) == "2.59 GB", LocalModels.gb(s.sizeBytes))
    check("the licence recorded is Apache-2.0 and its source is named", s.licence == "Apache-2.0" && s.licenceSource.contains("apache-2.0"))
    check("the app uses this model by default", LocalModels.active === s)
    check("the memory note does not claim a minimum the publisher did not state", s.publisherMemoryNote.contains("states no minimum"))
    val gib = 1024L * 1024 * 1024
    check("8 GB phone: enough", LocalModels.memoryFit(8 * gib) == LocalModels.Fit.OK)
    check("5 GB phone: enough (boundary)", LocalModels.memoryFit(5 * gib) == LocalModels.Fit.OK)
    check("4 GB phone: on the low side", LocalModels.memoryFit(4 * gib) == LocalModels.Fit.TIGHT)
    check("3 GB phone: likely too small", LocalModels.memoryFit(3 * gib) == LocalModels.Fit.LIKELY_TOO_SMALL)
    check("unknown memory does not scare the user", LocalModels.memoryFit(0) == LocalModels.Fit.OK)
    check("memory text for a small phone says problems are likely and still allows trying", LocalModels.memoryText(3 * gib).let { it.contains("likely") && it.contains("still try") })
    check("memory text calls its limits the app's own rule of thumb", LocalModels.memoryText(8 * gib).contains("rule of thumb"))
    check("space needed counts what is still missing plus a margin", LocalModels.spaceNeeded(s, 0) == s.sizeBytes + maxOf(300_000_000L, s.sizeBytes / 20) &&
        LocalModels.spaceNeeded(s, s.sizeBytes) == maxOf(300_000_000L, s.sizeBytes / 20))
    check("source names parse; unknown falls back to the on-phone source", AiSource.fromName("ONLINE") == AiSource.ONLINE && AiSource.fromName(null) == AiSource.LOCAL && AiSource.fromName("x") == AiSource.LOCAL)
    check("the default Credentials use the on-phone source", Credentials().aiSource == AiSource.LOCAL)
    check("backend names parse; unknown falls back to the CPU", LocalBackend.fromName("GPU") == LocalBackend.GPU && LocalBackend.fromName("zzz") == LocalBackend.CPU)
}

// ------------------------------------------------------------------------------------------ small helpers
fun testLocalHelpers() {
    section("On-device model: token estimate, plain-text cleaning, cancel hooks")
    check("empty text is zero tokens", TokenEstimate.of("") == 0)
    check("an Indic letter costs more than a Latin one", TokenEstimate.of("धर्म".repeat(100)) > TokenEstimate.of("dharma".repeat(66)))
    check("Kannada is counted like the other Indic scripts", TokenEstimate.of("ಧರ್ಮ".repeat(100)) == TokenEstimate.of("धर्म".repeat(100)))
    check("a 450-character Devanagari part is estimated well below the 4096 window", TokenEstimate.of("क".repeat(450)) in 150..400, TokenEstimate.of("क".repeat(450)).toString())
    check("an emoji outside the BMP counts once, without failing", TokenEstimate.of("😀😀") > 0)

    check("plain: fences removed", PlainText.clean("```text\nHello world\n```") == "Hello world")
    check("plain: bare fences removed", PlainText.clean("```\nHello\n```") == "Hello")
    check("plain: a lead-in line ending with a colon is removed", PlainText.clean("Here is the translation:\nನಮಸ್ಕಾರ") == "ನಮಸ್ಕಾರ")
    check("plain: 'Translation:' prefix removed", PlainText.clean("Translation: Hello") == "Hello")
    check("plain: wrapping quotes removed", PlainText.clean("\"Hello there\"") == "Hello there" && PlainText.clean("“Hello there”") == "Hello there")
    check("plain: inner quotes are kept", PlainText.clean("\"a\" and \"b\"") == "\"a\" and \"b\"")
    check("plain: something that looks like broken JSON is not accepted as an answer", PlainText.clean("{\"translations\": [\"abc") == "" && PlainText.clean("[1,2") == "")
    check("plain: a one-line answer is untouched", PlainText.clean("  Learning is supreme wealth.  ") == "Learning is supreme wealth.")
    check("plain: a colon inside a normal first line of a single-line answer is kept", PlainText.clean("Note: this stays") == "Note: this stays")
    check("markers: chat-template markers are removed", PlainText.stripMarkers("Hello<end_of_turn>") == "Hello" && PlainText.stripMarkers("<start_of_turn>model\nHi<eos>") == "Hi")

    run {
        val t = CancelToken(); val n = AtomicInteger(0)
        val h = t.onCancel { n.incrementAndGet() }
        t.cancel()
        check("a cancel hook runs once when the token is cancelled", n.get() == 1)
        t.cancel()
        check("cancelling twice does not run the hook twice", n.get() == 1)
        val late = AtomicInteger(0)
        t.onCancel { late.incrementAndGet() }
        check("a hook added after the cancel runs at once", late.get() == 1)
        h.close()
        val t2 = CancelToken(); val m = AtomicInteger(0)
        t2.onCancel { m.incrementAndGet() }.close()
        t2.cancel()
        check("a hook that was removed does not run", m.get() == 0)
        val t3 = CancelToken(); val order = ArrayList<Int>()
        t3.onCancel { throw IllegalStateException("bad hook") }; t3.onCancel { order.add(2) }
        t3.cancel()
        check("one failing hook does not stop the others", order == listOf(2))
    }
}

// ------------------------------------------------------------------------------------------ downloader
fun testModelDownloader() {
    section("Model download: resume, check, retry, cancel, disk and network rules (test server, no internet)")
    TestTls.trustInClient()
    val blob = TestBlob(3_000_000)
    val big = Long.MAX_VALUE / 4
    val sleeps = CopyOnWriteArrayList<Long>()
    val server = BlobServer(blob.data)
    try {
        fun newFiles(dir: File = tempDir("dl"), spec: LocalModels.Spec = blob.spec(server.url)) = LocalModelFiles(spec, dir)
        fun dl(f: LocalModelFiles, metered: Boolean = false, wifiOnly: Boolean = false, free: Long = big, retries: Int = 6) =
            ModelDownloader(f, freeSpace = { free }, isMetered = { metered }, wifiOnly = { wifiOnly }, sleeper = { sleeps.add(it) }, maxAutoRetries = retries,
                connectTimeoutMs = 5_000, readTimeoutMs = 5_000)
        fun same(f: File) = f.isFile && f.length() == blob.data.size.toLong() && java.security.MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { String.format("%02x", it) } == blob.sha256

        // 1. a plain download
        val f1 = newFiles(); val phases = CopyOnWriteArrayList<DownloadProgress>()
        check("before the download nothing is on the phone", f1.state() == LocalModelFiles.State.ABSENT && !f1.deleteAll().not())
        dl(f1).run(CancelToken()) { phases.add(it) }
        check("a fresh download ends with a finished, checked file", f1.state() == LocalModelFiles.State.READY && same(f1.finalFile) && !f1.partFile.exists())
        check("progress starts by checking, goes through downloading and verifying, and ends done",
            phases.first().phase == DownloadPhase.CHECKING && phases.any { it.phase == DownloadPhase.DOWNLOADING } && phases.any { it.phase == DownloadPhase.VERIFYING } && phases.last().phase == DownloadPhase.DONE)
        check("progress never goes backwards and never exceeds the total", phases.filter { it.phase == DownloadPhase.DOWNLOADING }.zipWithNext().all { (a, b) -> b.doneBytes >= a.doneBytes } &&
            phases.all { it.doneBytes <= it.totalBytes })
        check("the fresh download made one request, without a Range header", server.log.size == 1 && server.log[0].first == "" && server.log[0].second == 200, server.log.toString())

        // 2. already there
        val before = server.log.size
        dl(f1).run(CancelToken()) { }
        check("a model that is already on the phone and checked is not downloaded again", server.log.size == before)

        // 3. a file that changed afterwards is not trusted
        f1.finalFile.setLastModified(f1.finalFile.lastModified() + 5_000)
        check("a changed date makes the file 'damaged' (needs checking), not ready", f1.state() == LocalModelFiles.State.DAMAGED)
        dl(f1).run(CancelToken()) { }
        check("the file is checked again, found correct, and marked ready without downloading", f1.state() == LocalModelFiles.State.READY && server.log.size == before)
        f1.finalFile.writeBytes(blob.data.copyOf().also { it[10] = (it[10] + 1).toByte() })
        check("a file with one wrong byte is damaged", f1.state() == LocalModelFiles.State.DAMAGED)
        dl(f1).run(CancelToken()) { }
        check("a wrong file is deleted and downloaded again, correctly", f1.state() == LocalModelFiles.State.READY && same(f1.finalFile) && server.log.size == before + 1)
        check("deleteAll removes the file, the unfinished download and the mark", f1.deleteAll() && f1.state() == LocalModelFiles.State.ABSENT && f1.dir.listFiles()!!.isEmpty())

        // 4. resume
        val f2 = newFiles(); server.log.clear()
        f2.dir.mkdirs(); f2.partFile.writeBytes(blob.data.copyOf(1_000_000))
        check("an unfinished download shows as partial", f2.state() == LocalModelFiles.State.PARTIAL && f2.partialBytes() == 1_000_000L)
        dl(f2).run(CancelToken()) { }
        check("an unfinished download is resumed with a Range request and finishes correctly", same(f2.finalFile) && server.log.single() == ("bytes=1000000-" to 206), server.log.toString())

        // 5. server ignores Range
        val f3 = newFiles(); server.log.clear(); server.ignoreRange = true
        f3.dir.mkdirs(); f3.partFile.writeBytes(blob.data.copyOf(1_000_000))
        dl(f3).run(CancelToken()) { }
        server.ignoreRange = false
        check("if the server ignores the request to continue, the file is started again and still correct", same(f3.finalFile) && server.log.single().second == 200)

        // 6. Content-Range lies
        val f4 = newFiles(); server.log.clear(); server.contentRangeStartShift = 5
        f4.dir.mkdirs(); f4.partFile.writeBytes(blob.data.copyOf(1_000_000))
        dl(f4).run(CancelToken()) { }
        server.contentRangeStartShift = 0
        check("a continuation that starts at the wrong byte is not glued on: the file restarts and is correct", same(f4.finalFile))

        // 7. connection dropped in the middle, twice
        val f5 = newFiles(); server.log.clear(); sleeps.clear(); server.dropAfter = 500_000; server.dropTimes = 2
        dl(f5).run(CancelToken()) { }
        server.dropAfter = -1; server.dropTimes = 0
        check("a connection that breaks twice is resumed automatically and the file is correct", same(f5.finalFile) && server.log.size >= 3 && server.log.drop(1).all { it.first.startsWith("bytes=") }, server.log.toString())

        // 8. server busy twice
        val f6 = newFiles(); server.log.clear(); sleeps.clear(); server.failNext = 2
        dl(f6).run(CancelToken()) { }
        check("two 'busy' answers are waited out and the download then succeeds", same(f6.finalFile) && server.log.take(2).all { it.second == 503 } && server.log.size == 3 && sleeps.isNotEmpty())

        // 9. server permanently busy
        val f7 = newFiles(); server.log.clear(); server.failNext = 1000
        val e7 = failureOf { dl(f7, retries = 3).run(CancelToken()) { } }
        server.failNext = 0
        check("a server that stays busy ends in a clear SERVER failure after a limited number of tries", e7?.kind == DownloadFailure.Kind.SERVER && e7.retryable && server.log.size in 3..4, "${e7?.kind} ${server.log.size}")
        check("nothing unusable is left behind", f7.state() == LocalModelFiles.State.ABSENT)

        // 10. file gone
        val f8 = newFiles(); server.log.clear(); server.status = 404
        val e8 = failureOf { dl(f8).run(CancelToken()) { } }
        server.status = null
        check("a 404 is reported as 'the publisher no longer has the file' and is not retried", e8?.kind == DownloadFailure.Kind.SERVER && e8.message!!.contains("no longer has") && server.log.size == 1)
        server.status = 403
        val e8b = failureOf { dl(newFiles()).run(CancelToken()) { } }
        server.status = null
        check("a 403 explains that a login may now be needed, which the app does not use", e8b?.kind == DownloadFailure.Kind.SERVER && e8b.message!!.contains("login"))

        // 11. wrong content
        val f9 = newFiles(spec = blob.spec(server.url, sha = "0".repeat(64)))
        val e9 = failureOf { dl(f9).run(CancelToken()) { } }
        check("a complete file with the wrong checksum is refused and deleted", e9?.kind == DownloadFailure.Kind.CHECKSUM && f9.state() == LocalModelFiles.State.ABSENT && !f9.finalFile.exists() && !f9.partFile.exists())
        check("the refusal says what was expected and what arrived", e9?.detail?.contains(blob.sha256) == true && e9.message!!.contains("will not use it"))

        // 12. wrong size on the server
        val f10 = newFiles(spec = blob.spec(server.url, size = blob.data.size + 10L))
        val e10 = failureOf { dl(f10).run(CancelToken()) { } }
        check("a file whose size differs from the published size is refused", e10?.kind == DownloadFailure.Kind.SIZE && !f10.finalFile.exists() && f10.state() != LocalModelFiles.State.READY)

        // 13. finished part, never moved
        val f11 = newFiles(); server.log.clear(); f11.dir.mkdirs(); f11.partFile.writeBytes(blob.data)
        dl(f11).run(CancelToken()) { }
        check("a complete unfinished file is checked and accepted without another request", same(f11.finalFile) && server.log.isEmpty())
        val f12 = newFiles(); f12.dir.mkdirs(); f12.partFile.writeBytes(ByteArray(blob.data.size + 50))
        dl(f12).run(CancelToken()) { }
        check("an unfinished file larger than the model is thrown away and the model downloaded fresh", same(f12.finalFile))

        // 14. cancel in the middle, then resume
        val f13 = newFiles(); server.log.clear(); server.chunkDelayMs = 25
        val tok = CancelToken(); Thread { Thread.sleep(400); tok.cancel() }.start()
        val e13 = failureOf { dl(f13).run(tok) { } }
        server.chunkDelayMs = 0
        val kept = f13.partialBytes()
        check("cancelling pauses the download and keeps what arrived", e13?.kind == DownloadFailure.Kind.CANCELLED && kept > 0 && kept < blob.data.size && f13.state() == LocalModelFiles.State.PARTIAL, "${e13?.kind} kept=$kept")
        check("the pause message says that Resume continues", e13?.message!!.contains("Resume"))
        server.log.clear()
        dl(f13).run(CancelToken()) { }
        check("Resume continues from the kept bytes and finishes correctly", same(f13.finalFile) && server.log.single().first == "bytes=$kept-", server.log.toString())

        // 15. not enough room
        val f14 = newFiles(); server.log.clear()
        val e14 = failureOf { dl(f14, free = 1_000_000).run(CancelToken()) { } }
        check("too little free space stops the download before it starts, and says how much is needed", e14?.kind == DownloadFailure.Kind.DISK_FULL && server.log.isEmpty() && e14.message!!.contains("free"))
        val f14b = newFiles(); f14b.dir.mkdirs(); f14b.partFile.writeBytes(blob.data.copyOf(2_900_000)); server.log.clear()
        dl(f14b, free = 400_000_000L).run(CancelToken()) { }
        check("space already used by the unfinished file is not asked for twice", same(f14b.finalFile))
        val f14c = newFiles()
        dl(f14c, free = -1).run(CancelToken()) { }
        check("an unknown amount of free space does not block the download", same(f14c.finalFile))

        // 16. mobile data
        val f15 = newFiles(); server.log.clear()
        val e15 = failureOf { dl(f15, metered = true, wifiOnly = true).run(CancelToken()) { } }
        check("with 'Wi-Fi only' on and the phone on mobile data, nothing is downloaded", e15?.kind == DownloadFailure.Kind.METERED && server.log.isEmpty() && e15.message!!.contains("Wi-Fi"))
        dl(f15, metered = true, wifiOnly = false).run(CancelToken()) { }
        check("with 'Wi-Fi only' off, mobile data is allowed", same(f15.finalFile))

        // 17. plain http
        val badSpec = blob.spec("http://127.0.0.1:1/model.bin")
        val e17 = failureOf { dl(newFiles(spec = badSpec)).run(CancelToken()) { } }
        check("an address that is not https is refused", e17?.kind == DownloadFailure.Kind.BAD_URL)

        // 18. unreachable server
        val gone = BlobServer(blob.data); val goneUrl = gone.url; gone.stop()
        val e18 = failureOf { dl(newFiles(spec = blob.spec(goneUrl)), retries = 2).run(CancelToken()) { } }
        check("no connection ends in a clear NETWORK failure that can be retried", e18?.kind == DownloadFailure.Kind.NETWORK && e18.retryable, e18?.message ?: "none")

        // 19. a pre-cancelled token
        val e19 = failureOf { dl(newFiles()).run(CancelToken().also { it.cancel() }) { } }
        check("a token cancelled in advance does nothing", e19?.kind == DownloadFailure.Kind.CANCELLED)

        // 20. checksum on its own
        check("sha256() of a file equals the known value", dl(f15).sha256(f15.finalFile, CancelToken()) { } == blob.sha256)
    } finally { server.stop() }
}

// ------------------------------------------------------------------------------------------ runtime
private fun readyFiles(size: Int = 100_000): Pair<LocalModelFiles, TestBlob> {
    val blob = TestBlob(size)
    val spec = blob.spec("https://127.0.0.1:9/never-used")
    LocalModels.active = spec
    val files = LocalModelFiles(spec, tempDir("rt"))
    files.dir.mkdirs(); files.finalFile.writeBytes(blob.data); files.markVerified()
    return files to blob
}

private fun mkRuntime(files: LocalModelFiles, fake: FakeNativeFactory, backend: LocalBackend = LocalBackend.CPU, downloading: Boolean = false,
                      first: Long = 5_000, silence: Long = 5_000) =
    LocalModelRuntime({ files }, fake, { backend }, tempDir("cache").path, { downloading }, first, silence)

private fun req(maxOut: Int = 500, user: String = "u", system: String = "s") = LocalRequest(system, user, maxOut, 0.1)

fun testLocalRuntime() {
    section("On-device runtime with a stand-in engine: loading, one task at a time, cancel, stalls, memory, GPU")
    val saved = LocalModels.active
    try {
        val (files, _) = readyFiles()
        val fake = FakeNativeFactory()
        val rt = mkRuntime(files, fake)

        // availability messages
        run {
            val dir = tempDir("none"); val spec = LocalModels.active
            val none = LocalModelFiles(spec, dir)
            val r0 = mkRuntime(none, FakeNativeFactory())
            val msg = r0.unavailableReason()
            check("not downloaded: the reason says where to tap and that it is free and needs no account", msg != null && msg.contains("Settings") && msg.contains("Download") && msg.contains("no account"), msg ?: "")
            val ex = try { r0.generate(req(), CancelToken()) { }; null } catch (e: EngineException) { e }
            check("not downloaded: generating is refused as UNSUPPORTED with that reason", ex?.kind == FailKind.UNSUPPORTED && ex.message == msg)
            dir.mkdirs(); none.partFile.writeBytes(ByteArray(10))
            check("unfinished: the reason says Resume", r0.unavailableReason()!!.contains("Resume"))
            val r1 = mkRuntime(none, FakeNativeFactory(), downloading = true)
            check("downloading: the reason says to wait", r1.unavailableReason()!!.contains("still downloading"))
            none.partFile.delete(); none.finalFile.writeBytes(ByteArray(5))
            check("a file that was never checked: the reason offers 'Check the file'", r0.unavailableReason()!!.contains("Check the file"))
            check("the unusable file is never handed to the engine", FakeNativeFactory().let { f -> try { mkRuntime(none, f).generate(req(), CancelToken()) { } } catch (_: EngineException) { }; f.opens.get() == 0 })
        }
        check("a ready model has no 'unavailable' reason", rt.unavailableReason() == null && !rt.isLoaded)

        // first task loads, second reuses
        fake.loadDelayMs = 60; fake.answer = { _, u -> "Answer to: $u" }
        val seenStatus = CopyOnWriteArrayList<String>()
        val o1 = rt.generate(req(user = "hello"), CancelToken()) { seenStatus.add(it) }
        check("the first task loads the model and returns the engine's text", o1.text == "Answer to: hello" && fake.opens.get() == 1 && rt.isLoaded && o1.loadMs >= 50, "${o1.loadMs} ms")
        check("status lines tell the user about loading and writing", seenStatus.any { it.contains("Loading the model") } && seenStatus.any { it.contains("Writing the answer") })
        check("the label names the model and the processor", o1.modelLabel == "Test model (on this phone, CPU)", o1.modelLabel)
        check("the request reaches the engine unchanged", fake.requestsSeen.last() == Triple("s", "hello", 500))
        val o2 = rt.generate(req(user = "again"), CancelToken()) { }
        check("the second task does not load the model again", fake.opens.get() == 1 && o2.loadMs == 0L && o2.text == "Answer to: again")
        check("every turn was closed", fake.turnsClosed.get() == fake.starts.get())

        // length limit detection
        fake.answer = { _, _ -> "word ".repeat(400) }; fake.pieceChars = 5
        val cut = rt.generate(req(maxOut = 50), CancelToken()) { }
        check("an answer stopped by the length limit is reported as cut off", cut.reachedLimit && cut.pieces <= 50, "${cut.pieces}")
        fake.answer = { _, _ -> "short" }
        check("a short answer is not reported as cut off", !rt.generate(req(maxOut = 500), CancelToken()) { }.reachedLimit)
        fake.answer = { _, u -> "Answer to: $u" }; fake.pieceChars = 4

        // one at a time
        fake.answer = { _, u -> "x".repeat(600) + u }; fake.pieceDelayMs = 15; fake.pieceChars = 6
        val results = CopyOnWriteArrayList<String>(); val statusB = CopyOnWriteArrayList<String>()
        val ta = Thread { results.add(rt.generate(req(user = "A"), CancelToken()) { }.text) }
        val tb = Thread { Thread.sleep(60); results.add(rt.generate(req(user = "B"), CancelToken()) { statusB.add(it) }.text) }
        ta.start(); tb.start(); ta.join(); tb.join()
        check("two tasks at once are served one after the other, never together", fake.maxRunning.get() == 1 && results.size == 2 && results.all { it.endsWith("A") || it.endsWith("B") })
        check("the second task is told it is waiting", statusB.any { it.contains("Waiting for another task") })
        fake.pieceDelayMs = 0; fake.pieceChars = 4

        // cancel while writing
        fake.answer = { _, _ -> "y".repeat(2000) }; fake.pieceDelayMs = 20
        val c1 = CancelToken(); Thread { Thread.sleep(200); c1.cancel() }.start()
        val cancelsBefore = fake.cancels.get(); val t0 = System.currentTimeMillis()
        val ex1 = try { rt.generate(req(maxOut = 5000), c1) { }; null } catch (e: EngineException) { e }
        check("cancel while writing stops the engine promptly and is reported as a cancel", ex1?.kind == FailKind.CANCELLED && fake.cancels.get() > cancelsBefore && System.currentTimeMillis() - t0 < 3000, "${System.currentTimeMillis() - t0} ms")
        check("every turn is still closed after a cancel", fake.turnsClosed.get() == fake.starts.get())
        fake.pieceDelayMs = 0; fake.answer = { _, u -> "Answer to: $u" }
        val after = rt.generate(req(user = "next"), CancelToken()) { }
        check("after a cancel the model is still loaded and works", after.text == "Answer to: next" && fake.opens.get() == 1)

        // cancel before starting / while waiting
        val pre = CancelToken().also { it.cancel() }; val startsBefore = fake.starts.get()
        val ex2 = try { rt.generate(req(), pre) { }; null } catch (e: EngineException) { e }
        check("a token cancelled in advance never reaches the engine", ex2?.kind == FailKind.CANCELLED && fake.starts.get() == startsBefore)
        fake.answer = { _, _ -> "z".repeat(1500) }; fake.pieceDelayMs = 20
        val longDone = AtomicReference<String?>(null)
        val tl = Thread { longDone.set(rt.generate(req(maxOut = 5000), CancelToken()) { }.text.take(3)) }
        tl.start(); Thread.sleep(100)
        val wc = CancelToken(); Thread { Thread.sleep(150); wc.cancel() }.start()
        val tw = System.currentTimeMillis()
        val ex3 = try { rt.generate(req(), wc) { }; null } catch (e: EngineException) { e }
        check("a task that is only waiting its turn can be cancelled while the other one keeps running", ex3?.kind == FailKind.CANCELLED && System.currentTimeMillis() - tw < 2000 && tl.isAlive)
        tl.join(); check("…and the running task finishes normally", longDone.get() == "zzz")
        fake.pieceDelayMs = 0; fake.answer = { _, u -> "Answer to: $u" }

        // unload
        check("unload frees an idle model", rt.unload() && !rt.isLoaded && fake.enginesClosed.get() == 1)
        check("after an unload the next task loads again", rt.generate(req(user = "q"), CancelToken()) { }.text == "Answer to: q" && fake.opens.get() == 2)
        fake.answer = { _, _ -> "w".repeat(1000) }; fake.pieceDelayMs = 20
        val busy = Thread { rt.generate(req(maxOut = 5000), CancelToken()) { } }; busy.start(); Thread.sleep(100)
        check("unload does nothing while a task is running", !rt.unload() && rt.isLoaded)
        busy.join(); fake.pieceDelayMs = 0; fake.answer = { _, u -> "Answer to: $u" }

        // model file deleted while loaded
        run {
            val (f2, _) = readyFiles(); val fk = FakeNativeFactory(); val r = mkRuntime(f2, fk)
            r.generate(req(), CancelToken()) { }
            f2.deleteAll()
            val e = try { r.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("after the model file is deleted, it is no longer used even if it is still in memory", e?.kind == FailKind.UNSUPPORTED && r.unavailableReason() != null)
        }
    } finally { LocalModels.active = saved }
    LocalModels.active = saved
}

fun testLocalRuntimeFailures() {
    section("On-device runtime: stalls, load failures, out of memory, GPU")
    val saved = LocalModels.active
    try {
        // stalls
        run {
            val (files, _) = readyFiles(); val fake = FakeNativeFactory(); val rt = mkRuntime(files, fake, first = 400, silence = 400)
            fake.silent = true; val t0 = System.currentTimeMillis()
            val e = try { rt.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("an engine that never produces text is stopped, with a plain explanation", e?.kind == FailKind.LOCAL && e.message!!.contains("stopped producing text") && System.currentTimeMillis() - t0 < 4000, e?.message ?: "none")
            check("a stalled engine is dropped and not trusted again", !rt.isLoaded && fake.enginesClosed.get() == 1 && fake.cancels.get() >= 1)
            fake.silent = false
            check("the next task loads a fresh engine and works", rt.generate(req(user = "ok"), CancelToken()) { }.text.isNotEmpty() && fake.opens.get() == 2)
            fake.answer = { _, _ -> "abcdefgh" }; fake.pieceChars = 2; fake.pieceDelayMs = 700
            val e2 = try { rt.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("an engine that goes silent in the middle of an answer is also stopped", e2?.kind == FailKind.LOCAL && e2.message!!.contains("stopped producing text"))
        }
        // load failures
        run {
            val (files, _) = readyFiles(); val fake = FakeNativeFactory(); val rt = mkRuntime(files, fake)
            fake.failLoad = NativeFailure(NativeFailure.Kind.LOAD, "unsupported file version")
            val e = try { rt.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("a load failure is reported with its reason and a way to check the file", e?.kind == FailKind.LOCAL && e.message!!.contains("could not be loaded") && e.message!!.contains("unsupported file version") && e.message!!.contains("Check the file"), e?.message ?: "")
            check("after a failed load nothing is loaded", !rt.isLoaded)
            fake.failLoad = null
            check("the next attempt tries again and can succeed", rt.generate(req(), CancelToken()) { }.text.isNotEmpty() && rt.isLoaded && fake.opens.get() == 2)
            val (f2, _) = readyFiles(); val fk2 = FakeNativeFactory(); val r2 = mkRuntime(f2, fk2)
            fk2.failLoad = NativeFailure(NativeFailure.Kind.OUT_OF_MEMORY, "alloc failed")
            val e2 = try { r2.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("running out of memory while loading says so and suggests closing other apps", e2?.kind == FailKind.LOCAL && e2.message!!.contains("ran out of memory") && e2.message!!.contains("Close other apps"))
            val (f3, _) = readyFiles(); val fk3 = FakeNativeFactory(); val r3 = mkRuntime(f3, fk3)
            fk3.failLoadRaw = UnsatisfiedLinkError("libx.so not found")
            val e3 = try { r3.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("an unexpected error from the library becomes a plain error, not a crash", e3?.kind == FailKind.LOCAL && e3.message!!.contains("libx.so"), e3?.message ?: "")
        }
        // failures while writing
        run {
            val (files, _) = readyFiles(); val fake = FakeNativeFactory(); val rt = mkRuntime(files, fake)
            fake.answer = { _, _ -> "partial text that never completes" }; fake.errorAfterPieces = 3
            fake.errorToSend = NativeFailure(NativeFailure.Kind.OUT_OF_MEMORY, "oom")
            val e = try { rt.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("running out of memory while writing unloads the model and says so", e?.kind == FailKind.LOCAL && e.message!!.contains("ran out of memory") && !rt.isLoaded)
            fake.errorToSend = NativeFailure(NativeFailure.Kind.CONTEXT_FULL, "full")
            val e2 = try { rt.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("a text that does not fit the working memory is explained", e2?.kind == FailKind.LOCAL && e2.message!!.contains("do not fit"))
            fake.errorToSend = NativeFailure(NativeFailure.Kind.OTHER, "boom")
            val e3 = try { rt.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("another error is passed on in words and does not unload the model", e3?.kind == FailKind.LOCAL && e3.message!!.contains("boom") && rt.isLoaded)
            check("no result is returned together with an error (the partial text is not passed on)", e3 != null)
            check("turns are closed after failures too", fake.turnsClosed.get() == fake.starts.get())
        }
        // GPU
        run {
            val (files, _) = readyFiles(); val fake = FakeNativeFactory(); val rt = mkRuntime(files, fake, backend = LocalBackend.GPU)
            val ok = rt.generate(req(), CancelToken()) { }
            check("when the GPU loads the model, the label says GPU and there is no note", ok.modelLabel.contains("GPU") && ok.notes.isEmpty() && fake.backendsOpened.toList() == listOf(LocalBackend.GPU))
            val (f2, _) = readyFiles(); val fk2 = FakeNativeFactory(); val r2 = mkRuntime(f2, fk2, backend = LocalBackend.GPU)
            fk2.failGpuLoad = NativeFailure(NativeFailure.Kind.LOAD, "no OpenCL")
            val out = r2.generate(req(), CancelToken()) { }
            check("when the GPU cannot load it, the CPU is used and the answer says so", fk2.backendsOpened.toList() == listOf(LocalBackend.GPU, LocalBackend.CPU) && out.modelLabel.contains("CPU") &&
                out.notes.size == 1 && out.notes[0].contains("GPU could not load") && out.notes[0].contains("no OpenCL"), out.notes.toString())
            r2.unload()
            r2.generate(req(), CancelToken()) { }
            check("after a GPU failure the app does not keep retrying the GPU", fk2.backendsOpened.toList() == listOf(LocalBackend.GPU, LocalBackend.CPU, LocalBackend.CPU))
            val again = r2.generate(req(), CancelToken()) { }
            check("a later task says again that the GPU option is on but the CPU is used", again.notes.size == 1 && again.notes[0].contains("GPU option is on"), again.notes.toString())
            val (f3, _) = readyFiles(); val fk3 = FakeNativeFactory(); val r3 = mkRuntime(f3, fk3, backend = LocalBackend.GPU)
            fk3.failGpuLoad = NativeFailure(NativeFailure.Kind.LOAD, "x"); fk3.failLoad = NativeFailure(NativeFailure.Kind.LOAD, "cpu also fails")
            val e3 = try { r3.generate(req(), CancelToken()) { }; null } catch (x: EngineException) { x }
            check("if the CPU fails too, that is reported as a load failure", e3?.kind == FailKind.LOCAL && e3.message!!.contains("cpu also fails"))
        }
    } finally { LocalModels.active = saved }
    LocalModels.active = saved
}

// ------------------------------------------------------------------------------------------ provider
fun testLocalProvider() {
    section("On-device provider: fit check before starting, markers, truncation, no model is ever substituted")
    val saved = LocalModels.active
    try {
        val (files, _) = readyFiles(); val fake = FakeNativeFactory()
        val rt = mkRuntime(files, fake)
        val p = LocalLlmProvider(rt)
        check("the provider is called the AI model on this phone and has no account", p.label == "AI model on this phone" && p.id == "local" && p.account == "local")
        fake.answer = { _, _ -> "Hello<end_of_turn>" }
        val r = p.generate(LlmRequest("sys", "usr", json = true, maxTokens = 8192, temperature = 5.0), CancelToken())
        check("chat markers are removed from the answer", r.text == "Hello")
        check("the reply names the provider and the model on this phone", r.provider == "local" && r.model.contains("Test model") && !r.truncated)
        val seen = fake.requestsSeen.last()
        check("the answer length asked for is capped to what fits in the model's working memory", seen.third in 96..(rt.contextTokens - 48 - 16), seen.third.toString())
        check("a small request keeps its own answer limit", p.generate(LlmRequest("s", "u", false, 200, 0.2), CancelToken()).let { fake.requestsSeen.last().third == 200 })

        fake.answer = { _, _ -> "<think>hidden reasoning</think>The answer." }
        check("hidden reasoning in the model's text is not shown", p.generate(LlmRequest("s", "u", false, 300, 0.2), CancelToken()).text == "The answer.")

        fake.answer = { _, _ -> "word ".repeat(600) }; fake.pieceChars = 5
        check("a cut-off answer is reported as truncated", p.generate(LlmRequest("s", "u", false, 100, 0.2), CancelToken()).truncated)
        fake.pieceChars = 4; fake.answer = { _, u -> u }

        val starts = fake.starts.get()
        val huge = "क".repeat(9000)
        val ex = try { p.generate(LlmRequest("s", huge, true, 2000, 0.1), CancelToken()); null } catch (e: EngineException) { e }
        check("a text too long for the model is refused before any waiting, with advice", ex?.kind == FailKind.LOCAL && ex.message!!.contains("too long") && ex.message!!.contains("parts") && fake.starts.get() == starts && fake.opens.get() <= 1, ex?.message ?: "")
        val none = LocalLlmProvider(mkRuntime(LocalModelFiles(LocalModels.active, tempDir("empty")), FakeNativeFactory()))
        check("without the model on the phone the provider says UNSUPPORTED with the instruction", try { none.generate(LlmRequest("s", "u", false, 100, 0.1), CancelToken()); false } catch (e: EngineException) { e.kind == FailKind.UNSUPPORTED && e.message!!.contains("Settings") })
        run {
            val (f2, _) = readyFiles(); val fk = FakeNativeFactory(); val gp = LocalLlmProvider(mkRuntime(f2, fk, backend = LocalBackend.GPU))
            fk.failGpuLoad = NativeFailure(NativeFailure.Kind.LOAD, "no OpenCL")
            val rep = gp.generate(LlmRequest("s", "u", false, 200, 0.1), CancelToken())
            check("the provider carries the GPU-fallback note in its reply", rep.notes.size == 1 && rep.notes[0].contains("GPU could not load"), rep.notes.toString())
            val trace = Trace(); val router = LlmRouter(listOf(LocalLlmProvider(mkRuntime(readyFiles().first, FakeNativeFactory().also { it.failGpuLoad = NativeFailure(NativeFailure.Kind.LOAD, "no OpenCL") }, backend = LocalBackend.GPU))), NO_WAIT)
            router.generate(LlmRequest("s", "u", false, 200, 0.1), CancelToken(), trace)
            val qc = QcReport(); qc.addStandingNotes(true, trace)
            check("the router puts that note into the Quality report as a warning", qc.items.any { it.status == Qc.WARN && it.text.contains("GPU could not load") }, qc.toPlain())
        }
        check("a cancelled token is respected before anything starts", try { p.generate(LlmRequest("s", "u", false, 100, 0.1), CancelToken().also { it.cancel() }); false } catch (e: EngineException) { e.kind == FailKind.CANCELLED })
        check("the provider reports no cost and no account", p.account == "local")
    } finally { LocalModels.active = saved }
    LocalModels.active = saved
}

// ------------------------------------------------------------------------------------------ no silent fallback / full tasks
fun testLocalModeEndToEnd(mock: Mock) {
    section("On-device mode: six directions, reports, and no connection to any online service")
    val saved = LocalModels.active
    try {
        // positive control: the tripwire does see a connection
        mock.reset(); mock.on("GET", "/ping") { Resp(200, "{}") }
        NetTripwire.watching { Http.request("GET", mock.base + "/ping", emptyMap(), null, CancelToken()) }
        check("the network tripwire notices a connection (control)", NetTripwire.seen.any { it.contains("/ping") }, NetTripwire.seen.toString())

        val (files, _) = readyFiles(); val fake = FakeNativeFactory(); val rt = mkRuntime(files, fake)
        val allKeys = Credentials(llmKey = "SOME-KEY", bhashiniUserId = "u", bhashiniKey = "k", cfAccountId = "a", cfToken = "t", fallbackModel = "vendor/other:free")
        check("the default source is on this phone, even when online keys are saved", allKeys.aiSource == AiSource.LOCAL)
        val router = ServiceFactory.llmRouter(allKeys, RetryPolicy(maxAttempts = 1, baseDelayMs = 0), rt)
        check("on this phone the router holds only the on-device model, whatever online keys exist", router.labels == listOf("AI model on this phone"), router.labels.toString())
        val noRuntime = ServiceFactory.llmRouter(allKeys, RetryPolicy(maxAttempts = 1, baseDelayMs = 0), null)
        check("without an on-device runtime the router holds one placeholder that only explains", noRuntime.labels.size == 1 && noRuntime.labels[0] != "AI model on this phone" || noRuntime.labels.size == 1)
        val online = ServiceFactory.llmRouter(allKeys.copy(aiSource = AiSource.ONLINE), RetryPolicy(maxAttempts = 1, baseDelayMs = 0), rt)
        check("the online source holds the online model and the chosen back-up, and not the on-device one", online.labels.size == 2 && !online.labels.contains("AI model on this phone"), online.labels.toString())
        check("online with no key holds nothing", ServiceFactory.llmRouter(Credentials(aiSource = AiSource.ONLINE), NO_WAIT, rt).isEmpty)

        val retry = RetryPolicy(maxAttempts = 2, baseDelayMs = 1)
        val svc = ServiceFactory.translation(allKeys, retry, ServiceFactory.llmRouter(allKeys, retry, rt))
        val opts = Options()
        // the six directions
        fake.answer = { sys, u -> "TRANSLATED[" + (Regex("into (\\w+)\\.").find(sys)?.groupValues?.get(1) ?: "?") + "] " + u.substringAfterLast("segments: ").trim('[', ']', '"') }
        val samples = mapOf(Lang.SA to "विद्या परमं धनम्।", Lang.KN to "ವಿದ್ಯೆಯೇ ಪರಮ ಧನ.", Lang.EN to "Learning is the highest wealth.")
        NetTripwire.watching {
            for (d in Direction.ALL) {
                val src = samples[d.src]!!
                val before = fake.requestsSeen.size
                val res = svc.run(svc.newJob(src, d, opts, emptyList()), CancelToken()) { }
                val (sys, user, _) = fake.requestsSeen[before]   // the first request of the task is the translation itself
                check("${d.label}: the model is asked for the right target language", sys.contains("into ${d.tgt.english}."), sys.lines().first())
                check("${d.label}: the model receives exactly the source text", user.contains(src))
                val extra = fake.requestsSeen.size - before - 1
                check("${d.label}: " + (if (d.tgt == Lang.KN) "the Granthika polish is one more small request" else "one request in total"),
                    if (d.tgt == Lang.KN) extra == 1 && fake.requestsSeen.last().first.contains("Granthika") else extra == 0, "extra=$extra")
                check("${d.label}: the answer is shown", res.output.contains("TRANSLATED[${d.tgt.english}]") && res.engines.contains("not IndicTrans2"), res.output)
                if (d.tgt == Lang.KN) check("${d.label}: the polish step is reported, and its plain-text answer is flagged", res.qc.toPlain().contains("Granthika polish by") && res.qc.toPlain().contains("did not answer in the requested format"), res.qc.toPlain())
                check("${d.label}: nothing says IndicTrans2 produced it", !res.usedIndicTrans2)
                val q = res.qc.toPlain()
                check("${d.label}: the report says it was done on the phone and gives the low-confidence warning", q.contains("Done on this phone") && q.contains("Low confidence by default") && q.contains("not been tested with a Sanskrit evaluation set"), q)
                check("${d.label}: the report names the model that ran", q.contains("Test model"), q)
            }
        }
        check("none of the six on-device translations connected to the network", NetTripwire.seen.isEmpty(), NetTripwire.seen.toString())

        // format handling
        fake.answer = { _, _ -> """{"translations":["Learning is supreme wealth."]}""" }
        val rj = svc.run(svc.newJob("विद्या परमं धनम्।", Direction(Lang.SA, Lang.EN), opts, emptyList()), CancelToken()) { }
        check("a JSON answer in the requested format is accepted without a format warning", rj.output == "Learning is supreme wealth." && !rj.qc.toPlain().contains("did not answer in the requested format"), rj.qc.toPlain())
        fake.answer = { _, _ -> "Learning is supreme wealth." }
        val rp = svc.run(svc.newJob("विद्या परमं धनम्।", Direction(Lang.SA, Lang.EN), opts, emptyList()), CancelToken()) { }
        check("a plain-text answer is accepted but flagged as low confidence", rp.output == "Learning is supreme wealth." && rp.qc.items.any { it.status == Qc.WARN && it.text.contains("did not answer in the requested format") }, rp.qc.toPlain())
        // checks on the output
        fake.answer = { _, _ -> "Ram goes. ".repeat(30) }
        val rl = svc.run(svc.newJob("रामः गच्छति।", Direction(Lang.SA, Lang.EN), opts, emptyList()), CancelToken()) { }
        check("an answer that loops is warned about", rl.qc.items.any { it.status == Qc.WARN && it.text.contains("repeat the same words") }, rl.qc.toPlain())
        fake.answer = { _, u -> u.substringAfterLast("segments: ").trim('[', ']', '"') }
        val ru = svc.run(svc.newJob("धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः।", Direction(Lang.SA, Lang.KN), opts, emptyList()), CancelToken()) { }
        check("an answer that is the unchanged source is warned about", ru.qc.items.any { it.status == Qc.WARN && it.text.contains("exactly as they were sent") }, ru.qc.toPlain())

        // long text: small parts, one at a time, in order
        fake.answer = { _, u -> "T" + (Regex("\\d+").findAll(u.substringAfterLast("segments: ")).lastOrNull()?.value ?: "?") }
        val longSa = (1..30).joinToString(" ") { "रामो वनं गच्छति सीता च तस्य पत्नी भवति $it।" }
        val n0 = fake.starts.get(); val running0 = fake.maxRunning.get()
        val rlong = svc.run(svc.newJob(longSa, Direction(Lang.SA, Lang.EN), opts, emptyList()), CancelToken()) { }
        val mine = fake.requestsSeen.drop(n0)
        check("a long text is sent in several small requests, each one part", mine.size >= 3 && mine.all { it.second.contains("Number of segments: 1.") }, "${mine.size}")
        check("no request carries more than the local part size plus its framing", mine.maxOf { it.second.length } < ServiceFactory.LOCAL_SEGMENT_CHARS + 200, "${mine.maxOf { it.second.length }}")
        val nums = Regex("T(\\d+)").findAll(rlong.output).map { it.groupValues[1].toInt() }.toList()
        check("the parts are joined back in their original order", nums.size == mine.size && nums == nums.sorted() && nums.last() == 30, nums.toString())
        check("the parts were worked on one at a time", fake.maxRunning.get() == maxOf(running0, 1))

        // glossary still reaches the model
        fake.answer = { _, _ -> "Learning is supreme wealth." }
        val g = listOf(GlossaryEntry(1, sa = "विद्या", en = "learning"))
        svc.run(svc.newJob("विद्या परमं धनम्।", Direction(Lang.SA, Lang.EN), opts, g), CancelToken()) { }
        check("the personal glossary is still sent with each on-device translation", fake.requestsSeen.last().second.contains("विद्या => learning"))

        // failure: no silent fallback
        fake.failLoad = NativeFailure(NativeFailure.Kind.LOAD, "bad model"); rt.unload()
        val err = NetTripwire.watching { try { svc.run(svc.newJob("रामः।", Direction(Lang.SA, Lang.EN), opts, emptyList()), CancelToken()) { }; null } catch (e: Exception) { e } }
        check("a model failure is reported, not hidden", err is ServiceFailure && err.message!!.contains("could not be loaded"), err?.toString() ?: "none")
        check("…and nothing was sent to any online service, although online keys are saved", NetTripwire.seen.isEmpty() && mock.count("POST", CHAT) == 0, NetTripwire.seen.toString())
        fake.failLoad = null

        // model not downloaded
        val empty = mkRuntime(LocalModelFiles(LocalModels.active, tempDir("nodl")), FakeNativeFactory())
        val svc2 = ServiceFactory.translation(allKeys, retry, ServiceFactory.llmRouter(allKeys, retry, empty))
        val err2 = NetTripwire.watching { try { svc2.run(svc2.newJob("रामः।", Direction(Lang.SA, Lang.EN), opts, emptyList()), CancelToken()) { }; null } catch (e: Exception) { e } }
        check("without the model on the phone the task stops with the instruction to download it", err2 is ServiceFailure && err2.kinds == setOf(FailKind.UNSUPPORTED) && err2.message!!.contains("Download"), err2?.toString() ?: "none")
        check("…and again nothing went online", NetTripwire.seen.isEmpty())

        // cancel during a long on-device task
        fake.answer = { _, _ -> "c".repeat(1500) }; fake.pieceDelayMs = 20
        val cj = svc.newJob(longSa, Direction(Lang.SA, Lang.EN), opts, emptyList()); val ct = CancelToken()
        Thread { Thread.sleep(250); ct.cancel() }.start()
        val ce = try { svc.run(cj, ct) { }; null } catch (e: Exception) { e }
        check("cancelling a long on-device task stops it and is reported as a cancel", (ce is EngineException && ce.kind == FailKind.CANCELLED) || (ce is ServiceFailure && ce.allCancelled), ce?.toString() ?: "none")
        fake.pieceDelayMs = 0

        // scholar tools use the same on-device model, with the same notices
        fake.answer = { _, _ -> "The colour was good." }
        val scholar = ScholarService(ServiceFactory.llmRouter(allKeys, retry, rt), svc)
        val rr = NetTripwire.watching { scholar.refinePlain(Prompts.Refine.CORRECT_GRAMMAR, "The color was good.", Lang.EN, Options(), emptyList(), CancelToken()) { } }
        check("a refinement runs on the phone and its report carries the same standing warnings", rr.text == "The colour was good." && rr.qc.toPlain().contains("Low confidence by default") && rr.qc.toPlain().contains("Done on this phone"), rr.qc.toPlain())
        check("…without any connection", NetTripwire.seen.isEmpty())
    } finally { LocalModels.active = saved }
    LocalModels.active = saved
}

fun testLocalChecks() {
    section("On-device checks: loops, unchanged output, standing notices")
    check("the same line three times is a loop", LocalChecks.repeats("Ram goes home.\nRam goes home.\nRam goes home.\n"))
    check("a four-word phrase repeated four times is a loop", LocalChecks.repeats("a b c d e f g h a b c d i j k l a b c d m n o p a b c d q"))
    check("ordinary text is not a loop", !LocalChecks.repeats("Learning is the highest wealth, for it cannot be stolen by thieves or divided among brothers, and it grows when it is shared."))
    check("a short text is never a loop", !LocalChecks.repeats("go go go go"))
    check("a Sanskrit verse with repeated words but different lines is not a loop", !LocalChecks.repeats("धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः ।\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥"))
    val qc = QcReport(); val tr = Trace(); tr.onDevice = true; tr.onDeviceLabel = "Test model (on this phone, CPU)"; tr.flag("Some flag.")
    qc.addStandingNotes(true, tr)
    val plain = qc.toPlain()
    check("the standing notices appear once each, with the flags", plain.split("Low confidence by default").size == 2 && plain.contains("Done on this phone by Test model") && plain.contains("Some flag.") && plain.contains("Not checked:"), plain)
    check("isStanding recognises exactly the two standing lines", qc.items.count { LocalChecks.isStanding(it.text) } == 2)
    val qc2 = QcReport(); qc2.addStandingNotes(true, Trace())
    check("an online task gets none of the on-device notices", !qc2.toPlain().contains("Low confidence by default") && !qc2.toPlain().contains("Done on this phone"))
    val q3 = QcReport(); LocalChecks.translation(q3, listOf("a long source sentence here that is over twenty characters"), listOf("a long source sentence here that is over twenty characters"))
    check("unchanged output is flagged once per part", q3.items.count { it.text.contains("exactly as they were sent") } == 1)
    val q4 = QcReport(); LocalChecks.translation(q4, listOf("short"), listOf("short"))
    check("a very short source that is returned unchanged is not flagged (names and numbers stay the same)", q4.items.none { it.text.contains("exactly as they were sent") })
}
