import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import org.json.JSONArray
import org.json.JSONObject
import org.tribhasa.app.core.*
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.exitProcess

fun bhashiniConfig(mock: Mock, supported: (String, String) -> Boolean = { _, _ -> true }, key: String = "KEY-1"): (Req) -> Resp = { req ->
    val b = JSONObject(req.body)
    val lang = b.getJSONArray("pipelineTasks").getJSONObject(0).getJSONObject("config").getJSONObject("language")
    val s = lang.getString("sourceLanguage"); val t = lang.getString("targetLanguage")
    if (!supported(s, t)) Resp(200, JSONObject().put("pipelineResponseConfig", JSONArray()).put("languages", JSONArray()).toString())
    else Resp(200, JSONObject()
        .put("languages", JSONArray().put(JSONObject().put("sourceLanguage", s).put("targetLanguageList", JSONArray().put(t))))
        .put("pipelineResponseConfig", JSONArray().put(JSONObject().put("taskType", "translation").put("config", JSONArray()
            .put(JSONObject().put("serviceId", "some/other-nmt").put("modelId", "m0").put("language", JSONObject().put("sourceLanguage", s).put("targetLanguage", t)))
            .put(JSONObject().put("serviceId", "ai4bharat/indictrans-v2-all-gpu--t4").put("modelId", "m1").put("language", JSONObject().put("sourceLanguage", s).put("targetLanguage", t))))))
        .put("pipelineInferenceAPIEndPoint", JSONObject().put("callbackUrl", mock.base + B_COMPUTE).put("inferenceApiKey", JSONObject().put("name", "Authorization").put("value", key)))
        .toString())
}

fun fakeTarget(tgt: String, src: String): String = when (tgt) {
    "kn" -> "ಅನುವಾದಿತ ಪಠ್ಯ"
    "sa" -> "अनूदितः पाठः"
    else -> "The translated color text"
}

fun bhashiniCompute(expectKey: String = "KEY-1", onInputs: (List<String>, String, String) -> Unit = { _, _, _ -> }): (Req) -> Resp = { req ->
    if (req.headers["authorization"] != expectKey) Resp(401, """{"message":"Invalid API key"}""")
    else {
        val b = JSONObject(req.body)
        val lang = b.getJSONArray("pipelineTasks").getJSONObject(0).getJSONObject("config").getJSONObject("language")
        val s = lang.getString("sourceLanguage"); val t = lang.getString("targetLanguage")
        val inputs = b.getJSONObject("inputData").getJSONArray("input")
        val outs = JSONArray(); val srcs = ArrayList<String>()
        for (i in 0 until inputs.length()) { val src = inputs.getJSONObject(i).getString("source"); srcs.add(src); outs.put(JSONObject().put("source", src).put("target", fakeTarget(t, src))) }
        onInputs(srcs, s, t)
        Resp(200, JSONObject().put("pipelineResponse", JSONArray().put(JSONObject().put("taskType", "translation").put("output", outs))).toString())
    }
}


fun orRouter(mock: Mock, model: String = MODEL, think: Models.Think = Models.Think.DEFAULT): LlmRouter =
    LlmRouter(listOf(OpenAiCompatProvider("KEY", model, mock.base + "/api/v1", false, false, think)), NO_WAIT)


// ------------------------------------------------------------------ tests
fun testScripts() {
    section("Transliteration and scripts")
    val gita = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः"
    check("Devanagari -> IAST (Gītā 1.1a)", Translit.devanagariToIast(gita) == "dharmakṣetre kurukṣetre samavetā yuyutsavaḥ", Translit.devanagariToIast(gita))
    check("IAST -> Devanagari round trip", Translit.iastToDevanagari("dharmakṣetre kurukṣetre samavetā yuyutsavaḥ").text == gita)
    check("IAST with ṛ ṝ ḷ", Translit.devanagariToIast("कृष्ण पितॄन् कॢप्त") == "kṛṣṇa pitṝn kḷpta", Translit.devanagariToIast("कृष्ण पितॄन् कॢप्त"))
    check("anusvara / visarga / avagraha", Translit.devanagariToIast("सं नः कोऽपि") == "saṃ naḥ ko'pi", Translit.devanagariToIast("सं नः कोऽपि"))
    check("danda marks", Translit.devanagariToIast("अ । आ ॥") == "a | ā ||")
    check("IAST digits and danda", Translit.iastToDevanagari("a | ā || 12").text == "अ । आ ॥ १२")
    check("conjunct kṣa, jña, tra", Translit.iastToDevanagari("kṣa jña tra").text == "क्ष ज्ञ त्र")
    check("final consonant gets virama", Translit.iastToDevanagari("tat").text == "तत्")
    check("Devanagari -> Kannada script", Translit.devanagariToKannada(gita) == "ಧರ್ಮಕ್ಷೇತ್ರೇ ಕುರುಕ್ಷೇತ್ರೇ ಸಮವೇತಾ ಯುಯುತ್ಸವಃ", Translit.devanagariToKannada(gita))
    check("Kannada script -> Devanagari round trip", Translit.kannadaToDevanagari(Translit.devanagariToKannada(gita)) == gita)
    check("Kannada digits convert", Translit.devanagariToKannada("१२३") == "೧೨೩")
    check("danda unchanged by Kannada conversion", Translit.devanagariToKannada("॥") == "॥")
    val n1 = Translit.normaliseSanskritInput("vidyā paramaṃ dhanam")
    check("Sanskrit IAST input detected and converted", n1.converted && n1.devanagari == "विद्या परमं धनम्", n1.devanagari)
    val n2 = Translit.normaliseSanskritInput("ವಿದ್ಯಾ ಪರಮಂ ಧನಮ್")
    check("Sanskrit in Kannada script detected and converted", n2.converted && n2.devanagari == "विद्या परमं धनम्", n2.devanagari)
    val n3 = Translit.normaliseSanskritInput("विद्या परमं धनम्")
    check("Devanagari input untouched", !n3.converted && n3.devanagari == "विद्या परमं धनम्")
    check("Script share: Kannada text", Scripts.share("ಜ್ಞಾನವೇ ಶ್ರೇಷ್ಠ ಸಂಪತ್ತು.", Script.KANNADA) > 0.99)
    check("NFC normalisation helper", Scripts.nfc("ś") == "ś")
}

fun testProsody() {
    section("Metre scanner (local, no AI)")
    val gita = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः ।\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥ १.१ ॥"
    val a = Prosody.scan(gita)
    check("Gītā 1.1 = anuṣṭubh with pathyā pattern", a.name?.startsWith("anuṣṭubh") == true && a.exact, a.detail)
    check("Gītā 1.1 has 4 pādas of 8 syllables", a.syllableCounts == listOf(8, 8, 8, 8), a.syllableCounts.toString())
    val b = Prosody.scan("यस्यास्ति वित्तं स नरः कुलीनः स पण्डितः स श्रुतवान् गुणज्ञः ।\nस एव वक्ता स च दर्शनीयः सर्वे गुणाः काञ्चनमाश्रयन्ति ॥")
    check("Bhartṛhari verse = upajāti", b.name?.startsWith("upajāti") == true, "${b.name} ${b.patterns}")
    val c = Prosody.scan("कश्चित्कान्ताविरहगुरुणा स्वाधिकारात्प्रमत्तः शापेनास्तङ्गमितमहिमा वर्षभोग्येण भर्तुः ।\nयक्षश्चक्रे जनकतनयास्नानपुण्योदकेषु स्निग्धच्छायातरुषु वसतिं रामगिर्याश्रमेषु ॥")
    check("Meghadūta 1 = mandākrāntā", c.name == "mandākrāntā", "${c.name} ${c.syllableCounts}")
    val d = Prosody.scan("या सृष्टिः स्रष्टुराद्या वहति विधिहुतं या हविर्या च होत्री ये द्वे कालं विधत्तः श्रुतिविषयगुणा या स्थिता व्याप्य विश्वम् । यामाहुः सर्वबीजप्रकृतिरिति यया प्राणिनः प्राणवन्तः प्रत्यक्षाभिः प्रपन्नस्तनुभिरवतु वस्ताभिरष्टाभिरीशः ॥")
    check("Śākuntala nāndī = sragdharā", d.name == "sragdharā", "${d.name} ${d.syllableCounts}")
    val e = Prosody.scan("मुग्धे सा मधुमासि कोकिलरवः कान्तास्मितं सुन्दरम् ।")
    check("Single line without 4 pādas does not claim a metre falsely", e.name == null || !e.exact || e.padaCount >= 1)
    val f = Prosody.scan("")
    check("Empty input gives an empty scan", f.padaCount == 0)
    check("Syllable weight: long vowel guru, short before single consonant laghu",
        Prosody.syllabify("अनन्त").map { it.heavy } == listOf(false, true, false))
}

fun testSegmenter() {
    section("Segmenter")
    val text = "प्रथमः श्लोकः ।\nद्वितीयः पादः ॥\n\nतृतीयः अनुच्छेदः. चतुर्थं वाक्यम्."
    val segs = Segmenter.split(text, 380)
    val joined = Segmenter.join(segs, segs.map { it.text })
    check("Round trip keeps paragraph break", joined.contains("\n\n") && Segmenter.paragraphCount(joined) == 2, joined)
    check("Verse lines stay separate lines", joined.lines().first().endsWith("।"), joined)
    val long = (1..120).joinToString(" ") { "Sentence number $it is here." }
    val ls = Segmenter.split(long, 380)
    check("Long text split into chunks ≤ 380", ls.all { it.text.length <= 380 } && ls.size > 5, "${ls.size}")
    check("No characters lost in long split", ls.joinToString(" ") { it.text }.filter { !it.isWhitespace() } == long.filter { !it.isWhitespace() })
    val compound = "अ".repeat(1500)
    val cs = Segmenter.split(compound, 380)
    check("Space-free compound is cut safely and fully kept", cs.joinToString("") { it.text }.length == 1500 && cs.all { it.text.length <= 380 })
    val withMarks = "क".repeat(379) + "्ष" + "क".repeat(100)
    val ms = Segmenter.split(withMarks, 380)
    check("Cut never separates a combining mark from its letter", ms.none { it.text.startsWith("्") })
    val many = (1..10).joinToString("\n\n") { "Paragraph $it." }
    check("10 paragraphs stay 10", Segmenter.paragraphCount(Segmenter.join(Segmenter.split(many, 380), Segmenter.split(many, 380).map { it.text })) == 10)
    check("Empty input yields no segments", Segmenter.split("   \n\n  ", 380).isEmpty())
}

fun testSpellingGlossary() {
    section("Spelling and glossary")
    val r = Spelling.toBritish("Color, honor and the center; we analyze, organize and realize it. Organization, Colorful. Seize the prize, size matters. Meter of the poem.")
    check("British spelling rules", r.text == "Colour, honour and the centre; we analyse, organise and realise it. Organisation, Colourful. Seize the prize, size matters. Metre of the poem.", r.text)
    check("Words not in the list are untouched", Spelling.toBritish("Dharma and karma are doctrines.").changed == 0)
    val g = listOf(GlossaryEntry(1, sa = "धर्म", kn = "ಧರ್ಮ", en = "dharma"), GlossaryEntry(2, sa = "ज्ञान", kn = "ಜ್ಞಾನ", en = "jñāna (knowledge)"))
    val rel = Glossary.relevant(g, "Dharma is eternal", Lang.EN, Lang.KN)
    check("Glossary finds English term (case-insensitive, word-bounded)", rel.size == 1 && rel[0].id == 1L)
    check("Glossary does not match inside a longer word", Glossary.relevant(g, "dharmasthala", Lang.EN, Lang.KN).isEmpty())
    check("Glossary matches Sanskrit term typed in IAST", Glossary.relevant(g, "dharma eva", Lang.SA, Lang.EN).size == 1)
    check("Glossary output check", Glossary.termPresent("ಧರ್ಮವು ಶಾಶ್ವತ", g[0], Lang.KN) && !Glossary.termPresent("ಸತ್ಯ", g[0], Lang.KN))
    check("Glossary JSON round trip", Glossary.fromJson(Glossary.toJson(g)) == g)
    check("Glossary converts typed IAST Sanskrit to Devanagari", Glossary.normaliseSanskrit("dharma") == "धर्म")
}

fun testBhashini(mock: Mock) {
    section("Bhashini engine against mock service")
    mock.reset()
    mock.on("POST", B_CONFIG, bhashiniConfig(mock))
    var seen = emptyList<String>()
    mock.on("POST", B_COMPUTE, bhashiniCompute(onInputs = { s, _, _ -> seen = s }))
    val eng = BhashiniEngine("UID", "ULCA", mock.base + B_CONFIG)
    val tr = Trace()
    val out = eng.translate(listOf("Hello world", "Second"), Direction(Lang.EN, Lang.KN), CancelToken(), tr)
    check("returns one output per input", out.size == 2 && out[0] == "ಅನುವಾದಿತ ಪಠ್ಯ")
    val cfg = mock.last("POST", B_CONFIG)!!
    check("config call sends userID and ulcaApiKey headers", cfg.headers["userid"] == "UID" && cfg.headers["ulcaapikey"] == "ULCA", cfg.headers.toString())
    val cfgBody = JSONObject(cfg.body)
    check("config body has taskType translation + language pair + pipelineId",
        cfgBody.getJSONArray("pipelineTasks").getJSONObject(0).getString("taskType") == "translation" &&
            cfgBody.getJSONObject("pipelineRequestConfig").getString("pipelineId").isNotBlank())
    val comp = JSONObject(mock.last("POST", B_COMPUTE)!!.body)
    check("compute call uses the IndicTrans service id from the config reply",
        comp.getJSONArray("pipelineTasks").getJSONObject(0).getJSONObject("config").getString("serviceId") == "ai4bharat/indictrans-v2-all-gpu--t4")
    check("compute call sends both sentences in order", seen == listOf("Hello world", "Second"))
    check("route cached: second call does not repeat the config call", run { eng.translate(listOf("x"), Direction(Lang.EN, Lang.KN), CancelToken(), tr); mock.count("POST", B_CONFIG) == 1 })
    check("describe() names the exact service", eng.describe(Direction(Lang.EN, Lang.KN)).contains("indictrans-v2"))

    // all six directions: config is requested per pair
    for (d in Direction.ALL) {
        val o = eng.translate(listOf("x"), d, CancelToken(), tr)
        check("direction ${d.label}: request accepted and answered", o.size == 1 && o[0].isNotBlank())
    }
    val probe = eng.probeDirections(CancelToken())
    check("probeDirections reports all six directions available", probe.size == 6 && probe.all { it.second != null })

    // wrong key
    mock.reset(); mock.on("POST", B_CONFIG) { Resp(401, """{"message":"Invalid ulcaApiKey"}""") }
    val e1 = BhashiniEngine("UID", "BAD", mock.base + B_CONFIG)
    val ex = expectThrows<EngineException>("wrong key -> AUTH failure") { e1.translate(listOf("x"), Direction(Lang.EN, Lang.KN), CancelToken(), Trace()) }
    check("AUTH failure is not retryable and message is plain", ex?.kind == FailKind.AUTH && !ex.kind.retryable && ex.message!!.contains("rejected"))

    // pair not offered
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock, supported = { s, t -> !(s == "sa" || t == "sa") }))
    mock.on("POST", B_COMPUTE, bhashiniCompute())
    val e2 = BhashiniEngine("UID", "ULCA", mock.base + B_CONFIG)
    val ex2 = expectThrows<EngineException>("pair not offered -> UNSUPPORTED") { e2.translate(listOf("x"), Direction(Lang.SA, Lang.EN), CancelToken(), Trace()) }
    check("UNSUPPORTED message names the direction", ex2?.kind == FailKind.UNSUPPORTED && ex2.message!!.contains("Sanskrit → English"), ex2?.message ?: "")
    val probe2 = e2.probeDirections(CancelToken())
    check("probe shows which directions are missing", probe2.count { it.second == null } == 4 && probe2.count { it.second != null } == 2)

    // stale inference key: compute 401 once then refresh
    mock.reset()
    val keys = AtomicInteger(0)
    mock.on("POST", B_CONFIG) { req -> bhashiniConfig(mock, key = "KEY-${keys.incrementAndGet()}")(req) }
    mock.on("POST", B_COMPUTE) { req -> bhashiniCompute(expectKey = "KEY-2")(req) }
    val e3 = BhashiniEngine("UID", "ULCA", mock.base + B_CONFIG)
    val o3 = e3.translate(listOf("x"), Direction(Lang.EN, Lang.KN), CancelToken(), Trace())
    check("stale service key is refreshed automatically once", o3.size == 1 && mock.count("POST", B_CONFIG) == 2)

    // count mismatch
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock))
    mock.on("POST", B_COMPUTE) { Resp(200, """{"pipelineResponse":[{"taskType":"translation","output":[{"source":"a","target":"b"}]}]}""") }
    val e4 = BhashiniEngine("UID", "ULCA", mock.base + B_CONFIG)
    val ex4 = expectThrows<EngineException>("count mismatch is flagged") { e4.translate(listOf("a", "b"), Direction(Lang.EN, Lang.KN), CancelToken(), Trace()) }
    check("mismatch is BAD_RESPONSE", ex4?.kind == FailKind.BAD_RESPONSE)
}

fun testCloudflare(mock: Mock) {
    section("Cloudflare IndicTrans2 engine against mock service")
    mock.reset()
    mock.on("POST", CF_IT2) { req ->
        val b = JSONObject(req.body)
        if (req.headers["authorization"] != "Bearer TOK") Resp(403, """{"success":false,"errors":[{"code":10000,"message":"Authentication error"}]}""")
        else Resp(200, JSONObject().put("success", true).put("result", JSONObject().put("translations", JSONArray().put(fakeTarget(if (b.getString("target_language") == "kan_Knda") "kn" else "sa", "")))).toString())
    }
    val eng = CloudflareIndicEngine("ACC", "TOK", mock.base + "/client/v4")
    val kn = eng.translate(listOf("Knowledge"), Direction(Lang.EN, Lang.KN), CancelToken(), Trace())
    check("English -> Kannada accepted", kn == listOf("ಅನುವಾದಿತ ಪಠ್ಯ"))
    check("request body uses FLORES code kan_Knda", JSONObject(mock.last("POST", CF_IT2)!!.body).getString("target_language") == "kan_Knda")
    val sa = eng.translate(listOf("Knowledge"), Direction(Lang.EN, Lang.SA), CancelToken(), Trace())
    check("English -> Sanskrit accepted (san_Deva)", sa == listOf("अनूदितः पाठः") && JSONObject(mock.last("POST", CF_IT2)!!.body).getString("target_language") == "san_Deva")
    check("supports() is honest: only English as source", !eng.supports(Direction(Lang.KN, Lang.EN)) && !eng.supports(Direction(Lang.SA, Lang.KN)) && eng.supports(Direction(Lang.EN, Lang.SA)))
    val bad = CloudflareIndicEngine("ACC", "WRONG", mock.base + "/client/v4")
    val ex = expectThrows<EngineException>("wrong token -> AUTH") { bad.translate(listOf("x"), Direction(Lang.EN, Lang.KN), CancelToken(), Trace()) }
    check("AUTH kind for 403", ex?.kind == FailKind.AUTH && ex.message!!.contains("Authentication error"), ex?.message ?: "")
}

fun testOpenAi(mock: Mock) {
    section("Open-weight model provider against an OpenRouter-shaped mock service")
    mock.reset()
    val base = mock.base + "/api/v1"
    mock.on("POST", CHAT) { req ->
        if (req.headers["authorization"] != "Bearer KEY") Resp(401, """{"error":{"code":401,"message":"No auth credentials found"}}""")
        else llmText("{\"ok\":true}", tokens = 7)
    }
    val p = OpenAiCompatProvider("KEY", MODEL, base)
    val r = p.generate(LlmRequest("sys", "usr", json = true, maxTokens = 777, temperature = 0.3), CancelToken())
    check("reply text, model, token count and timing returned", r.text == "{\"ok\":true}" && r.model == MODEL && !r.truncated && r.completionTokens == 7 && r.latencyMs >= 0)
    val req1 = mock.last("POST", CHAT)!!
    val sent = JSONObject(req1.body)
    check("system and user text travel as separate chat messages", systemPrompt(req1) == "sys" && userPrompt(req1) == "usr" && sent.getString("model") == MODEL)
    check("max_tokens, temperature and stream=false are passed", sent.getInt("max_tokens") == 777 && sent.getDouble("temperature") == 0.3 && !sent.getBoolean("stream"))
    check("API key is sent only in the Authorization header", !req1.path.contains("KEY") && !req1.body.contains("KEY") && req1.headers["authorization"] == "Bearer KEY")
    check("no response_format is sent (many hosts reject it)", !sent.has("response_format"))
    check("by default no reasoning setting and no provider restriction are sent", !sent.has("reasoning") && !sent.has("provider"))

    val p2 = OpenAiCompatProvider("KEY", MODEL, base, false, true, Models.Think.LOW)
    p2.generate(LlmRequest("s", "u"), CancelToken())
    val s2 = JSONObject(mock.last("POST", CHAT)!!.body)
    check("thinking level is sent as reasoning.effort", s2.getJSONObject("reasoning").getString("effort") == "low")
    check("privacy option sends provider.data_collection = deny", s2.getJSONObject("provider").getString("data_collection") == "deny")
    OpenAiCompatProvider("KEY", MODEL, base, false, false, Models.Think.OFF).generate(LlmRequest("s", "u"), CancelToken())
    check("Off sends effort none", JSONObject(mock.last("POST", CHAT)!!.body).getJSONObject("reasoning").getString("effort") == "none")

    // ---- the free-only guard
    val before = mock.count("POST", CHAT)
    val paid = OpenAiCompatProvider("KEY", "deepseek/deepseek-v4.1-flash-1017", base)
    val exPaid = expectThrows<EngineException>("a paid model is refused while paid models are off") { paid.generate(LlmRequest("s", "u"), CancelToken()) }
    check("the refusal happens before anything is sent and points to Settings", mock.count("POST", CHAT) == before && exPaid?.kind == FailKind.UNSUPPORTED && exPaid.message!!.contains("Settings") && exPaid.message!!.contains("Allow paid models"), exPaid?.message ?: "")
    mock.on("POST", CHAT) { llmText("paid ok", model = "deepseek/deepseek-v4.1-flash-1017") }
    check("the same model works once paid models are allowed", OpenAiCompatProvider("KEY", "deepseek/deepseek-v4.1-flash-1017", base, allowPaid = true).generate(LlmRequest("s", "u"), CancelToken()).text == "paid ok")
    val exBad = expectThrows<EngineException>("an invalid model name is refused") { OpenAiCompatProvider("KEY", "bad name with spaces:free", base).generate(LlmRequest("s", "u"), CancelToken()) }
    check("invalid name is UNSUPPORTED", exBad?.kind == FailKind.UNSUPPORTED)
    expectThrows<EngineException>("a blank model name is refused") { OpenAiCompatProvider("KEY", "  ", base).generate(LlmRequest("s", "u"), CancelToken()) }
    check("openrouter/free router is not treated as a free model (unknown hosts and licences)", !Models.isFree("openrouter/free"))

    // ---- reading answers
    mock.on("POST", CHAT) { llmText("cut", finish = "length") }
    check("finish_reason length is reported as truncated", p.generate(LlmRequest("s", "u"), CancelToken()).truncated)
    mock.on("POST", CHAT) { llmText("<think>let me think about sandhi</think>\nThe answer.") }
    check("visible <think> blocks are removed", p.generate(LlmRequest("s", "u"), CancelToken()).text == "The answer.")
    mock.on("POST", CHAT) { llmText("some reasoning that began before the answer</think>Final answer") }
    check("a stray closing </think> drops the reasoning before it", p.generate(LlmRequest("s", "u"), CancelToken()).text == "Final answer")
    mock.on("POST", CHAT) { llmText("<think>I am still thinking and was cut off", finish = "length") }
    val exThink = expectThrows<EngineException>("thinking that eats the whole allowance is explained") { p.generate(LlmRequest("s", "u"), CancelToken()) }
    check("that failure is not retried (it would waste free requests) and names the Thinking setting", exThink?.kind == FailKind.BAD_REQUEST && !exThink.kind.retryable && exThink.message!!.contains("Thinking"), exThink?.message ?: "")
    mock.on("POST", CHAT) { Resp(200, """{"model":"x/y:free","choices":[{"finish_reason":"stop","message":{"role":"assistant","content":[{"type":"text","text":"Part one. "},{"type":"text","text":"Part two."}]}}]}""") }
    check("content given as a list of text parts is joined", p.generate(LlmRequest("s", "u"), CancelToken()).text == "Part one. Part two.")
    mock.on("POST", CHAT) { Resp(200, """{"model":"x/y:free","choices":[{"finish_reason":"stop","message":{"role":"assistant","content":null,"reasoning":"hidden"}}]}""") }
    val exEmpty = expectThrows<EngineException>("an empty answer is an error, not a blank result") { p.generate(LlmRequest("s", "u"), CancelToken()) }
    check("empty answer is BAD_RESPONSE (retryable)", exEmpty?.kind == FailKind.BAD_RESPONSE)
    mock.on("POST", CHAT) { Resp(200, "this is not json") }
    check("unreadable body is BAD_RESPONSE", expectThrows<EngineException>("garbage body") { p.generate(LlmRequest("s", "u"), CancelToken()) }?.kind == FailKind.BAD_RESPONSE)
    mock.on("POST", CHAT) { llmText("hello", model = "vendor/served-variant:free") }
    check("the model that actually answered is reported", p.generate(LlmRequest("s", "u"), CancelToken()).model == "vendor/served-variant:free")

    // ---- failures reported inside an HTTP 200
    mock.on("POST", CHAT) { Resp(200, """{"error":{"code":429,"message":"Rate limit exceeded: free-models-per-day. Add 10 credits to unlock 1000 free model requests per day"}}""") }
    val e200a = expectThrows<EngineException>("daily limit reported inside HTTP 200") { p.generate(LlmRequest("s", "u"), CancelToken()) }
    check("it is read as QUOTA and not retried", e200a?.kind == FailKind.QUOTA && !e200a.kind.retryable && e200a.message!!.contains("50 requests a day"), e200a?.message ?: "")
    mock.on("POST", CHAT) { Resp(200, """{"error":{"code":502,"message":"Provider returned error","metadata":{"provider_name":"SomeHost"}}}""") }
    val e200b = expectThrows<EngineException>("host failure reported inside HTTP 200") { p.generate(LlmRequest("s", "u"), CancelToken()) }
    check("it is SERVER (retryable) and names the host", e200b?.kind == FailKind.SERVER && e200b.message!!.contains("[host: SomeHost]"), e200b?.message ?: "")
    mock.on("POST", CHAT) { llmText("partial", finish = "error") }
    check("finish_reason error is BAD_RESPONSE", expectThrows<EngineException>("finish error") { p.generate(LlmRequest("s", "u"), CancelToken()) }?.kind == FailKind.BAD_RESPONSE)
    mock.on("POST", CHAT) { llmText("", finish = "content_filter") }
    check("content_filter is BLOCKED", expectThrows<EngineException>("content filter") { p.generate(LlmRequest("s", "u"), CancelToken()) }?.kind == FailKind.BLOCKED)

    // ---- HTTP error table
    fun fail(code: Int, msg: String, headers: Map<String, String> = emptyMap()): EngineException {
        mock.on("POST", CHAT) { Resp(code, """{"error":{"code":$code,"message":"$msg"}}""", headers) }
        return try { p.generate(LlmRequest("s", "u"), CancelToken()); EngineException(FailKind.CANCELLED, "no exception for $code") } catch (e: EngineException) { e }
    }
    check("401 -> AUTH", fail(401, "No auth credentials found").kind == FailKind.AUTH)
    val e402 = fail(402, "Insufficient credits")
    check("402 -> QUOTA, not retryable, says free models need a non-negative balance", e402.kind == FailKind.QUOTA && !e402.kind.retryable && e402.message!!.contains("zero or above"))
    check("403 moderation -> BLOCKED", fail(403, "Your chosen model requires moderation and your input was flagged").kind == FailKind.BLOCKED)
    check("403 other -> AUTH", fail(403, "Key lacks permission").kind == FailKind.AUTH)
    val e404 = fail(404, "No endpoints found for test/open-model:free")
    check("404 -> UNSUPPORTED and tells the user the model may be withdrawn", e404.kind == FailKind.UNSUPPORTED && e404.message!!.contains("withdrawn") && e404.message!!.contains(MODEL))
    check("408 -> TIMEOUT (retryable)", fail(408, "Request timed out").kind == FailKind.TIMEOUT)
    val e429d = fail(429, "Rate limit exceeded: free-models-per-day. Add 10 credits")
    check("429 daily -> QUOTA, not retryable", e429d.kind == FailKind.QUOTA && !e429d.kind.retryable)
    val e429m = fail(429, "Rate limit exceeded: free-models-per-min", mapOf("Retry-After" to "7"))
    check("429 per minute -> RATE_LIMIT honouring Retry-After", e429m.kind == FailKind.RATE_LIMIT && e429m.retryAfterMs == 7000L)
    check("429 per minute without a header waits a sensible default", fail(429, "slow down").retryAfterMs == 15_000L)
    check("502 -> SERVER", fail(502, "Your chosen model is down").kind == FailKind.SERVER)
    val e503r = fail(503, "No available model provider that meets your routing requirements")
    check("503 routing -> UNSUPPORTED and mentions the privacy option", e503r.kind == FailKind.UNSUPPORTED && e503r.message!!.contains("Avoid hosts"))
    check("503 plain -> SERVER", fail(503, "overloaded").kind == FailKind.SERVER)
    check("400 -> BAD_REQUEST", fail(400, "bad parameter").kind == FailKind.BAD_REQUEST)

    // ---- public catalogue and key status
    mock.on("GET", OR_MODELS) { Resp(200, """{"data":[
        {"id":"qwen/qwen3.8-27b:free","name":"Qwen3.8 27B (free)","context_length":262144,"pricing":{"prompt":"0","completion":"0"}},
        {"id":"deepseek/deepseek-v4.1-flash-1017","name":"DeepSeek V4.1 Flash","context_length":1048576,"pricing":{"prompt":"0.00000006","completion":"0.0000006"}},
        {"id":"","name":"broken row"}]}""") }
    val listed = p.listModels(CancelToken())
    check("model list is parsed, empty rows skipped", listed.size == 2 && listed[0].contextLength == 262144 && listed[1].promptPrice == "0.00000006")
    check("free means the :free suffix only", listed[0].free && !listed[1].free)
    mock.on("GET", OR_KEY) { Resp(200, """{"data":{"label":"example-key-label","is_free_tier":true,"usage":0,"limit":null,"free_model_daily_requests":3}}""") }
    val ks = p.keyStatus(CancelToken())
    check("key status shows what the service reports and skips nulls", ks.contains("is_free_tier: true") && ks.contains("free_model_daily_requests: 3") && !ks.contains("limit: null"), ks)
    mock.on("GET", OR_KEY) { Resp(401, """{"error":{"message":"bad key"}}""") }
    check("key status with a wrong key -> AUTH", expectThrows<EngineException>("key status 401") { p.keyStatus(CancelToken()) }?.kind == FailKind.AUTH)

    // ---- labels and helper rules
    check("OpenRouter is named plainly; another address is named by host", OpenAiCompatProvider("K", MODEL, Models.OPENROUTER_BASE).label == "OpenRouter" && OpenAiCompatProvider("K", MODEL, "https://my.proxy.example/v1").label.contains("my.proxy.example"))
    check("service address must be https and loses a trailing slash", Models.normaliseBase("http://x.example/v1") == null && Models.normaliseBase(" https://x.example/v1/ ") == "https://x.example/v1" && Models.normaliseBase("") == null)
    check("model names: provider/name[:variant]", Models.validId("qwen/qwen3.8-27b:free") && !Models.validId("a b") && !Models.validId("") && !Models.validId("x"))
    check("Think.fromName defaults to Low for unknown values", Models.Think.fromName("nonsense") == Models.Think.LOW && Models.Think.fromName("HIGH") == Models.Think.HIGH)
    check("default model is free and is one of the licence-checked models", Models.isFree(Models.DEFAULT_MODEL) && Models.candidate(Models.DEFAULT_MODEL) != null)
    check("every checked model names an allowed open licence and its source", Models.CHECKED.all { (it.licence == "Apache-2.0" || it.licence == "MIT") && it.licenceSource.isNotBlank() } && Models.CHECKED.map { it.id }.toSet().size == Models.CHECKED.size)
    check("no checked model is a proprietary Claude or Gemini model", Models.CHECKED.none { it.id.startsWith("anthropic/") || it.id.contains("gemini") })
    val c = Credentials(aiSource = AiSource.ONLINE, llmKey = "K")
    check("factory builds a provider only when a key is present", ServiceFactory.llmRouter(Credentials(aiSource = AiSource.ONLINE)).isEmpty && !ServiceFactory.llmRouter(c).isEmpty && ServiceFactory.llmRouter(c).labels == listOf("OpenRouter"))
    check("a saved address that is not https is refused, and the key is never sent to a different service instead",
        try { ServiceFactory.provider(Credentials(aiSource = AiSource.ONLINE, llmKey = "K", llmBaseUrl = "http://evil.example")); false } catch (ex: EngineException) { ex.kind == FailKind.UNSUPPORTED && ex.message!!.contains("https://") })
    check("a blank saved address means OpenRouter", ServiceFactory.provider(Credentials(aiSource = AiSource.ONLINE, llmKey = "K", llmBaseUrl = "")).label == "OpenRouter")
}

fun testCompare(mock: Mock) {
    section("Model comparison (real pipeline, mock models)")
    mock.reset()
    val base = mock.base + "/api/v1"
    // model A answers; model B hits the daily limit; model C never produces usable JSON
    mock.on("POST", CHAT) { req ->
        val model = JSONObject(req.body).getString("model")
        val u = userPrompt(req)
        when (model) {
            "test/a:free" -> {
                val n = Regex("Number of segments: (\\d+)").find(u)?.groupValues?.get(1)?.toInt() ?: 1
                val arr = JSONArray(); repeat(n) { arr.put("I read the book.") }
                llmText(JSONObject().put("translations", arr).toString(), model = "test/a:free")
            }
            "test/b:free" -> Resp(429, """{"error":{"code":429,"message":"Rate limit exceeded: free-models-per-day. Add 10 credits"}}""")
            else -> llmText("Sorry, no JSON here.", model = model)
        }
    }
    val creds = Credentials(aiSource = AiSource.ONLINE, llmKey = "KEY")
    val make = { c: Credentials, m: String -> OpenAiCompatProvider(c.llmKey, m, base, c.allowPaid, c.denyDataCollection, Models.Think.fromName(c.thinking)) as LlmProvider }
    val quick = RetryPolicy(2, 1000, sleeper = { })
    val sa = "अहं पुस्तकं पठामि।"
    val a = ModelCompare.run(ModelCompare.Task.TRANSLATE, sa, Direction(Lang.SA, Lang.EN), Lang.EN, creds, "test/a:free", CancelToken(), quick, make = make)
    check("a working model gives its answer", a.ok && a.text.contains("I read the book") && a.servedBy == "test/a:free" && a.error == null, a.error ?: a.text)
    check("it used exactly one request and the time was measured", a.requests == 1 && a.millis >= 0)
    check("the comparison says plainly that this was not IndicTrans2", a.qcWarnings >= 1)
    val b = ModelCompare.run(ModelCompare.Task.TRANSLATE, sa, Direction(Lang.SA, Lang.EN), Lang.EN, creds, "test/b:free", CancelToken(), quick, make = make)
    check("a model that hits the daily limit is reported as failed with the reason, not hidden", !b.ok && b.error!!.contains("daily"), b.error ?: "")
    check("the daily-limit failure was not retried", b.requests == 1, b.requests.toString())
    val c = ModelCompare.run(ModelCompare.Task.SLOKA, ModelCompare.SAMPLES[1].text, Direction(Lang.SA, Lang.EN), Lang.EN, creds, "test/c:free", CancelToken(), quick, make = make)
    check("a model that answers without usable JSON does not crash the comparison and is flagged", !c.ok || c.qcWarnings > 0, "ok=${c.ok} warnings=${c.qcWarnings}")
    val d = ModelCompare.run(ModelCompare.Task.TRANSLATE, sa, Direction(Lang.SA, Lang.EN), Lang.EN, creds, "paid/x-model", CancelToken(), quick, make = make)
    check("a paid model is refused by the guard and no request is sent", !d.ok && d.error!!.contains("Allow paid models") && d.requests == 0, d.error ?: "")
    val tok = CancelToken(); tok.cancel()
    val e = ModelCompare.run(ModelCompare.Task.TRANSLATE, sa, Direction(Lang.SA, Lang.EN), Lang.EN, creds, "test/a:free", tok, quick, make = make)
    check("a cancelled run says so", !e.ok && e.error == "Cancelled.")
    val f = ModelCompare.run(ModelCompare.Task.TRANSLATE, sa, Direction(Lang.SA, Lang.EN), Lang.EN, creds.copy(llmBaseUrl = "http://not-secure.example"), "test/a:free", CancelToken(), quick)
    check("an address that is not https is refused with a clear message, not silently replaced", !f.ok && f.error!!.contains("https://") && f.requests == 0, f.error ?: "")
    check("a saved bad address gives a router that explains itself", try { ServiceFactory.llmRouter(Credentials(aiSource = AiSource.ONLINE, llmKey = "K", llmBaseUrl = "http://x.example")).generate(LlmRequest("s", "u"), CancelToken(), Trace()); false } catch (ex: ServiceFailure) { ex.message!!.contains("https://") })

    section("Comparison samples are sound")
    check("every sample has text and a task", ModelCompare.SAMPLES.all { it.text.isNotBlank() })
    check("Sanskrit samples are written in Devanagari", ModelCompare.SAMPLES.filter { it.src == Lang.SA }.all { Scripts.share(it.text, Script.DEVANAGARI) > 0.9 })
    val gita247 = OfflineTools.metreReport(ModelCompare.SAMPLES[1].text).toPlain()
    check("the verse sample scans as anuṣṭubh with four 8-syllable pādas, by the app's own scanner", gita247.contains("anuṣṭubh") && (1..4).all { gita247.contains("Pāda $it — 8 syllables") }, gita247.take(300))
}

// ------------------------------------------------------------------ sign-in (OpenRouter OAuth with PKCE, loopback reply)
/** Sends one raw HTTP request to a port on this machine and returns (status, whole response text). */
fun rawGet(port: Int, requestLine: String, host: String? = "localhost:$port", timeoutMs: Int = 3000): Pair<Int, String> {
    java.net.Socket("127.0.0.1", port).use { s ->
        s.soTimeout = timeoutMs
        val req = requestLine + "\r\n" + (if (host != null) "Host: $host\r\n" else "") + "Connection: close\r\n\r\n"
        s.getOutputStream().write(req.toByteArray(Charsets.ISO_8859_1)); s.getOutputStream().flush()
        val text = String(s.getInputStream().readBytes(), Charsets.UTF_8)
        val code = Regex("^HTTP/1\\.[01] (\\d{3})").find(text)?.groupValues?.get(1)?.toInt() ?: -1
        return code to text
    }
}

fun queryOf(url: String): Map<String, String> = LoopbackReceiver.parseQuery(java.net.URI(url).rawQuery ?: "")

/** Plays the part of the browser: reads the sign-in address the app opened and calls back the address it contains. */
fun fakeBrowser(url: String, onCallback: (callback: String, state: String, challenge: String) -> Unit): Boolean {
    val q = queryOf(url)
    val cb = q["callback_url"] ?: return false
    Thread { try { Thread.sleep(150); onCallback(cb, q["state"] ?: "", q["code_challenge"] ?: "") } catch (_: Exception) {} }.start()
    return true
}

fun httpGet(url: String): Int {
    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 3000; c.readTimeout = 3000
    return try { c.responseCode } finally { c.disconnect() }
}

fun testSignIn(mock: Mock) {
    section("Sign-in: PKCE")
    // The worked example in RFC 7636, Appendix B.
    check("PKCE challenge matches the RFC 7636 example", Pkce.challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk") == "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM")
    val v1 = Pkce.newVerifier(); val v2 = Pkce.newVerifier()
    check("verifier is 43 URL-safe characters", v1.length == 43 && v1.all { it.isLetterOrDigit() || it == '-' || it == '_' })
    check("verifiers differ each time", v1 != v2 && Pkce.newState() != Pkce.newState())
    check("state is long enough to be unguessable", Pkce.newState().length >= 32)

    section("Sign-in: the address opened in the browser")
    val url = OpenRouterAuth.authorizeUrl("http://localhost:51423/callback", "CHAL", "ST&ATE=1", "Tribhasa Android app")
    val uri = java.net.URI(url)
    val q = queryOf(url)
    check("address is OpenRouter's documented sign-in page", uri.scheme == "https" && uri.host == "openrouter.ai" && uri.path == "/auth")
    check("callback_url, code_challenge and method are sent", q["callback_url"] == "http://localhost:51423/callback" && q["code_challenge"] == "CHAL" && q["code_challenge_method"] == "S256")
    check("state survives encoding and the key label is set", q["state"] == "ST&ATE=1" && q["key_label"] == "Tribhasa Android app")
    check("no key or secret is placed in the address", !url.contains("verifier") && !url.contains("sk-"))

    section("Sign-in: the listener on this phone")
    val state = "STATE-ABC-123"
    LoopbackReceiver(state).start().use { rx ->
        check("it listens on a system-chosen port of this phone only", rx.port > 0 && rx.callbackUrl == "http://localhost:${rx.port}/callback")
        val (c404, _) = rawGet(rx.port, "GET /favicon.ico HTTP/1.1")
        check("other paths get 404", c404 == 404)
        val (cHost, _) = rawGet(rx.port, "GET /callback?code=X&state=$state HTTP/1.1", host = "evil.example:${rx.port}")
        check("a wrong Host header is refused (DNS-rebinding guard)", cHost == 400)
        val (cNoHost, _) = rawGet(rx.port, "GET /callback?code=X&state=$state HTTP/1.1", host = null)
        check("a missing Host header is refused", cNoHost == 400)
        val (cPost, _) = rawGet(rx.port, "POST /callback?code=X&state=$state HTTP/1.1")
        check("only GET is answered", cPost == 405)
        val (cBadState, _) = rawGet(rx.port, "GET /callback?code=X&state=WRONG HTTP/1.1")
        check("a code with the wrong state is refused", cBadState == 400)
        val (cNoState, _) = rawGet(rx.port, "GET /callback?code=X HTTP/1.1")
        check("a code without state is refused", cNoState == 400)
        val t0 = System.nanoTime()
        expectThrows<SignInException>("nothing valid so far: waiting times out") { rx.await(400, CancelToken()) }
        check("the time-out is prompt", (System.nanoTime() - t0) / 1_000_000 in 350..2500)
        // An idle connection (browsers open spare ones) must not hold up the real reply.
        val idle = java.net.Socket("127.0.0.1", rx.port)
        Thread.sleep(100)
        val t1 = System.nanoTime()
        val (cOk, page) = rawGet(rx.port, "GET /callback?code=CODE%2B1&state=$state HTTP/1.1")
        val got = rx.await(2000, CancelToken())
        idle.close()
        check("a valid reply is answered with 200 and a page", cOk == 200 && page.contains("text/html") && page.contains("tribhasa://connected"))
        check("the code is delivered decoded", got is LoopbackReceiver.Callback.Code && got.code == "CODE+1")
        check("an idle connection does not delay it", (System.nanoTime() - t1) / 1_000_000 < 2000)
        check("the page never repeats what was sent", !page.contains("CODE") && !page.contains(state) && page.contains("no-store"))
    }
    LoopbackReceiver(state).start().use { rx ->
        val (cd, pd) = rawGet(rx.port, "GET /callback HTTP/1.1")
        check("a reply without a code means the user declined", cd == 200 && rx.await(2000, CancelToken()) is LoopbackReceiver.Callback.Denied && pd.contains("not completed"))
    }
    LoopbackReceiver(state).start().use { rx ->
        val real = httpGet(rx.callbackUrl + "?code=VIA-NAME&state=$state")
        check("the advertised address (localhost name) really reaches the listener", real == 200 && (rx.await(2000, CancelToken()) as? LoopbackReceiver.Callback.Code)?.code == "VIA-NAME")
    }
    run {
        val rx = LoopbackReceiver(state).start()
        val port = rx.port
        rx.close()
        val refused = try { java.net.Socket("127.0.0.1", port).use { false } } catch (e: java.io.IOException) { true }
        check("after closing, nothing listens any more", refused)
    }
    run {
        val rx = LoopbackReceiver(state).start()
        val cancel = CancelToken()
        Thread { Thread.sleep(250); cancel.cancel() }.start()
        val t0 = System.nanoTime()
        val e = expectThrows<EngineException>("cancelling stops the wait") { rx.await(30_000, cancel) }
        check("cancelled quickly with the CANCELLED kind", e?.kind == FailKind.CANCELLED && (System.nanoTime() - t0) / 1_000_000 < 3000)
        rx.close()
    }

    section("Sign-in: swapping the code for the user's key")
    val EX = "/api/v1/auth/keys"
    mock.reset()
    mock.on("POST", EX) { req ->
        val b = JSONObject(req.body)
        if (b.optString("code") == "GOOD" && b.optString("code_verifier") == "VER" && b.optString("code_challenge_method") == "S256") Resp(200, """{"key":"TESTKEY-ISSUED-1","user_id":"user_1"}""")
        else Resp(403, """{"error":{"message":"Invalid code or code_verifier"}}""")
    }
    val exUrl = mock.base + EX
    check("a good code gives the key", OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), exUrl) == "TESTKEY-ISSUED-1")
    check("the request carries code, verifier and S256", mock.last("POST", EX)?.body?.let { val j = JSONObject(it); j.getString("code") == "GOOD" && j.getString("code_verifier") == "VER" && j.getString("code_challenge_method") == "S256" } == true)
    check("no Authorization header is sent for the exchange", mock.last("POST", EX)?.headers?.containsKey("authorization") == false)
    val bad = expectThrows<SignInException>("a wrong code is reported as rejected") { OpenRouterAuth.exchange("BAD", "VER", CancelToken(), exUrl) }
    check("rejection is explained without any secret", bad?.why == SignInException.Why.REJECTED && bad.message!!.contains("connect again") && !bad.message!!.contains("VER") && bad.detail?.contains("403") == true)
    for ((code, word) in listOf(400 to "request", 405 to "kind of sign-in", 429 to "limiting", 503 to "unavailable")) {
        mock.on("POST", EX) { Resp(code, """{"error":{"message":"x"}}""") }
        val e = expectThrows<SignInException>("HTTP $code is explained in plain words") { OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), exUrl) }
        check("HTTP $code message mentions '$word'", e?.message?.contains(word) == true)
    }
    mock.on("POST", EX) { Resp(200, """{"user_id":"u"}""") }
    expectThrows<SignInException>("a reply without a key is rejected") { OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), exUrl) }
    mock.on("POST", EX) { Resp(200, """{"key":null}""") }
    expectThrows<SignInException>("a null key is rejected") { OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), exUrl) }
    mock.on("POST", EX) { Resp(200, """{"key":"has a space"}""") }
    expectThrows<SignInException>("a key with spaces is rejected") { OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), exUrl) }
    mock.on("POST", EX) { Resp(200, "not json") }
    expectThrows<SignInException>("a reply that is not JSON is rejected") { OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), exUrl) }
    val dead = java.net.ServerSocket(0).use { it.localPort }
    val net = expectThrows<SignInException>("an unreachable server is a network failure") { OpenRouterAuth.exchange("GOOD", "VER", CancelToken(), "http://127.0.0.1:$dead$EX") }
    check("network failure is worded for the user", net?.why == SignInException.Why.NETWORK && net.message!!.contains("internet"))

    section("Sign-in: the whole flow, with a browser stand-in")
    mock.reset()
    val seenChallenge = java.util.concurrent.atomic.AtomicReference("")
    mock.on("POST", EX) { req ->
        val b = JSONObject(req.body)
        val ok = Pkce.challenge(b.optString("code_verifier")) == seenChallenge.get() && b.optString("code") == "CODE-FLOW"
        if (ok) Resp(200, """{"key":"TESTKEY-FLOW"}""") else Resp(403, """{"error":{"message":"Invalid code or code_verifier"}}""")
    }
    val steps = java.util.Collections.synchronizedList(ArrayList<String>())
    val key = OpenRouterAuth.signIn(
        open = { u -> fakeBrowser(u) { cb, st, ch -> seenChallenge.set(ch); httpGet("$cb?code=CODE-FLOW&state=" + java.net.URLEncoder.encode(st, "UTF-8")) } },
        cancel = CancelToken(), progress = { steps.add(it) }, authBase = "https://openrouter.ai/auth", exchangeUrl = mock.base + EX, waitMs = 10_000)
    check("the key comes back after the user authorises", key == "TESTKEY-FLOW")
    check("the exchange proves the PKCE secret that matches the challenge in the address", mock.count("POST", EX) == 1)
    check("the user is told what to do and when it is finishing", steps.any { it.contains("Authorize") } && steps.any { it.contains("Finishing") })

    // A stray request with a wrong state arrives first; the genuine reply still completes the sign-in.
    seenChallenge.set("")
    val key2 = OpenRouterAuth.signIn(
        open = { u -> fakeBrowser(u) { cb, st, ch -> seenChallenge.set(ch); try { httpGet("$cb?code=CODE-FLOW&state=FORGED") } catch (_: Exception) {}; httpGet("$cb?code=CODE-FLOW&state=" + java.net.URLEncoder.encode(st, "UTF-8")) } },
        cancel = CancelToken(), exchangeUrl = mock.base + EX, waitMs = 10_000)
    check("a forged reply is ignored and the real one is used", key2 == "TESTKEY-FLOW")

    val denied = expectThrows<SignInException>("declining in the browser ends the sign-in") {
        OpenRouterAuth.signIn(open = { u -> fakeBrowser(u) { cb, _, _ -> httpGet(cb) } }, cancel = CancelToken(), exchangeUrl = mock.base + EX, waitMs = 10_000)
    }
    check("declined is reported as such, and no exchange was attempted", denied?.why == SignInException.Why.DENIED && mock.count("POST", EX) == 2)

    val nobrowser = expectThrows<SignInException>("no browser on the phone") {
        OpenRouterAuth.signIn(open = { false }, cancel = CancelToken(), exchangeUrl = mock.base + EX, waitMs = 10_000)
    }
    check("missing browser is reported", nobrowser?.why == SignInException.Why.BROWSER)

    val slow = expectThrows<SignInException>("the user never returns") {
        OpenRouterAuth.signIn(open = { true }, cancel = CancelToken(), exchangeUrl = mock.base + EX, waitMs = 500)
    }
    check("time-out is reported", slow?.why == SignInException.Why.TIMEOUT)

    run {
        val cancel = CancelToken()
        Thread { Thread.sleep(300); cancel.cancel() }.start()
        val e = expectThrows<EngineException>("cancel while waiting for the browser") {
            OpenRouterAuth.signIn(open = { true }, cancel = cancel, exchangeUrl = mock.base + EX, waitMs = 20_000)
        }
        check("cancel is a cancel, not an error", e?.kind == FailKind.CANCELLED)
    }

    // After every attempt above, the listener has been closed: capture a port and check nothing stays open.
    val portSeen = java.util.concurrent.atomic.AtomicInteger(0)
    try { OpenRouterAuth.signIn(open = { u -> portSeen.set(java.net.URI(queryOf(u)["callback_url"]!!).port); true }, cancel = CancelToken(), exchangeUrl = mock.base + EX, waitMs = 300) } catch (_: SignInException) {}
    // The listener closes as signIn returns; the operating system may take a moment to refuse connections, and the port
    // number can be handed to some other program straight away, so ask for up to two seconds and accept the first refusal.
    var refused = false
    for (i in 0 until 20) {
        refused = try { java.net.Socket("127.0.0.1", portSeen.get()).use { false } } catch (e: java.io.IOException) { true }
        if (refused) break
        Thread.sleep(100)
    }
    check("the listener is closed once the sign-in ends", portSeen.get() > 0 && refused)

    section("Sign-in: the key is only ever sent to OpenRouter")
    val sk = Credentials(aiSource = AiSource.ONLINE, llmKey = "K", llmModel = MODEL, llmKeyFromSignIn = true)
    check("default address works with a sign-in key", ServiceFactory.provider(sk) != null)
    check("blank address means OpenRouter", ServiceFactory.provider(sk.copy(llmBaseUrl = "")) != null)
    val misuse = expectThrows<EngineException>("a sign-in key is refused for another service") { ServiceFactory.provider(sk.copy(llmBaseUrl = "https://example.org/v1")) }
    check("the refusal says where to fix it", misuse?.kind == FailKind.UNSUPPORTED && misuse.message!!.contains("Advanced"))
    check("a hand-entered key may use the owner's own backend", ServiceFactory.provider(sk.copy(llmKeyFromSignIn = false, llmBaseUrl = "https://backend.example.org/v1")) != null)
    check("the router turns the misuse into a clear failure, not a send", run {
        val r = ServiceFactory.llmRouter(sk.copy(llmBaseUrl = "https://example.org/v1"), NO_WAIT)
        try { r.generate(LlmRequest("s", "u"), CancelToken(), Trace()); false } catch (e: Exception) { true }
    })
}

fun testRetryAndFailover(mock: Mock) {
    section("Retry, back-off, fail-over")
    // 503 twice then success
    mock.reset()
    val n = AtomicInteger(0)
    mock.on("POST", CHAT) { if (n.incrementAndGet() < 3) Resp(503, """{"error":{"message":"overloaded"}}""") else llmText("done") }
    val waits = ArrayList<Long>()
    val pol = RetryPolicy(3, 1000, sleeper = { waits.add(it) })
    val router = LlmRouter(listOf(OpenAiCompatProvider("KEY", MODEL, mock.base + "/api/v1")), pol)
    val tr = Trace()
    val rep = router.generate(LlmRequest("s", "u"), CancelToken(), tr)
    check("temporary 503 is retried and succeeds", rep.text == "done" && n.get() == 3 && tr.retries == 2)
    check("back-off waits grow (1s then 2s)", waits.sum() in 2900..3300, waits.sum().toString())

    // 429 with Retry-After
    mock.reset(); val m = AtomicInteger(0); waits.clear()
    mock.on("POST", CHAT) { if (m.incrementAndGet() < 2) Resp(429, """{"error":{"message":"rate limit"}}""", mapOf("Retry-After" to "7")) else llmText("ok") }
    val rep2 = router.generate(LlmRequest("s", "u"), CancelToken(), Trace())
    check("Retry-After header is honoured", rep2.text == "ok" && waits.sum() >= 7000, waits.sum().toString())

    // wrong key: no retry
    mock.reset(); mock.on("POST", CHAT) { Resp(403, """{"error":{"message":"API key not valid"}}""") }
    val ex = expectThrows<ServiceFailure>("wrong key fails after one attempt") { router.generate(LlmRequest("s", "u"), CancelToken(), Trace()) }
    check("no retry on AUTH", mock.count("POST", CHAT) == 1 && ex!!.kinds.contains(FailKind.AUTH))

    // timeout (server never answers within read timeout) -> use tiny timeout via connection refused instead
    val dead = LlmRouter(listOf(OpenAiCompatProvider("KEY", MODEL, "http://127.0.0.1:1/api/v1")), NO_WAIT)
    val tr3 = Trace()
    val ex3 = expectThrows<ServiceFailure>("unreachable network -> ServiceFailure") { dead.generate(LlmRequest("s", "u"), CancelToken(), tr3) }
    check("network failure retried 2 times then reported plainly", tr3.retries == 2 && ex3!!.kinds.contains(FailKind.NETWORK) && ex3.message!!.contains("connection"), ex3?.message ?: "")

    // fail-over from one model to another
    mock.reset()
    val aCalls = AtomicInteger(0)
    mock.on("POST", CHAT) { req ->
        if (JSONObject(req.body).getString("model") == "test/model-a:free") { aCalls.incrementAndGet(); Resp(500, """{"error":{"message":"boom"}}""") }
        else llmText("from model b", model = "test/model-b:free")
    }
    val two = LlmRouter(listOf(OpenAiCompatProvider("KEY", "test/model-a:free", mock.base + "/api/v1"), OpenAiCompatProvider("KEY", "test/model-b:free", mock.base + "/api/v1")), NO_WAIT)
    val tr4 = Trace()
    val r4 = two.generate(LlmRequest("s", "u"), CancelToken(), tr4)
    check("second model used automatically when the first keeps failing", r4.text == "from model b" && tr4.failovers == 1 && aCalls.get() == 3)

    // back-up model: not tried when the whole account is refused
    mock.reset()
    val quotaCalls = java.util.concurrent.ConcurrentHashMap<String, AtomicInteger>()
    mock.on("POST", CHAT) { req ->
        val mdl = JSONObject(req.body).getString("model")
        quotaCalls.computeIfAbsent(mdl) { AtomicInteger() }.incrementAndGet()
        Resp(429, """{"error":{"message":"Rate limit exceeded: free-models-per-day"}}""")
    }
    val trQ = Trace()
    val exQ = expectThrows<ServiceFailure>("daily allowance used up on the account") { two.generate(LlmRequest("s", "u"), CancelToken(), trQ) }
    check("the back-up model is not tried when the account itself is out of allowance",
        quotaCalls["test/model-a:free"]?.get() == 1 && quotaCalls["test/model-b:free"] == null && exQ!!.kinds == setOf(FailKind.QUOTA) && trQ.log.any { it.contains("not tried") })
    mock.reset(); val authCalls = AtomicInteger(0)
    mock.on("POST", CHAT) { authCalls.incrementAndGet(); Resp(401, """{"error":{"message":"No auth credentials found"}}""") }
    expectThrows<ServiceFailure>("key refused") { two.generate(LlmRequest("s", "u"), CancelToken(), Trace()) }
    check("a refused key is not sent again under another model name", authCalls.get() == 1)
    // two different services (different accounts) are still both tried
    mock.reset(); val svcA = AtomicInteger(0); val svcB = AtomicInteger(0)
    mock.on("POST", "/api/v1/chat/completions") { svcA.incrementAndGet(); Resp(429, """{"error":{"message":"free-models-per-day"}}""") }
    mock.on("POST", "/alt/v1/chat/completions") { svcB.incrementAndGet(); llmText("from the other service", model = "test/model-b:free") }
    val otherAcct = LlmRouter(listOf(OpenAiCompatProvider("KEY", "test/model-a:free", mock.base + "/api/v1"), OpenAiCompatProvider("KEY2", "test/model-b:free", mock.base + "/alt/v1")), NO_WAIT)
    val oa = otherAcct.generate(LlmRequest("s", "u"), CancelToken(), Trace())
    check("a different service (a different account) is still tried after one is used up", oa.text == "from the other service" && svcA.get() == 1 && svcB.get() == 1)

    // back-up model selection from the saved settings
    val bc = Credentials(aiSource = AiSource.ONLINE, llmKey = "K", llmModel = "test/model-a:free", fallbackModel = "test/model-b:free")
    check("a free back-up model is accepted", ServiceFactory.backupModel(bc) == "test/model-b:free")
    check("no back-up by default", ServiceFactory.backupModel(bc.copy(fallbackModel = "")) == null)
    check("a back-up equal to the first model is ignored", ServiceFactory.backupModel(bc.copy(fallbackModel = "test/model-a:free")) == null)
    check("a paid back-up is refused while paid models are off", ServiceFactory.backupModel(bc.copy(fallbackModel = "vendor/paid-model")) == null)
    check("a paid back-up is accepted once the user has allowed paid models", ServiceFactory.backupModel(bc.copy(fallbackModel = "vendor/paid-model", allowPaid = true)) == "vendor/paid-model")
    check("an invalid back-up name is ignored", ServiceFactory.backupModel(bc.copy(fallbackModel = "bad name!")) == null)
    check("the router holds two models only when a back-up is set",
        ServiceFactory.llmRouter(bc, NO_WAIT).labels.size == 2 && ServiceFactory.llmRouter(bc.copy(fallbackModel = ""), NO_WAIT).labels.size == 1)

    // cancellation
    val tok = CancelToken(); tok.cancel()
    expectThrows<EngineException>("cancelled token stops immediately") { Http.request("GET", mock.base + "/x", emptyMap(), null, tok) }
}

fun mkService(mock: Mock, bhashini: Boolean = true, cloudflare: Boolean = false, llmOn: Boolean = true, model: String = MODEL): TranslationService {
    val llm = if (llmOn) orRouter(mock, model) else LlmRouter(emptyList(), NO_WAIT)
    val engines = ArrayList<TranslationEngine>()
    if (bhashini) engines.add(BhashiniEngine("UID", "ULCA", mock.base + B_CONFIG))
    if (cloudflare) engines.add(CloudflareIndicEngine("ACC", "TOK", mock.base + "/client/v4"))
    if (!llm.isEmpty) engines.add(LlmTranslationEngine(llm))
    return TranslationService(engines, if (llm.isEmpty) null else llm, NO_WAIT)
}

fun testTranslation(mock: Mock) {
    section("Translation service — six directions, one by one (mock IndicTrans2)")
    val samples = mapOf(Lang.SA to "विद्या परमं धनम्।", Lang.KN to "ಜ್ಞಾನವೇ ಶ್ರೇಷ್ಠ ಸಂಪತ್ತು.", Lang.EN to "Knowledge is the supreme wealth.")
    for (d in Direction.ALL) {
        mock.reset()
        mock.on("POST", B_CONFIG, bhashiniConfig(mock))
        var got = emptyList<String>()
        mock.on("POST", B_COMPUTE, bhashiniCompute(onInputs = { s, _, _ -> got = s }))
        val svc = mkService(mock, llmOn = false)
        val job = svc.newJob(samples.getValue(d.src), d, Options(), emptyList())
        val res = svc.run(job, CancelToken()) { }
        check("${d.label}: translated", res.output.isNotBlank() && res.usedIndicTrans2, res.output)
        check("${d.label}: source sent unchanged", got == listOf(samples.getValue(d.src)))
        check("${d.label}: QC has no failure and passes the script check", res.qc.items.none { it.status == Qc.FAIL } && res.qc.items.any { it.status == Qc.PASS && it.text.startsWith("Output is written in") }, res.qc.toPlain())
        check("${d.label}: QC says IndicTrans2 and what was NOT checked", res.qc.toPlain().contains("indictrans-v2") && res.qc.toPlain().contains("Not checked"))
        if (d.tgt == Lang.EN) check("English output uses British spelling (color -> colour)", res.output.contains("colour") && !res.output.contains("color"), res.output)
    }

    section("Sanskrit typed in IAST / Kannada script is converted before sending")
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock))
    var sent = emptyList<String>()
    mock.on("POST", B_COMPUTE, bhashiniCompute(onInputs = { s, _, _ -> sent = s }))
    val svc = mkService(mock, llmOn = false)
    val r1 = svc.run(svc.newJob("vidyā paramaṃ dhanam", Direction(Lang.SA, Lang.EN), Options(), emptyList()), CancelToken()) { }
    check("IAST input sent as Devanagari", sent == listOf("विद्या परमं धनम्"), sent.toString())
    check("QC tells the user about the conversion", r1.qc.toPlain().contains("IAST"))
    svc.run(svc.newJob("ವಿದ್ಯಾ ಪರಮಂ ಧನಮ್", Direction(Lang.SA, Lang.EN), Options(), emptyList()), CancelToken()) { }
    check("Kannada-script Sanskrit sent as Devanagari", sent == listOf("विद्या परमं धनम्"), sent.toString())

    section("Long text: paragraphs, no silent truncation")
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock))
    val total = AtomicInteger(0)
    mock.on("POST", B_COMPUTE, bhashiniCompute(onInputs = { s, _, _ -> total.addAndGet(s.size) }))
    val para = (1..30).joinToString(" ") { "This is English sentence number $it of the long passage." }
    val longText = listOf(para, para, para).joinToString("\n\n")
    val job = svc.newJob(longText, Direction(Lang.EN, Lang.KN), Options(), emptyList())
    val big = svc.run(job, CancelToken()) { }
    val expectedSegs = Segmenter.split(longText, 380).size
    check("every segment sent to the service", total.get() == expectedSegs && job.doneCount == expectedSegs, "${total.get()} vs $expectedSegs")
    check("3 paragraphs in, 3 paragraphs out", Segmenter.paragraphCount(big.output) == 3, big.output.take(100))
    check("QC reports paragraph preservation", big.qc.toPlain().contains("Paragraph breaks preserved (3 paragraphs)"))

    section("Numbers are checked")
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock)); mock.on("POST", B_COMPUTE, bhashiniCompute())
    val rn = svc.run(svc.newJob("Verse 12 and 2026", Direction(Lang.EN, Lang.KN), Options(), emptyList()), CancelToken()) { }
    check("missing numbers are reported", rn.qc.items.any { it.status == Qc.WARN && it.text.contains("12") })

    section("Fail-over and resume")
    mock.reset()
    mock.on("POST", B_CONFIG, bhashiniConfig(mock))
    mock.on("POST", B_COMPUTE) { Resp(503, """{"message":"service unavailable"}""") }
    mock.on("POST", CHAT) { req ->
        val u = userPrompt(req); val n = Regex("Number of segments: (\\d+)").find(u)!!.groupValues[1].toInt()
        val arr = JSONArray(); repeat(n) { arr.put("ಮಾದರಿ ಅನುವಾದ") }
        llmText(JSONObject().put("translations", arr).toString())
    }
    val fsvc = mkService(mock)
    val fj = fsvc.newJob("Hello there. How are you?", Direction(Lang.EN, Lang.KN), Options(granthikaPolish = false), emptyList())
    val fr = fsvc.run(fj, CancelToken()) { }
    check("IndicTrans2 outage -> general AI model used, result delivered", fr.output.contains("ಮಾದರಿ") && !fr.usedIndicTrans2)
    check("QC clearly says the translation is NOT IndicTrans2", fr.qc.items.any { it.status == Qc.WARN && it.text.contains("not by IndicTrans2") }, fr.qc.toPlain())
    check("QC reports retries and fail-over", fr.qc.toPlain().contains("retry attempt(s)") && fj.trace.failovers >= 1)
    check("Bhashini was retried 3 times before giving up", mock.count("POST", B_COMPUTE) == 3, mock.count("POST", B_COMPUTE).toString())

    // fail-over disabled by the user
    val noFallback = fsvc.newJob("Hello there.", Direction(Lang.EN, Lang.KN), Options(allowLlmFallback = false, granthikaPolish = false), emptyList())
    val exNo = expectThrows<ServiceFailure>("fallback off + IndicTrans2 down -> honest failure") { fsvc.run(noFallback, CancelToken()) { } }
    check("failure message names Bhashini and the reason", exNo!!.message!!.contains("Bhashini") && exNo.message!!.contains("temporarily unavailable"), exNo.message ?: "")

    // resume: two batches; second fails, then the service recovers; first batch must not be re-sent
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock))
    val calls = AtomicInteger(0); val sentBatches = ArrayList<List<String>>()
    mock.on("POST", B_COMPUTE) { req ->
        val c = calls.incrementAndGet()
        if (c in 2..4) Resp(503, "{}") else bhashiniCompute(onInputs = { s, _, _ -> sentBatches.add(s) })(req)
    }
    val rsvc = mkService(mock, llmOn = false)
    val big2 = (1..12).joinToString(" ") { "Sentence $it ends here." }.let { (1..12).joinToString("\n") { i -> "Line $i of the verse ends here." } }
    val rj = rsvc.newJob(big2, Direction(Lang.EN, Lang.KN), Options(), emptyList())
    expectThrows<ServiceFailure>("service drops mid-way -> failure, input preserved") { rsvc.run(rj, CancelToken()) { } }
    val doneBefore = rj.doneCount
    check("completed sentences are kept", doneBefore in 1..11, doneBefore.toString())
    val rr = rsvc.run(rj, CancelToken()) { }
    check("Retry resumes: finished sentences are not translated again", sentBatches.flatten().size == rj.segments.size, "${sentBatches.flatten().size} vs ${rj.segments.size}")
    check("Retry completes the translation", rr.output.isNotBlank() && rj.doneCount == rj.segments.size)

    section("No service configured / unsupported direction")
    val none = TranslationService(emptyList(), null, NO_WAIT)
    val exn = expectThrows<EngineException>("nothing configured -> clear message") { none.run(none.newJob("x", Direction(Lang.EN, Lang.KN), Options(), emptyList()), CancelToken()) { } }
    check("message tells the user to open Settings", exn!!.message!!.contains("Settings"))
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock, supported = { s, t -> !(s == "sa" || t == "sa") })); mock.on("POST", B_COMPUTE, bhashiniCompute())
    val cf = mkService(mock, llmOn = false)
    val exs = expectThrows<ServiceFailure>("Bhashini lacks Sanskrit and no fallback -> honest failure") { cf.run(cf.newJob("विद्या", Direction(Lang.SA, Lang.EN), Options(), emptyList()), CancelToken()) { } }
    check("failure explains the exact obstacle", exs!!.message!!.contains("does not currently list a translation model for Sanskrit → English"), exs.message ?: "")

    section("Cancel")
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock)); mock.on("POST", B_COMPUTE, bhashiniCompute())
    val cs = mkService(mock, llmOn = false)
    val tok = CancelToken(); tok.cancel()
    val exc = expectThrows<EngineException>("cancel before start") { cs.run(cs.newJob("Hello", Direction(Lang.EN, Lang.KN), Options(), emptyList()), tok) { } }
    check("cancel reports CANCELLED", exc?.kind == FailKind.CANCELLED)
}

fun testPolishAndGlossary(mock: Mock) {
    section("Granthika polish and glossary")
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock)); mock.on("POST", B_COMPUTE, bhashiniCompute())
    mock.on("POST", CHAT) { req ->
        val u = userPrompt(req); val n = JSONArray(u.substringAfter("segments: ")).length()
        val arr = JSONArray(); repeat(n) { arr.put("ಗ್ರಾಂಥಿಕ ಪರಿಷ್ಕೃತ ಪಠ್ಯ") }
        llmText(JSONObject().put("segments", arr).toString())
    }
    val svc = mkService(mock)
    val r = svc.run(svc.newJob("Hello", Direction(Lang.EN, Lang.KN), Options(), emptyList()), CancelToken()) { }
    check("polish accepted when it passes the checks", r.output == "ಗ್ರಾಂಥಿಕ ಪರಿಷ್ಕೃತ ಪಠ್ಯ" && r.qc.items.any { it.status == Qc.PASS && it.text.contains("Granthika polish") }, r.qc.toPlain())

    mock.on("POST", CHAT) { llmText("""{"segments":["This is English now"]}""") }
    val r2 = svc.run(svc.newJob("Hello", Direction(Lang.EN, Lang.KN), Options(), emptyList()), CancelToken()) { }
    check("polish rejected when it switches script; original kept", r2.output == "ಅನುವಾದಿತ ಪಠ್ಯ" && r2.qc.items.any { it.status == Qc.WARN && it.text.contains("Granthika polish") }, r2.qc.toPlain())

    mock.on("POST", CHAT) { Resp(500, "{}") }
    val r3 = svc.run(svc.newJob("Hello", Direction(Lang.EN, Lang.KN), Options(), emptyList()), CancelToken()) { }
    check("polish failure never loses the IndicTrans2 translation", r3.output == "ಅನುವಾದಿತ ಪಠ್ಯ" && r3.qc.items.any { it.status == Qc.WARN && it.text.contains("skipped") }, r3.qc.toPlain())

    // glossary
    mock.on("POST", CHAT) { llmText("""{"segments":["ಧರ್ಮ ಪಠ್ಯ"]}""") }
    val g = listOf(GlossaryEntry(1, kn = "ಧರ್ಮ", en = "dharma"))
    val r4 = svc.run(svc.newJob("dharma", Direction(Lang.EN, Lang.KN), Options(granthikaPolish = false), g), CancelToken()) { }
    check("missing glossary term reported", r4.missingGlossary.size == 1 && r4.qc.items.any { it.status == Qc.WARN && it.text.contains("Glossary") })
    val r5 = svc.run(svc.newJob("dharma", Direction(Lang.EN, Lang.KN), Options(granthikaPolish = false, autoGlossaryFix = true), g), CancelToken()) { }
    check("auto glossary fix applies the preferred term", r5.output.contains("ಧರ್ಮ") && r5.missingGlossary.isEmpty() && r5.qc.items.any { it.status == Qc.PASS && it.text.contains("Glossary") }, r5.qc.toPlain())
}



fun testScholar(mock: Mock) {
    section("Refinement tools (mock open-weight model)")
    mock.reset()
    val svc = mkService(mock, bhashini = true)
    val scholar = ScholarService(orRouter(mock), svc)
    mock.on("POST", CHAT) { llmText("The colour of the centre was analysed.") }
    val r1 = scholar.refinePlain(Prompts.Refine.CORRECT_GRAMMAR, "The color of the center were analyzed.", Lang.EN, Options(), emptyList(), CancelToken()) { }
    check("Correct Grammar returns revised text only", r1.text == "The colour of the centre was analysed.")
    check("QC lists word-level changes and completeness", r1.qc.toPlain().contains("Words changed") && r1.qc.toPlain().contains("returned in full"))
    check("system prompt demands no commentary and honesty", systemPrompt(mock.last("POST", CHAT)!!).contains("Return ONLY the corrected text") && systemPrompt(mock.last("POST", CHAT)!!).contains("Do not invent quotations"))

    mock.on("POST", CHAT) { llmText("\"Quoted answer.\"") }
    check("wrapping quotes added by the model are removed", scholar.refinePlain(Prompts.Refine.IMPROVE_CLARITY, "Quoted answer.", Lang.EN, Options(), emptyList(), CancelToken()) { }.text == "Quoted answer.")

    mock.on("POST", CHAT) { llmText("Short.") }
    val rs = scholar.refinePlain(Prompts.Refine.CORRECT_GRAMMAR, "This is a long sentence that should not shrink to nothing at all by correction.", Lang.EN, Options(), emptyList(), CancelToken()) { }
    check("suspicious shrinkage is flagged", rs.qc.items.any { it.status == Qc.WARN && it.text.contains("original length") }, rs.qc.toPlain())

    // truncated answer -> split and retry
    mock.reset(); val tcalls = AtomicInteger(0)
    mock.on("POST", CHAT) { req ->
        val u = userPrompt(req)
        if (u.length > 300) { tcalls.incrementAndGet(); llmText("partial", finish = "length") } else llmText(u)
    }
    val longEn = (1..40).joinToString(" ") { "This is sentence number $it." }
    val rt = scholar.refinePlain(Prompts.Refine.CORRECT_GRAMMAR, longEn, Lang.EN, Options(), emptyList(), CancelToken()) { }
    check("truncated model answers are split and re-run, not accepted silently", tcalls.get() >= 1 && rt.text!!.contains("sentence number 40") && rt.qc.items.none { it.status == Qc.FAIL }, rt.qc.toPlain())

    section("Explain corrections / alternatives / grammar analysis")
    mock.reset()
    mock.on("POST", CHAT) { llmText("""{"corrected":"The colour was good.","corrections":[{"original":"color","corrected":"colour","category":"spelling","reason":"British spelling","confidence":"certain"},{"original":"phantom words","corrected":"x","category":"grammar","reason":"made up","confidence":"certain"}]}""") }
    val ex = scholar.refineStructured(Prompts.Refine.EXPLAIN, "The color was good.", Lang.EN, Lang.EN, Options(), emptyList(), CancelToken()) { }
    check("Explain Corrections returns corrected text + list", ex.text == "The colour was good." && ex.doc!!.sections.size == 2)
    check("a correction quoting words that are not in the text is flagged", ex.qc.items.any { it.status == Qc.WARN && it.text.contains("do not occur in your text") }, ex.qc.toPlain())
    mock.on("POST", CHAT) { llmText("""{"alternatives":[{"label":"Concise","text":"Good colour.","note":"shorter"},{"label":"Formal","text":"The colour was satisfactory.","note":"formal"},{"label":"Fluent","text":"The colour looked good.","note":"fluent"}]}""") }
    val al = scholar.refineStructured(Prompts.Refine.ALTERNATIVES, "The color was good.", Lang.EN, Lang.EN, Options(), emptyList(), CancelToken()) { }
    check("three alternatives returned and counted", al.qc.items.any { it.status == Qc.PASS && it.text.contains("3 alternatives") }, al.qc.toPlain())
    mock.on("POST", CHAT) { llmText("""{"overall":"Mostly fine.","issues":[{"quote":"were","category":"agreement","explanation":"subject is singular","suggestion":"was","confidence":"certain"}],"sentences":[{"text":"The color were good.","analysis":"subject: color"}]}""") }
    val ga = scholar.refineStructured(Prompts.Refine.GRAMMAR_ANALYSIS, "The color were good.", Lang.EN, Lang.EN, Options(), emptyList(), CancelToken()) { }
    check("Grammar Analysis lists issues without rewriting", ga.text == null && ga.doc!!.sections.any { it.title.startsWith("Issues found (1)") } && ga.qc.items.any { it.status == Qc.PASS && it.text.contains("really occur") })

    section("Refine and Translate")
    mock.reset(); mock.on("POST", B_CONFIG, bhashiniConfig(mock)); mock.on("POST", B_COMPUTE, bhashiniCompute())
    mock.on("POST", CHAT) { llmText("The refined sentence.") }
    val rt2 = scholar.refineAndTranslate("the refined sentence", Lang.EN, Lang.KN, Options(granthikaPolish = false), emptyList(), CancelToken()) { }
    check("refined text and translation both returned", rt2.refinedText == "The refined sentence." && rt2.text == "ಅನುವಾದಿತ ಪಠ್ಯ")
    check("combined QC covers both steps", rt2.qc.toPlain().contains("Step 1") && rt2.qc.toPlain().contains("Step 2"))

    section("Śloka analysis (mock open-weight model, app-side checks)")
    mock.reset()
    mock.on("POST", CHAT) { llmText(GITA_JSON) }
    val gita = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः ।\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥ १.१ ॥"
    val sl = scholar.analyseSloka(gita, Lang.EN, CancelToken()) { }
    val titles = sl.doc!!.sections.map { it.title }
    for (t in listOf("Original verse", "Padaccheda", "Samāsa analysis", "Anvaya", "Bhāvārtha", "Tātparya", "Chandas", "Alaṅkāra")) check("section present: $t", titles.any { it.contains(t) }, titles.toString())
    check("section present: Pratipadārtha", titles.any { it.contains("Pratipadārtha") })
    check("section present: Translation", titles.any { it.startsWith("Translation") })
    val plain = sl.doc!!.toPlain()
    check("original verse is kept separate and verbatim", sl.doc!!.sections[0].blocks[0].let { it is Block.Para && it.text == gita.trim() }, "got=[" + (sl.doc!!.sections[0].blocks[0] as Block.Para).text + "] want=[" + gita.trim() + "]")
    check("IAST is computed by the app from the Devanagari", plain.contains("dharmakṣetre kurukṣetre samavetā yuyutsavaḥ"))
    check("word cards show vibhakti/vacana/liṅga tags", plain.contains("saptamī · ekavacana · napuṃsakaliṅga"))
    check("uncertain word is marked", plain.contains("(uncertain)"))
    check("QC: model's metre agrees with the app's own scan", sl.qc.items.any { it.status == Qc.PASS && it.text.contains("agrees with the app's own syllable scan") }, sl.qc.toPlain())
    check("QC: verse copy matches", sl.qc.items.any { it.status == Qc.PASS && it.text.contains("matches your text exactly") }, sl.qc.toPlain())
    check("QC: uncertain words flagged, not hidden", sl.qc.items.any { it.status == Qc.WARN && it.text.contains("uncertain") })
    check("QC states nothing is independently verified", sl.qc.toPlain().contains("not been verified by a second engine"))
    check("QC contains no invented percentage", !Regex("\\d+\\s?%\\s*(accura|confiden)").containsMatchIn(sl.qc.toPlain()))

    // wrong metre claim is caught
    mock.on("POST", CHAT) { llmText(GITA_JSON.replace("\"Anuṣṭubh\"", "\"Mandākrāntā\"")) }
    val wrong = scholar.analyseSloka(gita, Lang.EN, CancelToken()) { }
    check("a wrong metre claim is caught by the app's scan", wrong.qc.items.any { it.status == Qc.WARN && it.text.contains("syllable scan gives") }, wrong.qc.toPlain())

    // invented attribution is caught
    mock.on("POST", CHAT) { llmText(GITA_JSON.replace("The question opens the narrative.", "As Śaṅkara explains, the question opens the narrative.")) }
    val att = scholar.analyseSloka(gita, Lang.EN, CancelToken()) { }
    check("attribution to a named commentator is flagged as unverified", att.qc.items.any { it.status == Qc.WARN && it.text.contains("Śaṅkara") }, att.qc.toPlain())

    // echo mismatch
    mock.on("POST", CHAT) { llmText(GITA_JSON.replace("धर्मक्षेत्रे कुरुक्षेत्रे समवेता", "धर्मक्षेत्रे कुरुक्षेत्रे सम्वेता")) }
    val echo = scholar.analyseSloka(gita, Lang.EN, CancelToken()) { }
    check("a verse the model silently changed is flagged", echo.qc.items.any { it.status == Qc.WARN && it.text.contains("differs from your text") })

    // invalid JSON -> second attempt -> still invalid -> raw shown honestly
    mock.on("POST", CHAT) { llmText("Sorry, here is a prose answer without JSON.") }
    val bad = scholar.analyseSloka(gita, Lang.EN, CancelToken()) { }
    check("unparseable answer is shown as raw text with a failure in the QC", bad.qc.items.any { it.status == Qc.FAIL } && bad.doc!!.toPlain().contains("prose answer"))

    // truncated JSON
    mock.on("POST", CHAT) { llmText("{\"words\":[", finish = "length") }
    val tr = scholar.analyseSloka(gita, Lang.EN, CancelToken()) { }
    check("truncated analysis is reported, never presented as complete", tr.qc.items.any { it.status == Qc.FAIL && it.text.contains("cut off") })

    // multiple verses
    mock.on("POST", CHAT) { llmText(GITA_JSON) }
    val two = scholar.analyseSloka(gita + "\n" + "तस्मादसक्तः सततं कार्यं कर्म समाचर ।\nअसक्तो ह्याचरन्कर्म परमाप्नोति पूरुषः ॥ ३.१९ ॥", Lang.EN, CancelToken()) { }
    check("several verses are analysed separately, none dropped", two.doc!!.sections.count { it.title.endsWith("Original verse") } == 2 && mock.count("POST", CHAT) >= 2)
    check("verse splitter keeps verse numbers with their verse", scholar.splitVerses(gita + "\nतस्मादसक्तः ॥ ३.१९ ॥").size == 2)

    section("Prose analysis and commentary")
    mock.reset()
    mock.on("POST", CHAT) { llmText("""{"sentences":[{"text":"रामः वनं गच्छति ।","words":[{"word":"रामः","pratipadartha":"Rāma","lemma":"राम","category":"noun","vibhakti":"prathamā","vacana":"ekavacana","linga":"puṃliṅga","verb_info":"","relation":"kartā","confidence":"certain","note":""},{"word":"वनम्","pratipadartha":"forest","lemma":"वन","category":"noun","vibhakti":"dvitīyā","vacana":"ekavacana","linga":"napuṃsakaliṅga","verb_info":"","relation":"karma","confidence":"certain","note":""},{"word":"गच्छति","pratipadartha":"goes","lemma":"गम्","category":"verb","vibhakti":"","vacana":"","linga":"","verb_info":"√गम् (bhvādi, parasmaipada), laṭ, prathama, ekavacana","relation":"kriyā","confidence":"certain","note":""}],"samasa":[],"syntax":"kartā रामः, karma वनम्, kriyā गच्छति","anvaya":"","meaning":"Rāma goes to the forest.","translation":"Rama goes to the forest."}],"overall_meaning":"Rāma goes to the forest.","uncertainties":[]}""") }
    val pr = scholar.analyseProse("रामः वनं गच्छति ।", Lang.EN, CancelToken()) { }
    val prText = pr.doc!!.toPlain()
    check("prose analysis has sentence segmentation, word forms, syntax, meaning, translation", prText.contains("Sentence 1") && prText.contains("prathamā · ekavacana · puṃliṅga") && prText.contains("kartā रामः") && prText.contains("Translation (English)") && prText.contains("Overall meaning"))
    check("prose QC confirms complete case information", pr.qc.items.any { it.status == Qc.PASS && it.text.contains("vibhakti, vacana and liṅga") })
    mock.on("POST", CHAT) { llmText("""{"paraphrase":"रामः अरण्यं प्रति गच्छति ।","grammar":[{"point":"वनं","explanation":"द्वितीया विभक्तिः, गमनकर्म","confidence":"certain"}],"words":[{"word":"वनं","artha":"अरण्यम्","confidence":"certain"}],"uncertainties":[]}""") }
    val cm = scholar.commentary("रामः वनं गच्छति ।", Prompts.CommentaryPart.ALL, CancelToken()) { }
    val ct = cm.doc!!.toPlain()
    check("commentary has paraphrase, grammar, word meanings", ct.contains("Simple Sanskrit paraphrase") && ct.contains("Grammatical commentary") && ct.contains("Word-by-word"))
    check("commentary carries an authorship disclaimer", ct.contains("not the commentary of any historical"))
    check("commentary prompt forbids attribution and invented quotations", systemPrompt(mock.last("POST", CHAT)!!).contains("Never present it as the commentary of any historical"))
    check("commentary QC: all requested parts returned", cm.qc.items.any { it.status == Qc.PASS && it.text.contains("All requested parts") })
}

fun testHistoryAndOffline() {
    section("History: storage, search, preview")
    val gita = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः ।\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥ १.१ ॥"
    val e1 = HistoryEntry(History.newId(1000), 1000, HistoryEntry.Kind.TRANSLATION, "Sanskrit → English", gita, "On the field of dharma, the Kuru field, \"assembled\"…\nwhat did they do?", "SA", "EN", "Bhashini service X", 1)
    val e2 = HistoryEntry(History.newId(2000), 2000, HistoryEntry.Kind.REFINEMENT, "Correct Grammar", "ನಾನು ಪುಸ್ತಕ ಓದುತ್ತೇನೆ", "ನಾನು ಪುಸ್ತಕವನ್ನು ಓದುತ್ತೇನೆ.", "KN", "", "OpenRouter", 0)
    val e3 = HistoryEntry(History.newId(3000), 3000, HistoryEntry.Kind.ANALYSIS, "Śloka analysis", "सत्यं वद ।", "■ Padaccheda\nसत्यम् वद", "", "", "OpenRouter", 2)
    var list = History.add(History.add(History.add(emptyList(), e1), e2), e3)
    check("newest entry comes first", list.map { it.time } == listOf(3000L, 2000L, 1000L))
    check("ids are unique even when created in the same millisecond", (1..50).map { History.newId(5) }.toSet().size == 50)
    val back = History.fromJson(History.toJson(list))
    check("history survives a JSON round trip exactly (Devanagari, Kannada, quotes, newlines)", back == list)
    check("original and result stay separate fields", back.last().input == gita && back.last().output.startsWith("On the field"))
    check("garbage file is reported as invalid, not as empty", History.parse("{not json") == null)
    check("empty file is an empty history", History.parse("")?.isEmpty() == true && History.parse(null)?.isEmpty() == true)
    check("unknown kind falls back safely", History.fromJson("[{\"id\":1,\"time\":2,\"kind\":\"X\",\"title\":\"t\",\"input\":\"a\",\"output\":\"b\"}]").single().kind == HistoryEntry.Kind.TRANSLATION)
    check("search by English word", History.search(list, "assembled").map { it.id } == listOf(e1.id))
    check("search is case-insensitive", History.search(list, "GRAMMAR").map { it.id } == listOf(e2.id))
    check("search by Devanagari", History.search(list, "सत्यं").map { it.id } == listOf(e3.id))
    check("search by Kannada", History.search(list, "ಪುಸ್ತಕ").map { it.id } == listOf(e2.id))
    check("IAST query finds Devanagari text", History.search(list, "dharmakṣetre").map { it.id } == listOf(e1.id))
    check("blank query returns everything", History.search(list, "  ").size == 3)
    check("no match returns nothing", History.search(list, "zzzz").isEmpty())
    list = History.remove(list, e2.id)
    check("remove deletes only that entry", list.map { it.id } == listOf(e3.id, e1.id))
    val full = "धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः"
    val pv = History.preview(full, 9)
    val kept = pv.dropLast(1).length
    check("preview ends with an ellipsis and the next original character is not a vowel sign or virama",
        pv.endsWith("…") && Character.getType(full[kept]) != Character.NON_SPACING_MARK.toInt() && Character.getType(full[kept]) != Character.COMBINING_SPACING_MARK.toInt(), pv)
    check("every possible preview length keeps whole aksharas", (1..full.length - 1).all { n ->
        val p2 = History.preview(full, n); val k = p2.dropLast(1).length
        !p2.endsWith("…") || k >= full.length || (Character.getType(full[k]) != Character.NON_SPACING_MARK.toInt() && Character.getType(full[k]) != Character.COMBINING_SPACING_MARK.toInt())
    })
    check("preview does not start a cut inside a letter's vowel sign", History.preview("कि" + "कि".repeat(10), 1).dropLast(1) == "कि")
    check("short text is not cut", History.preview("a   b\nc", 20) == "a b c")

    section("Offline metre check (no network, no AI)")
    val rep = OfflineTools.metreReport(gita)
    val plain = rep.toPlain()
    check("offline report names anuṣṭubh for Gītā 1.1", plain.contains("anuṣṭubh"))
    check("offline report shows IAST computed locally", plain.contains("dharmakṣetre kurukṣetre samavetā yuyutsavaḥ"))
    check("offline report keeps the verse as read, with its verse number", plain.contains("॥ १.१ ॥"))
    check("offline report lists four pādas of 8 syllables", (1..4).all { plain.contains("Pāda $it — 8 syllables") })
    check("offline QC says no network/AI used", rep.qc.items.any { it.status == Qc.PASS && it.text.contains("No network, no AI model") })
    check("offline QC states what was not checked", rep.qc.items.any { it.text.startsWith("Not checked") })
    val rep2 = OfflineTools.metreReport("dharmakṣetre kurukṣetre samavetā yuyutsavaḥ |\nmāmakāḥ pāṇḍavāścaiva kimakurvata sañjaya ||")
    check("IAST input is converted and scanned", rep2.toPlain().contains("anuṣṭubh") && rep2.qc.items.any { it.text.contains("IAST") })
    val rep3 = OfflineTools.metreReport(gita + "\n" + "सत्यं वद धर्मं चर स्वाध्यायान्मा प्रमदः ।\nआचार्याय प्रियं धनमाहृत्य प्रजातन्तुं मा व्यवच्छेत्सीः ॥ १.२ ॥")
    check("two verses are reported separately", rep3.toPlain().contains("Verse 1 —") && rep3.toPlain().contains("Verse 2 —"))
    expectThrows<EngineException>("empty input is rejected") { OfflineTools.metreReport("   ") }
    val odd = OfflineTools.metreReport("राम ।")
    check("an unidentifiable text is warned about, not forced into a metre", odd.qc.warnings > 0)
}

fun testGlossaryReachesTheModel(mock: Mock) {
    section("Glossary is sent to the AI translator (regression: it used to be only checked afterwards)")
    val g = listOf(GlossaryEntry(1, sa = "विद्या", en = "learning"), GlossaryEntry(2, sa = "धनम्", en = "wealth"))
    mock.reset()
    mock.on("POST", CHAT) { req ->
        val u = userPrompt(req)
        val segs = JSONArray(u.substringAfterLast("segments: "))
        llmText(JSONObject().put("translations", JSONArray().apply { for (i in 0 until segs.length()) put("Learning is supreme wealth.") }).toString())
    }
    val svc = mkService(mock, bhashini = false)
    val res = svc.run(svc.newJob("विद्या परमं धनम्।", Direction(Lang.SA, Lang.EN), Options(), g), CancelToken()) { }
    val prompt = userPrompt(mock.last("POST", CHAT)!!)
    check("the prompt carries the preferred renderings whose source term occurs", prompt.contains("Preferred renderings") && prompt.contains("विद्या => learning") && prompt.contains("धनम् => wealth"), prompt)
    check("the check afterwards finds both terms present", res.missingGlossary.isEmpty() && res.qc.items.any { it.status == Qc.PASS && it.text.startsWith("Glossary: all 2") }, res.qc.toPlain())
    mock.reset()
    mock.on("POST", CHAT) { req ->
        val segs = JSONArray(userPrompt(req).substringAfterLast("segments: "))
        llmText(JSONObject().put("translations", JSONArray().apply { for (i in 0 until segs.length()) put("Rama goes.") }).toString())
    }
    svc.run(svc.newJob("रामः गच्छति।", Direction(Lang.SA, Lang.EN), Options(), g), CancelToken()) { }
    check("a text that contains none of the terms gets no glossary section", !userPrompt(mock.last("POST", CHAT)!!).contains("Preferred renderings"))
    // only the terms of the batch being translated are sent
    mock.reset()
    val sent = java.util.concurrent.CopyOnWriteArrayList<String>()
    mock.on("POST", CHAT) { req ->
        val u = userPrompt(req); sent.add(u)
        val segs = JSONArray(u.substringAfterLast("segments: "))
        llmText(JSONObject().put("translations", JSONArray().apply { for (i in 0 until segs.length()) put("x") }).toString())
    }
    svc.run(svc.newJob("विद्या ।", Direction(Lang.SA, Lang.EN), Options(), g), CancelToken()) { }
    check("only the matching term is sent, not the whole glossary", sent.last().contains("विद्या => learning") && !sent.last().contains("धनम् => wealth"), sent.last())
}

/** Runs one group of checks; an unexpected exception inside it counts as a failure instead of hiding the groups after it. */
fun guarded(name: String, block: () -> Unit) {
    try { block() } catch (e: Throwable) { check("$name did not crash", false, e.toString()); e.printStackTrace(System.out) }
}

/** Runs every core check once and returns the number that failed. Used by main() here and by the Gradle unit-test wrapper. */
fun runAllCoreTests(): Int {
    val mock = Mock()
    try {
        guarded("scripts") { testScripts() }; guarded("prosody") { testProsody() }; guarded("segmenter") { testSegmenter() }; guarded("spelling") { testSpellingGlossary() }
        guarded("bhashini") { testBhashini(mock) }; guarded("cloudflare") { testCloudflare(mock) }; guarded("openai") { testOpenAi(mock) }; guarded("compare") { testCompare(mock) }
        guarded("sign-in") { testSignIn(mock) }; guarded("retry") { testRetryAndFailover(mock) }
        guarded("translation") { testTranslation(mock) }; guarded("polish") { testPolishAndGlossary(mock) }; guarded("glossary") { testGlossaryReachesTheModel(mock) }
        guarded("scholar") { testScholar(mock) }; guarded("history") { testHistoryAndOffline() }
        guarded("local facts") { testLocalModelFacts() }; guarded("local helpers") { testLocalHelpers() }; guarded("downloader") { testModelDownloader() }
        guarded("local runtime") { testLocalRuntime() }; guarded("local failures") { testLocalRuntimeFailures() }; guarded("local provider") { testLocalProvider() }
        guarded("local checks") { testLocalChecks() }; guarded("local end to end") { testLocalModeEndToEnd(mock) }
    } finally { mock.stop() }
    println("\n=============================")
    println("PASSED: $passed   FAILED: $failed")
    if (failed > 0) { println("Failures:"); failures.forEach { println(" - $it") } }
    return failed
}

fun main() { if (runAllCoreTests() > 0) exitProcess(1) }
