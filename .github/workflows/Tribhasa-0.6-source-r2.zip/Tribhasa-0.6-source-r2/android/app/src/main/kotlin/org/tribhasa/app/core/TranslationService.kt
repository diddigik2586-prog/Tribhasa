package org.tribhasa.app.core

import org.json.JSONArray

/** All state of one translation, kept so that "Retry" resumes where it stopped instead of starting over. */
class TranslationJob(
    val originalText: String,
    val direction: Direction,
    val opts: Options,
    val glossary: List<GlossaryEntry>,
) {
    val trace = Trace()
    var mtSource: String = ""
    var sanskritNote: String? = null
    var segments: List<Segmenter.Segment> = emptyList()
    var results: Array<String?> = emptyArray()
    var engineLabel: Array<String?> = emptyArray()
    var engineIsIt2: Array<Boolean> = emptyArray()
    var prepared = false
    val disabled = HashSet<String>()
    val lastFailures = LinkedHashMap<String, EngineException>()
    val doneCount: Int get() = results.count { it != null }
}

class TranslationResult(
    val output: String,
    val sourceUsed: String,
    val qc: QcReport,
    val trace: Trace,
    val missingGlossary: List<GlossaryEntry>,
    val usedIndicTrans2: Boolean,
    /** Which engines produced the segments, e.g. "Bhashini service ai4bharat/indictrans-v2-all-gpu--t4". */
    val engines: String = "",
)

class TranslationService(
    private val engines: List<TranslationEngine>,
    private val llm: LlmRouter?,
    private val retry: RetryPolicy = RetryPolicy(),
    /** Size of the parts sent to the AI model for the Kannada polish, and how many go in one request. The on-device model takes small parts, one at a time. */
    private val polishChars: Int = 1200,
    private val polishBatch: Int = 3,
    /** For a small model: a single plain-text answer to a one-part polish request is accepted (it still has to pass the same checks), and flagged. */
    private val polishAcceptsPlain: Boolean = false,
) {
    fun newJob(text: String, d: Direction, opts: Options, glossary: List<GlossaryEntry>) = TranslationJob(text, d, opts, glossary)

    fun chainFor(d: Direction, opts: Options): List<TranslationEngine> =
        engines.filter { it.supports(d) && (it.isIndicTrans2 || opts.allowLlmFallback) }

    fun explainNoEngine(d: Direction, opts: Options, anyConfigured: Boolean): String =
        if (!anyConfigured) "No translation service is set up yet. Open Settings and tap “Connect” to sign in to OpenRouter once (open-weight AI model), or add a Bhashini key (IndicTrans2) under Advanced."
        else "None of your configured services can do ${d.label}. " +
            if (!opts.allowLlmFallback) "Turn on “Use an AI model when IndicTrans2 can’t do a direction” in Settings, or add a Bhashini key (it covers all six directions)."
            else "Add a Bhashini key (it covers all six directions)."

    fun run(job: TranslationJob, cancel: CancelToken, progress: (String) -> Unit): TranslationResult {
        job.trace.statusSink = progress
        val d = job.direction
        val chain = chainFor(d, job.opts)
        if (chain.isEmpty()) throw EngineException(FailKind.UNSUPPORTED, explainNoEngine(d, job.opts, engines.isNotEmpty()))
        if (!job.prepared) prepare(job, chain)
        job.disabled.clear()
        job.lastFailures.clear()

        val n = job.segments.size
        var i = 0
        while (i < n) {
            cancel.check()
            if (job.results[i] != null) { i++; continue }
            val active = chain.filter { it.id !in job.disabled }
            if (active.isEmpty()) throw ServiceFailure(job.lastFailures.map { (k, v) -> k to v })
            val eng = active.first()
            val size = eng.batchSize
            val idx = ArrayList<Int>()
            var j = i
            while (j < n && idx.size < size) { if (job.results[j] == null) idx.add(j); j++ }
            val texts = idx.map { job.segments[it].text }
            progress("Translating ${job.doneCount + 1}–${job.doneCount + idx.size} of $n · ${eng.label}")
            try {
                val outs = callWithRetry(eng, texts, d, cancel, job.trace, progress, Glossary.relevant(job.glossary, texts.joinToString("\n"), d.src, d.tgt))
                for ((k, ix) in idx.withIndex()) { job.results[ix] = outs[k]; job.engineLabel[ix] = engineName(eng, d); job.engineIsIt2[ix] = eng.isIndicTrans2 }
                job.trace.use(engineName(eng, d), idx.size)
            } catch (e: AttemptsExhausted) {
                handleFailure(job, eng, e.last, active.size > 1)
            } catch (e: EngineException) {
                handleFailure(job, eng, e, active.size > 1)
            }
        }
        return finish(job, cancel, progress)
    }

    private fun engineName(e: TranslationEngine, d: Direction) = e.describe(d)

    private fun handleFailure(job: TranslationJob, eng: TranslationEngine, e: EngineException, hasOthers: Boolean) {
        if (e.kind == FailKind.CANCELLED) throw e
        job.lastFailures[eng.label] = e
        job.trace.note("${eng.label} could not be used: ${e.message}")
        job.disabled.add(eng.id) // a failed engine is not tried again for the rest of this run
        if (hasOthers) job.trace.failovers++
    }

    private fun callWithRetry(
        eng: TranslationEngine, texts: List<String>, d: Direction, cancel: CancelToken, trace: Trace, progress: (String) -> Unit,
        glossary: List<GlossaryEntry>,
    ): List<String> {
        try {
            return retry.run(cancel, onRetry = { a, e, w ->
                trace.retries++
                val msg = "${eng.label}: ${e.message} Trying again in ${(w + 500) / 1000}s (attempt ${a + 1})."
                trace.note(msg); progress(msg)
            }) { eng.translate(texts, d, cancel, trace, glossary) }.value
        } catch (e: AttemptsExhausted) {
            // A batch that came back the wrong size is retried one sentence at a time before giving up.
            if (texts.size > 1 && e.kind == FailKind.BAD_RESPONSE) {
                val out = ArrayList<String>()
                for (t in texts) out.addAll(retry.run(cancel, onRetry = { a, ex, w ->
                    trace.retries++; trace.note("${eng.label}: ${ex.message} Trying again in ${(w + 500) / 1000}s (attempt ${a + 1}).")
                }) { eng.translate(listOf(t), d, cancel, trace, Glossary.relevant(glossary, t, d.src, d.tgt)) }.value)
                return out
            }
            throw e
        }
    }

    private fun prepare(job: TranslationJob, chain: List<TranslationEngine>) {
        val d = job.direction
        var src = Scripts.nfc(job.originalText)
        if (d.src == Lang.SA) {
            val conv = Translit.normaliseSanskritInput(src)
            if (conv.converted) { src = conv.devanagari; job.sanskritNote = conv.note }
        }
        job.mtSource = src
        job.segments = Segmenter.split(src, chain.first().maxChars)
        job.results = arrayOfNulls(job.segments.size)
        job.engineLabel = arrayOfNulls(job.segments.size)
        job.engineIsIt2 = Array(job.segments.size) { false }
        job.prepared = true
    }

    // ------------------------------------------------------------------ post-processing + QC
    private fun finish(job: TranslationJob, cancel: CancelToken, progress: (String) -> Unit): TranslationResult {
        val d = job.direction
        val qc = QcReport()
        val segs = job.segments
        val rawOutputs = job.results.map { it ?: "" }
        var output = Segmenter.join(segs, rawOutputs)
        val usedIt2 = job.engineIsIt2.any { it }

        // 1. who translated
        val byEngine = LinkedHashMap<String, Int>()
        for (l in job.engineLabel) if (l != null) byEngine[l] = (byEngine[l] ?: 0) + 1
        val nonIt2 = job.engineIsIt2.indices.count { !job.engineIsIt2[it] }
        for ((label, cnt) in byEngine) qc.info("Translated by $label — $cnt of ${segs.size} segment(s).")
        if (nonIt2 > 0 && !job.trace.onDevice) qc.warn("$nonIt2 of ${segs.size} segment(s) were translated by a general AI model, not by IndicTrans2, because IndicTrans2 was not set up or not available for ${d.label}.")
        if (job.trace.retries > 0 || job.trace.failovers > 0)
            qc.info("Temporary problems handled automatically: ${job.trace.retries} retry attempt(s), ${job.trace.failovers} switch(es) to another service.")
        job.sanskritNote?.let { qc.info(it) }

        // 2. completeness and structure
        if (rawOutputs.all { it.isNotBlank() }) qc.pass("All ${segs.size} segment(s) were translated; none is empty.")
        else qc.fail("Some segments came back empty.")
        val pIn = Segmenter.paragraphCount(job.mtSource); val pOut = Segmenter.paragraphCount(output)
        if (pIn == pOut) qc.pass("Paragraph breaks preserved ($pIn paragraph${if (pIn == 1) "" else "s"}).")
        else qc.warn("Paragraph count changed: $pIn in the source, $pOut in the translation.")
        if (output.contains('�')) qc.fail("The output contains replacement characters (�): some text was damaged in transit.")
        else qc.pass("Unicode text received intact (no damaged characters).")

        // 3. script
        val expected = Scripts.expectedFor(d.tgt)
        val share = Scripts.share(output, expected)
        val scriptName = when (expected) { Script.DEVANAGARI -> "Devanagari"; Script.KANNADA -> "Kannada"; else -> "Latin" }
        if (Scripts.letterCount(output) == 0) qc.fail("The output contains no letters.")
        else if (share >= 0.85) qc.pass("Output is written in $scriptName script (${(share * 100).toInt()}% of letters).")
        else qc.warn("Only ${(share * 100).toInt()}% of the output letters are in $scriptName script; some text may have been left untranslated.")

        // 4. numerals
        val srcNums = numerals(job.mtSource); val outNums = numerals(output)
        if (srcNums.isNotEmpty()) {
            val pool = outNums.groupingBy { it }.eachCount().toMutableMap()
            val missing = ArrayList<String>()
            for (s in srcNums) { val c = pool[s] ?: 0; if (c > 0) pool[s] = c - 1 else missing.add(s) }
            if (missing.isEmpty()) qc.pass("All ${srcNums.size} number(s) of the source appear in the translation.")
            else qc.warn("Number(s) in the source not found in the translation: ${missing.distinct().joinToString(", ")}.")
        }
        // 5. length sanity (loose)
        val inLen = job.mtSource.count { !it.isWhitespace() }; val outLen = output.count { !it.isWhitespace() }
        if (inLen > 0 && outLen < inLen * 0.15) qc.warn("The translation is much shorter than the source; part of it may be missing (loose length check).")

        // 6. spelling for English
        if (d.tgt == Lang.EN && job.opts.britishSpelling) {
            val r = Spelling.toBritish(output); output = r.text
            qc.info("British spelling applied by word list: ${r.changed} word(s) changed.")
        }
        // 7. Kannada polish
        if (d.tgt == Lang.KN && job.opts.granthikaPolish) {
            output = polishKannada(output, job, qc, cancel, progress)
        }
        // 8. glossary
        val relevant = Glossary.relevant(job.glossary, job.mtSource, d.src, d.tgt)
        var missingG = relevant.filter { !Glossary.termPresent(output, it, d.tgt) }
        if (missingG.isNotEmpty() && job.opts.autoGlossaryFix && llm != null && !llm.isEmpty) {
            output = glossaryFix(output, job, missingG, qc, cancel, progress)
            missingG = relevant.filter { !Glossary.termPresent(output, it, d.tgt) }
        }
        when {
            relevant.isEmpty() -> if (job.glossary.isNotEmpty()) qc.info("Glossary checked: no saved term occurs in this text.")
            missingG.isEmpty() -> qc.pass("Glossary: all ${relevant.size} matching preferred term(s) appear in the translation.")
            else -> qc.warn("Glossary: ${missingG.size} of ${relevant.size} preferred term(s) not found in the translation: ${missingG.joinToString(", ") { it.term(d.tgt) }}.")
        }
        if (job.trace.onDevice) LocalChecks.translation(qc, segs.map { it.text }, rawOutputs)
        qc.addStandingNotes(aiInvolved = true, trace = job.trace)
        return TranslationResult(output, job.mtSource, qc, job.trace, missingG, usedIt2, byEngine.keys.joinToString("; "))
    }

    private fun numerals(s: String): List<String> =
        Regex("[0-9०-९೦-೯]+").findAll(s).map { m ->
            m.value.map { c -> when (c) { in '०'..'९' -> '0' + (c - '०'); in '೦'..'೯' -> '0' + (c - '೦'); else -> c } }.joinToString("")
        }.toList()

    private fun parseSegmentsReply(text: String, expected: Int): List<String>? {
        val o = JsonUtil.extractObject(text) ?: return null
        val a = JsonUtil.arr(o, "segments") ?: JsonUtil.arr(o, "translations") ?: return null
        if (a.length() != expected) return null
        return (0 until a.length()).map { a.opt(it)?.toString()?.trim() ?: "" }
    }

    private fun polishKannada(text: String, job: TranslationJob, qc: QcReport, cancel: CancelToken, progress: (String) -> Unit): String {
        if (llm == null || llm.isEmpty) {
            qc.info("Granthika polish not applied: no AI model key is set up (the IndicTrans2 output is shown as received).")
            return text
        }
        progress("Polishing Kannada to Granthika style…")
        val segs = Segmenter.split(text, polishChars)
        val relevant = Glossary.relevant(job.glossary, job.mtSource, job.direction.src, Lang.KN)
        val polished = Array(segs.size) { segs[it].text }
        var accepted = 0; var rejected = 0
        var model = ""
        try {
            var i = 0
            while (i < segs.size) {
                cancel.check()
                val batch = (i until minOf(segs.size, i + polishBatch)).toList()
                val reply = llm.generate(LlmRequest(Prompts.granthikaSystem(), Prompts.granthikaUser(batch.map { segs[it].text }, relevant), json = true, temperature = 0.1), cancel, job.trace)
                model = reply.model
                var outs = if (reply.truncated) null else parseSegmentsReply(reply.text, batch.size)
                if (outs == null && !reply.truncated && polishAcceptsPlain && batch.size == 1) {
                    val plain = PlainText.clean(reply.text)
                    if (plain.isNotBlank()) {
                        job.trace.flag("Granthika polish: the model did not answer in the requested format for some part(s); its plain-text answer was used only where it passed the same checks.")
                        outs = listOf(plain)
                    }
                }
                if (outs == null) { rejected += batch.size } else {
                    for ((k, ix) in batch.withIndex()) {
                        val a = segs[ix].text; val b = outs[k]
                        val ratio = if (a.isEmpty()) 1.0 else b.length.toDouble() / a.length
                        val okScript = Scripts.share(b, Script.KANNADA) >= 0.8 * Scripts.share(a, Script.KANNADA)
                        if (b.isNotBlank() && ratio in 0.6..1.7 && okScript && numerals(a) == numerals(b)) { polished[ix] = b; accepted++ } else rejected++
                    }
                }
                i += batch.size
            }
        } catch (e: ServiceFailure) {
            if (e.allCancelled) throw EngineException(FailKind.CANCELLED, "Cancelled.")
            qc.warn("Granthika polish was skipped because the AI model could not be reached (${e.failures.firstOrNull()?.second?.message ?: "unknown reason"}). The IndicTrans2 output is shown unpolished.")
            return text
        } catch (e: EngineException) {
            if (e.kind == FailKind.CANCELLED) throw e
            qc.warn("Granthika polish was skipped: ${e.message}. The IndicTrans2 output is shown unpolished.")
            return text
        }
        val result = Segmenter.join(segs, polished.toList())
        val total = accepted + rejected
        if (accepted == 0) qc.warn("Granthika polish: none of the $total segment(s) passed the safety checks, so the unpolished translation is shown.")
        else if (rejected > 0) qc.warn("Granthika polish by $model: $accepted of $total segment(s) accepted; $rejected kept unpolished because the polished version failed checks (script, length or numbers).")
        else qc.pass("Granthika polish by $model: all $total segment(s) passed the checks (script, length, numbers).")
        return result
    }

    /** Re-words [text] so that the glossary's preferred terms are used. Never loses the original on failure. */
    fun glossaryFix(text: String, job: TranslationJob, missing: List<GlossaryEntry>, qc: QcReport, cancel: CancelToken, progress: (String) -> Unit): String {
        val d = job.direction
        progress("Applying your glossary…")
        val segs = Segmenter.split(text, 1200)
        val srcSegs = Segmenter.split(job.mtSource, 1200).map { it.text }
        return try {
            val reply = llm!!.generate(LlmRequest(Prompts.glossaryFixSystem(d), Prompts.glossaryFixUser(segs.map { it.text }, if (srcSegs.size == segs.size) srcSegs else listOf(job.mtSource), missing, d), json = true, temperature = 0.1), cancel, job.trace)
            val outs = if (reply.truncated) null else parseSegmentsReply(reply.text, segs.size)
            if (outs == null || outs.any { it.isBlank() }) { qc.warn("Glossary fix by the AI model returned an unusable answer; the translation is unchanged."); text }
            else { qc.info("Glossary fix applied by ${reply.model}."); Segmenter.join(segs, outs) }
        } catch (e: ServiceFailure) {
            if (e.allCancelled) throw EngineException(FailKind.CANCELLED, "Cancelled.")
            qc.warn("Glossary fix could not run (AI model unavailable). The translation is unchanged."); text
        } catch (e: EngineException) {
            if (e.kind == FailKind.CANCELLED) throw e
            qc.warn("Glossary fix could not run: ${e.message}"); text
        }
    }
}

/** Builds the services from what the user has configured. */
object ServiceFactory {
    /** One provider for one model; [model] overrides the saved model (used by the model comparison). */
    fun provider(c: Credentials, model: String = c.llmModel): OpenAiCompatProvider {
        val base = Models.normaliseBase(c.llmBaseUrl.ifBlank { Models.OPENROUTER_BASE })
            ?: throw EngineException(FailKind.UNSUPPORTED, "The service address in Settings must start with https://. Open Settings and correct it.")
        if (c.llmKeyFromSignIn && base != Models.OPENROUTER_BASE)
            throw EngineException(FailKind.UNSUPPORTED, "The key obtained by signing in to OpenRouter is only ever sent to OpenRouter itself, but the service address in Settings points elsewhere. Open Settings, Advanced, and clear the service address.")
        return OpenAiCompatProvider(c.llmKey.trim(), model, base, c.allowPaid, c.denyDataCollection, Models.Think.fromName(c.thinking))
    }

    /** The back-up model, if one is set and may be used (valid name, not the same as the first, free unless paid models are allowed). */
    fun backupModel(c: Credentials): String? {
        val b = c.fallbackModel.trim()
        if (b.isEmpty() || !Models.validId(b) || b == c.llmModel.trim()) return null
        if (!c.allowPaid && !Models.isFree(b)) return null
        return b
    }

    /** Sizes used when the model runs on the phone: small, because that model holds little at a time. */
    const val LOCAL_SEGMENT_CHARS = 450
    const val LOCAL_BATCH = 1
    const val LOCAL_TRANSLATION_TOKENS = 1024

    /** A local answer takes a while to produce, so a failed one is repeated at most once. */
    fun retryFor(c: Credentials): RetryPolicy =
        if (c.aiSource == AiSource.LOCAL) RetryPolicy(maxAttempts = 2, baseDelayMs = 300) else RetryPolicy()

    /**
     * With the source "on this phone" the router holds ONLY the on-device model: the online services are not even built,
     * so no failure can send the user's text to them. With "online" it is the earlier optional route.
     */
    fun llmRouter(c: Credentials, retry: RetryPolicy = retryFor(c), local: LocalRuntime? = null): LlmRouter {
        if (c.aiSource == AiSource.LOCAL) {
            return LlmRouter(listOf(if (local != null) LocalLlmProvider(local) else BrokenProvider("The model on this phone is not available in this build.")), retry)
        }
        val p = ArrayList<LlmProvider>()
        if (c.hasLlm) {
            p.add(try { provider(c) } catch (e: EngineException) { BrokenProvider(e.message ?: "The AI service is not set up correctly.") })
            // At most one back-up, and only if the user chose one. Each model is tried at most RetryPolicy.maxAttempts times.
            val b = backupModel(c)
            if (b != null) try { p.add(provider(c, b)) } catch (_: EngineException) { }
        }
        return LlmRouter(p, retry)
    }

    fun translation(c: Credentials, retry: RetryPolicy = retryFor(c), llm: LlmRouter = llmRouter(c, retry)): TranslationService {
        if (c.aiSource == AiSource.LOCAL) {
            // Bhashini and Cloudflare are never used in this mode, even if keys were saved earlier.
            val only = LlmTranslationEngine(llm, LOCAL_SEGMENT_CHARS, LOCAL_BATCH, LOCAL_TRANSLATION_TOKENS, acceptPlainSingle = true)
            return TranslationService(listOf(only), llm, retry, polishChars = LOCAL_SEGMENT_CHARS, polishBatch = 1, polishAcceptsPlain = true)
        }
        val e = ArrayList<TranslationEngine>()
        if (c.hasBhashini) e.add(BhashiniEngine(c.bhashiniUserId.trim(), c.bhashiniKey.trim()))
        if (c.hasCloudflare) e.add(CloudflareIndicEngine(c.cfAccountId.trim(), c.cfToken.trim()))
        if (!llm.isEmpty) e.add(LlmTranslationEngine(llm))
        return TranslationService(e, if (llm.isEmpty) null else llm, retry)
    }
}
