package org.tribhasa.app.core

import org.json.JSONArray
import org.json.JSONObject

/** One personal-glossary entry: preferred Sanskrit, Kannada and English equivalents of the same term. */
data class GlossaryEntry(
    val id: Long,
    val sa: String = "",
    val kn: String = "",
    val en: String = "",
    val note: String = "",
) {
    fun term(l: Lang): String = when (l) { Lang.SA -> sa; Lang.KN -> kn; Lang.EN -> en }
    val isUsable: Boolean get() = listOf(sa, kn, en).count { it.isNotBlank() } >= 2
    val summary: String get() = listOf(sa, kn, en).filter { it.isNotBlank() }.joinToString("  ·  ")
}

object Glossary {
    fun toJson(list: List<GlossaryEntry>): String {
        val a = JSONArray()
        for (e in list) a.put(JSONObject().put("id", e.id).put("sa", e.sa).put("kn", e.kn).put("en", e.en).put("note", e.note))
        return a.toString()
    }

    fun fromJson(s: String?): List<GlossaryEntry> {
        if (s.isNullOrBlank()) return emptyList()
        val a = JsonUtil.parseArray(s) ?: return emptyList()
        val out = ArrayList<GlossaryEntry>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(GlossaryEntry(o.optLong("id", System.nanoTime() + i), JsonUtil.str(o, "sa"), JsonUtil.str(o, "kn"), JsonUtil.str(o, "en"), JsonUtil.str(o, "note")))
        }
        return out
    }

    /** Sanskrit entries are stored in Devanagari; typed IAST or Kannada script is converted on save. */
    fun normaliseSanskrit(term: String): String = if (term.isBlank()) term else Translit.normaliseSanskritInput(term.trim()).devanagari

    private fun contains(text: String, term: String, lang: Lang): Boolean {
        if (term.isBlank()) return false
        val t = Scripts.nfc(text); val q = Scripts.nfc(term.trim())
        return if (lang == Lang.EN) {
            Regex("(?<![\\p{L}\\p{M}])" + Regex.escape(q) + "(?![\\p{L}\\p{M}])", RegexOption.IGNORE_CASE).containsMatchIn(t)
        } else t.contains(q)
    }

    /** Entries whose [lang] term occurs in [text], and that have an equivalent in [target]. */
    fun relevant(entries: List<GlossaryEntry>, text: String, lang: Lang, target: Lang): List<GlossaryEntry> {
        val hay = if (lang == Lang.SA) Translit.normaliseSanskritInput(text).devanagari else text
        return entries.filter { it.term(lang).isNotBlank() && it.term(target).isNotBlank() && contains(hay, it.term(lang), lang) }
    }

    fun termPresent(output: String, entry: GlossaryEntry, target: Lang): Boolean =
        contains(output, entry.term(target), target)
}
