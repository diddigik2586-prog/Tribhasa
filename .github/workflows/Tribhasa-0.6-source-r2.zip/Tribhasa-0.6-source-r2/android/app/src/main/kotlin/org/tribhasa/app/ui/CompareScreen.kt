package org.tribhasa.app.ui

import android.content.Context
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import org.tribhasa.app.App
import org.tribhasa.app.UiError
import org.tribhasa.app.core.Direction
import org.tribhasa.app.core.EngineException
import org.tribhasa.app.core.FailKind
import org.tribhasa.app.core.Lang
import org.tribhasa.app.core.ModelCompare
import org.tribhasa.app.core.Models

/**
 * Settings → Compare models. Sends the same text through several open-weight models, one after another, and shows
 * every answer in full beside its model name, time and request count. It scores nothing: the scholar reads and decides.
 */
class CompareScreen(private val ctx: Context, private val host: Host, private val onClose: () -> Unit) {
    private val m = App.compare
    val view = FrameLayout(ctx)
    private val scroll = page(ctx)
    private val col = scroll.second

    private val taskPick = Picker(ctx, "What to compare") { pickTask() }
    private val dirPick = Picker(ctx, "Direction") { pickDirection() }
    private val outPick = Picker(ctx, "Explain in") { pickOut() }
    private val blurb = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val input = InputCard(ctx, "Text", "Paste or type the text to try on every model", 5) { m.input = it }
    private val modelBox = LinearLayout(ctx)
    private val info = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val runBtn = Ui.button(ctx, "Run the comparison") { start() }
    private val progress = ProgressArea(ctx) { m.cancel?.cancel() }
    private val error = ErrorArea(ctx, { start() }, { onClose(); host.openSettings() })
    private val results = LinearLayout(ctx)

    init {
        view.setBackgroundColor(Pal.bg)
        view.isClickable = true
        view.addView(scroll.first, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        modelBox.orientation = LinearLayout.VERTICAL
        results.orientation = LinearLayout.VERTICAL
        loadSaved()

        val top = hrow(ctx)
        top.addSide(Ui.chip(ctx, "← Back") { onClose() })
        col.add(top, bottom = 14)
        col.add(Ui.text(ctx, "Compare models", 26f, Pal.primary, bold = true), bottom = 6)
        col.add(Ui.text(ctx, "Run the same text through several open-weight models and read the answers side by side. The app does not score them: whether a rendering is good Granthika Kannada or a padaccheda is right is for you to judge.", 14f, Pal.ink), bottom = 10)
        val warn = Ui.card(ctx, Pal.accentSoft, Pal.outline)
        warn.add(Ui.text(ctx, "Each model uses at least one request, and a long text uses several. ${Models.FREE_LIMITS} Granthika polishing is left out of this comparison so that it costs fewer requests.", 13f, Pal.ink))
        col.add(warn, bottom = 12)

        col.add(taskPick.view, bottom = 4)
        blurb.setPadding(ctx.dp(4), 0, 0, ctx.dp(10))
        col.add(blurb)
        col.add(dirPick.view, bottom = 10)
        col.add(outPick.view, bottom = 10)
        col.add(Ui.chip(ctx, "Insert a sample…") { pickSample() }, bottom = 8)
        col.add(input.view, bottom = 12)

        val head = LabelRow(ctx, "Models to compare")
        head.action(Ui.chip(ctx, "Add by name") { addByName() })
        head.action(Ui.chip(ctx, "Live free list") { liveList() })
        col.add(head.view, bottom = 6)
        col.add(modelBox, bottom = 6)
        col.add(info, bottom = 10)
        col.add(runBtn, bottom = 12)
        col.add(progress.view, bottom = 12)
        col.add(error.view, bottom = 12)
        col.add(results)

        input.setText(m.input)
        m.listener = { render() }
        render()
    }

    // ---------------------------------------------------------------- saved choices
    private fun loadSaved() {
        if (m.loaded) return
        m.loaded = true
        val sel = App.store.pref("cmp_sel", "")
        val cus = App.store.pref("cmp_custom", "")
        m.custom.clear(); cus.split(',').map { it.trim() }.filter { Models.validId(it) }.forEach { if (it !in m.custom) m.custom.add(it) }
        m.selected.clear()
        val chosen = sel.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (chosen.isEmpty()) Models.CHECKED.filter { it.free }.forEach { m.selected.add(it.id) } else m.selected.addAll(chosen)
    }

    private fun saveChoices() {
        App.store.setPref("cmp_sel", m.selected.joinToString(","))
        App.store.setPref("cmp_custom", m.custom.joinToString(","))
    }

    private fun allIds(): List<String> = (Models.CHECKED.map { it.id } + m.custom).distinct()

    // ---------------------------------------------------------------- choosers
    private fun pickTask() {
        val all = ModelCompare.Task.values().toList()
        Ui.choose(ctx, "What to compare", all.map { it.label to it.blurb }, all.indexOf(m.task)) { i -> m.task = all[i]; render() }
    }

    private fun pickDirection() {
        val all = Direction.ALL
        Ui.choose(ctx, "Direction", all.map { it.label to "" }, all.indexOf(m.dir)) { i -> m.dir = all[i]; render() }
    }

    private fun pickOut() {
        val all = listOf(Lang.EN, Lang.KN)
        Ui.choose(ctx, "Explain in", langOptions(all), all.indexOf(m.out).coerceAtLeast(0)) { i -> m.out = all[i]; render() }
    }

    private fun pickSample() {
        val all = ModelCompare.SAMPLES
        Ui.choose(ctx, "A sample to try", all.map { it.label to it.task.label }, -1) { i ->
            val s = all[i]
            m.task = s.task
            if (s.task == ModelCompare.Task.TRANSLATE) m.dir = Direction(s.src, if (s.src == Lang.EN) Lang.KN else Lang.EN)
            m.input = s.text; input.setText(s.text); render()
        }
    }

    private fun addByName() {
        val box = Ui.input(ctx, "provider/model-name:free", 1, singleLine = true)
        val wrap = LinearLayout(ctx)
        wrap.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(8))
        wrap.addView(box, Ui.lp())
        android.app.AlertDialog.Builder(ctx).setTitle("Add a model by name").setView(wrap)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add") { _, _ ->
                val id = box.text.toString().trim()
                if (!Models.validId(id)) Ui.toast(ctx, "That does not look like a model name")
                else { if (id !in allIds()) m.custom.add(id); m.selected.add(id); saveChoices(); render() }
            }.show()
    }

    private fun liveList() {
        if (App.isOffline()) { Ui.toast(ctx, "The phone is offline"); return }
        val c = App.store.credentials()
        if (c.aiSource == org.tribhasa.app.core.AiSource.LOCAL) { Ui.toast(ctx, "Switch “Where the AI runs” to Online first"); return }
        Ui.toast(ctx, "Fetching the live list…")
        App.exec.execute {
            try {
                val p = org.tribhasa.app.core.ServiceFactory.provider(c.copy(llmModel = "x/x:free"))
                val free = p.listModels(org.tribhasa.app.core.CancelToken()).filter { it.free }.sortedBy { it.name.lowercase() }
                App.ui {
                    if (free.isEmpty()) { Ui.toast(ctx, "No free models are listed right now"); return@ui }
                    Ui.choose(ctx, "Free models listed now", free.map { x ->
                        (if (Models.candidate(x.id) != null) "✓ " else "") + x.id to "${x.name} · " + (Models.candidate(x.id)?.let { "licence ${it.licence}" } ?: "licence not checked by this app")
                    }, -1) { i -> val id = free[i].id; if (id !in allIds()) m.custom.add(id); m.selected.add(id); saveChoices(); render() }
                }
            } catch (e: Throwable) { val u = App.describe(e); App.ui { Ui.toast(ctx, u.message.take(160)) } }
        }
    }

    // ---------------------------------------------------------------- running
    private fun start() {
        if (m.running) return
        val text = input.text(); m.input = text
        if (text.isBlank()) { Ui.toast(ctx, "Please enter a text first."); return }
        val ids = allIds().filter { it in m.selected }
        if (ids.isEmpty()) { Ui.toast(ctx, "Tick at least one model."); return }
        val creds = App.store.credentials()
        if (creds.aiSource == org.tribhasa.app.core.AiSource.LOCAL) {
            m.error = UiError("Comparing models uses the online models through OpenRouter, which would send your text over the internet. “Where the AI runs” is set to “On this phone”, so the comparison is switched off. Choose “Online (optional)” in Settings if you want to compare online models.", false, true)
            render(); return
        }
        if (App.isOffline()) { m.error = UiError("The phone is offline. Connect to the internet and press Retry.", true, false); render(); return }
        if (creds.llmKey.isBlank()) { m.error = UiError("Connect the AI model in Settings first (a one-time sign-in).", false, true); render(); return }
        val task = m.task; val dir = m.dir; val out = m.out
        synchronized(m.results) { m.results.clear() }
        m.resultTask = task; m.resultInput = text
        App.launch(m, "Starting…", { cancel, p ->
            for ((i, id) in ids.withIndex()) {
                cancel.check()
                val head = "Model ${i + 1} of ${ids.size}: $id"
                p(head)
                val o = ModelCompare.run(task, text, dir, out, creds, id, cancel, progress = { s -> p("$head — $s") })
                if (cancel.cancelled) throw EngineException(FailKind.CANCELLED, "Cancelled.")
                synchronized(m.results) { m.results.add(o) }
                App.ui { m.changed() }
            }
        }) { }
    }

    // ---------------------------------------------------------------- drawing
    private fun render() {
        taskPick.set(m.task.label)
        blurb.text = m.task.blurb
        dirPick.view.show(m.task == ModelCompare.Task.TRANSLATE)
        dirPick.set(m.dir.label)
        outPick.view.show(m.task == ModelCompare.Task.SLOKA || m.task == ModelCompare.Task.PROSE)
        outPick.set(m.out.display)

        val creds = App.store.credentials()
        modelBox.removeAllViews()
        for (id in allIds()) {
            val chk = Models.candidate(id)
            val paidBlocked = !Models.isFree(id) && !creds.allowPaid
            val box = CheckBox(ctx)
            box.text = buildString {
                append(chk?.name ?: id)
                append("\n").append(id)
                append("\n").append(if (chk != null) "Licence ${chk.licence}" else "Licence not checked by this app")
                append(" · ").append(if (Models.isFree(id)) "free" else "paid")
                if (paidBlocked) append(" — blocked: switch on “Allow paid models” in Settings")
            }
            box.setTextColor(if (paidBlocked) Pal.inkSoft else Pal.ink)
            box.textSize = 14f
            box.isChecked = id in m.selected
            box.isEnabled = !m.running
            box.setOnCheckedChangeListener { _, v -> if (v) m.selected.add(id) else m.selected.remove(id); saveChoices(); updateInfo() }
            modelBox.add(box, bottom = 6)
        }
        updateInfo()

        runBtn.show(!m.running)
        progress.render(m.running, m.status)
        error.render(m.error)
        results.removeAllViews()
        val list = synchronized(m.results) { m.results.toList() }
        if (list.isNotEmpty()) {
            val head = LabelRow(ctx, "Results — ${m.resultTask.label}")
            head.action(Ui.chip(ctx, "Copy all") { Ui.copy(ctx, allText(list)) })
            results.add(head.view, bottom = 8)
            for (o in list) results.add(resultCard(o), bottom = 12)
            results.add(Ui.text(ctx, "These are machine answers. Read them yourself; the app has not decided which is best.", 12f, Pal.inkSoft))
        }
    }

    private fun updateInfo() {
        val n = allIds().count { it in m.selected }
        info.text = "$n model${if (n == 1) "" else "s"} ticked: at least $n request${if (n == 1) "" else "s"}."
    }

    private fun resultCard(o: ModelCompare.Outcome): View {
        val card = Ui.card(ctx)
        val chk = Models.candidate(o.model)
        val head = LabelRow(ctx, o.model)
        if (o.ok) {
            head.action(Ui.chip(ctx, "Copy") { Ui.copy(ctx, o.text) })
            head.action(Ui.chip(ctx, "Use this model") { useModel(o.model) })
        }
        card.add(head.view, bottom = 4)
        card.add(Ui.text(ctx, buildString {
            append("Answered by ${o.servedBy} · ${"%.1f".format(java.util.Locale.ROOT, o.millis / 1000.0)} s · ${o.requests} request${if (o.requests == 1) "" else "s"}")
            if (o.ok) append(" · ${o.qcWarnings} quality warning${if (o.qcWarnings == 1) "" else "s"}")
            append("\n").append(if (chk != null) "Licence ${chk.licence}" else "Licence not checked by this app")
        }, 12f, Pal.inkSoft), bottom = 8)
        if (o.ok) card.add(Ui.selectable(ctx, o.text.take(9000) + if (o.text.length > 9000) "\n… (shortened here; Copy gives everything)" else "", 15f, Pal.ink))
        else card.add(Ui.text(ctx, o.error ?: "Failed.", 14f, Pal.bad))
        return card
    }

    private fun useModel(id: String) {
        App.store.setLlmModel(id)
        val paid = !Models.isFree(id) && !App.store.credentials().allowPaid
        Ui.toast(ctx, if (paid) "Set as your model. It stays blocked until you allow paid models in Settings." else "Set as your model.")
    }

    private fun allText(list: List<ModelCompare.Outcome>): String = buildString {
        append("Model comparison — ${m.resultTask.label} — ")
        append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.ROOT).format(java.util.Date())).append("\n\n")
        append("Text:\n").append(m.resultInput).append("\n")
        for (o in list) {
            append("\n=== ").append(o.model).append(" (").append(o.servedBy).append(", ").append("%.1f".format(java.util.Locale.ROOT, o.millis / 1000.0)).append(" s, ").append(o.requests).append(" request(s)) ===\n")
            append(if (o.ok) o.text else "FAILED: ${o.error}").append("\n")
        }
    }
}
