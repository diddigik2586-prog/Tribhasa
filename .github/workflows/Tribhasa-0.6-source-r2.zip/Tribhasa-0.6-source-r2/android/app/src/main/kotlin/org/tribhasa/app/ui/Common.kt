package org.tribhasa.app.ui

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.tribhasa.app.core.Lang

/** Every screen implements this; the activity shows one at a time. */
interface Screen {
    val title: String
    val view: View
    fun onShow() {}
    fun saveDraft() {}
}

/** What a screen may ask of the activity. */
interface Host {
    fun openSettings()
    fun openAbout()
    fun openTranslate()
    fun openCompare()
}

fun LinearLayout.add(v: View, top: Int = 0, bottom: Int = 0, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f): View {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.topMargin = context.dp(top); p.bottomMargin = context.dp(bottom)
    addView(v, p)
    return v
}

fun LinearLayout.addSide(v: View, left: Int = 0, right: Int = 0, w: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f): View {
    val p = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
    p.leftMargin = context.dp(left); p.rightMargin = context.dp(right)
    addView(v, p)
    return v
}

fun hrow(ctx: Context): LinearLayout {
    val r = LinearLayout(ctx)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    return r
}

fun TextView.onChange(f: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
    })
}

fun View.show(on: Boolean) { visibility = if (on) View.VISIBLE else View.GONE }

/** Heading row: a small caps label on the left, actions on the right. */
class LabelRow(ctx: Context, label: String) {
    val view = hrow(ctx)
    init {
        view.addSide(Ui.label(ctx, label), w = 0, weight = 1f)
    }
    fun action(v: View) { view.addSide(v, left = 6) }
}

/** Text input card: label, Paste and Clear actions, the box and a character counter. */
class InputCard(private val ctx: Context, label: String, hint: String, minLines: Int = 6, val onText: (String) -> Unit) {
    val view = LinearLayout(ctx)
    val edit: EditText = Ui.input(ctx, hint, minLines)
    private val counter = Ui.text(ctx, "", 12f, Pal.inkSoft)
    private var silent = false
    init {
        view.orientation = LinearLayout.VERTICAL
        val row = LabelRow(ctx, label)
        row.action(Ui.chip(ctx, "Paste") {
            val t = Ui.pasteText(ctx)
            if (t.isBlank()) Ui.toast(ctx, "Nothing to paste") else { setText(t); onText(t) }
        })
        row.action(Ui.chip(ctx, "Clear") { setText(""); onText("") })
        view.add(row.view, bottom = 6)
        view.add(edit)
        counter.setPadding(ctx.dp(4), ctx.dp(4), 0, 0)
        view.add(counter)
        edit.onChange {
            if (!silent) onText(it)
            update(it)
        }
        update("")
    }
    private fun update(t: String) {
        val words = t.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        counter.text = if (t.isEmpty()) "" else "${t.length} characters · $words words"
    }
    fun text(): String = edit.text?.toString() ?: ""
    /** Sets the text without calling [onText]. */
    fun setText(t: String) {
        silent = true
        edit.setText(t)
        edit.setSelection(edit.text?.length ?: 0)
        silent = false
        update(t)
    }
}

/** A result card with a title, Copy action and a body that can be swapped. */
class OutputCard(private val ctx: Context, label: String, copyWhat: String = "Copied") {
    val view = LinearLayout(ctx)
    val actions = LabelRow(ctx, label)
    val body = Ui.selectable(ctx, "", 18f, Pal.ink)
    val extra = LinearLayout(ctx)
    private var raw = ""
    init {
        view.orientation = LinearLayout.VERTICAL
        extra.orientation = LinearLayout.VERTICAL
        val card = Ui.card(ctx)
        card.add(actions.view, bottom = 8)
        card.add(body)
        card.add(extra, top = 8)
        view.addView(card, Ui.lp())
        actions.action(Ui.chip(ctx, "Copy") { if (raw.isNotEmpty()) Ui.copy(ctx, raw, copyWhat) else Ui.toast(ctx, "Nothing to copy") })
    }
    /** [shown] is what is displayed; [copyText] is what Copy puts on the clipboard (defaults to the same). */
    fun set(shown: String, copyText: String = shown) { body.text = shown; raw = copyText }
}

/** Pill with a small caption above it. */
class Picker(private val ctx: Context, caption: String, private val onTap: () -> Unit) {
    val view = LinearLayout(ctx)
    private val cap = Ui.label(ctx, caption)
    val pill = Ui.pill(ctx) { onTap() }
    init {
        view.orientation = LinearLayout.VERTICAL
        cap.setPadding(ctx.dp(4), 0, 0, ctx.dp(4))
        view.add(cap)
        view.add(pill)
        pill.maxLines = 2
    }
    fun set(text: String) { pill.text = text }
    fun caption(t: String) { cap.text = t.uppercase() }
}

fun langOptions(langs: List<Lang>): List<Pair<String, String>> = langs.map { it.english to (if (it == Lang.EN) "" else it.nativeName) }
