package org.tribhasa.app.core

import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** The files of one model on the phone: the finished model, an unfinished download, and the mark that says the finished one was checked. */
class LocalModelFiles(val spec: LocalModels.Spec, val dir: File) {
    val finalFile: File get() = File(dir, spec.fileName)
    val partFile: File get() = File(dir, spec.fileName + ".part")
    private val marker: File get() = File(dir, spec.fileName + ".verified")

    /** ABSENT: nothing. PARTIAL: an unfinished download that can be resumed. READY: finished and checked. DAMAGED: a file is there but was never checked, or changed since. */
    enum class State { ABSENT, PARTIAL, READY, DAMAGED }

    fun state(): State = when {
        finalFile.isFile -> if (isMarkedVerified()) State.READY else State.DAMAGED
        partFile.isFile && partFile.length() > 0 -> State.PARTIAL
        else -> State.ABSENT
    }

    fun partialBytes(): Long = if (partFile.isFile) partFile.length() else 0L

    /** Cheap check used at every start: the mark exists and still matches the file's size and date. It does not re-read the file. */
    fun isMarkedVerified(): Boolean {
        val f = finalFile; val m = marker
        if (!f.isFile || !m.isFile) return false
        return try {
            val lines = m.readText(Charsets.UTF_8).lines()
            lines.size >= 3 && lines[0] == spec.sha256 &&
                lines[1] == f.length().toString() && f.length() == spec.sizeBytes &&
                lines[2] == f.lastModified().toString()
        } catch (e: IOException) { false }
    }

    /** Withdraws the "checked" mark, so the file is treated as damaged until it is checked again. */
    fun clearMark() { if (marker.exists()) marker.delete() }

    fun markVerified() { marker.writeText(spec.sha256 + "\n" + finalFile.length() + "\n" + finalFile.lastModified() + "\n", Charsets.UTF_8) }

    /** Removes the model, any unfinished download and the mark. Returns true when nothing is left. */
    fun deleteAll(): Boolean {
        for (f in listOf(finalFile, partFile, marker)) if (f.exists()) f.delete()
        return !finalFile.exists() && !partFile.exists() && !marker.exists()
    }
}

enum class DownloadPhase { CHECKING, DOWNLOADING, VERIFYING, DONE }

data class DownloadProgress(val phase: DownloadPhase, val doneBytes: Long, val totalBytes: Long, val note: String = "")

/** Why a download did not finish, in words the user can act on. [kind] lets the screen decide what to offer. */
class DownloadFailure(val kind: Kind, message: String, val detail: String? = null) : Exception(message) {
    enum class Kind { NETWORK, SERVER, DISK_FULL, CHECKSUM, SIZE, METERED, CANCELLED, BAD_URL, IO }
    /** True when pressing Retry / Resume can help without changing anything else. */
    val retryable: Boolean get() = kind == Kind.NETWORK || kind == Kind.SERVER || kind == Kind.IO || kind == Kind.METERED || kind == Kind.DISK_FULL || kind == Kind.CHECKSUM || kind == Kind.CANCELLED
}

/**
 * Downloads one model file, resumably, and accepts it only if its size and SHA-256 equal the published values.
 *
 *  - It writes to "<name>.part" and resumes from whatever is already there (HTTP Range).
 *  - A broken connection is retried automatically, resuming where it stopped; only repeated failures with no progress end the attempt.
 *  - Cancelling keeps the partly downloaded file, so "Resume" continues instead of starting again.
 *  - A finished file that fails the checksum is deleted, never used.
 *  - Nothing is sent but the HTTP request for the file: no account, no token, no analytics.
 */
class ModelDownloader(
    private val files: LocalModelFiles,
    private val freeSpace: (File) -> Long,
    private val isMetered: () -> Boolean = { false },
    private val wifiOnly: () -> Boolean = { false },
    private val sleeper: (Long) -> Unit = { Thread.sleep(it) },
    private val maxAutoRetries: Int = 6,
    private val baseBackoffMs: Long = 2_000,
    private val connectTimeoutMs: Int = 20_000,
    private val readTimeoutMs: Int = 30_000,
) {
    private class Retryable(message: String, val server: Boolean = false, val retryAfterMs: Long = 0) : Exception(message)
    private class RestartFromZero : Exception()

    fun run(cancel: CancelToken, progress: (DownloadProgress) -> Unit) {
        val spec = files.spec
        if (!spec.url.startsWith("https://"))
            throw DownloadFailure(DownloadFailure.Kind.BAD_URL, "The model address is not https, so the app refuses to download from it.")
        stopIfCancelled(cancel)
        if (!files.dir.isDirectory && !files.dir.mkdirs())
            throw DownloadFailure(DownloadFailure.Kind.IO, "The app could not create a folder for the model on this phone.")
        progress(DownloadProgress(DownloadPhase.CHECKING, 0, spec.sizeBytes, "Checking what is already on this phone…"))

        when (files.state()) {
            LocalModelFiles.State.READY -> { progress(DownloadProgress(DownloadPhase.DONE, spec.sizeBytes, spec.sizeBytes)); return }
            LocalModelFiles.State.DAMAGED -> {
                // A file is there that was never checked. Check it now; if it is the right one, keep it; if not, start again.
                if (files.finalFile.length() == spec.sizeBytes && sha256(files.finalFile, cancel, progress) == spec.sha256) {
                    files.markVerified(); progress(DownloadProgress(DownloadPhase.DONE, spec.sizeBytes, spec.sizeBytes)); return
                }
                files.finalFile.delete()
            }
            else -> {}
        }

        var have = files.partialBytes()
        if (have > spec.sizeBytes) { files.partFile.delete(); have = 0 }

        if (wifiOnly() && isMetered()) throw metered()
        val need = LocalModels.spaceNeeded(spec, have); val free = freeSpace(files.dir)
        if (free in 0 until need) throw DownloadFailure(DownloadFailure.Kind.DISK_FULL,
            "There is not enough free space. The download needs about ${LocalModels.gb(need)} free (the model plus a safety margin) and this phone has ${LocalModels.gb(free)}. Free some space, then tap Resume.")

        var stuck = 0
        var restarts = 0
        while (have < spec.sizeBytes) {
            stopIfCancelled(cancel)
            try {
                val now = transfer(have, cancel, progress)
                // A connection that ends early but delivered something is normal; one that delivers nothing, again and again, is not.
                stuck = if (now > have) 0 else stuck + 1
                have = now
                if (have < spec.sizeBytes && stuck >= maxAutoRetries)
                    throw DownloadFailure(DownloadFailure.Kind.NETWORK, "The server keeps closing the connection without sending data. The part already downloaded is kept; tap Resume later.")
                if (have < spec.sizeBytes && stuck > 0) { stopIfCancelled(cancel); sleeper(minOf(baseBackoffMs shl (stuck - 1).coerceIn(0, 5), 60_000L)) }
            } catch (e: RestartFromZero) {
                if (++restarts > 2) throw DownloadFailure(DownloadFailure.Kind.SERVER, "The server keeps answering in a way the app cannot resume from. Try again later.")
                files.partFile.delete(); have = 0
            } catch (e: Retryable) {
                stopIfCancelled(cancel)
                val after = files.partialBytes()
                stuck = if (after > have) 0 else stuck + 1
                have = after
                if (stuck >= maxAutoRetries) throw DownloadFailure(
                    if (e.server) DownloadFailure.Kind.SERVER else DownloadFailure.Kind.NETWORK,
                    (if (e.server) "The download server is not answering properly: " else "The connection keeps failing: ") + e.message +
                        " The part already downloaded (${LocalModels.gb(have)}) is kept; tap Resume to continue when the connection is better.")
                val wait = maxOf(baseBackoffMs shl (stuck - 1).coerceIn(0, 5), e.retryAfterMs).coerceAtMost(60_000)
                progress(DownloadProgress(DownloadPhase.DOWNLOADING, have, spec.sizeBytes, "${e.message} Trying again in ${(wait + 500) / 1000} s (attempt ${stuck + 1} of $maxAutoRetries)."))
                var left = wait
                while (left > 0) { stopIfCancelled(cancel); val s = minOf(left, 250L); sleeper(s); left -= s }
                if (wifiOnly() && isMetered()) throw metered("Paused: the phone is now on mobile data.")
            }
        }

        // The right number of bytes is there. Accept it only if it is the right bytes.
        if (files.partFile.length() != spec.sizeBytes) {
            files.partFile.delete()
            throw DownloadFailure(DownloadFailure.Kind.SIZE, "The downloaded file has the wrong size and was deleted. Tap Retry to download it again.")
        }
        val actual = sha256(files.partFile, cancel, progress)
        if (actual != spec.sha256) {
            files.partFile.delete()
            throw DownloadFailure(DownloadFailure.Kind.CHECKSUM,
                "The file arrived complete but its checksum does not match the one the publisher lists, so the app deleted it and will not use it. Tap Retry to download it again.",
                "expected ${spec.sha256}, got $actual")
        }
        files.finalFile.delete()
        if (!files.partFile.renameTo(files.finalFile))
            throw DownloadFailure(DownloadFailure.Kind.IO, "The model was downloaded and checked but could not be moved into place.")
        files.markVerified()
        progress(DownloadProgress(DownloadPhase.DONE, spec.sizeBytes, spec.sizeBytes, "Downloaded and checked."))
    }

    private fun metered(note: String = "") = DownloadFailure(DownloadFailure.Kind.METERED,
        (if (note.isNotEmpty()) "$note " else "") + "The phone is on mobile data, and “Download on Wi-Fi only” is switched on. Connect to Wi-Fi, or switch that option off in Settings, then tap Resume.")

    private fun stopIfCancelled(cancel: CancelToken) {
        if (cancel.cancelled) throw DownloadFailure(DownloadFailure.Kind.CANCELLED, "Paused. What was downloaded so far is kept; tap Resume to continue.")
    }

    /** One connection: from byte [from] to the end, or until it breaks. Returns the number of bytes now on disk. */
    private fun transfer(from: Long, cancel: CancelToken, progress: (DownloadProgress) -> Unit): Long {
        val spec = files.spec
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(spec.url).openConnection() as HttpURLConnection).apply {
                connectTimeout = connectTimeoutMs; readTimeout = readTimeoutMs
                requestMethod = "GET"; instanceFollowRedirects = true
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("User-Agent", "Tribhasa-model-download")
                if (from > 0) setRequestProperty("Range", "bytes=$from-")
            }
            cancel.attach(conn)
            val code = try { conn.responseCode } catch (e: IOException) { stopIfCancelled(cancel); throw Retryable("No connection (${e.javaClass.simpleName}).") }
            var offset = from
            when (code) {
                200 -> {
                    val len = conn.contentLengthLong
                    if (len >= 0 && len != spec.sizeBytes) throw DownloadFailure(DownloadFailure.Kind.SIZE,
                        "The file on the server is $len bytes, but the app expects ${spec.sizeBytes}. The publisher may have replaced it, so the app will not use it.")
                    if (from > 0) offset = 0   // the server ignored the request to continue; start the file again from the beginning
                }
                206 -> {
                    val range = Regex("bytes\\s+(\\d+)-(\\d+)/(\\d+|\\*)").find(conn.getHeaderField("Content-Range") ?: "")
                        ?: throw Retryable("The server's answer about the part sent could not be understood.", server = true)
                    val start = range.groupValues[1].toLong(); val total = range.groupValues[3]
                    if (total != "*" && total.toLong() != spec.sizeBytes) throw DownloadFailure(DownloadFailure.Kind.SIZE,
                        "The file on the server is $total bytes, but the app expects ${spec.sizeBytes}. The publisher may have replaced it, so the app will not use it.")
                    if (start != from) throw RestartFromZero()
                }
                416 -> {
                    if (from == spec.sizeBytes) return from
                    throw RestartFromZero()
                }
                408, 429, in 500..599 -> {
                    val ra = conn.getHeaderField("Retry-After")?.trim()?.toLongOrNull()?.times(1000) ?: 0L
                    throw Retryable("The server is busy (HTTP $code).", server = true, retryAfterMs = ra)
                }
                401, 403 -> throw DownloadFailure(DownloadFailure.Kind.SERVER,
                    "The publisher's server refused the download (HTTP $code). The file may have moved or may now need a login, which this app does not use.")
                404, 410 -> throw DownloadFailure(DownloadFailure.Kind.SERVER,
                    "The publisher's server no longer has this file (HTTP $code). The app needs an update with the new address.")
                else -> throw DownloadFailure(DownloadFailure.Kind.SERVER, "The server answered in an unexpected way (HTTP $code).")
            }
            if (offset == 0L && from > 0) files.partFile.delete()   // restarting from nothing

            RandomAccessFile(files.partFile, "rw").use { raf ->
                if (offset == 0L) raf.setLength(0)
                raf.seek(offset)
                val buf = ByteArray(256 * 1024)
                var written = offset
                var lastReport = 0L
                try {
                    conn.inputStream.use { input ->
                        while (true) {
                            if (cancel.cancelled) break
                            val n = input.read(buf)
                            if (n < 0) break
                            if (written + n > spec.sizeBytes) throw DownloadFailure(DownloadFailure.Kind.SIZE,
                                "The server sent more data than the file should contain. The app stopped and will not use it.")
                            raf.write(buf, 0, n); written += n
                            val now = System.nanoTime()
                            if (now - lastReport > 200_000_000L) {
                                lastReport = now
                                progress(DownloadProgress(DownloadPhase.DOWNLOADING, written, spec.sizeBytes))
                            }
                        }
                    }
                } catch (e: IOException) {
                    stopIfCancelled(cancel)
                    if (isDiskFull(e)) throw DownloadFailure(DownloadFailure.Kind.DISK_FULL, "The phone ran out of storage space while downloading. Free some space, then tap Resume.")
                    throw Retryable("The connection broke (${e.javaClass.simpleName}).")
                }
                stopIfCancelled(cancel)
                progress(DownloadProgress(DownloadPhase.DOWNLOADING, written, spec.sizeBytes))
            }
            return files.partialBytes()
        } catch (e: IOException) {
            stopIfCancelled(cancel)
            if (isDiskFull(e)) throw DownloadFailure(DownloadFailure.Kind.DISK_FULL, "The phone ran out of storage space. Free some space, then tap Resume.")
            throw Retryable("The connection failed (${e.javaClass.simpleName}).")
        } finally {
            cancel.attach(null)
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun isDiskFull(e: IOException) = (e.message ?: "").let { it.contains("No space left", true) || it.contains("ENOSPC") || it.contains("disk full", true) }

    /** SHA-256 of a whole file, reporting progress. Public so that "Check the file" can reuse it. */
    fun sha256(file: File, cancel: CancelToken, progress: (DownloadProgress) -> Unit): String {
        val md = MessageDigest.getInstance("SHA-256")
        val total = file.length()
        var done = 0L
        var lastReport = 0L
        FileInputStream(file).use { input ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                stopIfCancelled(cancel)
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n); done += n
                val now = System.nanoTime()
                if (now - lastReport > 200_000_000L) { lastReport = now; progress(DownloadProgress(DownloadPhase.VERIFYING, done, total, "Checking the file against the publisher's checksum…")) }
            }
        }
        return md.digest().joinToString("") { String.format("%02x", it) }
    }
}
