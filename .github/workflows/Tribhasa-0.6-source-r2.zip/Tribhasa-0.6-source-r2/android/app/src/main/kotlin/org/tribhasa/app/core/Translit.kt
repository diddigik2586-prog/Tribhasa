package org.tribhasa.app.core

/**
 * Deterministic script conversion for Sanskrit: Devanagari <-> IAST, and Devanagari <-> Kannada script.
 * These are rule tables, not AI output, so they are exactly reproducible.
 */
object Translit {
    // ---------- Devanagari -> IAST ----------
    private val CONS = arrayOf(
        // U+0915 .. U+0939
        "k", "kh", "g", "gh", "ṅ", "c", "ch", "j", "jh", "ñ", "ṭ", "ṭh", "ḍ", "ḍh", "ṇ",
        "t", "th", "d", "dh", "n", "n", "p", "ph", "b", "bh", "m", "y", "r", "r", "l", "ḷ", "ḻ",
        "v", "ś", "ṣ", "s", "h",
    )
    // U+0958 .. U+095F  (nukta forms) -> base letters
    private val NUKTA_CONS = arrayOf("k", "kh", "g", "j", "ḍ", "ḍh", "ph", "y")

    private fun consRoman(c: Int): String? = when (c) {
        in 0x0915..0x0939 -> CONS[c - 0x0915]
        in 0x0958..0x095F -> NUKTA_CONS[c - 0x0958]
        else -> null
    }

    private val INDEP = mapOf(
        0x0905 to "a", 0x0906 to "ā", 0x0907 to "i", 0x0908 to "ī", 0x0909 to "u", 0x090A to "ū",
        0x090B to "ṛ", 0x0960 to "ṝ", 0x090C to "ḷ", 0x0961 to "ḹ",
        0x090F to "e", 0x0910 to "ai", 0x0913 to "o", 0x0914 to "au",
        0x090E to "e", 0x0912 to "o", 0x090D to "e", 0x0911 to "o",
    )
    private val MATRA = mapOf(
        0x093E to "ā", 0x093F to "i", 0x0940 to "ī", 0x0941 to "u", 0x0942 to "ū",
        0x0943 to "ṛ", 0x0944 to "ṝ", 0x0962 to "ḷ", 0x0963 to "ḹ",
        0x0947 to "e", 0x0948 to "ai", 0x094B to "o", 0x094C to "au",
        0x0946 to "e", 0x094A to "o", 0x0945 to "e", 0x0949 to "o",
    )
    private const val VIRAMA = 0x094D
    private const val NUKTA = 0x093C

    fun consonantIast(cp: Int): String? = consRoman(cp)
    fun indepVowelIast(cp: Int): String? = INDEP[cp]
    fun matraIast(cp: Int): String? = MATRA[cp]

    private fun isIgnorable(cp: Int) = cp in 0x0951..0x0954 || cp in 0x1CD0..0x1CFF || cp == 0x200C || cp == 0x200D

    fun devanagariToIast(text: String): String {
        val s = Scripts.nfc(text)
        val sb = StringBuilder()
        var i = 0
        val n = s.length
        while (i < n) {
            val c = s[i].code
            val cons = consRoman(c)
            when {
                cons != null -> {
                    sb.append(cons); i++
                    if (i < n && s[i].code == NUKTA) i++
                    if (i < n) {
                        val d = s[i].code
                        val m = MATRA[d]
                        when {
                            m != null -> { sb.append(m); i++ }
                            d == VIRAMA -> i++
                            else -> sb.append('a')
                        }
                    } else sb.append('a')
                }
                INDEP.containsKey(c) -> { sb.append(INDEP[c]); i++ }
                c == 0x0902 -> { sb.append("ṃ"); i++ }
                c == 0x0903 -> { sb.append("ḥ"); i++ }
                c == 0x0901 -> { sb.append("m̐"); i++ }
                c == 0x093D -> { sb.append('\''); i++ }
                c == 0x0950 -> { sb.append("oṃ"); i++ }
                c == 0x0964 -> { sb.append('|'); i++ }
                c == 0x0965 -> { sb.append("||"); i++ }
                c in 0x0966..0x096F -> { sb.append(('0'.code + (c - 0x0966)).toChar()); i++ }
                isIgnorable(c) -> i++
                else -> { sb.append(s[i]); i++ }
            }
        }
        return Scripts.nfc(sb.toString())
    }

    // ---------- IAST -> Devanagari ----------
    private val ASPIRATED = mapOf(
        "kh" to 0x0916, "gh" to 0x0918, "ch" to 0x091B, "jh" to 0x091D,
        "ṭh" to 0x0920, "ḍh" to 0x0922, "th" to 0x0925, "dh" to 0x0927, "ph" to 0x092B, "bh" to 0x092D,
    )
    private val SINGLE_CONS = mapOf(
        'k' to 0x0915, 'g' to 0x0917, 'ṅ' to 0x0919, 'c' to 0x091A, 'j' to 0x091C, 'ñ' to 0x091E,
        'ṭ' to 0x091F, 'ḍ' to 0x0921, 'ṇ' to 0x0923, 't' to 0x0924, 'd' to 0x0926, 'n' to 0x0928,
        'p' to 0x092A, 'b' to 0x092C, 'm' to 0x092E, 'y' to 0x092F, 'r' to 0x0930, 'l' to 0x0932,
        'v' to 0x0935, 'ś' to 0x0936, 'ṣ' to 0x0937, 's' to 0x0938, 'h' to 0x0939,
    )
    private val VOWEL_INDEP = mapOf(
        "a" to 0x0905, "ā" to 0x0906, "i" to 0x0907, "ī" to 0x0908, "u" to 0x0909, "ū" to 0x090A,
        "ṛ" to 0x090B, "ṝ" to 0x0960, "ḷ" to 0x090C, "ḹ" to 0x0961, "e" to 0x090F, "ai" to 0x0910,
        "o" to 0x0913, "au" to 0x0914,
    )
    private val VOWEL_MATRA = mapOf(
        "a" to 0, "ā" to 0x093E, "i" to 0x093F, "ī" to 0x0940, "u" to 0x0941, "ū" to 0x0942,
        "ṛ" to 0x0943, "ṝ" to 0x0944, "ḷ" to 0x0962, "ḹ" to 0x0963, "e" to 0x0947, "ai" to 0x0948,
        "o" to 0x094B, "au" to 0x094C,
    )

    /** Result of an IAST -> Devanagari conversion. [unconverted] counts letters that are not IAST. */
    data class Converted(val text: String, val unconverted: Int)

    fun iastToDevanagari(text: String): Converted {
        val s = Scripts.nfc(text).lowercase()
        val sb = StringBuilder()
        var pending = false
        var unconverted = 0
        var i = 0
        val n = s.length
        fun flushPending() { if (pending) { sb.appendCodePoint(VIRAMA); pending = false } }
        while (i < n) {
            val ch = s[i]
            // aspirated consonant digraphs
            if (i + 1 < n) {
                val two = s.substring(i, i + 2)
                val asp = ASPIRATED[two]
                if (asp != null) { flushPending(); sb.appendCodePoint(asp); pending = true; i += 2; continue }
                if (two == "ai" || two == "au") {
                    if (pending) { sb.appendCodePoint(VOWEL_MATRA.getValue(two)); pending = false } else sb.appendCodePoint(VOWEL_INDEP.getValue(two))
                    i += 2; continue
                }
            }
            val sc = SINGLE_CONS[ch]
            val v = ch.toString()
            when {
                sc != null -> {
                    // m + combining candrabindu (U+0310) => candrabindu
                    if (ch == 'm' && i + 1 < n && s[i + 1].code == 0x0310) {
                        if (pending) { pending = false } // 'a' implied
                        sb.appendCodePoint(0x0901); i += 2
                    } else { flushPending(); sb.appendCodePoint(sc); pending = true; i++ }
                }
                VOWEL_INDEP.containsKey(v) -> {
                    if (pending) { val m = VOWEL_MATRA.getValue(v); if (m != 0) sb.appendCodePoint(m); pending = false }
                    else sb.appendCodePoint(VOWEL_INDEP.getValue(v))
                    i++
                }
                ch == 'ṃ' || ch == 'ṁ' -> { if (pending) pending = false; sb.appendCodePoint(0x0902); i++ }
                ch == 'ḥ' -> { if (pending) pending = false; sb.appendCodePoint(0x0903); i++ }
                ch == '\'' || ch == '’' || ch == 'ʼ' -> { flushPending(); sb.appendCodePoint(0x093D); i++ }
                ch == '|' -> {
                    flushPending()
                    if (i + 1 < n && s[i + 1] == '|') { sb.appendCodePoint(0x0965); i += 2 } else { sb.appendCodePoint(0x0964); i++ }
                }
                ch in '0'..'9' -> { flushPending(); sb.appendCodePoint(0x0966 + (ch - '0')); i++ }
                Scripts.isLatinLetter(ch.code) -> { flushPending(); sb.append(ch); unconverted++; i++ }
                else -> { flushPending(); sb.append(ch); i++ }
            }
        }
        flushPending()
        return Converted(sb.toString(), unconverted)
    }

    // ---------- Devanagari <-> Kannada (Unicode blocks are parallel, offset 0x380) ----------
    private const val DELTA = 0x380
    private fun devToKnCp(cp: Int): Int = when (cp) {
        in 0x0901..0x0903, 0x093C, 0x093D, in 0x0905..0x090C, in 0x090E..0x0910, in 0x0912..0x0928,
        in 0x092A..0x0933, in 0x0935..0x0939, in 0x093E..0x0944, in 0x0946..0x0948, in 0x094A..0x094D,
        in 0x0960..0x0963, in 0x0966..0x096F -> cp + DELTA
        else -> cp
    }
    private fun knToDevCp(cp: Int): Int = if (cp in 0x0C81..0x0CCD || cp in 0x0CE0..0x0CEF) {
        val d = cp - DELTA
        // only convert where the Devanagari counterpart exists
        if (devToKnCp(d) == cp) d else cp
    } else cp

    fun devanagariToKannada(text: String): String = mapCps(Scripts.nfc(text), ::devToKnCp)
    fun kannadaToDevanagari(text: String): String = mapCps(Scripts.nfc(text), ::knToDevCp)

    private fun mapCps(s: String, f: (Int) -> Int): String {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i); i += Character.charCount(cp)
            sb.appendCodePoint(f(cp))
        }
        return sb.toString()
    }

    // ---------- Convenience ----------
    enum class SanskritView(val label: String) { DEVANAGARI("देवनागरी"), IAST("IAST"), KANNADA("ಕನ್ನಡ ಲಿಪಿ") }

    /** Renders Sanskrit (held in Devanagari) in the requested script. */
    fun render(devanagari: String, view: SanskritView): String = when (view) {
        SanskritView.DEVANAGARI -> devanagari
        SanskritView.IAST -> devanagariToIast(devanagari)
        SanskritView.KANNADA -> devanagariToKannada(devanagari)
    }

    /** Result of normalising Sanskrit input into Devanagari. */
    data class SanskritInput(val devanagari: String, val detected: Script?, val converted: Boolean, val note: String?)

    /**
     * Sanskrit may be typed in Devanagari, IAST (Latin with diacritics) or Kannada script.
     * Machine translation expects Devanagari, so convert predictably before sending.
     */
    fun normaliseSanskritInput(text: String): SanskritInput {
        val dom = Scripts.dominant(text)
        return when (dom) {
            Script.KANNADA -> SanskritInput(kannadaToDevanagari(text), dom, true, "Sanskrit in Kannada script was converted to Devanagari before translation.")
            Script.LATIN -> {
                val r = iastToDevanagari(text)
                val note = if (r.unconverted > 0)
                    "Latin-script Sanskrit was read as IAST and converted to Devanagari; ${r.unconverted} letter(s) are not valid IAST and were left unchanged."
                else "Latin-script Sanskrit was read as IAST and converted to Devanagari before translation."
                SanskritInput(r.text, dom, true, note)
            }
            else -> SanskritInput(text, dom, false, null)
        }
    }
}
