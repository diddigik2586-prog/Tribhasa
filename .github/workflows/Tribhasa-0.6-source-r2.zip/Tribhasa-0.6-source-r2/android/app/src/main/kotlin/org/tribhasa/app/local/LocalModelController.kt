package org.tribhasa.app.local

import android.content.Context
import org.tribhasa.app.App
import org.tribhasa.app.Store
import org.tribhasa.app.TaskModel
import org.tribhasa.app.UiError
import org.tribhasa.app.core.CancelToken
import org.tribhasa.app.core.DownloadFailure
import org.tribhasa.app.core.DownloadPhase
import org.tribhasa.app.core.DownloadProgress
import org.tribhasa.app.core.LocalBackend
import org.tribhasa.app.core.LocalModelFiles
import org.tribhasa.app.core.LocalModelRuntime
import org.tribhasa.app.core.LocalModels
import org.tribhasa.app.core.ModelDownloader
import org.tribhasa.app.core.NativeEngineFactory
import java.io.File

/** What the Settings screen shows about the download and the file check. Lives here so a screen can be rebuilt while a download runs. */
class DownloadModel : TaskModel() {
    var phase = DownloadPhase.CHECKING
    var doneBytes = 0L
    var totalBytes = 0L
    /** The last failure, kept so the screen can word its buttons (Retry / Resume). */
    var failure: DownloadFailure? = null
    /** Text left by the last "Check the file". */
    var checkResult = ""
    var checking = false
    var lastFinishedOk = false
}

/**
 * The model on this phone: where its files are, downloading it (in the background, with a notification), pausing, resuming,
 * checking, deleting, and the runtime that runs it. The decisions live in core/ (and are tested there); this class wires them
 * to the phone.
 */
object Local {
    private lateinit var appCtx: Context
    private lateinit var store: Store
    lateinit var runtime: LocalModelRuntime; private set
    val download = DownloadModel()
    /** The real adapter is created only when a model is first loaded, so none of Google's library is touched while the app starts. */
    private class LateFactory : NativeEngineFactory {
        private val real by lazy { LiteRtEngineFactory() }
        override fun open(modelPath: String, backend: LocalBackend, contextTokens: Int, cacheDir: String) = real.open(modelPath, backend, contextTokens, cacheDir)
    }
    private var factory: NativeEngineFactory = LateFactory()

    /** For the automated screen tests: a different engine. The app never calls this. */
    fun useEngineFactoryForTests(f: NativeEngineFactory) { factory = f }

    fun init(ctx: Context, store: Store) {
        appCtx = ctx.applicationContext
        this.store = store
        runtime = LocalModelRuntime(
            files = { files() },
            factory = factory,
            backendChoice = { LocalBackend.fromName(store.localBackend()) },
            cacheDir = File(appCtx.cacheDir, "litertlm").also { it.mkdirs() }.path,
            isDownloading = { download.running },
        )
    }

    /** Forgets in-memory state (tests only). */
    fun resetForTests() {
        download.running = false; download.error = null; download.status = ""; download.failure = null; download.checkResult = ""; download.checking = false
        download.lastFinishedOk = false; download.doneBytes = 0; download.totalBytes = 0; download.cancel = null
    }

    /** The model's folder on the phone: private to the app, gone when the app is uninstalled, never backed up. */
    fun files(): LocalModelFiles = LocalModelFiles(LocalModels.active, File(appCtx.filesDir, "models/" + LocalModels.active.id))

    enum class UiState { NOT_ON_PHONE, DOWNLOADING, PAUSED, READY, DAMAGED }

    fun uiState(): UiState = when {
        download.running -> UiState.DOWNLOADING
        else -> when (files().state()) {
            LocalModelFiles.State.READY -> UiState.READY
            LocalModelFiles.State.DAMAGED -> UiState.DAMAGED
            LocalModelFiles.State.PARTIAL -> UiState.PAUSED
            LocalModelFiles.State.ABSENT -> UiState.NOT_ON_PHONE
        }
    }

    private fun changed() = download.changed()

    // ------------------------------------------------------------------ download
    fun startDownload() {
        val m = download
        if (m.running || m.checking) return
        val cancel = CancelToken()
        val spec = LocalModels.active
        m.cancel = cancel; m.running = true; m.error = null; m.failure = null; m.checkResult = ""; m.lastFinishedOk = false
        m.phase = DownloadPhase.CHECKING; m.doneBytes = files().partialBytes(); m.totalBytes = spec.sizeBytes
        m.status = "Starting…"
        changed()
        DownloadKeepAlive.start(appCtx)
        App.exec.execute {
            val downloader = ModelDownloader(
                files = files(),
                freeSpace = { DeviceInfo.freeSpace(it) },
                isMetered = { DeviceInfo.isMetered(appCtx) },
                wifiOnly = { store.localWifiOnly() },
            )
            try {
                downloader.run(cancel) { p ->
                    App.ui { if (m.cancel === cancel) apply(p) }
                    DownloadKeepAlive.update(appCtx, p)
                }
                App.ui { if (m.cancel === cancel) { m.running = false; m.error = null; m.lastFinishedOk = true; m.status = "The model is on this phone and checked."; changed() } }
            } catch (e: DownloadFailure) {
                App.ui {
                    if (m.cancel === cancel) {
                        m.running = false; m.failure = e
                        if (e.kind == DownloadFailure.Kind.CANCELLED) { m.status = e.message ?: "Paused."; m.error = null }
                        else { m.status = ""; m.error = UiError(e.message ?: "The download stopped.", e.retryable, false, e.detail) }
                        changed()
                    }
                }
            } catch (e: Throwable) {
                App.logCrash(e)
                App.ui {
                    if (m.cancel === cancel) {
                        m.running = false; m.status = ""
                        m.error = UiError("The download stopped unexpectedly (${e.javaClass.simpleName}: ${e.message}). What was downloaded is kept; tap Resume.", true, false, e.toString())
                        changed()
                    }
                }
            } finally {
                DownloadKeepAlive.stop(appCtx)
            }
        }
    }

    private fun apply(p: DownloadProgress) {
        val m = download
        m.phase = p.phase; m.doneBytes = p.doneBytes; m.totalBytes = p.totalBytes
        m.status = p.note.ifBlank {
            when (p.phase) {
                DownloadPhase.CHECKING -> "Checking what is already on this phone…"
                DownloadPhase.DOWNLOADING -> "Downloading…"
                DownloadPhase.VERIFYING -> "Checking the file against the publisher's checksum…"
                DownloadPhase.DONE -> "Done."
            }
        }
        changed()
    }

    /** Pauses the download. What has arrived is kept, and Resume continues from there. */
    fun cancelDownload() { download.cancel?.cancel() }

    // ------------------------------------------------------------------ check, delete
    /** Reads the whole file again and compares it with the publisher's checksum. Takes a minute or so. */
    fun verifyFile() {
        val m = download
        if (m.running || m.checking) return
        val f = files()
        if (!f.finalFile.isFile) { m.checkResult = "There is no complete model file on this phone to check."; changed(); return }
        val cancel = CancelToken()
        m.cancel = cancel; m.checking = true; m.checkResult = "Reading the file and computing its SHA-256 (this takes a minute or so)…"
        changed()
        App.exec.execute {
            val d = ModelDownloader(f, freeSpace = { -1L })
            val result = try {
                val spec = LocalModels.active
                val sha = d.sha256(f.finalFile, cancel) { p ->
                    App.ui { if (m.cancel === cancel && m.checking) { m.checkResult = "Checking the file… ${if (p.totalBytes > 0) p.doneBytes * 100 / p.totalBytes else 0}%"; changed() } }
                }
                if (f.finalFile.length() == spec.sizeBytes && sha == spec.sha256) {
                    f.markVerified()
                    "The file is the published one: its SHA-256 matches the publisher's value (checked just now)."
                } else {
                    f.clearMark()
                    "The file does NOT match the publisher's checksum, so the app will not use it. Delete it and download it again."
                }
            } catch (e: DownloadFailure) {
                if (e.kind == DownloadFailure.Kind.CANCELLED) "The check was cancelled." else (e.message ?: "The check could not be completed.")
            } catch (e: Throwable) {
                "The check could not be completed (${e.javaClass.simpleName}: ${e.message})."
            }
            App.ui { m.checking = false; m.checkResult = result; changed() }
        }
    }

    /** Frees the model from memory and removes it (and any unfinished download) from the phone. Returns a sentence for the user. */
    fun deleteModel(): String {
        if (download.running) return "Pause the download first."
        if (download.checking) return "Wait for the file check to end first."
        if (!runtime.unload()) return "A task is using the model right now. Wait for it to finish, or cancel it, then try again."
        val freed = files().let { it.finalFile.length() + it.partialBytes() }
        val ok = files().deleteAll()
        download.failure = null; download.error = null; download.checkResult = ""; download.lastFinishedOk = false; download.status = ""
        changed()
        return if (ok) "The model was removed from this phone (${LocalModels.gb(freed)} freed). You can download it again whenever you like."
        else "Some of the model's files could not be removed. Try again, or clear the app's storage in Android settings."
    }

    /** Frees the model's memory when nothing is using it (called when Android is short of memory or the app goes to the background). */
    fun trimMemory() { App.exec.execute { try { runtime.unload() } catch (_: Throwable) {} } }
}
