package org.tribhasa.app.local

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.StatFs
import java.io.File

/**
 * Facts about this phone that the model screen needs. Every function returns "unknown" (0, -1 or false) rather than failing.
 * (The automated screen tests replace this file with a version whose numbers they can set.)
 */
object DeviceInfo {
    /** Total memory Android reports for the phone (a little less than the advertised RAM), or 0 if unknown. */
    fun totalRamBytes(ctx: Context): Long = try {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); mi.totalMem
    } catch (e: Throwable) { 0L }

    /** Memory free right now, or 0 if unknown. */
    fun availableRamBytes(ctx: Context): Long = try {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); mi.availMem
    } catch (e: Throwable) { 0L }

    /** Free storage where [dir] is (or would be created), or -1 if unknown. */
    fun freeSpace(dir: File): Long = try {
        var d: File? = dir
        while (d != null && !d.exists()) d = d.parentFile
        if (d == null) -1L else StatFs(d.path).availableBytes
    } catch (e: Throwable) { -1L }

    /** True when the phone's current connection is one the user may pay for by the megabyte (mobile data, or a Wi-Fi marked metered). */
    fun isMetered(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
    } catch (e: Throwable) { false }

    /** Android 13+ lets the user decide whether the app may show notifications; ask once, only when a download is about to start. The download works either way. */
    fun askForNotificationPermission(activity: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
                activity.requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 4711)
        } catch (_: Throwable) {}
    }
}
