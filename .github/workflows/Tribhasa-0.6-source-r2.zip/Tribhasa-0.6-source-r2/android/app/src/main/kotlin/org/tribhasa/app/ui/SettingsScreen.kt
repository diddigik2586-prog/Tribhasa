package org.tribhasa.app.ui

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import org.tribhasa.app.App
import org.tribhasa.app.core.AiSource
import org.tribhasa.app.core.DownloadPhase
import org.tribhasa.app.core.LocalBackend
import org.tribhasa.app.core.LocalModels
import org.tribhasa.app.local.DeviceInfo
import org.tribhasa.app.local.Local
import org.tribhasa.app.core.BhashiniEngine
import org.tribhasa.app.core.CancelToken
import org.tribhasa.app.core.CloudflareIndicEngine
import org.tribhasa.app.core.Direction
import org.tribhasa.app.core.EngineException
import org.tribhasa.app.core.FailKind
import org.tribhasa.app.core.Lang
import org.tribhasa.app.core.LlmRequest
import org.tribhasa.app.core.Models
import org.tribhasa.app.core.OpenAiCompatProvider
import org.tribhasa.app.core.ServiceFactory
import org.tribhasa.app.core.Trace

class SettingsScreen(private val ctx: Context, private val host: Host) : Screen {
    override val title = "Settings"
    private val scroll = page(ctx)
    override val view: View = scroll.first
    private val col = scroll.second

    private val summary = Ui.text(ctx, "", 14f, Pal.ink)
    private val bUser = Ui.input(ctx, "ULCA User ID", 1, singleLine = true)
    private val bKey = Ui.input(ctx, "ULCA API key", 1, password = true)
    private val bStatus = Ui.selectable(ctx, "", 14f, Pal.inkSoft)
    private val lKey = Ui.input(ctx, "OpenRouter API key (only if you do not use Connect)", 1, password = true)
    private val lModel = Ui.input(ctx, "Model name, for example qwen/qwen3.8-27b:free", 1, singleLine = true)
    private val lBase = Ui.input(ctx, "Service address (https)", 1, singleLine = true)
    private val lThink = Ui.pill(ctx) { pickThinking() }
    private val lBackup = Ui.pill(ctx) { chooseBackup() }
    private val connStatus = Ui.selectable(ctx, "", 14f, Pal.ink)
    private val connBtn: TextView = Ui.button(ctx, "Connect — one-time sign-in") { onConnectTap() }
    private val disconnectChip: TextView = Ui.chip(ctx, "Disconnect") { confirmDisconnect() }
    private val advBox = LinearLayout(ctx)
    private var advToggle: TextView? = null
    private var sawSuccess = false
    private val lInfo = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val lStatus = Ui.selectable(ctx, "", 14f, Pal.inkSoft)
    private val cAcc = Ui.input(ctx, "Cloudflare account ID", 1, singleLine = true)
    private val cTok = Ui.input(ctx, "Cloudflare API token", 1, password = true)
    private val cStatus = Ui.selectable(ctx, "", 14f, Pal.inkSoft)
    private val selfStatus = Ui.selectable(ctx, "", 14f, Pal.inkSoft)
    // the model on this phone
    private val srcPill = Ui.pill(ctx) { pickSource() }
    private val srcInfo = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val locStatus = Ui.selectable(ctx, "", 14f, Pal.ink)
    private val locError = Ui.selectable(ctx, "", 14f, Pal.bad)
    private val locBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
    private val locMain: TextView = Ui.button(ctx, "Download the model") { onLocalMainTap() }
    private val locCheck: TextView = Ui.chip(ctx, "Check the file") { Local.verifyFile() }
    private val locDelete: TextView = Ui.chip(ctx, "Delete from this phone") { confirmDeleteModel() }
    private val locFree: TextView = Ui.chip(ctx, "Free memory now") { Local.trimMemory(); Ui.toast(ctx, "The model will be unloaded when no task is using it") }
    private val locCheckResult = Ui.selectable(ctx, "", 13f, Pal.ink)
    private val locMem = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val locLoaded = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val running = HashSet<String>()
    private val switches = HashMap<String, Switch>()
    private var quietSwitches = false

    init {
        col.add(Ui.card(ctx).also { it.add(summary) }, bottom = 14)
        buildLocal()
        buildAi()
        buildOptions()
        buildSelfTest()
        buildAdvanced()
        buildAbout()
        App.connect.listener = { renderConnect() }
        Local.download.listener = { renderLocal(); refreshSummary() }
        fill()
    }

    override fun onShow() { renderConnect(); renderLocal(); refreshSummary() }

    // ------------------------------------------------------------------ helpers
    private fun section(title: String, help: String, into: LinearLayout = col): LinearLayout {
        val card = Ui.card(ctx)
        card.add(Ui.text(ctx, title, 17f, Pal.primary, bold = true))
        if (help.isNotBlank()) card.add(Ui.text(ctx, help, 13f, Pal.inkSoft), top = 4, bottom = 8)
        into.add(card, bottom = 14)
        return card
    }

    private fun field(card: LinearLayout, caption: String, f: EditText) {
        card.add(Ui.label(ctx, caption), top = 8, bottom = 4)
        card.add(f)
    }

    private fun openUrl(url: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { Ui.toast(ctx, "Could not open the browser") }
    }

    /** Runs a test in the background and writes the outcome (plain text) into [out]. */
    private fun test(id: String, out: TextView, work: (CancelToken) -> String) {
        if (id in running) return
        if (App.isOffline()) { out.text = "The phone is offline."; return }
        running.add(id)
        out.text = "Testing… this can take up to a minute."
        App.exec.execute {
            val text = try { work(CancelToken()) } catch (e: Throwable) {
                val u = App.describe(e)
                u.message + (u.detail?.let { "\n\nDetails: $it" } ?: "")
            }
            App.ui { running.remove(id); out.text = text }
        }
    }

    // ------------------------------------------------------------------ Bhashini
    private fun buildBhashini() {
        val card = section(
            "Bhashini — IndicTrans2 (optional)",
            "Free government service that hosts AI4Bharat IndicTrans2. It needs a free sign-up on its website and a ULCA User ID and API key that you must create and enter yourself, so it is not part of the automatic set-up. Its use is currently limited to non-commercial testing; offered directions are discovered live when you press Test.",
            advBox
        )
        field(card, "ULCA User ID", bUser)
        field(card, "ULCA API key", bKey)
        val row = hrow(ctx)
        row.addSide(Ui.button(ctx, "Save") { saveBhashini() }, w = 0, weight = 1f)
        row.addSide(Ui.button(ctx, "Test connection", primary = false) { testBhashini() }, left = 8, w = 0, weight = 1f)
        card.add(row, top = 12)
        card.add(Ui.chip(ctx, "Open bhashini.gov.in to sign up") { openUrl("https://bhashini.gov.in") }, top = 8)
        card.add(bStatus, top = 8)
    }

    private fun saveBhashini() {
        App.store.setBhashini(bUser.text.toString(), bKey.text.toString())
        Ui.toast(ctx, "Saved"); fill()
    }

    private fun testBhashini() {
        val u = bUser.text.toString().trim(); val k = bKey.text.toString().trim()
        if (u.isEmpty() || k.isEmpty()) { bStatus.text = "Enter both the User ID and the API key first."; return }
        test("bhashini", bStatus) { cancel ->
            val res = BhashiniEngine(u, k).probeDirections(cancel)
            val sb = StringBuilder("Connected to Bhashini. Directions this account can use:\n")
            for ((d, svc) in res) sb.append(if (svc != null) "✓ " else "✗ ").append(d.label).append(if (svc != null) "  ($svc)\n" else "  — not offered\n")
            if (res.none { it.second != null }) sb.append("\nNo direction was offered. Bhashini may be having trouble; try again later.")
            else if (res.any { it.second == null }) sb.append("\nFor the missing directions the app will use a general AI model if you allow it below (clearly labelled “not IndicTrans2”).")
            sb.toString().trimEnd()
        }
    }

    // ------------------------------------------------------------------ the model on this phone
    private fun buildLocal() {
        val spec = LocalModels.active
        val card = section(
            "AI on this phone — free, private, works offline",
            "Translation, refinement, analysis and commentary can run on this phone with an open model (${spec.name}). After a one-time download of ${LocalModels.gb(spec.sizeBytes)}, no internet is needed and no text leaves the phone. No account, key, payment or hosting is involved."
        )
        card.add(Ui.label(ctx, "Where the AI runs"), top = 6, bottom = 4)
        card.add(srcPill)
        card.add(srcInfo, top = 4)
        card.add(Ui.label(ctx, "The model on this phone"), top = 14, bottom = 4)
        card.add(locStatus)
        locBar.max = 1000
        card.add(locBar, top = 8, h = ctx.dp(8))
        card.add(locError, top = 8)
        card.add(locMain, top = 10)
        val row = hrow(ctx)
        row.addSide(locCheck, right = 8)
        row.addSide(locDelete, right = 8)
        row.addSide(locFree)
        card.add(row, top = 8)
        card.add(locCheckResult, top = 6)
        card.add(switchRowNow("Download on Wi-Fi only (recommended: the file is ${LocalModels.gb(spec.sizeBytes)})", SW_WIFI, App.store.localWifiOnly()) { on -> App.store.setLocalWifiOnly(on) }, top = 8)
        card.add(switchRowNow("Use the phone's GPU (experimental; if it cannot load the model the CPU is used and the answer says so)", SW_GPU, App.store.localBackend() == LocalBackend.GPU.name) { on ->
            App.store.setLocalBackend(if (on) LocalBackend.GPU else LocalBackend.CPU); Local.trimMemory(); renderLocal()
        }, top = 4)
        card.add(locMem, top = 8)
        card.add(locLoaded, top = 4)
        card.add(Ui.text(ctx,
            "Model: ${spec.name}. Published by ${spec.publisher}. Licence: ${spec.licence} (${spec.licenceSource}). File: ${spec.fileName}, ${spec.sizeBytes} bytes. " +
                "The app downloads it from the publisher's own repository, pinned to one revision, and accepts it only if its SHA-256 is ${spec.sha256}. Facts read ${LocalModels.CHECKED_ON}.", 12f, Pal.inkSoft), top = 8)
        card.add(Ui.chip(ctx, "Open the model's page") { openUrl(spec.sourcePage) }, top = 8)
        card.add(Ui.text(ctx,
            "How good is it? This is a small model running on a phone. Its quality for Sanskrit and Kannada has NOT been tested with a Sanskrit evaluation set, so every result is marked low-confidence. " +
                "Short passages work best; śloka analysis, prose analysis and commentary are experimental on the phone and may be slow, incomplete or wrong. The app never switches to an online service by itself: if the model cannot do a task it says so.", 13f, Pal.warn), top = 8)
    }

    private fun pickSource() {
        val cur = App.store.credentials().aiSource
        Ui.choose(ctx, "Where the AI runs", listOf(
            "On this phone (default)" to "Free and private. Needs the one-time model download; then works without internet.",
            "Online (optional)" to "Uses OpenRouter's online models. Your texts are sent over the internet. Needs the one-time sign-in below.",
        ), if (cur == AiSource.LOCAL) 0 else 1) { i ->
            if (i == 0) { App.store.setAiSource(AiSource.LOCAL); renderLocal(); refreshSummary() }
            else AlertDialog.Builder(ctx).setTitle("Send my texts over the internet?")
                .setMessage("With “Online”, every text you translate, refine or analyse is sent to OpenRouter and on to the company that hosts the model. Your phone's own model is not used. You can switch back at any time.")
                .setNegativeButton("Stay on this phone", null)
                .setPositiveButton("Use online") { _, _ -> App.store.setAiSource(AiSource.ONLINE); renderLocal(); refreshSummary() }
                .show()
        }
    }

    private fun onLocalMainTap() {
        when (Local.uiState()) {
            Local.UiState.DOWNLOADING -> Local.cancelDownload()
            Local.UiState.DAMAGED -> Local.verifyFile()
            else -> beginDownload()
        }
    }

    /** Warns first if the phone looks too small, then asks for notification permission (Android 13+) and starts. */
    private fun beginDownload() {
        val ram = DeviceInfo.totalRamBytes(ctx)
        val go = {
            (ctx as? android.app.Activity)?.let { DeviceInfo.askForNotificationPermission(it) }
            Local.startDownload()
        }
        if (LocalModels.memoryFit(ram) == LocalModels.Fit.LIKELY_TOO_SMALL)
            AlertDialog.Builder(ctx).setTitle("This phone may be too small")
                .setMessage(LocalModels.memoryText(ram) + "\n\nThe download is ${LocalModels.gb(LocalModels.active.sizeBytes)}. Download anyway?")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Download anyway") { _, _ -> go() }
                .show()
        else go()
    }

    private fun confirmDeleteModel() {
        AlertDialog.Builder(ctx).setTitle("Delete the model from this phone?")
            .setMessage("This frees ${LocalModels.gb(LocalModels.active.sizeBytes)}. Translation, refinement and analysis on this phone stop until you download it again. Your glossary, history and settings are not touched.")
            .setNegativeButton("Keep it", null)
            .setPositiveButton("Delete") { _, _ -> Ui.toast(ctx, Local.deleteModel()); renderLocal(); refreshSummary() }
            .show()
    }

    /** Redraws the model area from what is on the phone and from the download that may be running. */
    private fun renderLocal() {
        val c = App.store.credentials()
        val spec = LocalModels.active
        val m = Local.download
        val st = Local.uiState()
        srcPill.text = if (c.aiSource == AiSource.LOCAL) "On this phone (default)" else "Online (optional)"
        srcInfo.text = if (c.aiSource == AiSource.LOCAL) "Texts are processed on this phone only. The online services further down are not used."
            else "Texts are sent over the internet to OpenRouter. The model on this phone is not used."
        fun pct(done: Long, total: Long) = if (total > 0) (done * 100 / total).toInt() else 0
        val sizes = "${LocalModels.mb(m.doneBytes)} of ${LocalModels.mb(m.totalBytes)} (${pct(m.doneBytes, m.totalBytes)}%)"
        when (st) {
            Local.UiState.NOT_ON_PHONE -> { locStatus.setTextColor(Pal.warn); locStatus.text = "Not on this phone yet. Tap Download: ${LocalModels.gb(spec.sizeBytes)}, once, free, no account." }
            Local.UiState.DOWNLOADING -> {
                locStatus.setTextColor(Pal.ink)
                locStatus.text = when (m.phase) {
                    DownloadPhase.VERIFYING -> "Checking the file against the publisher's checksum… ${pct(m.doneBytes, m.totalBytes)}%"
                    DownloadPhase.CHECKING -> m.status.ifBlank { "Starting…" }
                    else -> "Downloading… $sizes" + if (m.status.isNotBlank() && !m.status.startsWith("Downloading")) "\n${m.status}" else ""
                }
            }
            Local.UiState.PAUSED -> { locStatus.setTextColor(Pal.warn); locStatus.text = "Unfinished: ${LocalModels.mb(Local.files().partialBytes())} of ${LocalModels.mb(spec.sizeBytes)} is on this phone and kept. Tap Resume to continue." }
            Local.UiState.READY -> { locStatus.setTextColor(Pal.good); locStatus.text = "✓ On this phone and checked (${LocalModels.gb(spec.sizeBytes)}). Works without internet." }
            Local.UiState.DAMAGED -> { locStatus.setTextColor(Pal.bad); locStatus.text = "A model file is here, but it has not been confirmed to be the published one (or it changed), so it is not used. Tap “Check the file”, or delete it and download again." }
        }
        locStatus.show(true)
        val busy = st == Local.UiState.DOWNLOADING
        locBar.show(busy || m.checking)
        locBar.isIndeterminate = !(m.totalBytes > 0 && (m.phase == DownloadPhase.DOWNLOADING || m.phase == DownloadPhase.VERIFYING))
        if (!locBar.isIndeterminate) locBar.progress = (m.doneBytes * 1000 / m.totalBytes).toInt().coerceIn(0, 1000)
        val err = m.error
        locError.show(err != null && !busy)
        locError.text = err?.message ?: ""
        locMain.text = when (st) {
            Local.UiState.DOWNLOADING -> "Pause the download"
            Local.UiState.PAUSED -> if (err != null) "Retry" else "Resume the download"
            Local.UiState.DAMAGED -> "Check the file"
            else -> if (err != null) "Retry" else "Download the model (${LocalModels.gb(spec.sizeBytes)})"
        }
        locMain.show(st != Local.UiState.READY && !m.checking)
        locCheck.show(!busy && !m.checking && (st == Local.UiState.READY || st == Local.UiState.DAMAGED))
        locDelete.show(!busy && !m.checking && st != Local.UiState.NOT_ON_PHONE)
        locFree.show(st == Local.UiState.READY && Local.runtime.isLoaded)
        locCheckResult.text = m.checkResult
        locCheckResult.show(m.checkResult.isNotBlank())
        locMem.text = LocalModels.memoryText(DeviceInfo.totalRamBytes(ctx)) + " " + spec.publisherMemoryNote
        locLoaded.text = "In memory now: ${Local.runtime.loadedDescription}." + if (st == Local.UiState.READY) " The first task after a restart loads it, which takes a while." else ""
    }

    // ------------------------------------------------------------------ open-weight AI model (OpenRouter), connected by sign-in
    private fun buildAi() {
        val card = section(
            "Online AI (optional) — OpenRouter, open-weight models",
            "Used only when “Where the AI runs” above is set to Online. Then every text is sent over the internet to OpenRouter and the company that hosts the model. Only open-weight models are offered (Apache-2.0 or MIT, checked on ${Models.CHECKED_ON}); no Claude or Gemini is used."
        )
        card.add(connStatus, top = 4)
        card.add(connBtn, top = 10)
        card.add(disconnectChip, top = 8)
        card.add(Ui.text(ctx,
            "What happens when you tap Connect: your browser opens OpenRouter's own sign-in page. Sign in there (if you have no account, OpenRouter lets you create a free one) and tap Authorize. " +
                "The browser then sends you back to this app by itself, and the app keeps the access it was given, encrypted with the phone's secure keystore (this screen tells you afterwards how it was actually kept). You do not search for, copy or type any key. " +
                "Keep Tribhāṣā open in the background while you sign in.", 13f, Pal.inkSoft), top = 8)
        card.add(Ui.text(ctx,
            "An OpenRouter account is needed because the free allowance belongs to an account. ${Models.FREE_LIMITS} Tribhāṣā never buys credits or turns on billing.", 13f, Pal.inkSoft), top = 6)

        field(card, "Model", lModel)
        val row2 = hrow(ctx)
        row2.addSide(Ui.chip(ctx, "Choose a model") { chooseModel() }, right = 6)
        row2.addSide(Ui.chip(ctx, "Live free list") { liveList() })
        card.add(row2, top = 8)
        card.add(Ui.label(ctx, "Thinking before answering"), top = 12, bottom = 4)
        card.add(lThink)
        card.add(Ui.label(ctx, "Back-up model (optional)"), top = 12, bottom = 4)
        card.add(lBackup)
        card.add(Ui.text(ctx, "Used only when the first model keeps failing; at most one extra model, never a paid one unless you allow paid models. Every attempt counts against your daily free allowance. The report names the model that really answered.", 12f, Pal.inkSoft), top = 4)
        card.add(switchRowNow("Allow paid models (can use credits on your OpenRouter account)", Store_PAID, App.store.credentials().allowPaid) { on ->
            if (on) confirmPaid() else { App.store.setAllowPaid(false); refreshSummary() }
        }, top = 10)
        card.add(switchRowNow("Avoid hosts that keep or train on my text (may leave no free host)", Store_DENY, App.store.credentials().denyDataCollection) { on ->
            App.store.setDenyDataCollection(on); refreshSummary()
        }, top = 4)
        card.add(lInfo, top = 6)
        val row = hrow(ctx)
        row.addSide(Ui.button(ctx, "Save") { saveAi() }, w = 0, weight = 1f)
        row.addSide(Ui.button(ctx, "Test connection", primary = false) { testAi() }, left = 8, w = 0, weight = 1f)
        card.add(row, top = 12)
        card.add(Ui.button(ctx, "Compare models side by side", primary = false) { host.openCompare() }, top = 10)
        card.add(lStatus, top = 8)
    }

    /** The collapsed area for things that need keys the user has to make by hand. */
    private fun buildAdvanced() {
        advBox.orientation = LinearLayout.VERTICAL
        advBox.show(false)
        val toggle = Ui.button(ctx, "Show advanced options", primary = false) {
            val open = advBox.visibility != View.VISIBLE
            advBox.show(open)
            advToggle?.text = if (open) "Hide advanced options" else "Show advanced options"
        }
        advToggle = toggle
        col.add(toggle, bottom = 14)
        col.add(advBox)

        val card = section(
            "OpenRouter key by hand, or your own backend",
            "Normally you do not need this: Connect above does it for you. Use it only if the sign-in cannot work on your phone, or to point the app at your own secure backend (for production), whose token goes in the key box.",
            advBox
        )
        field(card, "API key", lKey)
        field(card, "Service address", lBase)
        card.add(Ui.text(ctx, "Leave the address as it is to use OpenRouter directly. A key obtained by Connect is only ever sent to OpenRouter.", 12f, Pal.inkSoft), top = 4)
        val kr = hrow(ctx)
        kr.addSide(Ui.button(ctx, "Save") { saveAi() }, w = 0, weight = 1f)
        kr.addSide(Ui.chip(ctx, "Get a key yourself") { openUrl("https://openrouter.ai/keys") }, left = 8)
        card.add(kr, top = 12)
        buildBhashini()
        buildCloudflare()
    }

    private fun onConnectTap() {
        if (App.connect.running) { App.cancelConnect(); return }
        if (App.isOffline()) { Ui.toast(ctx, "The phone is offline."); return }
        App.connect.error = null
        App.beginConnect()
    }

    private fun confirmDisconnect() {
        AlertDialog.Builder(ctx).setTitle("Disconnect the AI model?")
            .setMessage("The key will be erased from this phone and the AI features will stop until you connect again.\n\nA key made by the sign-in stays listed in your OpenRouter account until you delete it there (openrouter.ai/keys), which you may do if you wish.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Disconnect") { _, _ -> App.store.disconnectLlm(); App.connect.lastOutcome = ""; App.connect.lastWasSuccess = false; fill(); Ui.toast(ctx, "Disconnected") }
            .show()
    }

    /** Redraws the connection area from the saved state and from the sign-in that may be running. */
    private fun renderConnect() {
        val m = App.connect
        val c = App.store.credentials()
        val err = m.error
        when {
            m.running -> { connStatus.setTextColor(Pal.ink); connStatus.text = m.status.ifBlank { "Signing in…" } }
            err != null -> { connStatus.setTextColor(Pal.bad); connStatus.text = err.message }
            m.status.startsWith("Cancelled") -> { connStatus.setTextColor(Pal.inkSoft); connStatus.text = "The sign-in was cancelled. Nothing was saved." }
            m.lastWasSuccess && c.hasLlm -> { connStatus.setTextColor(Pal.good); connStatus.text = m.lastOutcome }
            c.llmKeyFromSignIn -> {
                connStatus.setTextColor(Pal.good)
                val at = App.store.signedInAt()
                val when_ = if (at > 0) " on " + java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(at)) else ""
                connStatus.text = "✓ Connected to OpenRouter through your sign-in$when_. The app holds its own key, ${App.store.llmKeyProtectionText()}."
            }
            c.llmKey.isNotBlank() -> { connStatus.setTextColor(Pal.good); connStatus.text = "✓ A key you entered by hand is saved on this phone, ${App.store.llmKeyProtectionText()}." }
            else -> { connStatus.setTextColor(Pal.warn); connStatus.text = "Not connected yet. Tap Connect to sign in once." }
        }
        connBtn.text = when {
            m.running -> "Cancel sign-in"
            c.llmKey.isNotBlank() -> "Connect again (new sign-in)"
            else -> "Connect — one-time sign-in"
        }
        disconnectChip.show(!m.running && c.llmKey.isNotBlank())
        if (!m.running) {
            refreshSummary()
            if (m.lastWasSuccess && !sawSuccess) { sawSuccess = true; fill(); Ui.toast(ctx, "Connected") }
            if (!m.lastWasSuccess) sawSuccess = false
        }
    }

    /** The saved credentials with whatever is typed in the boxes. A sign-in key is kept unless a different key is typed. */
    private fun candidateCreds(): org.tribhasa.app.core.Credentials {
        val c = App.store.credentials()
        val typed = lKey.text.toString().trim()
        return c.copy(
            llmKey = if (typed.isNotEmpty()) typed else c.llmKey,
            llmKeyFromSignIn = c.llmKeyFromSignIn && typed.isEmpty(),
            llmModel = lModel.text.toString().trim(), llmBaseUrl = lBase.text.toString().trim(),
        )
    }

    private fun saveAi() {
        val model = lModel.text.toString().trim()
        val base = lBase.text.toString().trim().ifBlank { Models.OPENROUTER_BASE }
        val typed = lKey.text.toString().trim()
        val cur = App.store.credentials()
        if (model.isNotEmpty() && !Models.validId(model)) { lStatus.text = "That model name is not valid. It looks like provider/name or provider/name:free."; return }
        if (Models.normaliseBase(base) == null) { lStatus.text = "The service address must start with https://"; return }
        if (cur.llmKeyFromSignIn && typed.isEmpty() && Models.normaliseBase(base) != Models.OPENROUTER_BASE) {
            lStatus.text = "The key from Connect is only ever sent to OpenRouter, so the service address must stay as it is. To use your own backend, disconnect first and enter its token under Advanced."; return
        }
        if (typed.isNotEmpty()) App.store.setLlmKey(typed)
        App.store.setLlmModel(model); App.store.setLlmBase(base)
        lStatus.text = if (model.isNotEmpty() && !Models.isFree(model) && !App.store.credentials().allowPaid)
            "Saved. Note: “$model” is not a free model, so it will be refused until “Allow paid models” is on." else "Saved."
        Ui.toast(ctx, "Saved"); fill()
    }

    private fun confirmPaid() {
        AlertDialog.Builder(ctx).setTitle("Allow paid models?")
            .setMessage("Paid models are charged by OpenRouter to your own account, and only if you have bought credits there. Tribhāṣā never buys credits and cannot top up your account. Switch this on only if you want that.")
            .setNegativeButton("Keep it off") { _, _ -> refreshSwitches() }
            .setPositiveButton("Allow") { _, _ -> App.store.setAllowPaid(true); refreshSummary() }
            .setOnCancelListener { refreshSwitches() }
            .show()
    }

    private fun refreshSwitches() {
        val c = App.store.credentials()
        quietSwitches = true
        switches[Store_PAID]?.isChecked = c.allowPaid
        switches[Store_DENY]?.isChecked = c.denyDataCollection
        switches[SW_WIFI]?.isChecked = App.store.localWifiOnly()
        switches[SW_GPU]?.isChecked = App.store.localBackend() == LocalBackend.GPU.name
        quietSwitches = false
    }

    private fun pickThinking() {
        val all = Models.Think.values().toList()
        val cur = Models.Think.fromName(App.store.credentials().thinking)
        Ui.choose(ctx, "Thinking before answering", all.map { it.label to when (it) {
            Models.Think.DEFAULT -> "Do not ask; the model decides."
            Models.Think.OFF -> "Fastest and uses the fewest tokens; best for plain translation."
            Models.Think.LOW -> "A little reasoning. Starting choice."
            Models.Think.MEDIUM -> "More reasoning for grammar and śloka work; slower."
            Models.Think.HIGH -> "Most reasoning; slowest; can use up the output allowance."
        } }, all.indexOf(cur)) { i -> App.store.setThinking(all[i].name); refreshThinking() }
    }

    private fun refreshThinking() { lThink.text = Models.Think.fromName(App.store.credentials().thinking).label }

    private fun refreshBackup() {
        val b = App.store.credentials().fallbackModel
        lBackup.text = if (b.isBlank()) "Off" else (Models.candidate(b)?.name ?: b)
    }

    private fun chooseBackup() {
        val primary = lModel.text.toString().trim()
        val list = Models.CHECKED.filter { it.free && it.id != primary }
        val cur = App.store.credentials().fallbackModel
        val opts = listOf("Off" to "No back-up. Recommended while the free allowance is small.") + list.map { it.name to "${it.licence} · ${it.id}" }
        val sel = if (cur.isBlank()) 0 else (list.indexOfFirst { it.id == cur } + 1).coerceAtLeast(0)
        Ui.choose(ctx, "Back-up model", opts, sel) { i ->
            App.store.setFallbackModel(if (i == 0) "" else list[i - 1].id); refreshBackup(); refreshSummary()
        }
    }

    private fun chooseModel() {
        val list = Models.CHECKED
        Ui.choose(ctx, "Models whose licence was checked", list.map { it.name to "${it.licence} · ${it.price}" }, list.indexOfFirst { it.id == lModel.text.toString().trim() }) { i ->
            lModel.setText(list[i].id); App.store.setLlmModel(list[i].id); lStatus.text = "Model set to ${list[i].id}.\n${list[i].licenceSource}\n${list[i].dataNote}"; fill()
        }
    }

    private fun liveList() {
        val c = candidateCreds()
        if (c.llmKey.isBlank()) { lStatus.text = "Tap Connect first."; return }
        if (App.isOffline()) { lStatus.text = "The phone is offline."; return }
        if (Models.normaliseBase(c.llmBaseUrl.ifBlank { Models.OPENROUTER_BASE }) == null) { lStatus.text = "The service address must start with https://"; return }
        lStatus.text = "Fetching the live model list…"
        App.exec.execute {
            try {
                val p = org.tribhasa.app.core.ServiceFactory.provider(c.copy(llmModel = "x/x:free"))
                val all = p.listModels(CancelToken())
                val free = all.filter { it.free }.sortedBy { it.name.lowercase() }
                App.ui {
                    if (free.isEmpty()) { lStatus.text = "The service lists no free models right now (${all.size} models in all)."; return@ui }
                    lStatus.text = "${free.size} free models listed. The app has checked the licence only of those marked ✓; for any other, read the model's own page before relying on it."
                    Ui.choose(ctx, "Free models listed now", free.map { m ->
                        val chk = Models.candidate(m.id)
                        (if (chk != null) "✓ " else "") + m.id to "${m.name} · ${if (m.contextLength > 0) "${m.contextLength / 1000}K context" else "context unknown"} · " + (chk?.let { "licence ${it.licence}" } ?: "licence not checked by this app")
                    }, -1) { i -> lModel.setText(free[i].id); App.store.setLlmModel(free[i].id); fill(); lStatus.text = "Model set to ${free[i].id}." + if (Models.candidate(free[i].id) == null) "\nIts licence has not been checked by this app." else "" }
                }
            } catch (e: Throwable) {
                val u = App.describe(e)
                App.ui { lStatus.text = u.message }
            }
        }
    }

    private fun testAi() {
        val c = candidateCreds()
        if (c.llmKey.isEmpty()) { lStatus.text = "Tap Connect first (or enter a key under Advanced)."; return }
        if (!Models.validId(c.llmModel)) { lStatus.text = "Choose or type a model name first."; return }
        if (Models.normaliseBase(c.llmBaseUrl.ifBlank { Models.OPENROUTER_BASE }) == null) { lStatus.text = "The service address must start with https://"; return }
        test("llm", lStatus) { cancel ->
            val p = org.tribhasa.app.core.ServiceFactory.provider(c.copy(llmBaseUrl = c.llmBaseUrl.ifBlank { Models.OPENROUTER_BASE }))
            val sb = StringBuilder()
            try {
                val ks = p.keyStatus(cancel)
                if (ks.isNotBlank()) sb.append("Key accepted.\n").append(ks).append("\n\n")
            } catch (e: EngineException) {
                if (e.kind == FailKind.AUTH) throw e
                sb.append("(This service does not show key details.)\n\n")
            }
            val r = p.generate(LlmRequest("You answer with a single word.", "Reply with the single word: ready", maxTokens = 600, temperature = 0.0), cancel)
            val chk = Models.candidate(r.model) ?: Models.candidate(c.llmModel)
            sb.append("Connected. Model: ${r.model}\nIt answered: “${r.text.trim().take(80)}” in ${r.latencyMs / 1000.0}s\n")
            sb.append(if (chk != null) "Licence: ${chk.licence} (${chk.licenceSource})" else "Licence: not checked by this app — read the model's page before relying on it.")
            sb.append("\n\nThis test used 1 request of your allowance. A real answer from the model is shown above, not a canned message.")
            sb.toString()
        }
    }

    // ------------------------------------------------------------------ Cloudflare
    private fun buildCloudflare() {
        val card = section(
            "Cloudflare Workers AI — optional",
            "A second, independent host of IndicTrans2. It translates English into Sanskrit and Kannada only. It needs an account ID and a token that you must create and enter yourself. This feature has not been checked against Cloudflare's own current documentation; the free plan has a daily allowance and the app never switches to a paid plan.",
            advBox
        )
        field(card, "Account ID", cAcc)
        field(card, "API token", cTok)
        val row = hrow(ctx)
        row.addSide(Ui.button(ctx, "Save") { saveCloudflare() }, w = 0, weight = 1f)
        row.addSide(Ui.button(ctx, "Test connection", primary = false) { testCloudflare() }, left = 8, w = 0, weight = 1f)
        card.add(row, top = 12)
        card.add(cStatus, top = 8)
    }

    private fun saveCloudflare() {
        App.store.setCloudflare(cAcc.text.toString(), cTok.text.toString())
        Ui.toast(ctx, "Saved"); fill()
    }

    private fun testCloudflare() {
        val a = cAcc.text.toString().trim(); val t = cTok.text.toString().trim()
        if (a.isEmpty() || t.isEmpty()) { cStatus.text = "Enter the account ID and the token first."; return }
        test("cloudflare", cStatus) { cancel ->
            val e = CloudflareIndicEngine(a, t)
            val sb = StringBuilder("Connected to Cloudflare.\n")
            for (tgt in listOf(Lang.KN, Lang.SA)) {
                val o = e.translate(listOf("Good morning. I read a book."), Direction(Lang.EN, tgt), cancel, Trace())
                sb.append("English → ${tgt.english}: ").append(o.firstOrNull() ?: "(empty)").append('\n')
            }
            sb.toString().trimEnd()
        }
    }

    // ------------------------------------------------------------------ switches
    private fun buildOptions() {
        val card = section("Behaviour", "")
        card.add(switchRow("Use an AI model when IndicTrans2 cannot do a direction (labelled in the report)", "o_fallback", App.store.options().allowLlmFallback))
        card.add(switchRow("Polish Kannada into Granthika register after translation (needs the AI model; on this phone it is a second, slower pass)", "o_granthika", App.store.options().granthikaPolish), top = 8)
        card.add(switchRow("Indian English with British spelling", "o_british", App.store.options().britishSpelling), top = 8)
        card.add(switchRow("Apply my glossary automatically after translation (needs the AI model)", "o_glossfix", App.store.options().autoGlossaryFix), top = 8)
    }

    /** A switch that tells the caller when it is turned on or off by the user (not when it is set by the app). */
    private fun switchRowNow(text: String, id: String, on: Boolean, onChange: (Boolean) -> Unit): View {
        val s = Switch(ctx)
        s.text = text
        s.setTextColor(Pal.ink)
        s.textSize = 15f
        s.isChecked = on
        s.setPadding(0, ctx.dp(6), 0, ctx.dp(6))
        switches[id] = s
        s.setOnCheckedChangeListener { _, v -> if (!quietSwitches) onChange(v) }
        return s
    }

    private fun switchRow(text: String, key: String, on: Boolean): View {
        val s = Switch(ctx)
        s.text = text
        s.setTextColor(Pal.ink)
        s.textSize = 15f
        s.isChecked = on
        s.setPadding(0, ctx.dp(6), 0, ctx.dp(6))
        s.setOnCheckedChangeListener { _, v -> App.store.setOption(key, v) }
        return s
    }

    // ------------------------------------------------------------------ six-direction self-test
    private fun buildSelfTest() {
        val card = section(
            "Test all six directions",
            "Sends one short sentence through each direction (on this phone, or through the saved online services, whichever “Where the AI runs” says) and shows exactly what came back and which service produced it. On the phone this takes a few minutes the first time. Directions that nothing configured can do are reported as such."
        )
        card.add(Ui.button(ctx, "Run the six-direction test") { selfTest() })
        card.add(selfStatus, top = 10)
    }

    private fun selfTest() {
        if ("self" in running) return
        val c0 = App.store.credentials()
        if (App.offlineBlocksAi(c0)) { selfStatus.text = "The phone is offline."; return }
        App.localBlockReason(c0)?.let { selfStatus.text = it; return }
        running.add("self")
        selfStatus.text = "Testing six directions…"
        val s = App.services()
        val samples = mapOf(
            Lang.SA to "अहं पुस्तकं पठामि।",
            Lang.KN to "ನಾನು ಪುಸ್ತಕವನ್ನು ಓದುತ್ತೇನೆ.",
            Lang.EN to "I read the book.",
        )
        App.exec.execute {
            val sb = StringBuilder()
            for (d in Direction.ALL) {
                val line = try {
                    val job = s.translation.newJob(samples.getValue(d.src), d, App.store.options().copy(granthikaPolish = false), emptyList())
                    val r = s.translation.run(job, CancelToken()) {}
                    "✓ ${d.label}\n   ${r.output.trim()}\n   via ${r.engines}${if (r.usedIndicTrans2) "" else " — NOT IndicTrans2"}"
                } catch (e: Throwable) {
                    "✗ ${d.label}\n   " + App.describe(e).message.lines().first()
                }
                sb.append(line).append("\n\n")
                val snapshot = sb.toString().trimEnd() + "\n\n(still running…)"
                App.ui { selfStatus.text = snapshot }
            }
            val done = sb.toString().trimEnd()
            App.ui { running.remove("self"); selfStatus.text = done + "\n\nDone. Judge the quality yourself: this test checks that each direction works, not that the translation is correct." }
        }
    }

    // ------------------------------------------------------------------ about, report, reset
    private fun buildAbout() {
        val card = section("This build", "")
        card.add(Ui.text(ctx, "Version ${App.BUILD_LABEL}", 14f, Pal.ink))
        card.add(Ui.text(ctx, org.tribhasa.app.core.FreeTestingPolicy.description, 13f, Pal.inkSoft), top = 4, bottom = 10)
        card.add(Ui.button(ctx, "About Tribhāṣā", primary = false) { host.openAbout() })
        card.add(Ui.button(ctx, "Last error report", primary = false) { showCrash() }, top = 8)
        card.add(Ui.button(ctx, "Remove all saved keys", primary = false) {
            AlertDialog.Builder(ctx).setTitle("Remove all saved keys?")
                .setMessage("The OpenRouter access (and any Bhashini or Cloudflare keys) saved on this phone will be erased. A key made by the sign-in stays listed in your OpenRouter account until you delete it there. Your glossary and texts are not touched.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove") { _, _ -> App.store.clearKeys(); App.connect.lastWasSuccess = false; App.connect.lastOutcome = ""; fill(); Ui.toast(ctx, "Keys removed") }
                .show()
        }, top = 8)
    }

    private fun showCrash() {
        val r = App.store.pref("last_crash", "")
        if (r.isBlank()) Ui.message(ctx, "Last error report", "No error has been recorded on this phone.")
        else Ui.message(ctx, "Last error report", r, r)
    }

    // ------------------------------------------------------------------ state
    private fun fill() {
        val c = App.store.credentials()
        bUser.setText(c.bhashiniUserId); bKey.setText(c.bhashiniKey)
        // A key handed over by the sign-in is never shown: the user has no need to see or handle it.
        lKey.setText(if (c.llmKeyFromSignIn) "" else c.llmKey)
        lKey.hint = if (c.llmKeyFromSignIn) "Signed in: no key is shown or needed" else "OpenRouter API key (only if you do not use Connect)"
        lModel.setText(c.llmModel); lBase.setText(c.llmBaseUrl)
        cAcc.setText(c.cfAccountId); cTok.setText(c.cfToken)
        refreshThinking(); refreshBackup(); refreshSwitches()
        refreshSummary()
        renderConnect()
        renderLocal()
    }

    private fun refreshSummary() {
        val c = App.store.credentials()
        summary.text = buildString {
            append("Where the AI runs: ${if (c.aiSource == AiSource.LOCAL) "on this phone (default)" else "online (optional)"}\n")
            append(when (Local.uiState()) {
                Local.UiState.READY -> "✓ Model on this phone: ${LocalModels.active.shortName}, ready — works without internet\n"
                Local.UiState.DOWNLOADING -> "… Model on this phone: downloading\n"
                Local.UiState.PAUSED -> "✗ Model on this phone: unfinished download — tap Resume\n"
                Local.UiState.DAMAGED -> "✗ Model on this phone: file not confirmed — see “The model on this phone”\n"
                Local.UiState.NOT_ON_PHONE -> "✗ Model on this phone: not downloaded yet\n"
            })
            append("\nOnline services (used only if you choose Online)\n")
            append(if (c.hasBhashini) "✓ Bhashini (IndicTrans2): all six directions if the service offers them\n" else "✗ Bhashini: not set up\n")
            append(if (c.hasCloudflare) "✓ Cloudflare (IndicTrans2): English → Sanskrit / Kannada\n" else "✗ Cloudflare: not set up (optional)\n")
            append(if (c.hasLlm) "✓ AI model: ${c.llmModel}${if (ServiceFactory.backupModel(c) != null) " (back-up: ${ServiceFactory.backupModel(c)})" else ""} — refinement, analysis, commentary, fall-back translation"
                   else "✗ AI model: not connected — tap Connect below; Refine, Analyse and AI translation need it")
        }
        val chk = Models.candidate(c.llmModel)
        lInfo.text = buildString {
            append(if (Models.isFree(c.llmModel)) "Free model selected. " else "This is not a free model. ")
            append(if (c.allowPaid) "Paid models are allowed. " else "Paid models are blocked. ")
            append(if (chk != null) "Licence ${chk.licence} (checked ${Models.CHECKED_ON}). ${chk.dataNote}" else "This app has not checked this model's licence.")
            append("\nPrivacy: every text you submit is sent to OpenRouter and on to the company that hosts the model. OpenRouter's privacy policy (read ${Models.CHECKED_ON}) says it collects the inputs you send, including any personal data in them, states no fixed retention period, and says OpenRouter itself does not train on them; it also says some model hosts may. " +
                "Do not submit anything you could not share with those companies. The option above asks OpenRouter to avoid hosts that keep or train on prompts, which may leave no free host.")
        }
    }

    private companion object {
        const val Store_PAID = "paid"
        const val Store_DENY = "deny"
        const val SW_WIFI = "local_wifi"
        const val SW_GPU = "local_gpu"
    }
}
