package org.tribhasa.app.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import org.tribhasa.app.App
import org.tribhasa.app.core.Direction
import org.tribhasa.app.core.History
import org.tribhasa.app.core.HistoryEntry
import org.tribhasa.app.core.Lang
import org.tribhasa.app.core.Translit

class TranslateScreen(private val ctx: Context, private val host: Host) : Screen {
    override val title = "Translate"
    private val m = App.translate
    private val scroll = page(ctx)
    override val view: View = scroll.first
    private val col = scroll.second

    private val from = Picker(ctx, "From") { pickLang(true) }
    private val to = Picker(ctx, "To") { pickLang(false) }
    private val input = InputCard(ctx, "Text to translate", "", 7) { m.input = it }
    private val hint = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val translateBtn = Ui.button(ctx, "Translate") { start(false) }
    private val progress = ProgressArea(ctx) { m.cancel?.cancel() }
    private val error = ErrorArea(ctx, { start(true) }, { host.openSettings() })
    private val statusLine = Ui.text(ctx, "", 14f, Pal.inkSoft)
    private val out = OutputCard(ctx, "Translation")
    private val viewRow = hrow(ctx)
    private val viewChips = ArrayList<Pair<Translit.SanskritView, TextView>>()
    private val glossBox = Ui.card(ctx, Pal.accentSoft, Pal.accent)
    private val glossText = Ui.text(ctx, "", 14f, Pal.ink)
    private val glossBtn = Ui.button(ctx, "Apply my glossary (uses AI)", primary = false) { applyGlossary() }
    private val qcHolder = LinearLayout(ctx)

    init {
        // restore the last session
        m.src = Lang.fromName(App.store.pref("t_src", m.src.name)) ?: m.src
        m.tgt = Lang.fromName(App.store.pref("t_tgt", m.tgt.name)) ?: m.tgt
        if (m.src == m.tgt) m.tgt = Lang.values().first { it != m.src }
        if (m.input.isEmpty()) m.input = App.store.draft("translate")
        input.setText(m.input)

        val langRow = hrow(ctx)
        langRow.gravity = Gravity.BOTTOM
        langRow.addSide(from.view, w = 0, weight = 1f)
        val swap = Ui.chip(ctx, "⇄") { swapLangs() }
        swap.textSize = 20f
        langRow.addSide(swap, left = 8, right = 8)
        langRow.addSide(to.view, w = 0, weight = 1f)
        col.add(langRow, bottom = 14)

        col.add(input.view)
        hint.setPadding(ctx.dp(4), ctx.dp(6), 0, 0)
        col.add(hint, bottom = 12)
        col.add(translateBtn, bottom = 12)
        col.add(progress.view, bottom = 12)
        col.add(error.view, bottom = 12)
        statusLine.setPadding(ctx.dp(4), 0, 0, ctx.dp(8))
        col.add(statusLine)

        for (v in Translit.SanskritView.values()) {
            val c = Ui.chip(ctx, v.label) { m.view = v; render() }
            viewChips.add(v to c)
            viewRow.addSide(c, right = 6)
        }
        out.extra.add(viewRow)
        out.actions.action(Ui.chip(ctx, "Run again") { start(false) })
        col.add(out.view, bottom = 12)

        glossBox.add(glossText, bottom = 8)
        glossBox.add(glossBtn)
        col.add(glossBox, bottom = 12)
        col.add(qcHolder)

        m.listener = { render() }
        render()
    }

    override fun onShow() {
        m.listener = { render() }
        if (input.text() != m.input) input.setText(m.input)   // e.g. after "Open in Translate" from History
        render()
    }
    override fun saveDraft() { App.store.setDraft("translate", m.input) }

    private fun pickLang(isFrom: Boolean) {
        val all = Lang.values().toList()
        val choices = if (isFrom) all else all.filter { it != m.src }
        val cur = if (isFrom) m.src else m.tgt
        Ui.choose(ctx, if (isFrom) "Translate from" else "Translate into", langOptions(choices), choices.indexOf(cur)) { i ->
            val l = choices[i]
            if (isFrom) { m.src = l; if (m.tgt == l) m.tgt = all.first { it != l } } else m.tgt = l
            saveLangs(); render()
        }
    }

    private fun swapLangs() {
        val s = m.src; m.src = m.tgt; m.tgt = s
        // the previous translation becomes the new input, which is what people usually want when swapping
        if (m.output.isNotBlank() && !m.running) { m.input = m.output; input.setText(m.input); m.output = ""; m.qc = null; m.missing = emptyList() }
        saveLangs(); render()
    }

    private fun saveLangs() { App.store.setPref("t_src", m.src.name); App.store.setPref("t_tgt", m.tgt.name) }

    private fun start(resume: Boolean) {
        if (m.running) return
        val text = input.text()
        m.input = text
        if (text.isBlank()) { Ui.toast(ctx, "Please type or paste some text first."); return }
        val creds = App.store.credentials()
        if (App.offlineBlocksAi(creds)) {
            m.error = org.tribhasa.app.UiError("The phone is offline. Your text is kept; connect to the internet and press Retry, or switch “Where the AI runs” to “On this phone” in Settings.", true, false)
            render(); return
        }
        App.localBlockReason(creds)?.let { m.error = org.tribhasa.app.UiError(it, false, true); render(); return }
        val s = App.services()
        val d = Direction(m.src, m.tgt)
        val key = "${d.label}|$text"
        val job = if (resume && m.job != null && m.jobKey == key) m.job!! else {
            m.output = ""; m.qc = null; m.missing = emptyList()
            s.translation.newJob(text, d, App.store.options(), App.store.glossary()).also { m.job = it; m.jobKey = key }
        }
        App.launch(m, "Starting…", { cancel, progressFn -> s.translation.run(job, cancel, progressFn) }) { res ->
            m.output = res.output
            m.qc = res.qc
            m.missing = res.missingGlossary
            m.hasRun = true
            val madeWith = if (res.usedIndicTrans2 || res.engines.contains("not IndicTrans2")) res.engines else res.engines + " (not IndicTrans2)"
            App.record(HistoryEntry(History.newId(), System.currentTimeMillis(), HistoryEntry.Kind.TRANSLATION, d.label, text, res.output, d.src.name, d.tgt.name, madeWith, res.qc.warnings))
        }
    }

    private fun applyGlossary() {
        val job = m.job ?: return
        val missing = m.missing
        val qc = m.qc ?: return
        val current = m.output
        if (missing.isEmpty() || m.running) return
        val s = App.services()
        App.launch(m, "Applying your glossary…", { cancel, progressFn -> s.translation.glossaryFix(current, job, missing, qc, cancel, progressFn) }) { fixed ->
            m.output = fixed
            // Re-check which terms are now present
            val d = job.direction
            m.missing = org.tribhasa.app.core.Glossary.relevant(job.glossary, job.mtSource, d.src, d.tgt)
                .filter { !org.tribhasa.app.core.Glossary.termPresent(fixed, it, d.tgt) }
            if (m.missing.isEmpty()) qc.pass("Glossary: all matching preferred terms now appear in the translation.")
            else qc.warn("Glossary: ${m.missing.size} preferred term(s) still not found: ${m.missing.joinToString(", ") { it.term(d.tgt) }}.")
        }
    }

    private fun render() {
        from.set(m.src.display)
        to.set(m.tgt.display)
        hint.text = when (m.src) {
            Lang.SA -> "You may type Sanskrit in Devanagari, IAST or Kannada script; it is converted to Devanagari automatically."
            Lang.KN -> "Kannada in Kannada script."
            Lang.EN -> "English. Output in Indian English uses British spelling."
        }
        if (input.edit.hint?.toString() != hintFor()) input.edit.hint = hintFor()
        translateBtn.show(!m.running)
        progress.render(m.running, m.status)
        error.render(m.error)
        statusLine.text = if (!m.running && m.error == null) m.status else ""
        statusLine.show(statusLine.text.isNotEmpty())

        val hasOut = m.output.isNotBlank()
        out.view.show(hasOut)
        if (hasOut) {
            val shownView = if (m.tgt == Lang.SA) m.view else Translit.SanskritView.DEVANAGARI
            val text = if (m.tgt == Lang.SA) Translit.render(m.output, shownView) else m.output
            // Copy gives exactly what is shown; the attribution line is never added to scholarly output.
            out.set(text)
            viewRow.show(m.tgt == Lang.SA)
            for ((v, c) in viewChips) Ui.setChipSelected(c, ctx, v == m.view)
        }

        val showGloss = hasOut && m.missing.isNotEmpty() && !m.running
        glossBox.show(showGloss)
        if (showGloss) {
            glossText.text = "Your glossary prefers these terms, which are not in the translation: " + m.missing.joinToString("; ") { it.term(m.tgt) } + "."
            glossBtn.show(App.hasAi(App.store.credentials()))
        }

        qcHolder.removeAllViews()
        val qc = m.qc
        if (hasOut && qc != null && !m.running) qcHolder.addView(ResultViews.qcCard(ctx, qc, expanded = true), Ui.lp())
    }

    private fun hintFor() = when (m.src) {
        Lang.SA -> "संस्कृतपाठम् अत्र लिखत / paste Sanskrit here"
        Lang.KN -> "ಕನ್ನಡ ಪಠ್ಯವನ್ನು ಇಲ್ಲಿ ಬರೆಯಿರಿ"
        Lang.EN -> "Type or paste English text here"
    }
}
