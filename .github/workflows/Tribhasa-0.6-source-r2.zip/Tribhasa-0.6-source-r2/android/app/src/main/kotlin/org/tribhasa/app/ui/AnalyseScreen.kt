package org.tribhasa.app.ui

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import org.tribhasa.app.App
import org.tribhasa.app.UiError
import org.tribhasa.app.core.History
import org.tribhasa.app.core.HistoryEntry
import org.tribhasa.app.core.Lang
import org.tribhasa.app.core.OfflineTools
import org.tribhasa.app.core.Prompts
import org.tribhasa.app.core.Translit
import org.tribhasa.app.core.Scripts

class AnalyseScreen(private val ctx: Context, private val host: Host) : Screen {
    override val title = "Analyse (Sanskrit)"
    private val m = App.analyse
    private val scroll = page(ctx)
    override val view: View = scroll.first
    private val col = scroll.second

    private val modePick = Picker(ctx, "Kind of analysis") { pickMode() }
    private val partPick = Picker(ctx, "Commentary to produce") { pickPart() }
    private val outPick = Picker(ctx, "Explain in") { pickOut() }
    private val blurb = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val input = InputCard(ctx, "Sanskrit text", "संस्कृतपाठम् अत्र लिखत / paste Sanskrit (Devanagari, IAST or Kannada script)", 6) { m.input = it }
    private val convertRow = hrow(ctx)
    private val runBtn = Ui.button(ctx, "Analyse") { start() }
    private val progress = ProgressArea(ctx) { m.cancel?.cancel() }
    private val error = ErrorArea(ctx, { start() }, { host.openSettings() })
    private val status = Ui.text(ctx, "", 14f, Pal.inkSoft)
    private val results = LinearLayout(ctx)
    private val localNote = Ui.text(ctx,
        "On this phone the model is small. Śloka analysis, prose analysis and commentary are experimental here: they can take several minutes, may be incomplete or wrong, and every result is marked low-confidence. The offline metre check below needs no AI.",
        13f, Pal.warn)

    init {
        m.mode = AnalyseModelMode.fromName(App.store.pref("a_mode", m.mode.name)) ?: m.mode
        m.out = Lang.fromName(App.store.pref("a_out", m.out.name)) ?: m.out
        if (m.out == Lang.SA) m.out = Lang.EN
        if (m.input.isEmpty()) m.input = App.store.draft("analyse")
        input.setText(m.input)
        results.orientation = LinearLayout.VERTICAL

        col.add(modePick.view, bottom = 4)
        blurb.setPadding(ctx.dp(4), 0, 0, ctx.dp(10))
        col.add(blurb)
        localNote.setPadding(ctx.dp(4), 0, 0, ctx.dp(10))
        col.add(localNote)
        col.add(partPick.view, bottom = 10)
        col.add(outPick.view, bottom = 10)
        col.add(input.view, bottom = 8)

        convertRow.addSide(Ui.chip(ctx, "→ Devanagari") { convert(Translit.SanskritView.DEVANAGARI) }, right = 6)
        convertRow.addSide(Ui.chip(ctx, "→ IAST") { convert(Translit.SanskritView.IAST) }, right = 6)
        convertRow.addSide(Ui.chip(ctx, "→ Kannada script") { convert(Translit.SanskritView.KANNADA) })
        col.add(convertRow, bottom = 12)
        col.add(Ui.button(ctx, "Check metre offline (no key, no internet)", primary = false) { offlineMetre() }, bottom = 12)
        col.add(runBtn, bottom = 12)
        col.add(progress.view, bottom = 12)
        col.add(error.view, bottom = 12)
        status.setPadding(ctx.dp(4), 0, 0, ctx.dp(8))
        col.add(status)
        col.add(results)

        m.listener = { render() }
        render()
    }

    override fun onShow() { m.listener = { render() }; render() }
    override fun saveDraft() { App.store.setDraft("analyse", m.input) }

    private fun convert(to: Translit.SanskritView) {
        val t = input.text()
        if (t.isBlank()) { Ui.toast(ctx, "Nothing to convert"); return }
        val dev = Translit.normaliseSanskritInput(Scripts.nfc(t)).devanagari
        val r = Translit.render(dev, to)
        input.setText(r); m.input = r
    }

    private fun pickMode() {
        val all = org.tribhasa.app.AnalyseModel.Mode.values().toList()
        Ui.choose(ctx, "Kind of analysis", all.map { it.label to it.blurb }, all.indexOf(m.mode)) { i ->
            m.mode = all[i]; App.store.setPref("a_mode", m.mode.name); clearResults(); render()
        }
    }

    private fun pickPart() {
        val all = Prompts.CommentaryPart.values().toList()
        Ui.choose(ctx, "Commentary to produce", all.map { it.label to "" }, all.indexOf(m.part)) { i -> m.part = all[i]; clearResults(); render() }
    }

    private fun pickOut() {
        val all = listOf(Lang.EN, Lang.KN)
        Ui.choose(ctx, "Explain in", langOptions(all), all.indexOf(m.out).coerceAtLeast(0)) { i ->
            m.out = all[i]; App.store.setPref("a_out", m.out.name); clearResults(); render()
        }
    }

    private fun clearResults() { m.doc = null; m.qc = null; m.error = null }

    /** Verse as read, IAST and metrical scan, computed on the phone with no network and no AI. */
    private fun offlineMetre() {
        if (m.running) return
        val text = input.text()
        m.input = text
        if (text.isBlank()) { Ui.toast(ctx, "Please type or paste a Sanskrit verse first."); return }
        try {
            val doc = OfflineTools.metreReport(text)
            m.doc = doc; m.qc = doc.qc; m.error = null; m.status = ""
            App.record(HistoryEntry(History.newId(), System.currentTimeMillis(), HistoryEntry.Kind.ANALYSIS, "Metre check (offline)", text, doc.toPlain(), Lang.SA.name, "", "On this phone, no AI", doc.qc.warnings))
        } catch (e: Throwable) {
            m.doc = null; m.qc = null; m.error = App.describe(e)
        }
        render()
    }

    private fun start() {
        if (m.running) return
        val text = input.text()
        m.input = text
        if (text.isBlank()) { Ui.toast(ctx, "Please type or paste a Sanskrit text first."); return }
        val c = App.store.credentials()
        if (App.offlineBlocksAi(c)) { m.error = UiError("The phone is offline. Your text is kept; connect to the internet and press Retry, or switch “Where the AI runs” to “On this phone” in Settings.", true, false); render(); return }
        App.aiBlockReason(c)?.let { m.error = UiError(it, false, true); render(); return }
        val s = App.services()
        val mode = m.mode; val out = m.out; val part = m.part
        clearResults()
        App.launch(m, "Starting…", { cancel, p ->
            when (mode) {
                org.tribhasa.app.AnalyseModel.Mode.SLOKA -> s.scholar.analyseSloka(text, out, cancel, p)
                org.tribhasa.app.AnalyseModel.Mode.PROSE -> s.scholar.analyseProse(text, out, cancel, p)
                org.tribhasa.app.AnalyseModel.Mode.COMMENTARY -> s.scholar.commentary(text, part, cancel, p)
            }
        }) { r ->
            m.doc = r.doc; m.qc = r.qc
            val d = r.doc
            if (d != null) App.record(HistoryEntry(History.newId(), System.currentTimeMillis(), HistoryEntry.Kind.ANALYSIS, mode.label, text, d.toPlain(), Lang.SA.name, "", r.trace.used.keys.joinToString("; "), r.qc.warnings))
        }
    }

    private fun render() {
        modePick.set(m.mode.label)
        blurb.text = m.mode.blurb
        localNote.show(App.store.credentials().aiSource == org.tribhasa.app.core.AiSource.LOCAL)
        partPick.view.show(m.mode == org.tribhasa.app.AnalyseModel.Mode.COMMENTARY)
        partPick.set(m.part.label)
        outPick.view.show(m.mode != org.tribhasa.app.AnalyseModel.Mode.COMMENTARY)
        outPick.set(m.out.display)
        runBtn.text = when (m.mode) {
            org.tribhasa.app.AnalyseModel.Mode.SLOKA -> "Analyse the śloka"
            org.tribhasa.app.AnalyseModel.Mode.PROSE -> "Analyse the prose"
            org.tribhasa.app.AnalyseModel.Mode.COMMENTARY -> "Write the commentary"
        }
        runBtn.show(!m.running)
        progress.render(m.running, m.status)
        error.render(m.error)
        status.text = if (!m.running && m.error == null) m.status else ""
        status.show(status.text.isNotEmpty())

        results.removeAllViews()
        if (m.running) return
        val doc = m.doc
        if (doc != null) {
            val card = Ui.card(ctx)
            val head = LabelRow(ctx, "Result")
            head.action(Ui.chip(ctx, "Copy all") { Ui.copy(ctx, doc.toPlain()) })
            card.add(head.view, bottom = 4)
            card.add(ResultViews.documentView(ctx, doc))
            results.add(card, bottom = 12)
            m.qc?.let { results.add(ResultViews.qcCard(ctx, it, expanded = true)) }
        }
    }
}

/** Small helper so the enum name can be restored from saved preferences. */
object AnalyseModelMode {
    fun fromName(n: String?): org.tribhasa.app.AnalyseModel.Mode? = org.tribhasa.app.AnalyseModel.Mode.values().firstOrNull { it.name == n }
}
