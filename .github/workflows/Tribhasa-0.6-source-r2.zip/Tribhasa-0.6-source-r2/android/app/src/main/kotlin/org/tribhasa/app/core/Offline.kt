package org.tribhasa.app.core

/**
 * Tools that work with no network, no key and no AI model: they run entirely on the phone
 * by fixed rules (the same rules the app uses to check the AI's metre claims).
 */
object OfflineTools {

    /** Splits at each double danda, keeping a trailing verse number ("॥ 1.1 ॥") and the exact original characters. */
    fun splitVerses(text: String): List<String> {
        val t = text.replace("\r\n", "\n").trim()
        if (!t.contains('॥')) return listOf(t).filter { it.isNotBlank() }
        val number = Regex("^\\s*[०-९0-9೦-೯][०-९0-9೦-೯.\\-–\\s]*॥")
        val verses = ArrayList<String>()
        var pos = 0
        while (pos < t.length) {
            val i = t.indexOf('॥', pos)
            if (i < 0) break
            var end = i + 1
            val m = number.find(t.substring(end))
            if (m != null) end += m.value.length
            val v = t.substring(pos, end).trim()
            if (v.any { it.isLetter() }) verses.add(v)
            pos = end
        }
        val rest = t.substring(pos).trim()
        if (rest.any { it.isLetter() }) verses.add(rest)
        return verses
    }

    /** "˘ – ˘ …" for a laghu/guru pattern written as L and G. */
    fun lgString(pattern: String): String = pattern.map { if (it == 'G') "–" else "˘" }.joinToString(" ")

    /** Verse as read, IAST and the metrical scan, computed locally. Accepts Devanagari, IAST or Kannada-script Sanskrit. */
    fun metreReport(text: String): Document {
        val conv = Translit.normaliseSanskritInput(Scripts.nfc(text))
        val verses = splitVerses(conv.devanagari)
        if (verses.isEmpty()) throw EngineException(FailKind.BAD_REQUEST, "Please enter a Sanskrit verse.")
        val qc = QcReport()
        val sections = ArrayList<Section>()
        conv.note?.let { qc.info(it) }
        qc.pass("Computed on this phone by fixed rules. No network, no AI model and no key were used.")
        for ((i, v) in verses.withIndex()) {
            val prefix = if (verses.size > 1) "Verse ${i + 1} — " else ""
            val scan = Prosody.scan(v)
            sections.add(Section("${prefix}Verse as read", listOf(Block.Para(v, sanskrit = true))))
            sections.add(Section("${prefix}IAST (computed by the app)", listOf(Block.Para(Translit.devanagariToIast(v)))))
            if (scan.padaCount == 0) {
                qc.warn("${prefix}No syllables could be read from this text.")
                continue
            }
            val lines = scan.patterns.mapIndexed { k, p -> "Pāda ${k + 1} — ${scan.syllableCounts[k]} syllables" to lgString(p) } +
                listOf("Result" to scan.detail)
            sections.add(Section("${prefix}Metre", listOf(Block.Entry(head = scan.name ?: "No standard metre identified", lines = lines, uncertain = !scan.exact))))
            when {
                scan.name != null && scan.exact -> qc.pass("${prefix}Every pāda fits ${scan.name} (the last syllable of a pāda is left free).")
                scan.name != null -> qc.warn("${prefix}The pādas look like ${scan.name} but not every pāda fits the usual pattern; check the text and the scan.")
                else -> qc.warn("${prefix}No standard metre was identified; the verse may be irregular, in a mātrā-metre, or split differently.")
            }
        }
        qc.info("Method: a syllable is guru if it has a long vowel, anusvāra or visarga, or is followed by a conjunct consonant; otherwise laghu. Optional poetic variants and mātrā-metres other than āryā are not recognised.")
        qc.info("Not checked: the app reads the text exactly as typed and does not check its spelling, completeness or meaning.")
        return Document(sections, qc)
    }
}
