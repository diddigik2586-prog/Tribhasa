package org.tribhasa.app.local

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.tribhasa.app.R
import org.tribhasa.app.core.DownloadPhase
import org.tribhasa.app.core.DownloadProgress
import org.tribhasa.app.core.LocalModels

/**
 * Keeps the app alive while the model downloads and shows a notification with a Pause button.
 *
 * The download itself does not run in this service: it runs in [Local] (a thread of the app), so it works even if this
 * service cannot be started. The service only asks Android to treat the app as busy, which stops it being closed
 * after the user leaves the app. It stops itself as soon as the download ends or is paused.
 *
 * Declared in the manifest as a foreground service of type dataSync (needed from Android 14).
 * NOT RUN YET: this file can only be exercised on a phone.
 */
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE) {
            try { Local.cancelDownload() } catch (_: Throwable) {}   // never let a tap on the notification close the app
            return START_NOT_STICKY
        }
        try {
            val n = DownloadKeepAlive.build(this, "Downloading the AI model…", 0, 0)
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIFICATION_ID, n)
            // Android requires startForeground() soon after startForegroundService(), which is done above. If the download has
            // already ended by now (for example it failed at once), there is nothing to keep alive, so stop again.
            if (!Local.download.running) stopSelf()
        } catch (e: Throwable) {
            // Android refused (for example, the app is not allowed to start a foreground service right now). The download goes on in the app.
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        const val NOTIFICATION_ID = 4711
        const val CHANNEL_ID = "model_download"
        const val ACTION_PAUSE = "org.tribhasa.app.PAUSE_DOWNLOAD"
    }
}

/** What [Local] calls while a download runs. Every call is safe to fail: the download does not depend on any of it. */
object DownloadKeepAlive {
    private const val STOP_DELAY_MS = 1500L
    private var lastNotifyMs = 0L

    fun start(ctx: Context) {
        try { ctx.startForegroundService(Intent(ctx, DownloadService::class.java)) } catch (_: Throwable) {}
    }

    /**
     * Stops the keep-alive service. This is done a moment later, not at once: a service started with startForegroundService()
     * must call startForeground() first, and if a download fails within milliseconds (wrong address, no space, Wi-Fi-only) an
     * immediate stop could come before that, which makes Android close the app. If another download has started during the
     * wait, the service is left running.
     */
    fun stop(ctx: Context) {
        try {
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    if (Local.download.running) return@postDelayed
                    ctx.stopService(Intent(ctx, DownloadService::class.java))
                    (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(DownloadService.NOTIFICATION_ID)
                } catch (_: Throwable) {}
            }, STOP_DELAY_MS)
        } catch (_: Throwable) {}
    }

    fun update(ctx: Context, p: DownloadProgress) {
        val now = System.currentTimeMillis()
        if (now - lastNotifyMs < 1000 && p.phase == DownloadPhase.DOWNLOADING) return
        lastNotifyMs = now
        try {
            val text = when (p.phase) {
                DownloadPhase.VERIFYING -> "Checking the file…"
                DownloadPhase.DONE -> "Done"
                else -> "Downloading the AI model — ${LocalModels.mb(p.doneBytes)} of ${LocalModels.mb(p.totalBytes)}"
            }
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(DownloadService.NOTIFICATION_ID, build(ctx, text, p.doneBytes, p.totalBytes))
        } catch (_: Throwable) {}
    }

    internal fun build(ctx: Context, text: String, done: Long, total: Long): Notification {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(DownloadService.CHANNEL_ID, "Model download", NotificationManager.IMPORTANCE_LOW))
        val pause = PendingIntent.getService(ctx, 0, Intent(ctx, DownloadService::class.java).setAction(DownloadService.ACTION_PAUSE), PendingIntent.FLAG_IMMUTABLE)
        val open = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.let { PendingIntent.getActivity(ctx, 1, it, PendingIntent.FLAG_IMMUTABLE) }
        val b = Notification.Builder(ctx, DownloadService.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("Tribhāṣā")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, "Pause", pause).build())
        if (open != null) b.setContentIntent(open)
        if (total > 0) b.setProgress(1000, (done * 1000 / total).toInt().coerceIn(0, 1000), false) else b.setProgress(0, 0, true)
        return b.build()
    }
}
