package org.tribhasa.app.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/** Why a provider call failed. Drives retry / failover decisions and the wording shown to the user. */
enum class FailKind(val retryable: Boolean) {
    NETWORK(true),       // no connection, DNS, reset
    TIMEOUT(true),
    SERVER(true),        // 5xx
    RATE_LIMIT(true),    // 429 / per-minute limits
    QUOTA(false),        // daily quota used up
    AUTH(false),         // wrong / missing key, no permission
    BAD_REQUEST(false),
    UNSUPPORTED(false),  // direction / language not offered by this provider
    BAD_RESPONSE(true),  // 2xx but unusable body (often transient)
    BLOCKED(false),      // provider refused to answer (safety filter)
    CANCELLED(false),
    LOCAL(false),        // the model that runs on this phone failed (could not load, ran out of memory, stopped with an error)
}

class EngineException(
    val kind: FailKind,
    message: String,
    val httpCode: Int = 0,
    val retryAfterMs: Long = 0,
    val detail: String? = null,
) : Exception(message)

class CancelToken {
    @Volatile var cancelled = false
        private set
    @Volatile private var conn: HttpURLConnection? = null
    private val hooks = ArrayList<Runnable>()

    fun cancel() {
        val toRun: List<Runnable>
        // Hooks run once, on the first cancel; cancelling again only closes the connection again.
        synchronized(hooks) { toRun = if (cancelled) emptyList() else hooks.toList(); cancelled = true; hooks.clear() }
        try { conn?.disconnect() } catch (_: Exception) {}
        for (h in toRun) try { h.run() } catch (_: Throwable) {}
    }

    /**
     * Runs [hook] when this token is cancelled (at once if it already was). Used to interrupt work that is not an HTTP
     * request, such as the model running on this phone. The returned handle removes the hook again.
     */
    fun onCancel(hook: Runnable): AutoCloseable {
        val runNow: Boolean
        synchronized(hooks) { runNow = cancelled; if (!runNow) hooks.add(hook) }
        if (runNow) try { hook.run() } catch (_: Throwable) {}
        return AutoCloseable { synchronized(hooks) { hooks.remove(hook) } }
    }
    /** Remembers the connection so cancel() can close it. A token that was already cancelled closes it at once. */
    internal fun attach(c: HttpURLConnection?) {
        conn = c
        if (c != null && cancelled) try { c.disconnect() } catch (_: Exception) {}
    }
    fun check() { if (cancelled) throw EngineException(FailKind.CANCELLED, "Cancelled.") }
}

data class HttpResponse(val code: Int, val body: String, val retryAfterMs: Long)

object Http {
    const val CONNECT_TIMEOUT_MS = 15_000
    const val READ_TIMEOUT_MS = 90_000
    private const val MAX_BYTES = 8 * 1024 * 1024

    fun request(
        method: String,
        url: String,
        headers: Map<String, String>,
        body: String?,
        cancel: CancelToken? = null,
        readTimeoutMs: Int = READ_TIMEOUT_MS,
    ): HttpResponse {
        cancel?.check()
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            cancel?.attach(conn)
            conn.requestMethod = method
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = readTimeoutMs
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Accept-Charset", "UTF-8")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(body.toByteArray(Charsets.UTF_8).size)
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            // Connect explicitly and look at the token straight afterwards: disconnect() does nothing while a connection
            // is still being made, so a Cancel pressed during that moment would otherwise be missed until the server answered.
            conn.connect()
            cancel?.check()
            if (body != null) conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream: InputStream? = if (code in 200..299) conn.inputStream else (conn.errorStream ?: null)
            val text = stream?.use { readAll(it) } ?: ""
            val ra = parseRetryAfter(conn.getHeaderField("Retry-After"))
            return HttpResponse(code, text, ra)
        } catch (e: EngineException) {
            throw e
        } catch (e: SocketTimeoutException) {
            if (cancel?.cancelled == true) throw EngineException(FailKind.CANCELLED, "Cancelled.")
            throw EngineException(FailKind.TIMEOUT, "The service took too long to answer.", detail = e.toString())
        } catch (e: UnknownHostException) {
            throw EngineException(FailKind.NETWORK, "Cannot reach the service. Check your internet connection.", detail = e.toString())
        } catch (e: SSLException) {
            throw EngineException(FailKind.NETWORK, "A secure connection could not be made. Check your network.", detail = e.toString())
        } catch (e: IOException) {
            if (cancel?.cancelled == true) throw EngineException(FailKind.CANCELLED, "Cancelled.")
            throw EngineException(FailKind.NETWORK, "The connection was interrupted.", detail = e.toString())
        } finally {
            cancel?.attach(null)
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun readAll(s: InputStream): String {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val r = s.read(buf)
            if (r < 0) break
            total += r
            if (total > MAX_BYTES) throw EngineException(FailKind.BAD_RESPONSE, "The service sent an unexpectedly large reply.")
            bos.write(buf, 0, r)
        }
        return String(bos.toByteArray(), Charsets.UTF_8)
    }

    private fun parseRetryAfter(v: String?): Long {
        if (v == null) return 0
        return v.trim().toLongOrNull()?.times(1000)?.coerceIn(0, 120_000) ?: 0
    }

    /** Maps an HTTP error to an [EngineException] with a plain-language message. */
    fun failure(resp: HttpResponse, provider: String): EngineException {
        val msg = JsonUtil.errorMessage(resp.body)
        val code = resp.code
        val tail = if (msg.isNotBlank()) " ($msg)" else ""
        return when {
            code == 401 || code == 403 -> EngineException(FailKind.AUTH, "$provider rejected the key or permission$tail", code, detail = resp.body.take(400))
            code == 429 -> {
                val low = msg.lowercase()
                val daily = low.contains("quota") || low.contains("daily") || low.contains("exhaust") || low.contains("neurons") || low.contains("per day")
                if (daily && resp.retryAfterMs == 0L)
                    EngineException(FailKind.QUOTA, "$provider's free allowance appears to be used up for now$tail", code, detail = resp.body.take(400))
                else EngineException(FailKind.RATE_LIMIT, "$provider is limiting requests right now$tail", code, resp.retryAfterMs, resp.body.take(400))
            }
            code == 408 -> EngineException(FailKind.TIMEOUT, "$provider timed out$tail", code)
            code in 500..599 -> EngineException(FailKind.SERVER, "$provider is temporarily unavailable (error $code)$tail", code, resp.retryAfterMs, resp.body.take(400))
            code in 400..499 -> EngineException(FailKind.BAD_REQUEST, "$provider could not process the request (error $code)$tail", code, detail = resp.body.take(400))
            else -> EngineException(FailKind.BAD_RESPONSE, "$provider sent an unexpected reply (code $code)", code, detail = resp.body.take(400))
        }
    }
}

object JsonUtil {
    fun parseObject(text: String): JSONObject? = try { JSONObject(text.trim()) } catch (_: Exception) { null }
    fun parseArray(text: String): JSONArray? = try { JSONArray(text.trim()) } catch (_: Exception) { null }

    /** Safe string getter (Android's optString returns the text "null" for JSON null). */
    fun str(o: JSONObject?, key: String): String {
        if (o == null || !o.has(key) || o.isNull(key)) return ""
        val v = o.opt(key)
        return when (v) {
            is String -> v
            is JSONArray -> (0 until v.length()).joinToString("; ") { v.opt(it)?.toString() ?: "" }
            else -> v.toString()
        }
    }

    fun arr(o: JSONObject?, key: String): JSONArray? =
        if (o == null || !o.has(key) || o.isNull(key)) null else o.optJSONArray(key)

    fun obj(o: JSONObject?, key: String): JSONObject? =
        if (o == null || !o.has(key) || o.isNull(key)) null else o.optJSONObject(key)

    fun strList(o: JSONObject?, key: String): List<String> {
        val a = arr(o, key) ?: return emptyList()
        return (0 until a.length()).mapNotNull { i -> if (a.isNull(i)) null else a.opt(i)?.toString() }
    }

    fun objList(o: JSONObject?, key: String): List<JSONObject> {
        val a = arr(o, key) ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    }

    /** Extracts a human-readable message from the usual provider error shapes. */
    fun errorMessage(body: String): String {
        val o = parseObject(body) ?: return body.trim().take(200)
        val err = o.opt("error")
        if (err is JSONObject) {
            val m = str(err, "message")
            if (m.isNotBlank()) return m.take(300)
        }
        if (err is String && err.isNotBlank()) return err.take(300)
        val errors = arr(o, "errors")
        if (errors != null && errors.length() > 0) {
            val first = errors.opt(0)
            if (first is JSONObject) {
                val m = str(first, "message"); if (m.isNotBlank()) return m.take(300)
            } else if (first != null) return first.toString().take(300)
        }
        val m = str(o, "message"); if (m.isNotBlank()) return m.take(300)
        val d = str(o, "detail"); if (d.isNotBlank()) return d.take(300)
        return ""
    }

    /** Pulls the first JSON object out of model text that may be wrapped in ``` fences or have prose around it. */
    fun extractObject(text: String): JSONObject? {
        var t = text.trim()
        if (t.startsWith("```")) {
            t = t.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            if (t.endsWith("```")) t = t.removeSuffix("```").trim()
        }
        parseObject(t)?.let { return it }
        val s = t.indexOf('{'); val e = t.lastIndexOf('}')
        if (s >= 0 && e > s) parseObject(t.substring(s, e + 1))?.let { return it }
        return null
    }
}

/** Retry helper with exponential back-off for temporary failures. */
class RetryPolicy(
    val maxAttempts: Int = 3,
    val baseDelayMs: Long = 1_000,
    val sleeper: (Long) -> Unit = { Thread.sleep(it) },
) {
    class Outcome<T>(val value: T, val attempts: Int)

    /** Runs [block]; retries only temporary failures. Reports each retry through [onRetry]. */
    fun <T> run(cancel: CancelToken?, onRetry: (attempt: Int, e: EngineException, waitMs: Long) -> Unit = { _, _, _ -> }, block: () -> T): Outcome<T> {
        var attempt = 0
        while (true) {
            attempt++
            cancel?.check()
            try {
                return Outcome(block(), attempt)
            } catch (e: EngineException) {
                if (!e.kind.retryable || attempt >= maxAttempts) throw AttemptsExhausted(e, attempt)
                val backoff = baseDelayMs shl (attempt - 1)
                val wait = maxOf(backoff, e.retryAfterMs).coerceAtMost(30_000)
                onRetry(attempt, e, wait)
                var left = wait
                while (left > 0) {
                    cancel?.check()
                    val step = minOf(left, 250L)
                    sleeper(step); left -= step
                }
            }
        }
    }
}

/** Carries the final failure plus how many attempts were made. */
class AttemptsExhausted(val last: EngineException, val attempts: Int) : Exception(last.message) {
    val kind: FailKind get() = last.kind
}
