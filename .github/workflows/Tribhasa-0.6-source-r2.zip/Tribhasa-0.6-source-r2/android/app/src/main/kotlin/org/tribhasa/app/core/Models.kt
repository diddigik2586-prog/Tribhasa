package org.tribhasa.app.core

/**
 * Facts about the open-weight models this app knows about, and the rules that keep the app on free models.
 *
 * Nothing here is a quality ranking. The licence and price facts below were read from the model cards and
 * OpenRouter pages on [CHECKED_ON]; hosts, prices and free variants change, so the app re-reads the live
 * list from the service whenever the user asks.
 */
object Models {
    const val OPENROUTER_BASE = "https://openrouter.ai/api/v1"

    /**
     * Provisional starting model: its weights are Apache-2.0, a free variant exists, and its context is long.
     * It was NOT chosen because it translates Sanskrit or Kannada best; no such comparison has been run yet.
     * The scholar is meant to compare models in the app (Settings → Compare models) and pick one.
     */
    const val DEFAULT_MODEL = "qwen/qwen3.8-27b:free"

    const val CHECKED_ON = "19 October 2026"

    /** Free variants on OpenRouter carry the suffix ":free". This is the only rule used for "free". */
    fun isFree(id: String) = id.trim().endsWith(":free")

    private val ID_OK = Regex("^[A-Za-z0-9][A-Za-z0-9._~/:+-]{1,119}$")
    fun validId(id: String) = ID_OK.matches(id.trim())

    /** Accepts only https addresses (the app does not allow plain http). Returns null if unusable. */
    fun normaliseBase(url: String): String? {
        val u = url.trim().trimEnd('/')
        if (!u.startsWith("https://") || u.length < 12 || u.any { it.isWhitespace() }) return null
        return u
    }

    /** How much thinking a model is asked to do before it answers (OpenRouter `reasoning.effort`). */
    enum class Think(val label: String, val effort: String?) {
        DEFAULT("Model default", null),
        OFF("Off (fastest)", "none"),
        LOW("Low", "low"),
        MEDIUM("Medium", "medium"),
        HIGH("High", "high");

        companion object {
            fun fromName(n: String?): Think = values().firstOrNull { it.name == n } ?: LOW
        }
    }

    /** A model whose licence and terms were read from its own page. */
    data class Candidate(
        val id: String,
        val name: String,
        val licence: String,
        val licenceSource: String,
        val contextTokens: Int,
        val price: String,
        val dataNote: String,
    ) {
        val free get() = isFree(id)
    }

    /**
     * Candidates whose licence was checked. Apache-2.0 and MIT both allow commercial use and redistribution;
     * this app only calls the models through an API and does not redistribute weights, so the licences' notice
     * conditions are not triggered by the app itself.
     */
    val CHECKED: List<Candidate> = listOf(
        Candidate(
            id = "qwen/qwen3.8-27b:free",
            name = "Qwen3.8 27B (free)",
            licence = "Apache-2.0",
            licenceSource = "Hugging Face model card Qwen/Qwen3.8-27B, field “License: apache-2.0”",
            contextTokens = 262_144,
            price = "Free on OpenRouter (limits below)",
            dataNote = "A third-party survey of 5 Oct 2026 listed the free host as zero-retention. Hosts change: check OpenRouter's page.",
        ),
        Candidate(
            id = "google/gemma-4-31b-it:free",
            name = "Gemma 4 31B (free)",
            licence = "Apache-2.0",
            licenceSource = "Hugging Face model card google/gemma-4-31B-it, field “License: apache-2.0”",
            contextTokens = 262_144,
            price = "Free on OpenRouter (limits below)",
            dataNote = "The free host is Google AI Studio; the same survey listed it as keeping prompts for 55 days. The model is open-weight, but this host is a Google service.",
        ),
        Candidate(
            id = "deepseek/deepseek-v4.1-flash-1017",
            name = "DeepSeek V4.1 Flash (paid)",
            licence = "MIT",
            licenceSource = "Hugging Face model card deepseek-ai/DeepSeek-V4.1-Flash: “licensed under the MIT License”",
            contextTokens = 1_048_576,
            price = "Paid. OpenRouter listed from about $0.06 in / $0.60 out per million tokens (varies by host).",
            dataNote = "Paid hosts have their own data policies; set “Avoid hosts that keep or train on my text” if that matters.",
        ),
    )

    fun candidate(id: String): Candidate? = CHECKED.firstOrNull { it.id == id.trim() }

    /** Free-tier rules of OpenRouter as published on 19 Oct 2026. They can change. */
    const val FREE_LIMITS =
        "OpenRouter free models: 20 requests per minute; 50 requests per day until the account has bought at least 10 credits, then 1,000 per day. " +
            "Failed requests can still count against the day's allowance."

    /** One row of the service's public model list. */
    data class Listed(val id: String, val name: String, val contextLength: Int, val promptPrice: String, val completionPrice: String) {
        val free get() = isFree(id)
    }
}
