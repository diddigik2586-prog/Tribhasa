package org.tribhasa.app.ui

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import org.tribhasa.app.App
import org.tribhasa.app.core.Glossary
import org.tribhasa.app.core.GlossaryEntry
import org.tribhasa.app.core.Scripts

/** The scholar's personal glossary: preferred Sanskrit / Kannada / English renderings of the same term. */
class GlossaryScreen(private val ctx: Context) : Screen {
    override val title = "Glossary"
    private val scroll = page(ctx)
    override val view: View = scroll.first
    private val col = scroll.second
    private val search = Ui.input(ctx, "Search the glossary", 1, singleLine = true)
    private val list = LinearLayout(ctx)
    private val empty = Ui.text(ctx, "", 15f, Pal.inkSoft)
    private var entries: List<GlossaryEntry> = emptyList()

    init {
        list.orientation = LinearLayout.VERTICAL
        col.add(Ui.text(ctx, "Preferred renderings of your key terms. The AI model is told to use them in translations and refinements, and the app then checks whether each term really appears in the result. (IndicTrans2, if you add it, cannot take a glossary: for it the app can only check, and offer to apply your terms afterwards.)", 14f, Pal.inkSoft), bottom = 12)
        col.add(Ui.button(ctx, "Add a term") { edit(null) }, bottom = 12)
        col.add(search, bottom = 12)
        col.add(list)
        empty.setPadding(ctx.dp(4), ctx.dp(8), ctx.dp(4), 0)
        col.add(empty)
        search.onChange { render() }
        reload(); render()
    }

    override fun onShow() { reload(); render() }

    private fun reload() { entries = App.store.glossary() }

    private fun matches(e: GlossaryEntry, q: String): Boolean {
        if (q.isBlank()) return true
        val n = q.trim().lowercase()
        return listOf(e.sa, e.kn, e.en, e.note).any { it.lowercase().contains(n) } ||
            (Scripts.nfc(e.sa).let { Glossary.normaliseSanskrit(q).let { d -> d.isNotBlank() && it.contains(d) } })
    }

    private fun render() {
        list.removeAllViews()
        val q = search.text?.toString() ?: ""
        val shown = entries.filter { matches(it, q) }
        for (e in shown) list.add(row(e), bottom = 8)
        empty.text = when {
            entries.isEmpty() -> "No terms yet. Add the Sanskrit, Kannada and English forms you prefer for a term (any two are enough)."
            shown.isEmpty() -> "No term matches “$q”."
            else -> "${entries.size} term(s) saved on this phone."
        }
    }

    private fun row(e: GlossaryEntry): View {
        val card = Ui.card(ctx)
        card.isClickable = true
        card.setOnClickListener { edit(e) }
        if (e.sa.isNotBlank()) card.add(Ui.text(ctx, "संस्कृतम्   " + e.sa, 17f, Pal.ink, bold = true))
        if (e.kn.isNotBlank()) card.add(Ui.text(ctx, "ಕನ್ನಡ   " + e.kn, 17f, Pal.ink, bold = true), top = 2)
        if (e.en.isNotBlank()) card.add(Ui.text(ctx, "English   " + e.en, 17f, Pal.ink, bold = true), top = 2)
        if (e.note.isNotBlank()) card.add(Ui.text(ctx, e.note, 13f, Pal.inkSoft, italic = true), top = 4)
        card.add(Ui.text(ctx, "Tap to edit", 12f, Pal.primary), top = 6)
        return card
    }

    private fun edit(existing: GlossaryEntry?) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(8))
        val sa = Ui.input(ctx, "Sanskrit (Devanagari, IAST or Kannada script)", 1, singleLine = true); sa.setText(existing?.sa ?: "")
        val kn = Ui.input(ctx, "Kannada", 1, singleLine = true); kn.setText(existing?.kn ?: "")
        val en = Ui.input(ctx, "English", 1, singleLine = true); en.setText(existing?.en ?: "")
        val note = Ui.input(ctx, "Note (optional)", 2); note.setText(existing?.note ?: "")
        for ((i, f) in listOf<EditText>(sa, kn, en, note).withIndex()) box.add(f, top = if (i == 0) 0 else 8)
        box.add(Ui.text(ctx, "Fill at least two of the three languages. Sanskrit typed in IAST or Kannada script is stored in Devanagari.", 12f, Pal.inkSoft), top = 8)
        val sv = ScrollView(ctx); sv.addView(box)
        val b = AlertDialog.Builder(ctx).setTitle(if (existing == null) "Add a term" else "Edit term").setView(sv)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
        if (existing != null) b.setNeutralButton("Delete") { _, _ ->
            App.store.saveGlossary(entries.filter { it.id != existing.id }); reload(); render()
        }
        val dlg = b.create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val e = GlossaryEntry(
                existing?.id ?: System.currentTimeMillis(),
                Glossary.normaliseSanskrit(sa.text.toString()).trim(),
                Scripts.nfc(kn.text.toString().trim()),
                en.text.toString().trim(),
                note.text.toString().trim(),
            )
            if (!e.isUsable) { Ui.toast(ctx, "Please fill at least two of the three languages."); return@setOnClickListener }
            val list2 = if (existing == null) entries + e else entries.map { if (it.id == existing.id) e else it }
            App.store.saveGlossary(list2); reload(); render()
            dlg.dismiss()
        }
    }
}
