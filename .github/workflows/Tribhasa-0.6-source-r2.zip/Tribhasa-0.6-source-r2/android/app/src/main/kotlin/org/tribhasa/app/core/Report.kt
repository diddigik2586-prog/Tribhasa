package org.tribhasa.app.core

/** One line of the Quality Control Report. Only checks that were really run are ever listed. */
enum class Qc(val symbol: String) { PASS("✓"), WARN("⚠"), INFO("ℹ"), FAIL("✗") }

data class QcItem(val status: Qc, val text: String)

class QcReport(val title: String = "Quality Control Report") {
    val items = ArrayList<QcItem>()
    fun pass(t: String) = apply { items.add(QcItem(Qc.PASS, t)) }
    fun warn(t: String) = apply { items.add(QcItem(Qc.WARN, t)) }
    fun info(t: String) = apply { items.add(QcItem(Qc.INFO, t)) }
    fun fail(t: String) = apply { items.add(QcItem(Qc.FAIL, t)) }
    val warnings: Int get() = items.count { it.status == Qc.WARN || it.status == Qc.FAIL }

    fun toPlain(): String = buildString {
        append(title).append('\n')
        for (i in items) append(i.status.symbol).append(' ').append(i.text).append('\n')
    }.trimEnd()

    /** Standing statement appended to every report so nothing is over-claimed. */
    fun addStandingNotes(aiInvolved: Boolean, trace: Trace? = null) {
        if (trace != null && trace.onDevice) LocalChecks.standing(this, trace)
        info(
            if (aiInvolved) "Not checked: whether the meaning and scholarly content are correct. The result is machine-generated and has not been verified by a second engine or by a person."
            else "Not checked: whether the meaning is correct. The result is machine-generated and has not been verified by a second engine or by a person."
        )
    }
}

/** A displayable result: titled sections of text, entries, and the QC report. */
sealed class Block {
    data class Para(val text: String, val uncertain: Boolean = false, val sanskrit: Boolean = false) : Block()
    /** A word / compound / correction card: heading, optional sub-heading, labelled lines and small tags. */
    data class Entry(
        val head: String,
        val sub: String = "",
        val lines: List<Pair<String, String>> = emptyList(),
        val tags: List<String> = emptyList(),
        val uncertain: Boolean = false,
    ) : Block()
}

data class Section(val title: String, val blocks: List<Block>)

class Document(val sections: List<Section>, val qc: QcReport, val engineNote: String = "") {
    fun toPlain(): String = buildString {
        for (s in sections) {
            append("■ ").append(s.title).append('\n')
            for (b in s.blocks) {
                when (b) {
                    is Block.Para -> append(if (b.uncertain) "(uncertain) " else "").append(b.text).append('\n')
                    is Block.Entry -> {
                        append("• ").append(b.head)
                        if (b.sub.isNotBlank()) append("  [").append(b.sub).append(']')
                        if (b.uncertain) append("  (uncertain)")
                        append('\n')
                        for ((k, v) in b.lines) if (v.isNotBlank()) append("   ").append(k).append(": ").append(v).append('\n')
                        if (b.tags.isNotEmpty()) append("   ").append(b.tags.joinToString(" · ")).append('\n')
                    }
                }
            }
            append('\n')
        }
    }.trimEnd()
}
