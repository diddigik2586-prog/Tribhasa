package org.tribhasa.app.core

import java.text.Normalizer

/** The three working languages. */
enum class Lang(
    val english: String,
    val nativeName: String,
    /** Code used by the Bhashini / Dhruva service. */
    val bhashini: String,
    /** FLORES-200 code used by AI4Bharat IndicTrans2 itself. */
    val flores: String,
) {
    SA("Sanskrit", "संस्कृतम्", "sa", "san_Deva"),
    KN("Kannada", "ಕನ್ನಡ", "kn", "kan_Knda"),
    EN("English", "English", "en", "eng_Latn");

    val display: String get() = if (this == EN) "English" else "$english · $nativeName"

    companion object {
        fun fromName(n: String?): Lang? = values().firstOrNull { it.name == n }
    }
}

/** A translation direction, e.g. Sanskrit → Kannada. */
data class Direction(val src: Lang, val tgt: Lang) {
    val label: String get() = "${src.english} → ${tgt.english}"
    val valid: Boolean get() = src != tgt

    companion object {
        val ALL: List<Direction> = Lang.values().flatMap { s -> Lang.values().filter { it != s }.map { Direction(s, it) } }
    }
}

enum class Script { DEVANAGARI, KANNADA, LATIN, OTHER }

object Scripts {
    fun isDevanagariLetter(cp: Int) =
        cp in 0x0900..0x097F && cp != 0x0964 && cp != 0x0965 && cp !in 0x0966..0x096F
    fun isKannadaLetter(cp: Int) = cp in 0x0C80..0x0CFF && cp !in 0x0CE6..0x0CEF
    fun isLatinLetter(cp: Int) =
        cp in 0x41..0x5A || cp in 0x61..0x7A || cp in 0xC0..0x24F || cp in 0x1E00..0x1EFF

    /** Counts of letters per script (digits, punctuation and spaces are ignored). */
    fun profile(text: String): Map<Script, Int> {
        val m = HashMap<Script, Int>()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            val s = when {
                isDevanagariLetter(cp) -> Script.DEVANAGARI
                isKannadaLetter(cp) -> Script.KANNADA
                isLatinLetter(cp) -> Script.LATIN
                Character.isLetter(cp) -> Script.OTHER
                else -> null
            }
            if (s != null) m[s] = (m[s] ?: 0) + 1
        }
        return m
    }

    fun letterCount(text: String): Int = profile(text).values.sum()

    fun dominant(text: String): Script? = profile(text).maxByOrNull { it.value }?.key

    fun share(text: String, s: Script): Double {
        val p = profile(text)
        val total = p.values.sum()
        return if (total == 0) 0.0 else (p[s] ?: 0).toDouble() / total
    }

    /** The script a translation *into* [lang] is expected to be written in. */
    fun expectedFor(lang: Lang): Script = when (lang) {
        Lang.SA -> Script.DEVANAGARI
        Lang.KN -> Script.KANNADA
        Lang.EN -> Script.LATIN
    }

    fun nfc(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFC)
}
