package org.tribhasa.app.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import org.tribhasa.app.App

object Brand {
    const val ATTRIBUTION = "by Dr. Diddigi Vamsi Krishna"
    const val NAME = "Tribhāṣā"
    const val NATIVE = "त्रिभाषा · ತ್ರಿಭಾಷಾ"
}

/** Full-screen About panel (shown over the main screen). */
fun aboutView(ctx: Context, onClose: () -> Unit): View {
    val frame = FrameLayout(ctx)
    frame.setBackgroundColor(Pal.bg)
    frame.isClickable = true   // swallow touches so nothing behind it reacts
    val (sv, col) = page(ctx)
    frame.addView(sv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

    val top = hrow(ctx)
    top.addSide(Ui.chip(ctx, "← Back") { onClose() })
    col.add(top, bottom = 18)

    val name = Ui.text(ctx, Brand.NAME, 34f, Pal.primary, bold = true)
    name.setTypeface(Typeface.SERIF, Typeface.BOLD)
    col.add(name)
    col.add(Ui.text(ctx, Brand.NATIVE, 20f, Pal.accent, bold = true), top = 2)
    col.add(Ui.text(ctx, Brand.ATTRIBUTION, 16f, Pal.ink, italic = true), top = 10, bottom = 18)

    col.add(Ui.text(ctx, "A scholar’s tool for Sanskrit, Kannada and English: translation in six directions, careful refinement, śloka and prose analysis, Sanskrit-to-Sanskrit commentary, and a personal glossary.", 15f, Pal.ink), bottom = 16)

    fun block(head: String, body: String) {
        col.add(Ui.label(ctx, head), bottom = 4)
        col.add(Ui.text(ctx, body, 14f, Pal.ink), bottom = 14)
    }
    block("How the work is done",
        "An open AI model runs on your phone and does the translation, refinement, analysis and commentary. You download it once in Settings (about ${org.tribhasa.app.core.LocalModels.gb(org.tribhasa.app.core.LocalModels.active.sizeBytes)}); after that no internet, account, key or payment is needed. No proprietary model such as Claude or Gemini is used. Metre and transliteration are also computed by the app itself and compared with the model’s claims. Optionally, under “Where the AI runs” in Settings, you can choose Online to use OpenRouter's open-weight models instead; the app never switches to Online by itself.")
    block("The AI model and its licence",
        "The model is ${org.tribhasa.app.core.LocalModels.active.name}, published as ${org.tribhasa.app.core.LocalModels.active.fileName} by ${org.tribhasa.app.core.LocalModels.active.publisher}, under the ${org.tribhasa.app.core.LocalModels.active.licence} licence (facts read ${org.tribhasa.app.core.LocalModels.CHECKED_ON}). It runs through Google's LiteRT-LM library (Apache-2.0). It is a small model, and its quality for Sanskrit and Kannada has NOT been tested with a Sanskrit evaluation set: treat every result as a machine draft.")
    block("What works without internet",
        "After the one-time model download: translation in all six directions, refinement, śloka and prose analysis and commentary (the last three are experimental on a phone and can be slow), script conversion, the metre check, your glossary and your history. Without the model, only script conversion, the metre check, glossary and history work offline.")
    block("Please remember",
        "Everything produced is machine-generated. It is checked for completeness, script, numbers and the like, but its meaning has not been verified by a second engine or by a person. Generated commentary is never the voice of a historical commentator. Verify before citing.")
    block("Privacy",
        "With the default setting your texts are processed on this phone only and are not sent anywhere; the app contains no analytics. The only network use is the one-time model download from the publisher's repository (and, only if you choose Online, the texts you submit go to OpenRouter and the company that hosts the model; OpenRouter's privacy policy, read ${org.tribhasa.app.core.Models.CHECKED_ON}, says it collects the inputs you send and gives no fixed retention period). Any key you add for the optional online services is kept encrypted with the phone's secure keystore when that works; Settings says how it was actually kept.")
    block("This build", "Version ${App.BUILD_LABEL}\n${org.tribhasa.app.core.FreeTestingPolicy.description}")
    return frame
}

/** Shown in place of a screen that failed to start, so a fault never takes the whole app down silently. */
class FailedScreen(private val ctx: Context, override val title: String, e: Throwable) : Screen {
    private val p = page(ctx)
    override val view: View = p.first
    init {
        App.logCrash(e)
        val report = android.util.Log.getStackTraceString(e)
        p.second.add(Ui.text(ctx, "This screen could not start.", 18f, Pal.bad, bold = true), bottom = 8)
        p.second.add(Ui.text(ctx, "The other screens still work. Please copy the report below and send it to the developer.", 14f, Pal.ink), bottom = 12)
        p.second.add(Ui.button(ctx, "Copy report") { Ui.copy(ctx, "Tribhāṣā ${App.BUILD_LABEL} — $title\n$report") }, bottom = 12)
        p.second.add(Ui.selectable(ctx, report, 11f, Pal.inkSoft))
    }
}
