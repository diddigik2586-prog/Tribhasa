package org.tribhasa.app.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

/**
 * One finished task, kept so the scholar can find, re-open and copy it later.
 * The original text and the generated result are always stored separately and never merged.
 */
data class HistoryEntry(
    val id: Long,
    /** Epoch milliseconds. */
    val time: Long,
    val kind: Kind,
    /** "Sanskrit → Kannada", or the name of the refinement tool or analysis. */
    val title: String,
    val input: String,
    val output: String,
    /** For translations: [Lang] names, so the entry can be re-opened in the Translate screen. */
    val from: String = "",
    val to: String = "",
    /** Which service and model produced the result (as reported in the Quality Control Report). */
    val madeWith: String = "",
    val warnings: Int = 0,
) {
    enum class Kind(val label: String) { TRANSLATION("Translation"), REFINEMENT("Refinement"), ANALYSIS("Analysis") }
}

/** Pure storage and search logic for the history list (the file handling lives in the Android layer). */
object History {
    private val seq = AtomicLong()

    fun newId(now: Long = System.currentTimeMillis()): Long = now * 1000 + (seq.getAndIncrement() % 1000)

    fun toJson(list: List<HistoryEntry>): String {
        val a = JSONArray()
        for (e in list) a.put(
            JSONObject().put("id", e.id).put("time", e.time).put("kind", e.kind.name).put("title", e.title)
                .put("input", e.input).put("output", e.output).put("from", e.from).put("to", e.to)
                .put("madeWith", e.madeWith).put("warnings", e.warnings)
        )
        return a.toString()
    }

    /** Returns null when [s] is not a valid history file (so the caller never overwrites it blindly). */
    fun parse(s: String?): List<HistoryEntry>? {
        if (s.isNullOrBlank()) return emptyList()
        val a = JsonUtil.parseArray(s) ?: return null
        val out = ArrayList<HistoryEntry>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val kind = HistoryEntry.Kind.values().firstOrNull { it.name == JsonUtil.str(o, "kind") } ?: HistoryEntry.Kind.TRANSLATION
            out.add(
                HistoryEntry(
                    id = o.optLong("id", System.nanoTime() + i), time = o.optLong("time", 0L), kind = kind,
                    title = JsonUtil.str(o, "title"), input = JsonUtil.str(o, "input"), output = JsonUtil.str(o, "output"),
                    from = JsonUtil.str(o, "from"), to = JsonUtil.str(o, "to"),
                    madeWith = JsonUtil.str(o, "madeWith"), warnings = o.optInt("warnings", 0),
                )
            )
        }
        return out
    }

    fun fromJson(s: String?): List<HistoryEntry> = parse(s) ?: emptyList()

    /** Newest first. */
    fun add(list: List<HistoryEntry>, e: HistoryEntry): List<HistoryEntry> = listOf(e) + list

    fun remove(list: List<HistoryEntry>, id: Long): List<HistoryEntry> = list.filter { it.id != id }

    /**
     * Case-insensitive search over title, original, result and service. A Latin query is also tried as IAST,
     * so "dharma" finds धर्म, and a Kannada-script or IAST query finds Devanagari text.
     */
    fun search(list: List<HistoryEntry>, query: String): List<HistoryEntry> {
        val q = Scripts.nfc(query).trim()
        if (q.isEmpty()) return list
        val needles = LinkedHashSet<String>()
        needles.add(q.lowercase())
        try {
            val dev = Translit.normaliseSanskritInput(q).devanagari
            if (dev.isNotBlank()) needles.add(Scripts.nfc(dev))
        } catch (_: Exception) {}
        return list.filter { e ->
            val hay = Scripts.nfc(listOf(e.title, e.input, e.output, e.madeWith).joinToString("\n"))
            val low = hay.lowercase()
            needles.any { n -> low.contains(n) || hay.contains(n) }
        }
    }

    /** One-line preview that never cuts a letter away from its vowel sign. */
    fun preview(text: String, max: Int): String {
        val t = text.replace(Regex("\\s+"), " ").trim()
        if (t.length <= max) return t
        var cut = max
        while (cut < t.length && isMark(t[cut])) cut++
        return t.substring(0, cut).trimEnd() + "…"
    }

    private fun isMark(c: Char): Boolean {
        val type = Character.getType(c)
        return type == Character.NON_SPACING_MARK.toInt() || type == Character.COMBINING_SPACING_MARK.toInt() || c == '‍' || c == '‌'
    }
}
