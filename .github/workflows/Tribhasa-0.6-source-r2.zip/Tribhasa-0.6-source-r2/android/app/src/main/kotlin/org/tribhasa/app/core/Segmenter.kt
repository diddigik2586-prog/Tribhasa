package org.tribhasa.app.core

/**
 * Splits text into pieces small enough for a translation engine and reassembles the output so that
 * paragraph breaks and line breaks of the original are kept. Nothing is dropped: every non-space
 * character of the input is in exactly one segment.
 */
object Segmenter {
    data class Segment(
        val text: String,
        /** Text to put after this segment's output when reassembling: " ", "\n" or a run of newlines. */
        val after: String,
    )

    private val SENTENCE_END = setOf('।', '॥', '.', '?', '!', '…', '|')
    private val SOFT_BREAKS = setOf(',', ';', ':', '—', '–', ')', ']')

    private fun endsSentence(s: String): Boolean {
        var i = s.length - 1
        while (i >= 0 && (s[i].isWhitespace() || s[i] in "\"'”’»)]”" || s[i].isDigit() || s[i] in '०'..'९' || s[i] in '೦'..'೯')) i--
        return i >= 0 && s[i] in SENTENCE_END
    }

    fun split(text: String, maxChars: Int): List<Segment> {
        require(maxChars >= 50)
        val src = text.replace("\r\n", "\n").replace('\r', '\n')
        val out = ArrayList<Segment>()
        // Paragraphs are separated by one or more blank lines; remember the exact separator.
        val paraRegex = Regex("\\n[ \\t]*\\n(?:[ \\t]*\\n)*")
        var pos = 0
        val paras = ArrayList<Pair<String, String>>() // text, separator after
        for (m in paraRegex.findAll(src)) {
            paras.add(src.substring(pos, m.range.first) to normaliseBlank(m.value))
            pos = m.range.last + 1
        }
        paras.add(src.substring(pos) to "")
        for ((pi, p) in paras.withIndex()) {
            val unitsOfPara = unitsFromParagraph(p.first, maxChars)
            if (unitsOfPara.isEmpty()) {
                // empty paragraph: just carry separator into the previous segment
                if (out.isNotEmpty() && p.second.isNotEmpty()) {
                    val last = out.removeAt(out.size - 1)
                    out.add(last.copy(after = last.after.trimEnd('\n', ' ') + p.second))
                }
                continue
            }
            for ((ui, u) in unitsOfPara.withIndex()) {
                val isLast = ui == unitsOfPara.size - 1
                out.add(if (isLast) Segment(u.text, if (pi == paras.size - 1) "" else p.second) else u)
            }
        }
        return out
    }

    private fun normaliseBlank(sep: String) = "\n".repeat(sep.count { it == '\n' }.coerceAtLeast(2))

    private fun unitsFromParagraph(para: String, maxChars: Int): List<Segment> {
        val lines = para.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()
        val result = ArrayList<Segment>()
        // Merge short consecutive lines that do not end a sentence (typical for verse pādas).
        var acc = StringBuilder()
        fun flushAcc() {
            if (acc.isNotEmpty()) {
                result.addAll(splitLong(acc.toString().trim(), maxChars, "\n"))
                acc = StringBuilder()
            }
        }
        for (line in lines) {
            if (acc.isNotEmpty() && acc.length + 1 + line.length > maxChars) flushAcc()
            if (acc.isNotEmpty()) acc.append(' ')
            acc.append(line)
            if (endsSentence(line)) flushAcc()
        }
        flushAcc()
        // The last unit of a paragraph gets its separator from the caller.
        return result
    }

    /** Splits one logical unit into chunks ≤ [maxChars]; chunks of the same unit are joined with a space. */
    private fun splitLong(unit: String, maxChars: Int, afterUnit: String): List<Segment> {
        if (unit.length <= maxChars) return listOf(Segment(unit, afterUnit))
        // 1. sentences
        val sentences = ArrayList<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < unit.length) {
            cur.append(unit[i])
            if (unit[i] in SENTENCE_END) {
                // swallow closing punctuation / verse numbers directly after the terminator
                var j = i + 1
                while (j < unit.length && (unit[j] in SENTENCE_END || unit[j] in "\"'”’»)]")) { cur.append(unit[j]); j++ }
                if (j >= unit.length || unit[j].isWhitespace()) { sentences.add(cur.toString().trim()); cur.setLength(0) }
                i = j
                continue
            }
            i++
        }
        if (cur.isNotBlank()) sentences.add(cur.toString().trim())
        // 2. break any sentence that is itself too long
        val pieces = ArrayList<String>()
        for (s in sentences) if (s.length <= maxChars) pieces.add(s) else pieces.addAll(breakLongSentence(s, maxChars))
        // 3. pack greedily
        val chunks = ArrayList<String>()
        val buf = StringBuilder()
        for (p in pieces) {
            if (buf.isNotEmpty() && buf.length + 1 + p.length > maxChars) { chunks.add(buf.toString()); buf.setLength(0) }
            if (buf.isNotEmpty()) buf.append(' ')
            buf.append(p)
        }
        if (buf.isNotEmpty()) chunks.add(buf.toString())
        return chunks.mapIndexed { idx, c -> Segment(c, if (idx == chunks.size - 1) afterUnit else " ") }
    }

    private fun breakLongSentence(s: String, maxChars: Int): List<String> {
        val parts = ArrayList<String>()
        var rest = s
        while (rest.length > maxChars) {
            var cut = -1
            // prefer a soft break (comma etc.) followed by space, then any space, in the window
            val window = rest.substring(0, maxChars)
            for (k in window.length - 1 downTo window.length / 3) {
                if (window[k] in SOFT_BREAKS && k + 1 < rest.length && rest[k + 1] == ' ') { cut = k + 1; break }
            }
            if (cut < 0) {
                val sp = window.lastIndexOf(' ')
                cut = if (sp > window.length / 3) sp else -1
            }
            if (cut < 0) {
                // no space at all (long Sanskrit compound): cut at a code-point boundary that is not before a combining mark
                var k = maxChars
                while (k > maxChars / 2 && (Character.isLowSurrogate(rest[k]) || isCombining(rest[k]))) k--
                cut = k
            }
            parts.add(rest.substring(0, cut).trim())
            rest = rest.substring(cut).trim()
        }
        if (rest.isNotEmpty()) parts.add(rest)
        return parts
    }

    private fun isCombining(c: Char): Boolean {
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt() || c == '‍' || c == '‌'
    }

    /** Rebuilds output text from translated segments (same order/length as the input segments). */
    fun join(segments: List<Segment>, outputs: List<String>): String {
        require(segments.size == outputs.size)
        val sb = StringBuilder()
        for (i in segments.indices) { sb.append(outputs[i].trim()); sb.append(segments[i].after) }
        return sb.toString().trimEnd()
    }

    /** Number of paragraphs (blocks separated by blank lines). */
    fun paragraphCount(text: String): Int =
        text.replace("\r\n", "\n").split(Regex("\\n[ \\t]*\\n")).count { it.isNotBlank() }
}
