package org.tribhasa.app.core

/**
 * Word-list based conversion of American spellings to British ones (Indian English follows British usage).
 * Only whole words in the list/rules are changed; nothing else in the text is touched.
 */
object Spelling {
    private val OR_STEMS = listOf(
        "color", "honor", "favor", "labor", "neighbor", "behavior", "flavor", "harbor", "humor", "rumor", "vigor",
        "savior", "valor", "ardor", "armor", "candor", "clamor", "endeavor", "fervor", "glamor", "parlor", "splendor",
        "tumor", "odor", "demeanor", "rigor", "vapor", "rancor", "savor", "succor",
    )
    private val OR_SUFFIXES = listOf("", "s", "ed", "ing", "ful", "less", "able", "ably", "ite", "ites")
    private val RE_STEMS = mapOf(
        "center" to "centre", "theater" to "theatre", "fiber" to "fibre", "liter" to "litre", "meter" to "metre",
        "caliber" to "calibre", "meager" to "meagre", "luster" to "lustre", "somber" to "sombre", "specter" to "spectre",
        "saber" to "sabre", "maneuver" to "manoeuvre", "kilometer" to "kilometre", "centimeter" to "centimetre", "millimeter" to "millimetre",
    )
    private val EXPLICIT = mapOf(
        "defense" to "defence", "offense" to "offence", "pretense" to "pretence", "gray" to "grey", "plow" to "plough",
        "plowed" to "ploughed", "mold" to "mould", "molds" to "moulds", "ax" to "axe", "aluminum" to "aluminium",
        "sulfur" to "sulphur", "skillful" to "skilful", "fulfill" to "fulfil", "fulfills" to "fulfils", "enroll" to "enrol",
        "enrollment" to "enrolment", "installment" to "instalment", "catalog" to "catalogue", "catalogs" to "catalogues",
        "dialog" to "dialogue", "dialogs" to "dialogues", "analog" to "analogue", "prolog" to "prologue", "epilog" to "epilogue",
        "monolog" to "monologue", "traveled" to "travelled", "traveling" to "travelling", "traveler" to "traveller",
        "travelers" to "travellers", "labeled" to "labelled", "labeling" to "labelling", "modeled" to "modelled",
        "modeling" to "modelling", "canceled" to "cancelled", "canceling" to "cancelling", "signaled" to "signalled",
        "signaling" to "signalling", "totaled" to "totalled", "leveled" to "levelled", "leveling" to "levelling",
        "fueled" to "fuelled", "quarreled" to "quarrelled", "jeweler" to "jeweller", "counselor" to "counsellor",
        "esthetic" to "aesthetic", "esthetics" to "aesthetics", "archeology" to "archaeology", "archeological" to "archaeological",
        "archeologist" to "archaeologist", "encyclopedia" to "encyclopaedia", "anesthesia" to "anaesthesia",
        "fetus" to "foetus", "pediatric" to "paediatric", "orthopedic" to "orthopaedic", "cozy" to "cosy",
        "artifact" to "artefact", "artifacts" to "artefacts", "analyze" to "analyse", "analyzed" to "analysed",
        "analyzes" to "analyses", "analyzing" to "analysing", "paralyze" to "paralyse", "catalyze" to "catalyse",
    )

    private val IZE_EXCEPTIONS = setOf(
        "size", "sizes", "sized", "sizing", "prize", "prizes", "prized", "seize", "seizes", "seized", "seizing",
        "capsize", "capsized", "capsizes", "capsizing", "resize", "resized", "resizing", "downsize", "downsized", "downsizing",
        "upsize", "upsized", "oversize", "oversized", "outsize", "outsized", "maize", "bronze", "freeze", "squeeze", "breeze", "sneeze", "wheeze",
    )

    private val MAP: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        for (stem in OR_STEMS) for (suf in OR_SUFFIXES) m[stem + suf] = stem.removeSuffix("or") + "our" + suf
        for ((us, uk) in RE_STEMS) {
            val usBase = us.removeSuffix("er")   // centered -> centred, centering -> centring
            val ukBase = uk.removeSuffix("re")
            m[us] = uk
            m[us + "s"] = uk + "s"
            m[usBase + "ered"] = ukBase + "red"
            m[usBase + "ering"] = ukBase + "ring"
        }
        m.putAll(EXPLICIT)
        m
    }

    data class Result(val text: String, val changed: Int)

    fun toBritish(text: String): Result {
        var changed = 0
        val sb = StringBuilder()
        val re = Regex("[A-Za-z]+")
        var last = 0
        for (mt in re.findAll(text)) {
            sb.append(text, last, mt.range.first)
            val w = mt.value
            val lower = w.lowercase()
            var rep = MAP[lower]
            if (rep == null) rep = izeRule(lower)
            if (rep != null && rep != lower) {
                sb.append(matchCase(w, rep)); changed++
            } else sb.append(w)
            last = mt.range.last + 1
        }
        sb.append(text, last, text.length)
        return Result(sb.toString(), changed)
    }

    private fun izeRule(w: String): String? {
        if (w in IZE_EXCEPTIONS || w.length < 7) return null
        return when {
            w.endsWith("ization") -> w.removeSuffix("ization") + "isation"
            w.endsWith("izations") -> w.removeSuffix("izations") + "isations"
            w.endsWith("izing") -> w.removeSuffix("izing") + "ising"
            w.endsWith("ized") -> w.removeSuffix("ized") + "ised"
            w.endsWith("izes") -> w.removeSuffix("izes") + "ises"
            w.endsWith("ize") -> w.removeSuffix("ize") + "ise"
            w.endsWith("izer") -> w.removeSuffix("izer") + "iser"
            else -> null
        }
    }

    private fun matchCase(orig: String, rep: String): String = when {
        orig.length > 1 && orig.all { it.isUpperCase() } -> rep.uppercase()
        orig[0].isUpperCase() -> rep.replaceFirstChar { it.uppercaseChar() }
        else -> rep
    }
}
