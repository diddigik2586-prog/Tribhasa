package org.tribhasa.app.core

/**
 * Where the AI runs.
 *
 * LOCAL is the default: the model that was downloaded once runs on this phone and nothing is sent anywhere.
 * ONLINE keeps the earlier optional route (OpenRouter and the other services). The app never changes from one to the
 * other by itself: if the chosen source fails, the user is told and decides.
 */
enum class AiSource { LOCAL, ONLINE;
    companion object { fun fromName(n: String?): AiSource = values().firstOrNull { it.name == n } ?: LOCAL }
}

/**
 * The on-device model the app downloads on first use. Every fact below was read on [CHECKED_ON] from the publisher's own
 * pages (see docs/ON_DEVICE_MODEL.md); none of it says anything about Sanskrit or Kannada quality.
 */
object LocalModels {
    const val CHECKED_ON = "20 October 2026"

    data class Spec(
        /** Stable key; also the folder name on the phone. */
        val id: String,
        val name: String,
        /** Short name used in reports and status lines. */
        val shortName: String,
        /** File name on the phone. */
        val fileName: String,
        /** Address of the file, pinned to one repository revision so it cannot change under the app. Must be https. */
        val url: String,
        val sizeBytes: Long,
        /** SHA-256 of the whole file, as published by the repository. The download is deleted if it does not match. */
        val sha256: String,
        val licence: String,
        val licenceSource: String,
        val publisher: String,
        val sourcePage: String,
        /** How many tokens (prompt plus answer) the app lets the engine hold. The model itself supports more; memory use grows with this. */
        val contextTokens: Int,
        /** What the publisher says about memory, in its own terms. */
        val publisherMemoryNote: String,
    )

    val GEMMA4_E2B = Spec(
        id = "gemma-4-e2b-it",
        name = "Gemma 4 E2B (instruction-tuned, LiteRT-LM)",
        shortName = "Gemma 4 E2B",
        fileName = "gemma-4-E2B-it.litertlm",
        url = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/" +
            "b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1/gemma-4-E2B-it.litertlm",
        sizeBytes = 2_588_147_712L,
        sha256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
        licence = "Apache-2.0",
        licenceSource = "Hugging Face repository litert-community/gemma-4-E2B-it-litert-lm (licence field: apache-2.0; base model google/gemma-4-E2B-it)",
        publisher = "LiteRT Community on Hugging Face (Google's open-model conversions for LiteRT-LM)",
        sourcePage = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm",
        contextTokens = 4096,
        publisherMemoryNote = "The model card states no minimum RAM. Its benchmark on one flagship phone (Galaxy S26 Ultra, 2048-token context) measured about 1.7 GB of CPU memory.",
    )

    /** The model in use. A variable only so the automated tests can point it at a small test file; the app never changes it. */
    @Volatile var active: Spec = GEMMA4_E2B

    /** Decimal gigabytes with two places, the way download sites show sizes. */
    fun gb(bytes: Long): String = String.format(java.util.Locale.US, "%.2f GB", bytes / 1_000_000_000.0)
    fun mb(bytes: Long): String = String.format(java.util.Locale.US, "%.0f MB", bytes / 1_000_000.0)

    /**
     * Whether this phone looks able to run the model. These limits are the app's own cautious judgement, because the
     * publisher gives no minimum; they are not measured values. Android reports a little less than the advertised RAM.
     */
    enum class Fit { OK, TIGHT, LIKELY_TOO_SMALL }
    private const val GIB = 1024.0 * 1024 * 1024
    const val TIGHT_BELOW_GIB = 5.0
    const val TOO_SMALL_BELOW_GIB = 3.5

    fun memoryFit(totalRamBytes: Long): Fit = when {
        totalRamBytes <= 0 -> Fit.OK            // unknown: do not scare the user
        totalRamBytes / GIB < TOO_SMALL_BELOW_GIB -> Fit.LIKELY_TOO_SMALL
        totalRamBytes / GIB < TIGHT_BELOW_GIB -> Fit.TIGHT
        else -> Fit.OK
    }

    fun memoryText(totalRamBytes: Long): String {
        val gib = String.format(java.util.Locale.US, "%.1f", totalRamBytes / GIB)
        return when (memoryFit(totalRamBytes)) {
            Fit.OK -> "This phone reports $gib GB of memory, which should be enough (the app's own rule of thumb is about 5 GB or more)."
            Fit.TIGHT -> "This phone reports $gib GB of memory. That is on the low side: the model may be slow, and Android may close the app while it runs. Close other apps first."
            Fit.LIKELY_TOO_SMALL -> "This phone reports only $gib GB of memory. The model is likely to fail to load or to be closed by Android. You can still try, but expect problems."
        }
    }

    /** Room needed on the phone for the download: what is still missing plus a margin for the verification and Android itself. */
    fun spaceNeeded(spec: Spec, alreadyDownloaded: Long): Long {
        val missing = (spec.sizeBytes - alreadyDownloaded).coerceAtLeast(0)
        val margin = maxOf(300_000_000L, spec.sizeBytes / 20)
        return missing + margin
    }
}
