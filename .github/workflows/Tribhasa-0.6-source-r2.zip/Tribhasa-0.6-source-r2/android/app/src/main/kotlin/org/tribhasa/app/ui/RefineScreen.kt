package org.tribhasa.app.ui

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import org.tribhasa.app.App
import org.tribhasa.app.UiError
import org.tribhasa.app.core.History
import org.tribhasa.app.core.HistoryEntry
import org.tribhasa.app.core.Lang
import org.tribhasa.app.core.Prompts

class RefineScreen(private val ctx: Context, private val host: Host) : Screen {
    override val title = "Refine"
    private val m = App.refine
    private val scroll = page(ctx)
    override val view: View = scroll.first
    private val col = scroll.second

    private val langPick = Picker(ctx, "Language of your text") { pickLang() }
    private val toolPick = Picker(ctx, "Tool") { pickTool() }
    private val outPick = Picker(ctx, "Translate into") { pickOut() }
    private val blurb = Ui.text(ctx, "", 13f, Pal.inkSoft)
    private val input = InputCard(ctx, "Your text", "", 7) { m.input = it }
    private val runBtn = Ui.button(ctx, "Refine") { start(false) }
    private val progress = ProgressArea(ctx) { m.cancel?.cancel() }
    private val error = ErrorArea(ctx, { start(false) }, { host.openSettings() })
    private val status = Ui.text(ctx, "", 14f, Pal.inkSoft)
    private val results = LinearLayout(ctx)
    private val localNote = Ui.text(ctx,
        "On this phone the model is small: use short passages (a few sentences at a time). Results are marked low-confidence, and tools that return a structured list of corrections may fail on a small model; the app then says so.",
        13f, Pal.warn)

    init {
        m.lang = Lang.fromName(App.store.pref("r_lang", m.lang.name)) ?: m.lang
        m.out = Lang.fromName(App.store.pref("r_out", m.out.name)) ?: m.out
        m.tool = Prompts.Refine.values().firstOrNull { it.name == App.store.pref("r_tool", m.tool.name) } ?: m.tool
        if (m.input.isEmpty()) m.input = App.store.draft("refine")
        input.setText(m.input)
        results.orientation = LinearLayout.VERTICAL

        col.add(langPick.view, bottom = 10)
        col.add(toolPick.view, bottom = 4)
        blurb.setPadding(ctx.dp(4), 0, 0, ctx.dp(10))
        col.add(blurb)
        localNote.setPadding(ctx.dp(4), 0, 0, ctx.dp(10))
        col.add(localNote)
        col.add(outPick.view, bottom = 10)
        col.add(input.view, bottom = 12)
        col.add(runBtn, bottom = 12)
        col.add(progress.view, bottom = 12)
        col.add(error.view, bottom = 12)
        status.setPadding(ctx.dp(4), 0, 0, ctx.dp(8))
        col.add(status)
        col.add(results)

        m.listener = { render() }
        render()
    }

    override fun onShow() { m.listener = { render() }; render() }
    override fun saveDraft() { App.store.setDraft("refine", m.input) }

    private fun pickLang() {
        val all = Lang.values().toList()
        Ui.choose(ctx, "Language of your text", langOptions(all), all.indexOf(m.lang)) { i ->
            m.lang = all[i]
            if (m.tool == Prompts.Refine.REFINE_TRANSLATE && m.out == m.lang) m.out = all.first { it != m.lang }
            App.store.setPref("r_lang", m.lang.name); clearResults(); render()
        }
    }

    private fun pickTool() {
        val all = Prompts.Refine.values().toList()
        Ui.choose(ctx, "Choose a tool", all.map { it.label to it.blurb }, all.indexOf(m.tool)) { i ->
            m.tool = all[i]
            if (m.tool == Prompts.Refine.REFINE_TRANSLATE && m.out == m.lang) m.out = Lang.values().first { it != m.lang }
            App.store.setPref("r_tool", m.tool.name); clearResults(); render()
        }
    }

    private fun pickOut() {
        val all = if (m.tool == Prompts.Refine.REFINE_TRANSLATE) Lang.values().filter { it != m.lang } else Lang.values().toList()
        Ui.choose(ctx, if (m.tool == Prompts.Refine.REFINE_TRANSLATE) "Translate into" else "Explain in", langOptions(all), all.indexOf(m.out)) { i ->
            m.out = all[i]; App.store.setPref("r_out", m.out.name); clearResults(); render()
        }
    }

    private fun clearResults() { m.text = null; m.refined = null; m.doc = null; m.qc = null; m.error = null }

    private fun start(@Suppress("UNUSED_PARAMETER") retry: Boolean) {
        if (m.running) return
        val text = input.text()
        m.input = text
        if (text.isBlank()) { Ui.toast(ctx, "Please type or paste some text first."); return }
        val c = App.store.credentials()
        if (App.offlineBlocksAi(c)) { m.error = UiError("The phone is offline. Your text is kept; connect to the internet and press Retry, or switch “Where the AI runs” to “On this phone” in Settings.", true, false); render(); return }
        App.aiBlockReason(c)?.let { m.error = UiError(it, false, true); render(); return }
        val s = App.services()
        val opts = App.store.options()
        val gloss = App.store.glossary()
        val tool = m.tool; val lang = m.lang; val out = m.out
        clearResults()
        App.launch(m, "Starting…", { cancel, p ->
            when {
                tool == Prompts.Refine.REFINE_TRANSLATE -> s.scholar.refineAndTranslate(text, lang, out, opts, gloss, cancel, p)
                tool.json -> s.scholar.refineStructured(tool, text, lang, out, opts, gloss, cancel, p)
                else -> s.scholar.refinePlain(tool, text, lang, opts, gloss, cancel, p)
            }
        }) { r ->
            m.text = r.text; m.refined = r.refinedText; m.doc = r.doc; m.qc = r.qc
            val title = tool.label + " (" + lang.english + (if (tool.needsOutLang) " → " + out.english else "") + ")"
            val output = r.doc?.toPlain()
                ?: r.refinedText?.let { "Refined text:\n$it\n\nTranslation (${out.english}):\n${r.text ?: ""}" }
                ?: (r.text ?: "")
            App.record(HistoryEntry(History.newId(), System.currentTimeMillis(), HistoryEntry.Kind.REFINEMENT, title, text, output, lang.name, "", r.trace.used.keys.joinToString("; "), r.qc.warnings))
        }
    }

    private fun render() {
        langPick.set(m.lang.display)
        toolPick.set(m.tool.label)
        blurb.text = m.tool.blurb
        localNote.show(App.store.credentials().aiSource == org.tribhasa.app.core.AiSource.LOCAL)
        outPick.view.show(m.tool.needsOutLang)
        if (m.tool.needsOutLang) {
            outPick.caption(if (m.tool == Prompts.Refine.REFINE_TRANSLATE) "Translate into" else "Explain in")
            outPick.set(m.out.display)
        }
        input.edit.hint = when (m.lang) { Lang.SA -> "संस्कृतपाठम् अत्र लिखत"; Lang.KN -> "ಕನ್ನಡ ಪಠ್ಯ"; Lang.EN -> "English text" }
        runBtn.text = m.tool.label
        runBtn.show(!m.running)
        progress.render(m.running, m.status)
        error.render(m.error)
        status.text = if (!m.running && m.error == null) m.status else ""
        status.show(status.text.isNotEmpty())

        results.removeAllViews()
        if (m.running) return
        val doc = m.doc
        val text = m.text
        val qc = m.qc
        if (doc != null) {
            val card = Ui.card(ctx)
            val head = LabelRow(ctx, m.tool.label)
            head.action(Ui.chip(ctx, "Copy all") { Ui.copy(ctx, doc.toPlain()) })
            card.add(head.view, bottom = 4)
            card.add(ResultViews.documentView(ctx, doc))
            results.add(card, bottom = 12)
        } else if (text != null) {
            val refined = m.refined
            if (refined != null) {
                val c1 = OutputCard(ctx, "Refined text (${m.lang.english})")
                c1.set(refined)
                results.add(c1.view, bottom = 12)
            }
            val label = when {
                refined != null -> "Translation (${m.out.english})"
                else -> "Revised text"
            }
            val c2 = OutputCard(ctx, label)
            c2.set(text)
            if (refined == null) {
                c2.actions.action(Ui.chip(ctx, "Use as input") {
                    input.setText(text); m.input = text; clearResults(); render()
                    Ui.toast(ctx, "Revised text moved into the input box")
                })
            }
            results.add(c2.view, bottom = 12)
        }
        if (qc != null && (doc != null || text != null)) results.add(ResultViews.qcCard(ctx, qc, expanded = true))
    }
}
