package org.tribhasa.app.ui

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import org.tribhasa.app.UiError
import org.tribhasa.app.core.Block
import org.tribhasa.app.core.Document
import org.tribhasa.app.core.Qc
import org.tribhasa.app.core.QcReport
import org.tribhasa.app.core.Section

object ResultViews {

    /** The Quality Control Report: only checks that were actually run. */
    fun qcCard(ctx: Context, qc: QcReport, expanded: Boolean = true): View {
        val card = Ui.card(ctx, Pal.surface, Pal.outline)
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = Ui.text(ctx, qc.title, 15f, Pal.primary, bold = true)
        head.addView(title, Ui.lp(0, ViewGroupWrap, 1f))
        val warnCount = qc.warnings
        val summary = Ui.text(ctx, if (warnCount == 0) "no warnings" else "$warnCount to review", 12f, if (warnCount == 0) Pal.good else Pal.warn, bold = true)
        head.addView(summary)
        card.addView(head, Ui.lp())
        val body = LinearLayout(ctx)
        body.orientation = LinearLayout.VERTICAL
        body.visibility = if (expanded) View.VISIBLE else View.GONE
        for (item in qc.items) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            val color = when (item.status) { Qc.PASS -> Pal.good; Qc.WARN -> Pal.warn; Qc.FAIL -> Pal.bad; Qc.INFO -> Pal.inkSoft }
            val sym = Ui.text(ctx, item.status.symbol, 15f, color, bold = true)
            sym.gravity = Gravity.CENTER_HORIZONTAL
            row.addView(sym, Ui.lp(ctx.dp(24), ViewGroupWrap))
            val t = Ui.selectable(ctx, item.text, 14f, if (item.status == Qc.INFO) Pal.inkSoft else Pal.ink)
            row.addView(t, Ui.lp(0, ViewGroupWrap, 1f))
            val p = Ui.lp(); p.topMargin = ctx.dp(6)
            body.addView(row, p)
        }
        val bp = Ui.lp(); bp.topMargin = ctx.dp(4)
        card.addView(body, bp)
        val toggle = Ui.text(ctx, if (expanded) "Hide details" else "Show details", 13f, Pal.primary, bold = true)
        toggle.setPadding(0, ctx.dp(10), 0, ctx.dp(2))
        toggle.isClickable = true
        toggle.setOnClickListener {
            val show = body.visibility != View.VISIBLE
            body.visibility = if (show) View.VISIBLE else View.GONE
            toggle.text = if (show) "Hide details" else "Show details"
        }
        card.addView(toggle, Ui.lp())
        return card
    }

    private const val ViewGroupWrap = LinearLayout.LayoutParams.WRAP_CONTENT

    fun documentView(ctx: Context, doc: Document): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        for (s in doc.sections) col.addView(sectionView(ctx, s), Ui.lp())
        return col
    }

    private fun sectionView(ctx: Context, s: Section): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val h = Ui.text(ctx, s.title, 15f, Pal.accent, bold = true)
        h.setPadding(0, ctx.dp(18), 0, ctx.dp(6))
        col.addView(h, Ui.lp())
        for (b in s.blocks) {
            when (b) {
                is Block.Para -> {
                    val tv = Ui.selectable(ctx, (if (b.uncertain) "⚠ " else "") + b.text, if (b.sanskrit) 18f else 16f, if (b.uncertain) Pal.warn else Pal.ink)
                    tv.setPadding(0, ctx.dp(2), 0, ctx.dp(6))
                    col.addView(tv, Ui.lp())
                }
                is Block.Entry -> col.addView(entryView(ctx, b), Ui.lp().also { it.bottomMargin = ctx.dp(8) })
            }
        }
        return col
    }

    private fun entryView(ctx: Context, e: Block.Entry): View {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
        card.background = Ui.rounded(ctx, if (e.uncertain) Pal.accentSoft else Pal.surface, 12, if (e.uncertain) Pal.warn else Pal.outline, 1)
        val head = Ui.selectable(ctx, e.head, 18f, Pal.ink)
        head.setTypeface(head.typeface, android.graphics.Typeface.BOLD)
        card.addView(head, Ui.lp())
        if (e.sub.isNotBlank()) card.addView(Ui.text(ctx, e.sub, 14f, Pal.inkSoft, italic = true), Ui.lp())
        val tags = ArrayList<String>()
        if (e.uncertain) tags.add("⚠ uncertain")
        tags.addAll(e.tags)
        if (tags.isNotEmpty()) {
            val t = Ui.text(ctx, tags.joinToString("  ·  "), 13f, if (e.uncertain) Pal.warn else Pal.accent, bold = true)
            t.setPadding(0, ctx.dp(4), 0, ctx.dp(2))
            card.addView(t, Ui.lp())
        }
        for ((k, v) in e.lines) {
            if (v.isBlank()) continue
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, ctx.dp(4), 0, 0)
            if (k.isNotBlank()) row.addView(Ui.text(ctx, k, 12f, Pal.inkSoft, bold = true), Ui.lp())
            row.addView(Ui.selectable(ctx, v, 15f, Pal.ink), Ui.lp())
            card.addView(row, Ui.lp())
        }
        return card
    }
}

/** "Working…" area: progress bar, current status and a Cancel button. */
class ProgressArea(private val ctx: Context, private val onCancel: () -> Unit) {
    val view = LinearLayout(ctx)
    private val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
    private val status = Ui.text(ctx, "", 14f, Pal.inkSoft)
    init {
        view.orientation = LinearLayout.VERTICAL
        view.visibility = View.GONE
        bar.isIndeterminate = true
        view.addView(bar, Ui.lp(h = ctx.dp(8)))
        status.setPadding(0, ctx.dp(8), 0, ctx.dp(8))
        view.addView(status, Ui.lp())
        view.addView(Ui.button(ctx, "Cancel", primary = false) { onCancel() }, Ui.lp())
    }
    fun render(running: Boolean, text: String) {
        view.visibility = if (running) View.VISIBLE else View.GONE
        status.text = text
    }
}

/** Plain-language error with Retry, Settings and technical details. */
class ErrorArea(private val ctx: Context, private val onRetry: () -> Unit, private val onSettings: () -> Unit) {
    val view = LinearLayout(ctx)
    private val msg = Ui.selectable(ctx, "", 15f, Pal.bad)
    private val row = LinearLayout(ctx)
    private var detail: String? = null
    private val retry = Ui.button(ctx, "Retry", primary = true) { onRetry() }
    private val settings = Ui.chip(ctx, "Open Settings") { onSettings() }
    private val details = Ui.chip(ctx, "Details") { detail?.let { Ui.message(ctx, "Technical details", it, it) } }
    init {
        view.orientation = LinearLayout.VERTICAL
        view.visibility = View.GONE
        view.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        view.background = Ui.rounded(ctx, Pal.badSoft, 16, Pal.bad, 1)
        view.addView(Ui.text(ctx, "Could not finish", 15f, Pal.bad, bold = true), Ui.lp())
        msg.setPadding(0, ctx.dp(6), 0, ctx.dp(10))
        view.addView(msg, Ui.lp())
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(retry, Ui.lp(0, ViewGroupWrap2, 1f))
        row.addView(settings, Ui.lp(ViewGroupWrap2, ViewGroupWrap2).also { it.leftMargin = ctx.dp(8) })
        row.addView(details, Ui.lp(ViewGroupWrap2, ViewGroupWrap2).also { it.leftMargin = ctx.dp(8) })
        view.addView(row, Ui.lp())
    }
    fun render(e: UiError?) {
        if (e == null) { view.visibility = View.GONE; return }
        view.visibility = View.VISIBLE
        msg.text = e.message
        detail = e.detail
        retry.visibility = if (e.canRetry) View.VISIBLE else View.GONE
        settings.visibility = if (e.needsSettings) View.VISIBLE else View.GONE
        details.visibility = if (e.detail.isNullOrBlank()) View.GONE else View.VISIBLE
    }
    private companion object { const val ViewGroupWrap2 = LinearLayout.LayoutParams.WRAP_CONTENT }
}

/** Scrolling page container used by every screen. */
fun page(ctx: Context): Pair<android.widget.ScrollView, LinearLayout> {
    val sv = android.widget.ScrollView(ctx)
    sv.isFillViewport = false
    sv.clipToPadding = false
    val col = LinearLayout(ctx)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(24))
    sv.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
    return sv to col
}
