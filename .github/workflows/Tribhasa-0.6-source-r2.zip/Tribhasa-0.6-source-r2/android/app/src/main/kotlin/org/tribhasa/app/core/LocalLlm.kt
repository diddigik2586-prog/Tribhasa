package org.tribhasa.app.core

/** What the on-device engine is asked to do: one question, one answer. */
data class LocalRequest(val system: String, val user: String, val maxOutputTokens: Int, val temperature: Double)

data class LocalOutput(
    val text: String,
    /** How many streamed pieces arrived. Pieces are roughly tokens but not exactly, so this is an estimate. */
    val pieces: Int,
    /** True when the answer probably stopped because it hit the length limit (judged from the number of pieces and the text length, so a guess). */
    val reachedLimit: Boolean,
    val modelLabel: String,
    val loadMs: Long,
    val generateMs: Long,
    /** Things the user should know, such as "the GPU could not be used, the CPU was used". */
    val notes: List<String> = emptyList(),
)

/** The model that runs on this phone, as the rest of the app sees it. */
interface LocalRuntime {
    /** How many tokens (question plus answer) fit. */
    val contextTokens: Int
    /** Null when the model is on the phone, checked and usable; otherwise a plain-language reason with what to do. */
    fun unavailableReason(): String?
    /** Blocks until the answer is complete. Throws [EngineException]; never falls back to anything else. */
    fun generate(req: LocalRequest, cancel: CancelToken, status: (String) -> Unit): LocalOutput
}

/**
 * Rough size of a text in model tokens. Deliberately on the high side so that a text that would not fit is refused
 * before a long wait rather than after it. It is an estimate, not a count.
 */
object TokenEstimate {
    fun of(text: String): Int {
        var indic = 0; var other = 0
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i); i += Character.charCount(cp)
            if (cp in 0x0900..0x0DFF) indic++ else other++
        }
        return Math.ceil(indic * 0.55 + other * 0.32).toInt()
    }
}

/** Cleaning of a small model's plain-text answer. */
object PlainText {
    /** Returns the answer without code fences, a lead-in line or wrapping quotes; empty when the text looks like broken JSON instead. */
    fun clean(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.removePrefix("```").let { x -> val nl = x.indexOf('\n'); if (nl in 0..12 && x.substring(0, nl).trim().all { it.isLetter() }) x.substring(nl + 1) else x }.trim()
            if (s.endsWith("```")) s = s.removeSuffix("```").trim()
        }
        if (s.startsWith("{") || s.startsWith("[")) return ""
        val lines = s.lines().toMutableList()
        if (lines.size > 1 && lines.first().trim().let { it.endsWith(":") && it.length < 80 }) lines.removeAt(0)
        s = lines.joinToString("\n").trim()
        s = s.replace(Regex("^(translation|translated text|answer)\\s*:\\s*", RegexOption.IGNORE_CASE), "").trim()
        val pairs = listOf('"' to '"', '“' to '”', '«' to '»')
        for ((a, b) in pairs) {
            // Wrapping quotes only: if the same quote mark also appears inside, the text really contains quotations and is left alone.
            val inside = if (a == b) s.count { it == a } <= 2 else s.count { it == a } <= 1 && s.count { it == b } <= 1
            if (s.length > 1 && s.first() == a && s.last() == b && inside) { s = s.substring(1, s.length - 1).trim(); break }
        }
        return s
    }

    /** Removes chat-template markers a model sometimes leaves in its text. */
    fun stripMarkers(s: String): String =
        s.replace(Regex("<end_of_turn>|<start_of_turn>(model|user)?|<eos>|<bos>|<turn\\|>|<\\|turn>(model|user)?"), "").trim()
}

/**
 * Adapts the on-device model to the app's provider interface.
 * It checks that the text fits the model's memory *before* starting, and reports a cut-off answer as such.
 */
class LocalLlmProvider(private val runtime: LocalRuntime) : LlmProvider {
    companion object {
        const val ID = "local"
        /** Room kept for the chat template's own markers. */
        const val TEMPLATE_TOKENS = 48
        /** Smallest answer worth starting. */
        const val MIN_ANSWER_TOKENS = 96
    }
    override val id = ID
    override val label = "AI model on this phone"
    override val account = "local"

    override fun generate(req: LlmRequest, cancel: CancelToken): LlmReply = generate(req, cancel) { }

    override fun generate(req: LlmRequest, cancel: CancelToken, status: (String) -> Unit): LlmReply {
        cancel.check()
        runtime.unavailableReason()?.let { throw EngineException(FailKind.UNSUPPORTED, it) }
        val prompt = TokenEstimate.of(req.system) + TokenEstimate.of(req.user) + TEMPLATE_TOKENS
        val room = runtime.contextTokens - prompt
        if (room < MIN_ANSWER_TOKENS) throw EngineException(FailKind.LOCAL,
            "This text is too long for the model on this phone (about $prompt tokens needed for the request alone; it can hold ${runtime.contextTokens} including the answer). " +
                "Shorten it or work on it in parts.")
        val maxOut = minOf(req.maxTokens, room - 16).coerceAtLeast(MIN_ANSWER_TOKENS)
        val t0 = System.currentTimeMillis()
        val out = runtime.generate(LocalRequest(req.system, req.user, maxOut, req.temperature.coerceIn(0.0, 1.0)), cancel, status)
        val text = PlainText.stripMarkers(OpenAiCompatProvider.stripThinking(out.text))
        return LlmReply(text, truncated = out.reachedLimit, model = out.modelLabel, provider = ID,
            latencyMs = System.currentTimeMillis() - t0, completionTokens = out.pieces, notes = out.notes)
    }
}
