package org.tribhasa.app.core

/**
 * Local (non-AI) metrical scan of Sanskrit verse. Weighs each syllable (laghu "L" / guru "G")
 * from the Devanagari text and compares the result with the standard varṇavṛtta patterns.
 * The AI's claim about chandas is checked against this scan.
 */
object Prosody {
    data class Syllable(val iast: String, val heavy: Boolean)

    private fun isCons(c: Int) = c in 0x0915..0x0939 || c in 0x0958..0x095F
    private val LONG_INDEP = setOf(0x0906, 0x0908, 0x090A, 0x0960, 0x0961, 0x090F, 0x0910, 0x0913, 0x0914)
    private val SHORT_INDEP = setOf(0x0905, 0x0907, 0x0909, 0x090B, 0x090C, 0x090E, 0x0912)
    private val LONG_MATRA = setOf(0x093E, 0x0940, 0x0942, 0x0944, 0x0963, 0x0947, 0x0948, 0x094B, 0x094C)
    private val SHORT_MATRA = setOf(0x093F, 0x0941, 0x0943, 0x0962, 0x0946, 0x094A)

    private class Nucleus(var long: Boolean, var mark: Boolean, var consAfter: Int, val onset: String, var vowelIast: String)

    /** Splits Devanagari text into syllables (akṣaras) with laghu/guru weight. */
    fun syllabify(devanagari: String): List<Syllable> {
        val s = Scripts.nfc(devanagari)
        val nuclei = ArrayList<Nucleus>()
        var consRun = 0
        val cluster = StringBuilder() // consonants (IAST) seen since the last vowel
        var i = 0
        val n = s.length
        fun newVowel(long: Boolean, vowel: String) {
            if (nuclei.isNotEmpty()) nuclei.last().consAfter = consRun
            consRun = 0
            nuclei.add(Nucleus(long, false, 0, cluster.toString(), vowel))
            cluster.setLength(0)
        }
        while (i < n) {
            val c = s[i].code
            when {
                isCons(c) -> {
                    consRun++
                    cluster.append(Translit.consonantIast(c) ?: "")
                    i++
                    if (i < n && s[i].code == 0x093C) i++
                    val d = if (i < n) s[i].code else -1
                    when {
                        d in LONG_MATRA -> { newVowel(true, Translit.matraIast(d) ?: ""); i++ }
                        d in SHORT_MATRA -> { newVowel(false, Translit.matraIast(d) ?: ""); i++ }
                        d == 0x094D -> i++            // virama: consonant joins the cluster, no vowel
                        else -> newVowel(false, "a")  // inherent a
                    }
                }
                c in LONG_INDEP -> { newVowel(true, Translit.indepVowelIast(c) ?: ""); i++ }
                c in SHORT_INDEP -> { newVowel(false, Translit.indepVowelIast(c) ?: ""); i++ }
                c == 0x0902 || c == 0x0903 || c == 0x0901 -> {
                    if (nuclei.isNotEmpty()) {
                        val nu = nuclei.last()
                        if (c != 0x0901) nu.mark = true
                        nu.vowelIast += when (c) { 0x0902 -> "ṃ"; 0x0903 -> "ḥ"; else -> "m\u0310" }
                    }
                    i++
                }
                else -> i++
            }
        }
        if (nuclei.isNotEmpty()) nuclei.last().consAfter = consRun
        return nuclei.map { nu -> Syllable(nu.onset + nu.vowelIast, nu.long || nu.mark || nu.consAfter >= 2) }
    }

    // ---------- Metre patterns (G = guru, L = laghu). Last syllable of a pāda is free (anceps). ----------
    private data class Metre(val name: String, val pattern: String, val note: String = "")

    private fun gana(vararg g: String): String = g.joinToString("") {
        when (it) {
            "ya" -> "LGG"; "ma" -> "GGG"; "ta" -> "GGL"; "ra" -> "GLG"; "ja" -> "LGL"
            "bha" -> "GLL"; "na" -> "LLL"; "sa" -> "LLG"; "la" -> "L"; "ga" -> "G"
            else -> error(it)
        }
    }

    private val METRES = listOf(
        Metre("indravajrā", gana("ta", "ta", "ja", "ga", "ga")),
        Metre("upendravajrā", gana("ja", "ta", "ja", "ga", "ga")),
        Metre("vaṃśastha", gana("ja", "ta", "ja", "ra")),
        Metre("drutavilambita", gana("na", "bha", "bha", "ra")),
        Metre("toṭaka", gana("sa", "sa", "sa", "sa")),
        Metre("bhujaṅgaprayāta", gana("ya", "ya", "ya", "ya")),
        Metre("rathoddhatā", gana("ra", "na", "ra", "la", "ga")),
        Metre("śālinī", gana("ma", "ta", "ta", "ga", "ga")),
        Metre("rucirā", gana("ja", "bha", "sa", "ja", "ga")),
        Metre("praharṣiṇī", gana("ma", "na", "ja", "ra", "ga")),
        Metre("vasantatilakā", gana("ta", "bha", "ja", "ja", "ga", "ga")),
        Metre("mālinī", gana("na", "na", "ma", "ya", "ya")),
        Metre("mandākrāntā", gana("ma", "bha", "na", "ta", "ta", "ga", "ga")),
        Metre("śikhariṇī", gana("ya", "ma", "na", "sa", "bha", "la", "ga")),
        Metre("pṛthvī", gana("ja", "sa", "ja", "sa", "ya", "la", "ga")),
        Metre("hariṇī", gana("na", "sa", "ma", "ra", "sa", "la", "ga")),
        Metre("śārdūlavikrīḍita", gana("ma", "sa", "ja", "sa", "ta", "ta", "ga")),
        Metre("sragdharā", gana("ma", "ra", "bha", "na", "ya", "ya", "ya")),
    )

    data class Scan(
        val padaCount: Int,
        val syllableCounts: List<Int>,
        val patterns: List<String>,
        /** Best identification, or null if nothing fits. */
        val name: String?,
        /** True when every pāda fits the named metre (final syllable free). */
        val exact: Boolean,
        val detail: String,
    )

    /** Strips verse numbers and splits into pāda-chunks. */
    fun splitIntoPadas(devanagari: String): List<List<Syllable>> {
        var t = Scripts.nfc(devanagari)
        t = t.replace(Regex("[०-९0-9]+(\\s*[.\\-]\\s*[०-९0-9]+)*"), " ")
        val chunks = t.split(Regex("[।॥|\\n]+")).map { it.trim() }.filter { it.isNotEmpty() && syllabify(it).isNotEmpty() }
        val sylls = chunks.map { syllabify(it) }
        return when (sylls.size) {
            4 -> sylls
            2 -> sylls.flatMap { half ->
                if (half.size % 2 == 0) listOf(half.subList(0, half.size / 2), half.subList(half.size / 2, half.size))
                else listOf(half)
            }
            1 -> {
                val all = sylls[0]
                if (all.size % 4 == 0) all.chunked(all.size / 4) else listOf(all)
            }
            else -> sylls
        }
    }

    private fun pat(sy: List<Syllable>) = sy.joinToString("") { if (it.heavy) "G" else "L" }

    private fun fits(pattern: String, actual: String): Boolean {
        if (pattern.length != actual.length) return false
        for (i in 0 until pattern.length - 1) if (pattern[i] != actual[i]) return false
        return true // last syllable is free
    }

    private fun mismatches(pattern: String, actual: String): Int {
        if (pattern.length != actual.length) return Int.MAX_VALUE
        var m = 0
        for (i in 0 until pattern.length - 1) if (pattern[i] != actual[i]) m++
        return m
    }

    fun scan(devanagari: String): Scan {
        val padas = splitIntoPadas(devanagari)
        if (padas.isEmpty()) return Scan(0, emptyList(), emptyList(), null, false, "No syllables found.")
        val pats = padas.map { pat(it) }
        val counts = padas.map { it.size }
        val allEqual = counts.distinct().size == 1

        // Āryā: mātrā counts 12 / 18 / 12 / 15 (guru = 2, laghu = 1)
        if (padas.size == 4) {
            val m = padas.map { p -> p.sumOf { if (it.heavy) 2 else 1 } }
            if (m == listOf(12, 18, 12, 15)) {
                return Scan(4, counts, pats, "āryā", true, "Mātrā counts per pāda are 12-18-12-15, as in āryā.")
            }
        }
        if (!allEqual) {
            return Scan(padas.size, counts, pats, null, false,
                "Pādas have unequal syllable counts ${counts.joinToString("/")}; no varṇavṛtta with equal pādas fits (could be a mātrā-metre or a mis-split verse).")
        }
        val len = counts[0]
        if (len == 8) {
            // anuṣṭubh: 5th laghu, 6th guru; 7th guru in pādas 1,3 and laghu in 2,4 (pathyā)
            val ok56 = pats.all { it[4] == 'L' && it[5] == 'G' }
            val pathya = pats.withIndex().all { (i, p) -> if (i % 2 == 0) p[6] == 'G' else p[6] == 'L' }
            val d = when {
                ok56 && pathya -> "Each pāda has 8 syllables; 5th laghu, 6th guru and the 7th alternates guru/laghu — regular (pathyā) anuṣṭubh."
                ok56 -> "Each pāda has 8 syllables with 5th laghu and 6th guru; the 7th syllable departs from the pathyā pattern (a permitted variant of anuṣṭubh)."
                else -> "Each pāda has 8 syllables (anuṣṭubh length), but the 5th/6th syllables do not follow the usual laghu-guru rule; treat as anuṣṭubh-like with irregularities."
            }
            return Scan(padas.size, counts, pats, "anuṣṭubh (śloka)", ok56, d)
        }
        // exact varṇavṛtta match (all pādas)
        for (m in METRES) {
            if (pats.all { fits(m.pattern, it) }) {
                return Scan(padas.size, counts, pats, m.name, true, "All ${padas.size} pādas have $len syllables and match the ${m.name} pattern (last syllable of each pāda free).")
            }
        }
        // upajāti: pādas each fit indravajrā or upendravajrā
        val indra = METRES.first { it.name == "indravajrā" }.pattern
        val upendra = METRES.first { it.name == "upendravajrā" }.pattern
        if (len == 11 && pats.all { fits(indra, it) || fits(upendra, it) }) {
            return Scan(padas.size, counts, pats, "upajāti (indravajrā / upendravajrā)", true, "Each pāda fits indravajrā or upendravajrā; the mixture is called upajāti.")
        }
        // nearest
        val near = METRES.filter { it.pattern.length == len }
            .map { m -> m to pats.sumOf { p -> mismatches(m.pattern, p).let { x -> if (x == Int.MAX_VALUE) 99 else x } } }
            .minByOrNull { it.second }
        val generic = when (len) { 11 -> "triṣṭubh-type (11 syllables)"; 12 -> "jagatī-type (12 syllables)"; else -> null }
        val detail = StringBuilder("Pādas have $len syllables each, but the laghu-guru pattern matches none of the standard patterns exactly.")
        if (near != null && near.second <= padas.size * 2) detail.append(" Nearest: ${near.first.name} (${near.second} syllable(s) differ across the verse).")
        return Scan(padas.size, counts, pats, generic, false, detail.toString())
    }
}
