package org.tribhasa.app.core

import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Runs the same piece of text through several models, one after another, with the real pipeline of the app,
 * so that the scholar can read the answers side by side and choose a model. It scores nothing by itself:
 * a machine cannot judge whether a Kannada rendering is Granthika or whether a pada-cheda is right.
 */
object ModelCompare {
    enum class Task(val label: String, val blurb: String) {
        TRANSLATE("Translation", "One of the six directions, using the AI model only (not IndicTrans2)."),
        SLOKA("Śloka analysis", "Padaccheda, grammar, anvaya, metre and the rest, with the app's own metre check."),
        PROSE("Prose analysis", "Sentences, word forms, compounds and translation."),
        GRAMMAR("Sanskrit grammar, in Sanskrit", "Grammatical commentary written in Sanskrit."),
        COMMENTARY("Sanskrit commentary, all parts", "Paraphrase, grammar and word meanings in Sanskrit."),
    }

    class Outcome(
        val model: String,
        val servedBy: String,
        val ok: Boolean,
        val text: String,
        val error: String?,
        val millis: Long,
        /** Warnings and failures in the app's own Quality Control Report for this answer. */
        val qcWarnings: Int,
        /** Number of HTTP requests actually sent (retries included): these count against a free daily allowance. */
        val requests: Int,
    )

    /** Counts the requests and the time spent in the service. */
    private class Counting(private val inner: LlmProvider) : LlmProvider {
        override val id get() = inner.id
        override val label get() = inner.label
        val calls = AtomicInteger(0)
        /** Requests really sent: the provider's own count when it keeps one, otherwise the number of calls made. */
        fun requestCount(): Int = (inner as? OpenAiCompatProvider)?.requestsSent?.get() ?: calls.get()
        val served = java.util.concurrent.atomic.AtomicReference("")
        val ms = AtomicLong(0)
        override fun generate(req: LlmRequest, cancel: CancelToken): LlmReply {
            calls.incrementAndGet()
            val r = inner.generate(req, cancel)
            ms.addAndGet(r.latencyMs)
            served.set(r.model)
            return r
        }
    }

    fun explain(e: Throwable): String = when (e) {
        is ServiceFailure -> e.message ?: "The service failed."
        is AttemptsExhausted -> e.last.message ?: "The service failed."
        is EngineException -> e.message ?: "The service failed."
        else -> "${e.javaClass.simpleName}: ${e.message}"
    }

    fun run(
        task: Task, text: String, direction: Direction, out: Lang, creds: Credentials, model: String,
        cancel: CancelToken, retry: RetryPolicy = RetryPolicy(maxAttempts = 2), progress: (String) -> Unit = {},
        make: (Credentials, String) -> LlmProvider = { c, m -> ServiceFactory.provider(c, m) },
    ): Outcome {
        val t0 = System.nanoTime()
        fun took() = (System.nanoTime() - t0) / 1_000_000
        var counting: Counting? = null
        fun sent() = counting?.requestCount() ?: 0
        return try {
            val cnt = Counting(make(creds, model)); counting = cnt
            val router = LlmRouter(listOf(cnt), retry)
            val svc = TranslationService(listOf(LlmTranslationEngine(router)), router, retry)
            val scholar = ScholarService(router, svc)
            // Granthika polishing would double the requests, so it is left out of the comparison.
            val opts = Options(allowLlmFallback = true, granthikaPolish = false, britishSpelling = true, autoGlossaryFix = false)
            val (body, qc) = when (task) {
                Task.TRANSLATE -> {
                    val job = svc.newJob(text, direction, opts, emptyList())
                    val r = svc.run(job, cancel, progress)
                    r.output to r.qc
                }
                Task.SLOKA -> scholar.analyseSloka(text, out, cancel, progress).let { (it.doc?.toPlain() ?: it.text ?: "") to it.qc }
                Task.PROSE -> scholar.analyseProse(text, out, cancel, progress).let { (it.doc?.toPlain() ?: it.text ?: "") to it.qc }
                Task.GRAMMAR -> scholar.commentary(text, Prompts.CommentaryPart.GRAMMAR, cancel, progress).let { (it.doc?.toPlain() ?: it.text ?: "") to it.qc }
                Task.COMMENTARY -> scholar.commentary(text, Prompts.CommentaryPart.ALL, cancel, progress).let { (it.doc?.toPlain() ?: it.text ?: "") to it.qc }
            }
            val served = cnt.served.get().ifBlank { model }
            if (body.isBlank()) Outcome(model, served, false, "", "The model answered, but nothing usable could be read from it.", took(), qc.warnings, sent())
            else Outcome(model, served, true, body, null, took(), qc.warnings, sent())
        } catch (e: Throwable) {
            val c = (e as? EngineException)?.kind == FailKind.CANCELLED || (e as? AttemptsExhausted)?.kind == FailKind.CANCELLED || (e as? ServiceFailure)?.allCancelled == true
            Outcome(model, counting?.served?.get()?.ifBlank { model } ?: model, false, "", if (c) "Cancelled." else explain(e), took(), 0, sent())
        }
    }

    /** Short sample inputs. They are plain, widely known, or written for this test, so no one's rights are involved. */
    class Sample(val label: String, val task: Task, val text: String, val src: Lang)

    val SAMPLES: List<Sample> = listOf(
        Sample("Simple Sanskrit sentence", Task.TRANSLATE, "अहं पुस्तकं पठामि।", Lang.SA),
        Sample("Gītā 2.47 (verse)", Task.SLOKA, "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥", Lang.SA),
        Sample("Short Sanskrit prose", Task.PROSE, "कश्चित् वृद्धः ब्राह्मणः ग्रामं गतवान्। सः तत्र पाठशालाम् अपश्यत्।", Lang.SA),
        Sample("Simple Kannada sentence", Task.TRANSLATE, "ನಾನು ಪುಸ್ತಕವನ್ನು ಓದುತ್ತೇನೆ.", Lang.KN),
        Sample("Simple English sentence", Task.TRANSLATE, "Knowledge is the supreme wealth.", Lang.EN),
    )
}
