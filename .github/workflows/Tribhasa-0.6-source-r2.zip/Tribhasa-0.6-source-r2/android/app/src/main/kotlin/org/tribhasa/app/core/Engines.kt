package org.tribhasa.app.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Credentials and settings entered by the user on the phone. Never part of the app's source code. */
data class Credentials(
    /** Where the AI runs. The default is on this phone; the online services are used only when the user chose them. */
    val aiSource: AiSource = AiSource.LOCAL,
    val bhashiniUserId: String = "",
    val bhashiniKey: String = "",
    val cfAccountId: String = "",
    val cfToken: String = "",
    /** The user's own OpenRouter key (normally handed to the app by the sign-in), or the token of their own secure backend. */
    val llmKey: String = "",
    val llmModel: String = Models.DEFAULT_MODEL,
    val llmBaseUrl: String = Models.OPENROUTER_BASE,
    val allowPaid: Boolean = false,
    val denyDataCollection: Boolean = false,
    val thinking: String = Models.Think.LOW.name,
    /** True when [llmKey] was handed to the app by OpenRouter's own sign-in. Such a key is only ever sent to OpenRouter. */
    val llmKeyFromSignIn: Boolean = false,
    /** Optional second model, tried only when the first keeps failing. Empty means no back-up (the default). */
    val fallbackModel: String = "",
) {
    val hasBhashini get() = bhashiniUserId.isNotBlank() && bhashiniKey.isNotBlank()
    val hasCloudflare get() = cfAccountId.isNotBlank() && cfToken.isNotBlank()
    val hasLlm get() = llmKey.isNotBlank() && llmModel.isNotBlank()
}

data class Options(
    val allowLlmFallback: Boolean = true,
    val granthikaPolish: Boolean = true,
    val britishSpelling: Boolean = true,
    val autoGlossaryFix: Boolean = false,
)

/** A running log of what the services did; used for the status line and the Quality report. */
class Trace {
    val log = ArrayList<String>()
    var retries = 0
    var failovers = 0
    val used = LinkedHashMap<String, Int>()
    /** True once any answer in this task came from the model that runs on this phone. */
    @Volatile var onDevice = false
    @Volatile var onDeviceLabel = ""
    /** Low-confidence findings raised while the task ran; each one becomes a warning in the Quality report. */
    val flags = ArrayList<String>()
    /** Where live progress text goes (the status line on screen). Providers that can report progress use it. */
    @Volatile var statusSink: (String) -> Unit = {}
    fun note(s: String) { synchronized(log) { log.add(s) } }
    fun use(label: String, n: Int) { used[label] = (used[label] ?: 0) + n }
    fun flag(s: String) { synchronized(flags) { if (s !in flags) flags.add(s) } }
}

interface TranslationEngine {
    val id: String
    val label: String
    /** True only when the engine is AI4Bharat IndicTrans2 (so the report never mislabels another model). */
    val isIndicTrans2: Boolean
    val maxChars: Int
    val batchSize: Int
    fun supports(d: Direction): Boolean
    /**
     * Translate [texts] (already segmented). Returns one output per input, in order.
     * [glossary] holds the scholar's preferred renderings that occur in these texts; an engine that takes a prompt passes them on,
     * a machine-translation service (which cannot) ignores them, and the service checks the result afterwards either way.
     */
    fun translate(texts: List<String>, d: Direction, cancel: CancelToken, trace: Trace, glossary: List<GlossaryEntry> = emptyList()): List<String>
    /** A short description of the exact model/service for reports, available after first use. */
    fun describe(d: Direction): String
}

// ---------------------------------------------------------------------------------------------
// Bhashini / Dhruva (hosts AI4Bharat IndicTrans v2). Two-step API: pipeline config, then compute.
// ---------------------------------------------------------------------------------------------
class BhashiniEngine(
    private val userId: String,
    private val ulcaKey: String,
    private val configUrl: String = CONFIG_URL,
    private val pipelineIds: List<String> = listOf(PIPELINE_MEITY, PIPELINE_AI4BHARAT),
) : TranslationEngine {
    override val id = "bhashini"
    override val label = "Bhashini (AI4Bharat IndicTrans2)"
    override val isIndicTrans2 = true
    override val maxChars = 380
    override val batchSize = 5

    class Route(val callbackUrl: String, val headerName: String, val headerValue: String, val serviceId: String)

    private val routes = ConcurrentHashMap<String, Route>()

    override fun supports(d: Direction) = d.valid

    override fun describe(d: Direction): String {
        val r = routes[key(d)]
        return if (r != null) "Bhashini service ${r.serviceId}" else "Bhashini"
    }

    private fun key(d: Direction) = d.src.bhashini + ">" + d.tgt.bhashini

    /** Looks up (and caches) which hosted model Bhashini offers for this pair. */
    fun route(d: Direction, cancel: CancelToken, force: Boolean = false): Route {
        if (!force) routes[key(d)]?.let { return it }
        var lastError: EngineException? = null
        var sawNoModel = false
        for (pid in pipelineIds) {
            val body = JSONObject()
                .put("pipelineTasks", JSONArray().put(JSONObject()
                    .put("taskType", "translation")
                    .put("config", JSONObject().put("language", JSONObject()
                        .put("sourceLanguage", d.src.bhashini).put("targetLanguage", d.tgt.bhashini)))))
                .put("pipelineRequestConfig", JSONObject().put("pipelineId", pid))
            val resp = Http.request("POST", configUrl,
                mapOf("userID" to userId, "ulcaApiKey" to ulcaKey), body.toString(), cancel)
            if (resp.code !in 200..299) {
                val ex = Http.failure(resp, "Bhashini")
                // A pair that this pipeline does not offer is reported as 4xx; try the next pipeline.
                if (ex.kind == FailKind.BAD_REQUEST || ex.kind == FailKind.BAD_RESPONSE) { lastError = ex; sawNoModel = true; continue }
                throw ex
            }
            val root = JsonUtil.parseObject(resp.body)
                ?: throw EngineException(FailKind.BAD_RESPONSE, "Bhashini sent a reply that could not be read.", resp.code)
            val route = parseRoute(root, d)
            if (route != null) { routes[key(d)] = route; return route }
            sawNoModel = true
        }
        if (sawNoModel) {
            throw EngineException(FailKind.UNSUPPORTED,
                "Bhashini does not currently list a translation model for ${d.label}." + (lastError?.message?.let { " ($it)" } ?: ""))
        }
        throw lastError ?: EngineException(FailKind.BAD_RESPONSE, "Bhashini did not return a usable configuration.")
    }

    internal fun parseRoute(root: JSONObject, d: Direction): Route? {
        val ep = JsonUtil.obj(root, "pipelineInferenceAPIEndPoint") ?: return null
        val callback = JsonUtil.str(ep, "callbackUrl")
        val keyObj = JsonUtil.obj(ep, "inferenceApiKey")
        val hName = JsonUtil.str(keyObj, "name").ifBlank { "Authorization" }
        val hValue = JsonUtil.str(keyObj, "value")
        if (callback.isBlank() || hValue.isBlank()) return null
        val configs = ArrayList<JSONObject>()
        for (task in JsonUtil.objList(root, "pipelineResponseConfig")) {
            val tt = JsonUtil.str(task, "taskType")
            if (tt.isNotBlank() && tt != "translation") continue
            configs.addAll(JsonUtil.objList(task, "config"))
        }
        val matching = configs.filter { c ->
            val lang = JsonUtil.obj(c, "language")
            lang == null || (JsonUtil.str(lang, "sourceLanguage") == d.src.bhashini && JsonUtil.str(lang, "targetLanguage") == d.tgt.bhashini)
        }.filter { JsonUtil.str(it, "serviceId").isNotBlank() }
        val pick = matching.firstOrNull { JsonUtil.str(it, "serviceId").contains("indictrans", ignoreCase = true) } ?: matching.firstOrNull()
            ?: return null
        return Route(callback, hName, hValue, JsonUtil.str(pick, "serviceId"))
    }

    override fun translate(texts: List<String>, d: Direction, cancel: CancelToken, trace: Trace, glossary: List<GlossaryEntry>): List<String> {
        var route = route(d, cancel)
        var refreshed = false
        while (true) {
            try {
                return compute(route, texts, d, cancel)
            } catch (e: EngineException) {
                // A stale inference key is the usual reason for 401 after hours of use: refresh once.
                if (e.kind == FailKind.AUTH && !refreshed) {
                    refreshed = true
                    trace.note("Bhashini: refreshing the service key and trying again.")
                    route = route(d, cancel, force = true)
                    continue
                }
                throw e
            }
        }
    }

    private fun compute(route: Route, texts: List<String>, d: Direction, cancel: CancelToken): List<String> {
        val inputs = JSONArray()
        for (t in texts) inputs.put(JSONObject().put("source", t))
        val body = JSONObject()
            .put("pipelineTasks", JSONArray().put(JSONObject()
                .put("taskType", "translation")
                .put("config", JSONObject()
                    .put("language", JSONObject().put("sourceLanguage", d.src.bhashini).put("targetLanguage", d.tgt.bhashini))
                    .put("serviceId", route.serviceId))))
            .put("inputData", JSONObject().put("input", inputs))
        val resp = Http.request("POST", route.callbackUrl, mapOf(route.headerName to route.headerValue), body.toString(), cancel)
        if (resp.code !in 200..299) throw Http.failure(resp, "Bhashini")
        val root = JsonUtil.parseObject(resp.body)
            ?: throw EngineException(FailKind.BAD_RESPONSE, "Bhashini sent a reply that could not be read.", resp.code)
        val out = ArrayList<String>()
        for (task in JsonUtil.objList(root, "pipelineResponse")) {
            val tt = JsonUtil.str(task, "taskType")
            if (tt.isNotBlank() && tt != "translation") continue
            for (o in JsonUtil.objList(task, "output")) out.add(JsonUtil.str(o, "target"))
            break
        }
        if (out.size != texts.size)
            throw EngineException(FailKind.BAD_RESPONSE, "Bhashini returned ${out.size} translations for ${texts.size} sentences.", resp.code)
        if (out.any { it.isBlank() } )
            throw EngineException(FailKind.BAD_RESPONSE, "Bhashini returned an empty translation.", resp.code)
        return out
    }

    /** For the Settings "Test connection" button: which of the six directions does Bhashini offer? */
    fun probeDirections(cancel: CancelToken): List<Pair<Direction, String?>> =
        Direction.ALL.map { d ->
            try { val r = route(d, cancel); d to r.serviceId } catch (e: EngineException) {
                if (e.kind == FailKind.AUTH || e.kind == FailKind.NETWORK || e.kind == FailKind.TIMEOUT) throw e
                d to null
            }
        }

    companion object {
        const val CONFIG_URL = "https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline"
        const val PIPELINE_MEITY = "64392f96daac500b55c543cd"
        const val PIPELINE_AI4BHARAT = "643930aa521a4b1ba0f4c41d"
    }
}

// ---------------------------------------------------------------------------------------------
// Cloudflare Workers AI hosting of AI4Bharat IndicTrans2 (English -> Indic only).
// ---------------------------------------------------------------------------------------------
class CloudflareIndicEngine(
    private val accountId: String,
    private val token: String,
    private val baseUrl: String = "https://api.cloudflare.com/client/v4",
) : TranslationEngine {
    override val id = "cloudflare"
    override val label = "Cloudflare (AI4Bharat IndicTrans2 1B)"
    override val isIndicTrans2 = true
    override val maxChars = 380
    override val batchSize = 1

    override fun supports(d: Direction) = d.src == Lang.EN && (d.tgt == Lang.SA || d.tgt == Lang.KN)
    override fun describe(d: Direction) = "Cloudflare Workers AI @cf/ai4bharat/indictrans2-en-indic-1B"

    override fun translate(texts: List<String>, d: Direction, cancel: CancelToken, trace: Trace, glossary: List<GlossaryEntry>): List<String> {
        if (!supports(d)) throw EngineException(FailKind.UNSUPPORTED, "Cloudflare's IndicTrans2 only translates from English.")
        return texts.map { one(it, d, cancel) }
    }

    private fun one(text: String, d: Direction, cancel: CancelToken): String {
        val url = "$baseUrl/accounts/$accountId/ai/run/@cf/ai4bharat/indictrans2-en-indic-1B"
        val body = JSONObject().put("text", text).put("target_language", d.tgt.flores)
        val resp = Http.request("POST", url, mapOf("Authorization" to "Bearer $token"), body.toString(), cancel)
        if (resp.code !in 200..299) throw Http.failure(resp, "Cloudflare")
        val root = JsonUtil.parseObject(resp.body)
            ?: throw EngineException(FailKind.BAD_RESPONSE, "Cloudflare sent a reply that could not be read.", resp.code)
        if (root.has("success") && !root.optBoolean("success", true))
            throw EngineException(FailKind.BAD_REQUEST, "Cloudflare reported an error: " + JsonUtil.errorMessage(resp.body), resp.code)
        val result = JsonUtil.obj(root, "result") ?: root
        val tr = result.opt("translations")
        val s = when (tr) {
            is JSONArray -> (0 until tr.length()).joinToString(" ") { tr.opt(it)?.toString() ?: "" }
            is String -> tr
            else -> JsonUtil.str(result, "translation").ifBlank { JsonUtil.str(result, "response") }
        }.trim()
        if (s.isBlank()) throw EngineException(FailKind.BAD_RESPONSE, "Cloudflare returned an empty translation.", resp.code)
        return s
    }
}

// ---------------------------------------------------------------------------------------------
// General AI model used as translator (clearly labelled "not IndicTrans2").
// ---------------------------------------------------------------------------------------------
class LlmTranslationEngine(
    private val llm: LlmRouter,
    /** Segment size, batch size and answer length. The defaults suit large online models; the on-device model uses smaller ones. */
    override val maxChars: Int = 1200,
    override val batchSize: Int = 3,
    private val maxTokens: Int = 8192,
    /** For a small model that often ignores the requested format: a single plain-text answer is accepted, and flagged. */
    private val acceptPlainSingle: Boolean = false,
) : TranslationEngine {
    override val id = "llm"
    override val label = "AI model (not IndicTrans2)"
    override val isIndicTrans2 = false
    private var lastModel = ""

    override fun supports(d: Direction) = d.valid
    override fun describe(d: Direction) = if (lastModel.isNotBlank()) "General AI model $lastModel (not IndicTrans2)" else "General AI model (not IndicTrans2)"

    override fun translate(texts: List<String>, d: Direction, cancel: CancelToken, trace: Trace, glossary: List<GlossaryEntry>): List<String> {
        val sys = Prompts.translationSystem(d)
        val user = Prompts.translationUser(texts, glossary, d)
        val reply = llm.generate(LlmRequest(sys, user, json = true, maxTokens = maxTokens, temperature = 0.1), cancel, trace)
        lastModel = reply.model
        if (reply.truncated) throw EngineException(FailKind.BAD_RESPONSE, "The AI model's answer was cut off.")
        val o = JsonUtil.extractObject(reply.text)
        val arr = JsonUtil.arr(o, "translations")
        val out = ArrayList<String>()
        if (arr != null) for (i in 0 until arr.length()) out.add(arr.opt(i)?.toString()?.trim() ?: "")
        else if (acceptPlainSingle && texts.size == 1) {
            val plain = PlainText.clean(reply.text)
            if (plain.isNotBlank()) {
                trace.flag("The model did not answer in the requested format for one part; its plain-text answer was accepted without that safeguard.")
                out.add(plain)
            }
        }
        if (out.size != texts.size || out.any { it.isBlank() })
            throw EngineException(FailKind.BAD_RESPONSE, "The AI model did not return one translation per sentence.")
        return out
    }
}
