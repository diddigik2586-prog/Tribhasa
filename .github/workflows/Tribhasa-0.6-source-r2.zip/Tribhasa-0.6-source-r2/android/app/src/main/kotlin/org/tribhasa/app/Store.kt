package org.tribhasa.app

import java.io.File

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.tribhasa.app.core.AiSource
import org.tribhasa.app.core.Credentials
import org.tribhasa.app.core.LocalBackend
import org.tribhasa.app.core.Glossary
import org.tribhasa.app.core.GlossaryEntry
import org.tribhasa.app.core.Options
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Keys typed by the user are stored encrypted with a key that lives in the Android Keystore. */
object Secrets {
    private const val ALIAS = "tribhasa_secret_key_v1"
    private const val PLAIN = "p:"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        if (!ks.containsAlias(ALIAS)) {
            val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            g.init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            g.generateKey()
        }
        return ks.getKey(ALIAS, null) as SecretKey
    }

    /** True when [stored] was kept without the keystore (base64 only, in the app's private storage). */
    fun isPlainFallback(stored: String) = stored.startsWith(PLAIN)

    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val iv = c.iv
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) {
            // Keystore unavailable on this phone: fall back to the app's private storage (still sandboxed by Android).
            PLAIN + Base64.encodeToString(plain.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    fun decrypt(stored: String): String {
        if (stored.isEmpty()) return ""
        return try {
            if (stored.startsWith(PLAIN)) return String(Base64.decode(stored.removePrefix(PLAIN), Base64.NO_WRAP), Charsets.UTF_8)
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            val iv = raw.copyOfRange(0, 12)
            val ct = raw.copyOfRange(12, raw.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            "" // unreadable (for example after a restore to another phone): treat as not set
        }
    }
}

class Store(ctx: Context) {
    private val dir: File = ctx.applicationContext.filesDir
    private val p: SharedPreferences = ctx.applicationContext.getSharedPreferences("tribhasa", Context.MODE_PRIVATE)

    init {
        // Version 0.2 could keep a Gemini key and a Cloudflare chat-model name. This version uses neither, so any
        // such leftovers are erased rather than left sitting on the phone.
        p.edit().remove("s_g_key").remove("g_model").remove("cf_llm").apply()
    }

    // --- credentials ---
    private fun sec(k: String) = Secrets.decrypt(p.getString("s_$k", "") ?: "")
    private fun setSec(k: String, v: String) { p.edit().putString("s_$k", Secrets.encrypt(v.trim())).apply() }

    fun credentials(): Credentials {
        val d = Credentials()
        return Credentials(
            aiSource = aiSource(),
            bhashiniUserId = sec("b_uid"), bhashiniKey = sec("b_key"),
            cfAccountId = sec("cf_acc"), cfToken = sec("cf_tok"),
            llmKey = sec("llm_key"),
            llmModel = (p.getString("llm_model", d.llmModel) ?: d.llmModel).ifBlank { d.llmModel },
            llmBaseUrl = (p.getString("llm_base", d.llmBaseUrl) ?: d.llmBaseUrl).ifBlank { d.llmBaseUrl },
            allowPaid = p.getBoolean("llm_paid", false),
            denyDataCollection = p.getBoolean("llm_deny", false),
            thinking = p.getString("llm_think", d.thinking) ?: d.thinking,
            llmKeyFromSignIn = p.getString("llm_key_src", "") == "signin" && sec("llm_key").isNotBlank(),
            fallbackModel = p.getString("llm_backup", "") ?: "",
        )
    }

    // --- where the AI runs, and the on-phone model's settings ---
    /** On this phone unless the user chose Online. Never switched by the app itself. */
    fun aiSource(): AiSource = AiSource.fromName(p.getString("ai_source", null))
    fun setAiSource(s: AiSource) { p.edit().putString("ai_source", s.name).apply() }
    fun localBackend(): String = p.getString("local_backend", LocalBackend.CPU.name) ?: LocalBackend.CPU.name
    fun setLocalBackend(b: LocalBackend) { p.edit().putString("local_backend", b.name).apply() }
    /** Download the model only on a connection that is not metered. On by default: the file is 2.6 GB. */
    fun localWifiOnly(): Boolean = p.getBoolean("local_wifi_only", true)
    fun setLocalWifiOnly(v: Boolean) { p.edit().putBoolean("local_wifi_only", v).apply() }

    enum class Protection { NONE, KEYSTORE, PRIVATE_STORAGE_ONLY }

    /** How the saved AI key is kept: encrypted with the phone's keystore, or (if the keystore failed) only in the app's private storage. */
    fun llmKeyProtection(): Protection {
        val raw = p.getString("s_llm_key", "") ?: ""
        return when {
            raw.isEmpty() -> Protection.NONE
            Secrets.isPlainFallback(raw) -> Protection.PRIVATE_STORAGE_ONLY
            else -> Protection.KEYSTORE
        }
    }

    /** The truth about how the key is kept, in words for the screen. */
    fun llmKeyProtectionText(): String = when (llmKeyProtection()) {
        Protection.KEYSTORE -> "encrypted on this phone"
        Protection.PRIVATE_STORAGE_ONLY -> "kept in this app's private storage; this phone's secure keystore could not be used, so it is NOT encrypted (other apps still cannot read it)"
        Protection.NONE -> "not saved"
    }

    fun setBhashini(uid: String, key: String) { setSec("b_uid", uid); setSec("b_key", key) }
    fun setCloudflare(acc: String, tok: String) { setSec("cf_acc", acc); setSec("cf_tok", tok) }
    /** A key typed or pasted by the user. If it differs from the stored one, it is no longer a sign-in key. */
    fun setLlmKey(key: String) {
        if (key.trim() != sec("llm_key")) p.edit().putString("llm_key_src", "manual").apply()
        setSec("llm_key", key)
    }
    /** The key OpenRouter handed to the app after the user's sign-in. The service address goes back to OpenRouter itself. */
    fun setLlmKeyFromSignIn(key: String) {
        setSec("llm_key", key)
        p.edit().putString("llm_key_src", "signin").putString("llm_base", "").putLong("llm_signin_at", System.currentTimeMillis()).apply()
    }
    fun signedInAt(): Long = if (credentials().llmKeyFromSignIn) p.getLong("llm_signin_at", 0L) else 0L
    /** Forgets the key on this phone. (A key made by sign-in stays listed in the user's OpenRouter account until revoked there.) */
    fun disconnectLlm() { p.edit().remove("s_llm_key").remove("llm_key_src").remove("llm_signin_at").apply() }
    fun setLlmModel(m: String) { p.edit().putString("llm_model", m.trim()).apply() }
    fun setFallbackModel(m: String) { p.edit().putString("llm_backup", m.trim()).apply() }
    fun setLlmBase(u: String) { p.edit().putString("llm_base", u.trim()).apply() }
    fun setAllowPaid(v: Boolean) { p.edit().putBoolean("llm_paid", v).apply() }
    fun setDenyDataCollection(v: Boolean) { p.edit().putBoolean("llm_deny", v).apply() }
    fun setThinking(name: String) { p.edit().putString("llm_think", name).apply() }
    fun clearKeys() {
        p.edit().remove("s_b_uid").remove("s_b_key").remove("s_cf_acc").remove("s_cf_tok").remove("s_llm_key").remove("llm_key_src").remove("llm_signin_at").apply()
    }

    // --- options ---
    fun options() = Options(
        allowLlmFallback = p.getBoolean("o_fallback", true),
        granthikaPolish = p.getBoolean("o_granthika", true),
        britishSpelling = p.getBoolean("o_british", true),
        autoGlossaryFix = p.getBoolean("o_glossfix", false),
    )
    fun setOption(name: String, v: Boolean) { p.edit().putBoolean(name, v).apply() }

    // --- glossary ---
    fun glossary(): List<GlossaryEntry> = Glossary.fromJson(p.getString("glossary", ""))
    fun saveGlossary(list: List<GlossaryEntry>) { p.edit().putString("glossary", Glossary.toJson(list)).apply() }

    // --- drafts (inputs survive the app being closed) ---
    fun draft(k: String): String = p.getString("d_$k", "") ?: ""
    fun setDraft(k: String, v: String) { p.edit().putString("d_$k", v).apply() }
    fun pref(k: String, def: String): String = p.getString("x_$k", def) ?: def
    fun setPref(k: String, v: String) { p.edit().putString("x_$k", v).apply() }

    // --- history: a private file on this phone; no cap and no expiry ---
    private val historyFile get() = File(dir, "history.json")

    @Synchronized
    fun history(): List<org.tribhasa.app.core.HistoryEntry> = try {
        if (historyFile.exists()) org.tribhasa.app.core.History.fromJson(historyFile.readText(Charsets.UTF_8)) else emptyList()
    } catch (e: Exception) { emptyList() }

    @Synchronized
    fun saveHistory(list: List<org.tribhasa.app.core.HistoryEntry>) {
        val tmp = File(dir, "history.json.tmp")
        tmp.writeText(org.tribhasa.app.core.History.toJson(list), Charsets.UTF_8)
        if (!tmp.renameTo(historyFile)) { historyFile.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8); tmp.delete() }
    }

    /** Adds one entry. A history file that cannot be read is set aside, never overwritten. */
    @Synchronized
    fun addHistory(e: org.tribhasa.app.core.HistoryEntry) {
        var current = emptyList<org.tribhasa.app.core.HistoryEntry>()
        if (historyFile.exists()) {
            val text = historyFile.readText(Charsets.UTF_8)
            val parsed = org.tribhasa.app.core.History.parse(text)
            if (parsed == null) historyFile.renameTo(File(dir, "history.unreadable-${System.currentTimeMillis()}.json")) else current = parsed
        }
        saveHistory(org.tribhasa.app.core.History.add(current, e))
    }
}
