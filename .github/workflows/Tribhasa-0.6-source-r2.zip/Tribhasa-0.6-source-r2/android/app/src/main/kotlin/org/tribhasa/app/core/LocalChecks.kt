package org.tribhasa.app.core

/**
 * Checks and notices for answers that came from the small model running on this phone.
 *
 * None of these checks judges whether a translation or analysis is *right*. They catch some obvious failures of a small
 * model (it got stuck repeating itself, it handed the text back unchanged, it ignored the requested format) and say, every
 * time, that the quality for Sanskrit and Kannada has not been tested.
 */
object LocalChecks {
    private const val STANDING_DONE = "Done on this phone"
    private const val STANDING_LOW = "Low confidence by default"

    /** True for the two standing lines, so a combined report can add them once instead of once per step. */
    fun isStanding(text: String) = text.startsWith(STANDING_DONE) || text.startsWith(STANDING_LOW)

    /** Added to every report whose answer came from the on-device model. */
    fun standing(qc: QcReport, trace: Trace) {
        qc.info("$STANDING_DONE by ${trace.onDeviceLabel.ifBlank { "the on-device model" }}. No text was sent over the internet for this.")
        qc.warn("$STANDING_LOW: this is a small model running on a phone. Its quality for Sanskrit and Kannada has not been tested with a Sanskrit evaluation set, " +
            "so read the result as a machine draft and check it yourself.")
        for (f in synchronized(trace.flags) { trace.flags.toList() }) qc.warn(f)
    }

    /** Some obvious signs that a part of a translation went wrong. */
    fun translation(qc: QcReport, sourceParts: List<String>, outputParts: List<String>) {
        var looping = 0; var unchanged = 0
        for (i in outputParts.indices) {
            val out = outputParts[i]
            if (repeats(out)) looping++
            val src = sourceParts.getOrNull(i) ?: continue
            if (src.trim().length >= 20 && Scripts.nfc(out).trim() == Scripts.nfc(src).trim()) unchanged++
        }
        if (looping > 0) qc.warn("$looping part(s) of the answer repeat the same words over and over: the model may have got stuck. Please read those parts carefully, or run the text again.")
        else qc.pass("No part of the answer repeats itself in a loop (simple check).")
        if (unchanged > 0) qc.warn("$unchanged part(s) came back exactly as they were sent, so they were probably not translated.")
    }

    /** A generous test for "stuck in a loop": the same line three times in a row, or the same four words four or more times. */
    fun repeats(text: String): Boolean {
        val lines = text.lines().map { it.trim() }.filter { it.length >= 6 }
        for (i in 0..lines.size - 3) if (lines[i] == lines[i + 1] && lines[i] == lines[i + 2]) return true
        val words = text.split(Regex("[\\s।॥,.;:!?]+")).filter { it.isNotEmpty() }
        if (words.size < 16) return false
        val counts = HashMap<String, Int>()
        for (i in 0..words.size - 4) {
            val k = words.subList(i, i + 4).joinToString(" ")
            val n = (counts[k] ?: 0) + 1
            if (n >= 4) return true
            counts[k] = n
        }
        return false
    }
}
