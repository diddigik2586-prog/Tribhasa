package org.tribhasa.app.core

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.locks.ReentrantLock

// ---------------------------------------------------------------------------------------------
// The only things the library-specific code has to provide. Everything else about running a model on
// this phone (loading once, one task at a time, cancelling, stalls, memory failures, honest messages)
// lives below and is tested on a computer with a fake engine. The real implementation,
// LiteRtEngineFactory, is a thin wrapper around Google's LiteRT-LM library and is the one file that
// can only be exercised on a phone.
// ---------------------------------------------------------------------------------------------

enum class LocalBackend(val label: String) { CPU("CPU"), GPU("GPU");
    companion object { fun fromName(n: String?): LocalBackend = values().firstOrNull { it.name == n } ?: CPU }
}

class NativeFailure(val kind: Kind, message: String, cause: Throwable? = null) : Exception(message, cause) {
    enum class Kind { LOAD, OUT_OF_MEMORY, CONTEXT_FULL, CANCELLED, OTHER }
}

interface NativeListener {
    fun onPiece(text: String)
    fun onDone()
    fun onError(error: NativeFailure)
}

/** One question being answered. [cancel] asks the engine to stop; [close] releases the turn's resources and is always called afterwards. */
interface NativeTurn : AutoCloseable { fun cancel() }

interface NativeEngine : AutoCloseable {
    /** Starts one chat turn and returns at once; the answer arrives through [listener], on any thread. */
    fun start(system: String, user: String, maxOutputTokens: Int, temperature: Double, listener: NativeListener): NativeTurn
}

interface NativeEngineFactory {
    /** Loads the model file into memory. Can take many seconds. Throws [NativeFailure] (kind LOAD or OUT_OF_MEMORY). */
    fun open(modelPath: String, backend: LocalBackend, contextTokens: Int, cacheDir: String): NativeEngine
}

/**
 * Runs the downloaded model through a [NativeEngineFactory].
 *
 *  - Loads the model on first use and keeps it loaded until [unload] (the app does that when Android is short of memory).
 *  - Serves one task at a time; a second task waits (and can be cancelled while waiting).
 *  - Cancel stops the running answer. An engine that goes silent for too long is stopped and dropped.
 *  - If the GPU was chosen and cannot load the model, the CPU is used and that is reported in the notes.
 *  - It never talks to the network and never substitutes another model.
 */
class LocalModelRuntime(
    private val files: () -> LocalModelFiles,
    private val factory: NativeEngineFactory,
    private val backendChoice: () -> LocalBackend,
    private val cacheDir: String,
    private val isDownloading: () -> Boolean = { false },
    private val firstPieceTimeoutMs: Long = 300_000,
    private val silenceTimeoutMs: Long = 120_000,
) : LocalRuntime {
    private val gate = ReentrantLock()
    @Volatile private var engine: NativeEngine? = null
    @Volatile private var engineBackend: LocalBackend = LocalBackend.CPU
    @Volatile private var gpuRefused = false

    override val contextTokens: Int get() = LocalModels.active.contextTokens

    val isLoaded: Boolean get() = engine != null
    val loadedDescription: String get() = if (engine != null) "${LocalModels.active.shortName} loaded (${engineBackend.label})" else "not loaded"

    override fun unavailableReason(): String? {
        val spec = LocalModels.active
        return when (files().state()) {
            LocalModelFiles.State.READY -> null
            LocalModelFiles.State.ABSENT, LocalModelFiles.State.PARTIAL ->
                if (isDownloading()) "The model on this phone is still downloading. Wait until Settings shows it as ready, then try again."
                else if (files().state() == LocalModelFiles.State.PARTIAL)
                    "The model download on this phone is unfinished. Open Settings → “AI model on this phone” and tap Resume."
                else "The AI model is not on this phone yet. Open Settings → “AI model on this phone” and tap Download (${LocalModels.gb(spec.sizeBytes)}, once, free, no account needed)."
            LocalModelFiles.State.DAMAGED ->
                "The model file on this phone could not be confirmed to be the published one. Open Settings → “AI model on this phone” and tap “Check the file”, or delete it and download it again."
        }
    }

    /** Frees the model's memory if no task is using it. Returns false if a task is running (nothing is touched then). */
    fun unload(): Boolean {
        if (!gate.tryLock()) return false
        try { closeEngine() } finally { gate.unlock() }
        return true
    }

    private fun closeEngine() { val e = engine; engine = null; if (e != null) try { e.close() } catch (_: Throwable) {} }

    override fun generate(req: LocalRequest, cancel: CancelToken, status: (String) -> Unit): LocalOutput {
        unavailableReason()?.let { throw EngineException(FailKind.UNSUPPORTED, it) }
        var told = false
        while (!gate.tryLock(200, TimeUnit.MILLISECONDS)) {
            cancel.check()
            if (!told) { status("Waiting for another task to finish on the model on this phone…"); told = true }
        }
        try {
            cancel.check()
            return generateLocked(req, cancel, status)
        } finally { gate.unlock() }
    }

    private fun label(): String = "${LocalModels.active.shortName} (on this phone, ${engineBackend.label})"

    private fun generateLocked(req: LocalRequest, cancel: CancelToken, status: (String) -> Unit): LocalOutput {
        val notes = ArrayList<String>()
        var loadMs = 0L
        val wasLoaded = engine != null
        if (engine == null) {
            status("Loading the model into memory. This takes a while the first time…")
            val t = System.currentTimeMillis()
            engine = load(notes)
            loadMs = System.currentTimeMillis() - t
        }
        cancel.check()
        val eng = engine ?: throw EngineException(FailKind.LOCAL, "The model on this phone is not loaded.")
        if (wasLoaded && gpuRefused && backendChoice() == LocalBackend.GPU)
            notes.add("The GPU option is on, but the phone's GPU could not load the model earlier, so the CPU is being used (slower).")

        val text = StringBuilder()
        val pieces = AtomicLong(0)
        val lastPiece = AtomicLong(System.nanoTime())
        val done = CountDownLatch(1)
        val failure = AtomicReference<NativeFailure?>(null)
        var lastStatus = 0L
        val listener = object : NativeListener {
            override fun onPiece(text0: String) {
                synchronized(text) { text.append(text0) }
                val n = pieces.incrementAndGet()
                lastPiece.set(System.nanoTime())
                val now = System.nanoTime()
                if (now - lastStatus > 400_000_000L) { lastStatus = now; status("Writing the answer on this phone… about $n pieces so far") }
            }
            override fun onDone() { done.countDown() }
            override fun onError(error: NativeFailure) { failure.compareAndSet(null, error); done.countDown() }
        }
        val t0 = System.currentTimeMillis()
        status("Writing the answer on this phone…")
        val turn = try { eng.start(req.system, req.user, req.maxOutputTokens, req.temperature, listener) }
        catch (e: NativeFailure) { throw mapRun(e) }
        catch (e: Throwable) { throw mapRun(NativeFailure(NativeFailure.Kind.OTHER, e.message ?: e.javaClass.simpleName, e)) }
        val hook = cancel.onCancel { try { turn.cancel() } catch (_: Throwable) {} }
        var stalled = false
        try {
            while (!done.await(250, TimeUnit.MILLISECONDS)) {
                val idleMs = (System.nanoTime() - lastPiece.get()) / 1_000_000
                if (idleMs > (if (pieces.get() == 0L) firstPieceTimeoutMs else silenceTimeoutMs)) {
                    stalled = true
                    try { turn.cancel() } catch (_: Throwable) {}
                    done.await(5, TimeUnit.SECONDS)
                    break
                }
            }
        } finally {
            hook.close()
            try { turn.close() } catch (_: Throwable) {}
        }
        if (cancel.cancelled) throw EngineException(FailKind.CANCELLED, "Cancelled.")
        if (stalled) {
            closeEngine()   // an engine that went silent is not trusted again until it is loaded afresh
            throw EngineException(FailKind.LOCAL,
                "The model on this phone stopped producing text (no output for ${(if (pieces.get() == 0L) firstPieceTimeoutMs else silenceTimeoutMs) / 1000} s), so it was stopped. " +
                    "Your text is kept. Close other apps and try again; a shorter text also helps.")
        }
        failure.get()?.let { throw mapRun(it) }

        val raw = synchronized(text) { text.toString() }
        val limit = req.maxOutputTokens
        val reached = pieces.get() >= limit - 2 || TokenEstimate.of(raw) >= (limit * 0.98).toInt()
        return LocalOutput(raw, pieces.get().toInt(), reached, label(), loadMs, System.currentTimeMillis() - t0, notes)
    }

    private fun load(notes: MutableList<String>): NativeEngine {
        val path = files().finalFile.absolutePath
        val ctx = contextTokens
        var backend = if (gpuRefused) LocalBackend.CPU else backendChoice()
        while (true) {
            try {
                val e = factory.open(path, backend, ctx, cacheDir)
                engineBackend = backend
                return e
            } catch (e: NativeFailure) {
                if (backend == LocalBackend.GPU) {
                    gpuRefused = true
                    notes.add("The phone's GPU could not load the model (${e.message}), so the CPU was used instead. This is slower; Settings lets you switch the GPU option off.")
                    backend = LocalBackend.CPU
                    continue
                }
                throw mapLoad(e)
            } catch (e: Throwable) {
                if (backend == LocalBackend.GPU) {
                    gpuRefused = true
                    notes.add("The phone's GPU could not load the model (${e.javaClass.simpleName}), so the CPU was used instead.")
                    backend = LocalBackend.CPU
                    continue
                }
                throw mapLoad(NativeFailure(NativeFailure.Kind.LOAD, e.message ?: e.javaClass.simpleName, e))
            }
        }
    }

    private fun mapLoad(e: NativeFailure): EngineException = when (e.kind) {
        NativeFailure.Kind.OUT_OF_MEMORY -> EngineException(FailKind.LOCAL,
            "The phone ran out of memory while loading the model. Close other apps and try again. If it keeps happening, this phone may not have enough memory for this model.", detail = e.toString())
        else -> EngineException(FailKind.LOCAL,
            "The model on this phone could not be loaded: ${e.message}. The file may be damaged: in Settings tap “Check the file”, or delete it and download it again.", detail = e.toString())
    }

    private fun mapRun(e: NativeFailure): EngineException {
        if (e.kind == NativeFailure.Kind.OUT_OF_MEMORY) closeEngine()
        return when (e.kind) {
            NativeFailure.Kind.CANCELLED -> EngineException(FailKind.CANCELLED, "Cancelled.")
            NativeFailure.Kind.OUT_OF_MEMORY -> EngineException(FailKind.LOCAL,
                "The phone ran out of memory while the model was working. The model was unloaded. Close other apps and try again, or use a shorter text.", detail = e.toString())
            NativeFailure.Kind.CONTEXT_FULL -> EngineException(FailKind.LOCAL,
                "This text and its answer do not fit in the model's working memory. Shorten the text or work on it in parts.", detail = e.toString())
            else -> EngineException(FailKind.LOCAL, "The model on this phone stopped with an error: ${e.message}", detail = e.toString())
        }
    }
}
