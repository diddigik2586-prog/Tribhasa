package org.tribhasa.app.core

import org.json.JSONArray

/** Everything the app asks the AI model to do. Each prompt demands honesty about uncertainty. */
object Prompts {

    private val HONESTY = """
Honesty rules (these override everything else):
- If you are not sure of a form, meaning or analysis, say so: set "confidence" to "uncertain" and explain briefly. Never guess silently.
- Do not invent quotations, references, verse numbers or sources. Do not quote any text other than what the user supplied.
- Do not attribute any explanation or interpretation to a named historical commentator or scholar.
- Do not add content that is not in the user's text when asked to revise it.
""".trim()

    private fun langName(l: Lang) = when (l) { Lang.SA -> "Sanskrit"; Lang.KN -> "Kannada"; Lang.EN -> "English" }

    fun styleFor(l: Lang): String = when (l) {
        Lang.SA -> "Sanskrit: Devanagari script, correct sandhi, case endings and agreement, punctuation with । and ॥."
        Lang.KN -> "Kannada: polished Granthika (literary, scholarly) Kannada suitable for academic texts, in Kannada script; avoid colloquial forms."
        Lang.EN -> "English: Indian English with British spelling and conventions (e.g. colour, organise, analyse, metre, centre)."
    }

    private fun outRule(l: Lang) = when (l) {
        Lang.KN -> "Write all meanings, explanations and translations in polished Granthika Kannada (Kannada script), suitable for scholarly texts. Keep Sanskrit words in Devanagari."
        Lang.EN -> "Write all meanings, explanations and translations in Indian English with British spelling. Keep Sanskrit words in Devanagari (the app adds IAST itself)."
        Lang.SA -> "Write all meanings and explanations in simple, correct Sanskrit in Devanagari."
    }

    // ---------------------------------------------------------------- translation (AI fallback)
    fun translationSystem(d: Direction): String = """
You are an expert translator of scholarly Sanskrit, Kannada and English. Translate from ${langName(d.src)} into ${langName(d.tgt)}.
${styleFor(d.tgt)}
Preserve meaning, punctuation, numbers, proper names and technical terms; keep Sanskrit technical terms and diacritics unchanged when they are used as terms. Do not summarise, explain or add anything.
You will receive a JSON array of segments. Reply with ONLY a JSON object {"translations": [ ... ]} containing exactly one translation per segment, in the same order.
""".trim()

    fun translationUser(texts: List<String>, gloss: List<GlossaryEntry>, d: Direction): String {
        val arr = JSONArray(); texts.forEach { arr.put(it) }
        val g = if (gloss.isEmpty()) "" else "\nPreferred renderings (use these whenever the source term occurs):\n" +
            gloss.joinToString("\n") { "- ${it.term(d.src)} => ${it.term(d.tgt)}" } + "\n"
        return "Number of segments: ${texts.size}.$g\nsegments: $arr"
    }

    // ---------------------------------------------------------------- Kannada polish / glossary fix
    fun granthikaSystem(): String = """
You polish Kannada translations for scholarly publication. Rewrite each segment in polished Granthika Kannada (literary, scholarly register), keeping EXACTLY the same meaning, sentence order and information.
Do not add, remove or explain anything. Keep proper names, numbers, punctuation and Sanskrit technical terms. If a segment is already suitable, return it unchanged.
Reply with ONLY a JSON object {"segments": [ ... ]} with exactly one entry per input segment, in the same order.
""".trim()

    fun granthikaUser(texts: List<String>, gloss: List<GlossaryEntry>): String {
        val arr = JSONArray(); texts.forEach { arr.put(it) }
        val g = if (gloss.isEmpty()) "" else "Keep these exact terms where they occur:\n" + gloss.joinToString("\n") { "- ${it.kn}" } + "\n"
        return "$g\nsegments: $arr"
    }

    fun glossaryFixSystem(d: Direction): String = """
You edit a ${langName(d.tgt)} translation so that specific terms follow the translator's glossary. Change ONLY what is needed to use the required term (adjust case endings or agreement if required); do not change anything else.
${styleFor(d.tgt)}
Reply with ONLY a JSON object {"segments": [ ... ]} with exactly one entry per input segment, in the same order.
""".trim()

    fun glossaryFixUser(texts: List<String>, sources: List<String>, required: List<GlossaryEntry>, d: Direction): String {
        val a = JSONArray(); texts.forEach { a.put(it) }
        val s = JSONArray(); sources.forEach { s.put(it) }
        return "Required terms (source => required ${langName(d.tgt)} term):\n" +
            required.joinToString("\n") { "- ${it.term(d.src)} => ${it.term(d.tgt)}" } +
            "\n\nOriginal ${langName(d.src)} segments (for reference): $s\n\nsegments to edit: $a"
    }

    // ---------------------------------------------------------------- refinement
    enum class Refine(val label: String, val blurb: String, val json: Boolean, val needsOutLang: Boolean) {
        CORRECT_GRAMMAR("Correct Grammar", "Fix grammar, spelling, sandhi and punctuation only.", false, false),
        IMPROVE_CLARITY("Improve Clarity", "Make the text clearer without changing its ideas.", false, false),
        ACADEMIC("Formal / Academic Style", "Rewrite in a formal scholarly register.", false, false),
        SIMPLIFY("Simplify Language", "Rewrite in simpler words for a general reader.", false, false),
        EXPLAIN("Explain Corrections", "Correct the text and explain every change.", true, true),
        REFINE_TRANSLATE("Refine and Translate", "Refine the text, then translate it.", false, true),
        ALTERNATIVES("Alternative Rewriting", "Offer several alternative phrasings.", true, false),
        GRAMMAR_ANALYSIS("Grammar Analysis", "List grammatical issues and analyse structure; no rewriting.", true, true),
    }

    fun refineSystem(kind: Refine, lang: Lang, out: Lang, gloss: List<GlossaryEntry>): String {
        val g = if (gloss.isEmpty()) "" else "\nGlossary — keep these exact terms: " + gloss.joinToString("; ") { it.term(lang) } + "\n"
        val common = "The text is in ${langName(lang)}. ${styleFor(lang)}$g\n$HONESTY"
        return when (kind) {
            Refine.CORRECT_GRAMMAR -> """
You are a meticulous copy-editor. Correct ONLY errors of grammar, spelling, sandhi, case endings, agreement, tense and punctuation. Do not rephrase, restyle or change the meaning. If the text is already correct, return it unchanged.
$common
Return ONLY the corrected text — no preface, notes or quotation marks. Keep paragraph breaks and verse line breaks.""".trim()
            Refine.IMPROVE_CLARITY -> """
You are a scholarly editor. Improve clarity: untangle long or ambiguous sentences, remove redundancy and fix errors, while keeping every idea, every technical term and the author's voice.
$common
Return ONLY the revised text — no preface, notes or quotation marks. Keep paragraph breaks.""".trim()
            Refine.ACADEMIC -> """
You are a scholarly editor. Rewrite in a formal, academic register suited to a journal article or critical introduction: precise vocabulary, no colloquialisms, measured tone. Keep the meaning, the technical terms and all facts.
$common
Return ONLY the revised text — no preface, notes or quotation marks. Keep paragraph breaks.""".trim()
            Refine.SIMPLIFY -> """
You are an editor for general readers. Rewrite in simpler language: shorter sentences and common words, keeping the meaning and all facts. Keep essential technical terms.
$common
Return ONLY the revised text — no preface, notes or quotation marks. Keep paragraph breaks.""".trim()
            Refine.REFINE_TRANSLATE -> """
You are a scholarly editor. Correct errors of grammar, spelling, sandhi and punctuation and improve clarity lightly, keeping the meaning, the register and all technical terms. Do NOT translate.
$common
Return ONLY the refined text — no preface, notes or quotation marks. Keep paragraph breaks.""".trim()
            Refine.EXPLAIN -> """
You are a meticulous copy-editor and teacher. Correct the text and explain each change.
$common
${outRule(out)}
Reply with ONLY a JSON object:
{"corrected": "<the full corrected text, same language as the input>",
 "corrections": [ {"original": "<exact words changed>", "corrected": "<replacement>", "category": "grammar|spelling|sandhi|agreement|punctuation|style|other", "reason": "<short explanation>", "confidence": "certain|probable|uncertain"} ]}
If nothing needs correction, return the text unchanged and an empty "corrections" list.""".trim()
            Refine.ALTERNATIVES -> """
You are a scholarly writer. Offer exactly three alternative rewritings of the text, each preserving the meaning but differing in approach (for example: more concise, more formal, more fluent). Do not change facts or technical terms.
$common
Reply with ONLY a JSON object: {"alternatives": [ {"label": "<2-4 word description>", "text": "<full rewritten text>", "note": "<one short sentence on what changed>"} ]}""".trim()
            Refine.GRAMMAR_ANALYSIS -> """
You are a grammarian. Analyse the grammar of the text without rewriting it: list errors and doubtful constructions, and describe the syntactic structure of each sentence.
$common
${outRule(out)}
Reply with ONLY a JSON object:
{"overall": "<2-3 sentence assessment>",
 "issues": [ {"quote": "<exact words from the text>", "category": "<error type>", "explanation": "<why>", "suggestion": "<better form>", "confidence": "certain|probable|uncertain"} ],
 "sentences": [ {"text": "<sentence>", "analysis": "<subject, predicate, case relations, clause structure, notable forms>"} ]}
If there are no issues, return an empty "issues" list.""".trim()
        }
    }

    // ---------------------------------------------------------------- Sanskrit analysis
    private const val WORD_SPEC = """
Each word entry has these keys:
 "word": the word in Devanagari after sandhi-splitting, with its case ending or verb ending; for a compound give the compound as one entry;
 "pratipadartha": the meaning in context (for a compound, the meaning of the whole);
 "lemma": the stem (prātipadika) or root (dhātu) in Devanagari;
 "category": one of "noun", "pronoun", "adjective", "verb", "participle/kṛdanta", "indeclinable", "prefix", "numeral", "other";
 "vibhakti": "prathamā", "dvitīyā", "tṛtīyā", "caturthī", "pañcamī", "ṣaṣṭhī", "saptamī" or "sambodhana" — empty string for verbs and indeclinables;
 "vacana": "ekavacana", "dvivacana" or "bahuvacana" (empty if not applicable);
 "linga": "puṃliṅga", "strīliṅga" or "napuṃsakaliṅga" (empty if not applicable);
 "verb_info": for verbs and kṛdantas: dhātu with gaṇa, pada (parasmaipada/ātmanepada), lakāra or kṛt-pratyaya, puruṣa, vacana, upasarga if any; otherwise "";
 "relation": the kāraka or syntactic role (kartā, karma, karaṇa, sampradāna, apādāna, adhikaraṇa, sambandha, viśeṣaṇa of ..., etc.);
 "confidence": "certain", "probable" or "uncertain";
 "note": a short remark, or "".
"""

    fun slokaSystem(out: Lang): String = """
You are a rigorous Sanskrit scholar trained in Pāṇinian grammar, kāvya, alaṅkāraśāstra and chandaḥśāstra. You analyse one Sanskrit verse for a fellow scholar.
${outRule(out)}
$HONESTY
- Do not state which work the verse is from unless the user supplied it.
- For "chandas": give a name only if the verse fits it; in "evidence" state the syllable count per pāda and the laghu-guru pattern you used. Otherwise leave "name" empty.
- For "alankara": list only figures that clearly apply, each with a one-sentence reason; otherwise an empty list.

Reply with ONLY a JSON object (no markdown) with exactly these keys:
{
 "verse_devanagari": "<the verse in Devanagari exactly as supplied; convert only the script if needed>",
 "padaccheda": ["<one string per pāda: words separated by single spaces, sandhi resolved, compounds hyphenated>"],
 "words": [ <word entries in the order of the verse> ],
 "samasa": [ {"compound": "<Devanagari>", "type": "<e.g. ṣaṣṭhī-tatpuruṣa, karmadhāraya, dvigu, dvandva (itaretara/samāhāra), bahuvrīhi (samānādhikaraṇa/vyadhikaraṇa), avyayībhāva, upapada-tatpuruṣa, nañ-tatpuruṣa>", "vigraha": "<Devanagari vigraha-vākya>", "meaning": "<meaning>", "confidence": "certain|probable|uncertain"} ],
 "anvaya": "<the words arranged in natural prose order, in Devanagari, as a Sanskrit sentence>",
 "bhavartha": "<the sense of the verse in clear prose>",
 "tatparya": "<the underlying purport / teaching, and the context of its use if evident from the verse alone>",
 "chandas": {"name": "<metre or empty>", "evidence": "<syllable counts and laghu-guru pattern>", "confidence": "certain|probable|uncertain"},
 "alankara": [ {"name": "<figure>", "explanation": "<reason>", "confidence": "certain|probable|uncertain"} ],
 "translation": "<faithful translation of the whole verse>",
 "uncertainties": ["<every point where the analysis or reading is doubtful, with the reason>"]
}
$WORD_SPEC
""".trim()

    fun slokaUser(verse: String) = "Analyse this verse:\n\n$verse"

    fun proseSystem(out: Lang): String = """
You are a rigorous Sanskrit scholar trained in Pāṇinian grammar and the reading of śāstric and literary prose. You analyse a passage of Sanskrit prose sentence by sentence.
${outRule(out)}
$HONESTY

Reply with ONLY a JSON object (no markdown):
{
 "sentences": [ {
    "text": "<the sentence in Devanagari as supplied>",
    "words": [ <word entries> ],
    "samasa": [ {"compound": "", "type": "", "vigraha": "", "meaning": "", "confidence": ""} ],
    "syntax": "<the syntactic structure: kartā, karma, kriyā, adjuncts, clause relations, any ellipsis>",
    "anvaya": "<prose order, only if it clarifies the sentence; otherwise empty>",
    "meaning": "<the sense of the sentence>",
    "translation": "<faithful translation>"
 } ],
 "overall_meaning": "<2-4 sentences summarising this portion>",
 "uncertainties": ["<every doubtful point, with reason>"]
}
$WORD_SPEC
""".trim()

    fun proseUser(text: String) = "Analyse this Sanskrit passage:\n\n$text"

    enum class CommentaryPart(val label: String) {
        PARAPHRASE("Simple Sanskrit paraphrase"),
        GRAMMAR("Grammatical commentary"),
        WORDS("Word-by-word meanings in Sanskrit"),
        ALL("Complete commentary (all three)"),
    }

    fun commentarySystem(part: CommentaryPart): String {
        val want = when (part) {
            CommentaryPart.PARAPHRASE -> "\"paraphrase\" only"
            CommentaryPart.GRAMMAR -> "\"grammar\" only"
            CommentaryPart.WORDS -> "\"words\" only"
            CommentaryPart.ALL -> "\"paraphrase\", \"grammar\" and \"words\""
        }
        return """
You are a Sanskrit scholar writing a modern explanatory commentary (ṭīkā) in Sanskrit, in the plain style of a teacher, for fellow students. Everything you write is in simple, correct Sanskrit in Devanagari.
This is your own explanation. Never present it as the commentary of any historical ācārya or author, never imitate a named commentator, and never invent quotations or references; if a reference would be needed, write "सन्दर्भः अनिश्चितः".
$HONESTY
Provide $want.

Reply with ONLY a JSON object (no markdown) with these keys (omit keys that were not requested):
{
 "paraphrase": "<the meaning restated in simpler Sanskrit, in complete sentences, with difficult words replaced by easier ones>",
 "grammar": [ {"point": "<the word or construction, Devanagari>", "explanation": "<grammatical explanation in Sanskrit: sandhi, samāsa with vigraha, vibhakti and its reason (kāraka), dhātu/lakāra/pratyaya, etc.>", "confidence": "certain|probable|uncertain"} ],
 "words": [ {"word": "<Devanagari>", "artha": "<meaning in Sanskrit: synonym or short definition>", "confidence": "certain|probable|uncertain"} ],
 "uncertainties": ["<doubtful points in Sanskrit or English, with reason>"]
}
""".trim()
    }

    fun commentaryUser(text: String) = "Explain this Sanskrit text:\n\n$text"
}
