package org.tribhasa.app.ui

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Colour palette; light "parchment" by day, deep indigo by night. */
object Pal {
    var dark = false
    fun init(ctx: Context) {
        dark = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private fun c(l: Long, d: Long) = (if (dark) d else l).toInt()
    val bg get() = c(0xFFFBF7EF, 0xFF131217)
    val surface get() = c(0xFFFFFFFF, 0xFF1E1C26)
    val surfaceAlt get() = c(0xFFF3ECDD, 0xFF28253A)
    val outline get() = c(0xFFE2D8C3, 0xFF3A364D)
    val ink get() = c(0xFF231F20, 0xFFF1ECE2)
    val inkSoft get() = c(0xFF5E5650, 0xFFB5ADA0)
    val primary get() = c(0xFF2E2A6B, 0xFFB9B3FF)
    val onPrimary get() = c(0xFFFFFFFF, 0xFF1B1840)
    val accent get() = c(0xFFB86A12, 0xFFF2A65A)
    val accentSoft get() = c(0xFFFBE7C9, 0xFF3B2D1B)
    val good get() = c(0xFF2E7D4F, 0xFF7FD6A1)
    val warn get() = c(0xFF9A5B00, 0xFFF2B35A)
    val bad get() = c(0xFFB3261E, 0xFFFF9C94)
    val badSoft get() = c(0xFFFBE9E7, 0xFF3A1F1D)
    val splash get() = c(0xFF2E2A6B, 0xFF1B1840)
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

object Ui {
    fun rounded(ctx: Context, fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = ctx.dpf(radiusDp.toFloat())
        g.setColor(fill)
        if (stroke != 0 && strokeDp > 0) g.setStroke(ctx.dp(strokeDp), stroke)
        return g
    }

    fun ripple(ctx: Context, content: Drawable, radiusDp: Int): Drawable {
        val mask = GradientDrawable()
        mask.shape = GradientDrawable.RECTANGLE
        mask.cornerRadius = ctx.dpf(radiusDp.toFloat())
        mask.setColor(Color.WHITE)
        val rc = if (Pal.dark) 0x33FFFFFF else 0x22000000
        return RippleDrawable(ColorStateList.valueOf(rc), content, mask)
    }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight)

    fun margins(v: View, ctx: Context, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): View {
        val p = (v.layoutParams as? LinearLayout.LayoutParams) ?: lp()
        p.setMargins(ctx.dp(l), ctx.dp(t), ctx.dp(r), ctx.dp(b))
        v.layoutParams = p
        return v
    }

    fun text(ctx: Context, s: CharSequence, sizeSp: Float = 16f, color: Int = Pal.ink, bold: Boolean = false, italic: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(color)
        t.setLineSpacing(ctx.dpf(2f), 1.0f)
        val style = when { bold && italic -> Typeface.BOLD_ITALIC; bold -> Typeface.BOLD; italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
        t.setTypeface(Typeface.DEFAULT, style)
        return t
    }

    fun selectable(ctx: Context, s: CharSequence, sizeSp: Float = 17f, color: Int = Pal.ink): TextView {
        val t = text(ctx, s, sizeSp, color)
        t.setTextIsSelectable(true)
        t.setLineSpacing(ctx.dpf(4f), 1.0f)
        return t
    }

    fun label(ctx: Context, s: String): TextView = text(ctx, s.uppercase(), 11f, Pal.inkSoft, bold = true).also { it.letterSpacing = 0.08f }

    fun button(ctx: Context, label: String, primary: Boolean = true, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.minHeight = ctx.dp(48)
        t.setPadding(ctx.dp(18), ctx.dp(10), ctx.dp(18), ctx.dp(10))
        if (primary) {
            t.setTextColor(Pal.onPrimary)
            t.background = ripple(ctx, rounded(ctx, Pal.primary, 24), 24)
        } else {
            t.setTextColor(Pal.primary)
            t.background = ripple(ctx, rounded(ctx, Pal.surface, 24, Pal.outline, 1), 24)
        }
        t.isClickable = true
        t.isFocusable = true
        t.setOnClickListener { onClick() }
        return t
    }

    /** Small low-emphasis action (Copy, Clear, Paste …). */
    fun chip(ctx: Context, label: String, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.setTextColor(Pal.primary)
        t.minHeight = ctx.dp(40)
        t.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
        t.background = ripple(ctx, rounded(ctx, Pal.surfaceAlt, 20), 20)
        t.isClickable = true
        t.isFocusable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun setChipSelected(t: TextView, ctx: Context, selected: Boolean) {
        t.setTextColor(if (selected) Pal.onPrimary else Pal.primary)
        t.background = ripple(ctx, rounded(ctx, if (selected) Pal.primary else Pal.surfaceAlt, 20), 20)
    }

    /** A selector that looks like a field and opens a chooser dialog. */
    fun pill(ctx: Context, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.gravity = Gravity.CENTER_VERTICAL
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
        t.setTextColor(Pal.ink)
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.minHeight = ctx.dp(52)
        t.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
        t.background = ripple(ctx, rounded(ctx, Pal.surface, 14, Pal.outline, 1), 14)
        t.isClickable = true
        t.isFocusable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun card(ctx: Context, fill: Int = Pal.surface, stroke: Int = Pal.outline): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        l.background = rounded(ctx, fill, 16, stroke, 1)
        return l
    }

    fun input(ctx: Context, hint: String, minLines: Int = 1, password: Boolean = false, singleLine: Boolean = false): EditText {
        val e = EditText(ctx)
        e.hint = hint
        e.setHintTextColor(Pal.inkSoft)
        e.setTextColor(Pal.ink)
        e.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 17f)
        e.setLineSpacing(ctx.dpf(4f), 1.0f)
        e.gravity = Gravity.TOP or Gravity.START
        e.background = rounded(ctx, Pal.surface, 14, Pal.outline, 1)
        e.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        e.minLines = minLines
        if (password) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else if (singleLine) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.setSingleLine(true)
        } else {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            e.setHorizontallyScrolling(false)
        }
        return e
    }

    fun spacer(ctx: Context, hDp: Int): View {
        val v = View(ctx)
        v.layoutParams = lp(1, ctx.dp(hDp))
        return v
    }

    fun toast(ctx: Context, msg: String) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }

    fun copy(ctx: Context, text: String, what: String = "Copied") {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Tribhāṣā", text))
            toast(ctx, what)
        } catch (e: Exception) { toast(ctx, "Could not copy") }
    }

    fun pasteText(ctx: Context): String {
        return try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(ctx)?.toString() ?: "" else ""
        } catch (e: Exception) { "" }
    }

    /** Chooser with a title and a small description per option. */
    fun choose(ctx: Context, title: String, options: List<Pair<String, String>>, selected: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        var dlg: AlertDialog? = null
        options.forEachIndexed { i, (name, desc) ->
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
            row.background = ripple(ctx, rounded(ctx, if (i == selected) Pal.accentSoft else Color.TRANSPARENT, 12), 12)
            row.isClickable = true
            row.addView(text(ctx, name, 17f, Pal.ink, bold = i == selected))
            if (desc.isNotBlank()) row.addView(text(ctx, desc, 13f, Pal.inkSoft))
            row.setOnClickListener { dlg?.dismiss(); onPick(i) }
            box.addView(row, lp())
        }
        val sv = ScrollView(ctx)
        sv.addView(box)
        dlg = AlertDialog.Builder(ctx).setTitle(title).setView(sv).setNegativeButton("Cancel", null).create()
        dlg.show()
    }

    fun message(ctx: Context, title: String, body: String, copyText: String? = null) {
        val tv = selectable(ctx, body, 14f)
        tv.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(8))
        val sv = ScrollView(ctx); sv.addView(tv)
        val b = AlertDialog.Builder(ctx).setTitle(title).setView(sv).setPositiveButton("OK", null)
        if (copyText != null) b.setNeutralButton("Copy") { _, _ -> copy(ctx, copyText) }
        b.show()
    }
}
