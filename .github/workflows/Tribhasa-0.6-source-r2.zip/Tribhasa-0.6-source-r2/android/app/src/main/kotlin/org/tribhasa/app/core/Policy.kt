package org.tribhasa.app.core

/**
 * Seam for the later "Final" phase (sign-in, 10 free translations per account, Play Billing).
 * The testing build uses [FreeTestingPolicy], which never limits anything.
 */
interface UsagePolicy {
    val description: String
    fun mayRun(): Boolean
    fun recordSuccess()
}

object FreeTestingPolicy : UsagePolicy {
    override val description = "Testing build: no trial limit, no expiry, no payments. Only the limits of the outside services apply."
    override fun mayRun() = true
    override fun recordSuccess() {}
}
