package org.tribhasa.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.tribhasa.app.core.LocalModels
import org.tribhasa.app.local.DeviceInfo
import org.tribhasa.app.local.Local
import org.tribhasa.app.ui.AnalyseScreen
import org.tribhasa.app.ui.Brand
import org.tribhasa.app.ui.CompareScreen
import org.tribhasa.app.ui.FailedScreen
import org.tribhasa.app.ui.GlossaryScreen
import org.tribhasa.app.ui.HistoryScreen
import org.tribhasa.app.ui.Host
import org.tribhasa.app.ui.Pal
import org.tribhasa.app.ui.RefineScreen
import org.tribhasa.app.ui.Screen
import org.tribhasa.app.ui.SettingsScreen
import org.tribhasa.app.ui.TranslateScreen
import org.tribhasa.app.ui.Ui
import org.tribhasa.app.ui.aboutView
import org.tribhasa.app.ui.add
import org.tribhasa.app.ui.addSide
import org.tribhasa.app.ui.dp
import org.tribhasa.app.ui.show

class MainActivity : Activity(), Host {
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var footer: View
    private lateinit var nav: LinearLayout
    private var screens: List<Screen> = emptyList()
    private var current = 0
    private var aboutPanel: View? = null
    private var comparePanel: View? = null
    private var splash: View? = null
    private var keyboardUp = false

    private class NavItem(val box: LinearLayout, val iconWrap: FrameLayout, val icon: ImageView, val label: TextView)
    private val navItems = ArrayList<NavItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi(savedInstanceState)
        } catch (e: Throwable) {
            showStartupFailure(e)
        }
    }

    /** Last resort: if the main screen cannot be built, show a readable report instead of closing silently. */
    private fun showStartupFailure(e: Throwable) {
        try { App.logCrash(e) } catch (_: Throwable) {}
        val report = "Tribhāṣā ${App.BUILD_LABEL} could not start.\n\n" + android.util.Log.getStackTraceString(e)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(20))
        val head = TextView(this); head.text = "Tribhāṣā could not start"; head.textSize = 22f
        col.addView(head)
        val help = TextView(this); help.text = "Please copy the report below and send it to the developer."; help.setPadding(0, dp(8), 0, dp(12))
        col.addView(help)
        val btn = TextView(this); btn.text = "COPY REPORT"; btn.textSize = 16f; btn.setPadding(0, dp(8), 0, dp(12))
        btn.setOnClickListener { Ui.copy(this, report) }
        col.addView(btn)
        val body = TextView(this); body.text = report; body.textSize = 11f; body.setTextIsSelectable(true)
        col.addView(body)
        val sv = android.widget.ScrollView(this); sv.addView(col)
        setContentView(sv)
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        Pal.init(this)
        App.init(this)
        App.installCrashHandler()
        styleSystemBars()

        root = FrameLayout(this)
        root.setBackgroundColor(Pal.bg)
        setContentView(root)

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        root.addView(main, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(20), 0, dp(20), 0)
        titleView = Ui.text(this, "", 22f, Pal.primary, bold = true)
        header.addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        main.addView(header, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))

        content = FrameLayout(this)
        main.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        footer = buildFooter()
        main.addView(footer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        nav = buildNav()
        main.addView(nav, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)))

        screens = listOf(
            safe("Translate") { TranslateScreen(this, this) },
            safe("Refine") { RefineScreen(this, this) },
            safe("Analyse") { AnalyseScreen(this, this) },
            safe("Glossary") { GlossaryScreen(this) },
            safe("History") { HistoryScreen(this, this) },
            safe("Settings") { SettingsScreen(this, this) },
        )
        val back = isSignInReturn(intent)
        go(if (back) 5 else savedInstanceState?.getInt("tab", 0) ?: 0)

        watchKeyboard()
        if (savedInstanceState == null && !back) showSplash() else if (!maybeShowCrash() && !back) maybeAskFirstRun()
    }

    /** The link the sign-in page offers after OpenRouter has sent the browser back. It carries no data. */
    private fun isSignInReturn(i: android.content.Intent?): Boolean =
        i?.action == android.content.Intent.ACTION_VIEW && i.data?.scheme == "tribhasa" && i.data?.host == "connected"

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        if (isSignInReturn(intent)) { setIntent(android.content.Intent()); openSettings() }
    }

    /** Once only, on the very first start: explain the one-time model download and offer to start it now. */
    private fun maybeAskFirstRun() {
        try {
            if (App.store.pref("local_asked", "") == "yes") return
            if (Local.uiState() == Local.UiState.READY) { App.store.setPref("local_asked", "yes"); return }
            App.store.setPref("local_asked", "yes")
            val spec = LocalModels.active
            val ram = DeviceInfo.totalRamBytes(this)
            val warn = if (LocalModels.memoryFit(ram) != LocalModels.Fit.OK) "\n\n" + LocalModels.memoryText(ram) else ""
            AlertDialog.Builder(this)
                .setTitle("Download the AI model")
                .setMessage("Tribhāṣā runs its AI model on this phone. It needs a one-time download of ${LocalModels.gb(spec.sizeBytes)} (free, no account or key; Wi-Fi is best). After that it works without internet and your texts never leave the phone.\n\nThe model is a small one: its quality for Sanskrit and Kannada has not been tested, and every result says so.$warn")
                .setPositiveButton("Download now") { _, _ -> openSettings(); DeviceInfo.askForNotificationPermission(this); Local.startDownload() }
                .setNegativeButton("Later", null)
                .show()
        } catch (e: Throwable) { App.logCrash(e) }
    }

    /** Android asks apps to give memory back. The model is the biggest thing this app holds, so it is let go when nothing is using it. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= 10) try { Local.trimMemory() } catch (_: Throwable) {}   // 10 = TRIM_MEMORY_RUNNING_LOW; larger values mean the app is hidden or in the background
    }

    private fun safe(name: String, make: () -> Screen): Screen =
        try { make() } catch (e: Throwable) { FailedScreen(this, name, e) }

    @Suppress("DEPRECATION")
    private fun styleSystemBars() {
        window.setBackgroundDrawable(ColorDrawable(Pal.bg))
        window.statusBarColor = Pal.bg
        window.navigationBarColor = Pal.surface
        var f = window.decorView.systemUiVisibility
        if (!Pal.dark) f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    // ---------------------------------------------------------------- chrome
    private fun buildFooter(): View {
        val f = LinearLayout(this)
        f.orientation = LinearLayout.VERTICAL
        f.gravity = Gravity.CENTER_HORIZONTAL
        f.setPadding(dp(16), dp(6), dp(16), dp(8))
        f.setBackgroundColor(Pal.bg)
        val line = View(this); line.setBackgroundColor(Pal.outline)
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
        wrap.addView(f, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val brand = Ui.text(this, "${Brand.NAME}  ·  ${Brand.NATIVE}", 14f, Pal.primary, bold = true)
        brand.setTypeface(Typeface.SERIF, Typeface.BOLD)
        brand.gravity = Gravity.CENTER
        f.addView(brand, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val by = Ui.text(this, Brand.ATTRIBUTION, 12f, Pal.inkSoft, italic = true)
        by.gravity = Gravity.CENTER
        f.addView(by, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return wrap
    }

    private fun buildNav(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Pal.surface)
        bar.elevation = dp(6).toFloat()
        val defs = listOf(
            Triple("Translate", R.drawable.ic_nav_translate, 0),
            Triple("Refine", R.drawable.ic_nav_refine, 1),
            Triple("Analyse", R.drawable.ic_nav_analyse, 2),
            Triple("Glossary", R.drawable.ic_nav_glossary, 3),
            Triple("History", R.drawable.ic_nav_history, 4),
            Triple("Settings", R.drawable.ic_nav_settings, 5),
        )
        for ((label, icon, idx) in defs) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.isClickable = true
            box.isFocusable = true
            val wrap = FrameLayout(this)
            val img = ImageView(this)
            img.setImageResource(icon)
            wrap.addView(img, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            box.addView(wrap, LinearLayout.LayoutParams(dp(56), dp(30)))
            val tv = Ui.text(this, label, 11f, Pal.inkSoft)
            tv.gravity = Gravity.CENTER
            box.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            box.setOnClickListener { go(idx) }
            bar.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            navItems.add(NavItem(box, wrap, img, tv))
        }
        return bar
    }

    private fun paintNav() {
        for ((i, n) in navItems.withIndex()) {
            val sel = i == current
            val c = if (sel) Pal.primary else Pal.inkSoft
            n.icon.setColorFilter(c)
            n.label.setTextColor(c)
            n.label.setTypeface(Typeface.DEFAULT, if (sel) Typeface.BOLD else Typeface.NORMAL)
            n.iconWrap.background = if (sel) Ui.rounded(this, Pal.accentSoft, 15) else null
        }
    }

    // ---------------------------------------------------------------- navigation
    private fun go(i: Int) {
        val idx = i.coerceIn(0, screens.size - 1)
        hideKeyboard()
        screens.getOrNull(current)?.saveDraft()
        current = idx
        content.removeAllViews()
        val s = screens[idx]
        content.addView(s.view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        titleView.text = s.title
        try { s.onShow() } catch (e: Throwable) { App.logCrash(e) }
        paintNav()
    }

    override fun openSettings() { hideAbout(); hideCompare(); go(5) }

    override fun openTranslate() { hideAbout(); hideCompare(); go(0) }

    override fun openCompare() {
        if (comparePanel != null) return
        val v = try { CompareScreen(this, this) { hideCompare() }.view } catch (e: Throwable) { App.logCrash(e); Ui.toast(this, "The comparison screen could not open."); return }
        comparePanel = v
        root.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
    }

    private fun hideCompare() {
        comparePanel?.let { root.removeView(it) }
        comparePanel = null
        App.compare.listener = null
    }

    override fun openAbout() {
        if (aboutPanel != null) return
        val v = aboutView(this) { hideAbout() }
        aboutPanel = v
        root.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
    }

    private fun hideAbout() {
        aboutPanel?.let { root.removeView(it) }
        aboutPanel = null
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when {
            comparePanel != null -> hideCompare()
            aboutPanel != null -> hideAbout()
            current != 0 -> go(0)
            else -> super.onBackPressed()
        }
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(root.windowToken, 0)
        } catch (_: Exception) {}
    }

    private fun watchKeyboard() {
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val full = root.rootView.height
            val up = full > 0 && (full - r.bottom) > full * 0.15
            if (up != keyboardUp) {
                keyboardUp = up
                // While typing, the footer and the tab bar make way for the keyboard.
                footer.show(!up)
                nav.show(!up)
            }
        }
    }

    // ---------------------------------------------------------------- splash and crash report
    private fun showSplash() {
        val s = FrameLayout(this)
        s.setBackgroundColor(Pal.splash)
        s.isClickable = true
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.gravity = Gravity.CENTER
        val name = Ui.text(this, Brand.NAME, 44f, 0xFFFFFFFF.toInt(), bold = true)
        name.setTypeface(Typeface.SERIF, Typeface.BOLD)
        name.gravity = Gravity.CENTER
        mid.addView(name)
        val nat = Ui.text(this, Brand.NATIVE, 22f, 0xFFF2A65A.toInt(), bold = true)
        nat.gravity = Gravity.CENTER
        mid.add(nat, top = 6)
        val sub = Ui.text(this, "Sanskrit · Kannada · English", 14f, 0xCCFFFFFF.toInt())
        sub.gravity = Gravity.CENTER
        mid.add(sub, top = 14)
        s.addView(mid, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        val by = Ui.text(this, Brand.ATTRIBUTION, 15f, 0xFFFFFFFF.toInt(), italic = true)
        by.gravity = Gravity.CENTER
        val lp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lp.bottomMargin = dp(36)
        s.addView(by, lp)
        root.addView(s, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        splash = s
        s.postDelayed({
            s.animate().alpha(0f).setDuration(350).withEndAction {
                root.removeView(s); splash = null
                if (!maybeShowCrash()) maybeAskFirstRun()
            }.start()
        }, 1400)
    }

    /** Shows the report of an earlier crash, if there is one. Returns true when a dialog was shown. */
    private fun maybeShowCrash(): Boolean {
        val report = App.takeCrashReport() ?: return false
        App.store.setPref("last_crash", report)
        val tv = Ui.selectable(this, report.take(3000), 12f, Pal.ink)
        tv.setPadding(dp(20), dp(8), dp(20), dp(8))
        val sv = android.widget.ScrollView(this); sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("Tribhāṣā stopped unexpectedly last time")
            .setView(sv)
            .setPositiveButton("OK", null)
            .setNeutralButton("Copy report") { _, _ -> Ui.copy(this, report) }
            .show()
        return true
    }

    // ---------------------------------------------------------------- lifecycle
    override fun onPause() {
        super.onPause()
        for (s in screens) try { s.saveDraft() } catch (_: Throwable) {}
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }
}
