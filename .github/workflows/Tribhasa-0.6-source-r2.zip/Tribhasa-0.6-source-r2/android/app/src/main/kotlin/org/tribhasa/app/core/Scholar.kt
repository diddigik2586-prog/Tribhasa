package org.tribhasa.app.core

import org.json.JSONObject
import java.text.Normalizer

class ScholarResult(
    /** Main plain-text result (revised text / translation), when the task produces one. */
    val text: String?,
    /** Structured result, when the task produces one. */
    val doc: Document?,
    val qc: QcReport,
    /** For "Refine and Translate": the refined source-language text. */
    val refinedText: String? = null,
    val trace: Trace,
)

object TextDiff {
    private fun tokens(s: String) = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    /** Returns (words of [a] not kept, words of [b] new, total words of [a]) from a longest-common-subsequence. */
    fun wordChanges(a: String, b: String): Triple<Int, Int, Int> {
        val x = tokens(a); val y = tokens(b)
        if (x.size > 4000 || y.size > 4000) return Triple(-1, -1, x.size)
        var prev = IntArray(y.size + 1)
        for (i in 1..x.size) {
            val cur = IntArray(y.size + 1)
            for (j in 1..y.size) cur[j] = if (x[i - 1] == y[j - 1]) prev[j - 1] + 1 else maxOf(prev[j], cur[j - 1])
            prev = cur
        }
        val lcs = prev[y.size]
        return Triple(x.size - lcs, y.size - lcs, x.size)
    }
}

class ScholarService(
    private val llm: LlmRouter,
    private val translation: TranslationService?,
) {
    // ------------------------------------------------------------------ shared helpers
    private val HISTORICAL_NAMES = listOf(
        "शङ्कर", "शंकर", "शङ्कराचार्य", "मल्लिनाथ", "सायण", "रामानुज", "मध्व", "भट्टोजि", "पतञ्जलि", "कात्यायन", "पाणिनि",
        "अभिनवगुप्त", "आनन्दवर्धन", "कुमारिल", "प्रभाकर", "वाचस्पति", "विज्ञानेश्वर", "नीलकण्ठ", "श्रीधर", "मधुसूदन", "कालिदास", "भर्तृहरि",
        "Śaṅkara", "Shankara", "Sankara", "Mallinātha", "Mallinatha", "Sāyaṇa", "Sayana", "Rāmānuja", "Ramanuja", "Madhva",
        "Patañjali", "Patanjali", "Kātyāyana", "Pāṇini", "Panini", "Abhinavagupta", "Ānandavardhana", "Kumārila", "Vācaspati",
        "ಶಂಕರ", "ಮಲ್ಲಿನಾಥ", "ಸಾಯಣ", "ರಾಮಾನುಜ", "ಮಧ್ವ", "ಪತಂಜಲಿ", "ಪಾಣಿನಿ",
    )

    private fun clean(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) { t = t.removePrefix("```json").removePrefix("```").trim(); if (t.endsWith("```")) t = t.removeSuffix("```").trim() }
        return t
    }

    private fun stripWrappingQuotes(reply: String, original: String): String {
        var t = clean(reply)
        val pairs = listOf("\"" to "\"", "“" to "”", "‘" to "’", "«" to "»")
        for ((o, c) in pairs) if (t.length > 2 && t.startsWith(o) && t.endsWith(c) && !original.trim().startsWith(o)) { t = t.substring(1, t.length - 1).trim(); break }
        return t
    }

    private fun letters(s: String) = s.filter { it.isLetter() || Character.getType(it) == Character.NON_SPACING_MARK.toInt() || Character.getType(it) == Character.COMBINING_SPACING_MARK.toInt() }

    private fun fold(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }.lowercase().filter { it.isLetter() }

    private fun numerals(s: String): List<String> =
        Regex("[0-9०-९೦-೯]+").findAll(s).map { m ->
            m.value.map { c -> when (c) { in '०'..'९' -> '0' + (c - '०'); in '೦'..'೯' -> '0' + (c - '೦'); else -> c } }.joinToString("")
        }.toList()

    private fun sanskritDev(s: String) = Translit.normaliseSanskritInput(Scripts.nfc(s)).devanagari

    private class JsonResult(val obj: JSONObject?, val reply: LlmReply?, val truncated: Boolean, val parseFailed: Boolean)

    /** Calls the AI model expecting a JSON object; asks once more if the answer is not valid JSON. */
    private fun jsonCall(sys: String, user: String, cancel: CancelToken, trace: Trace, maxTokens: Int = 12000): JsonResult {
        var last: LlmReply? = null
        for (attempt in 1..2) {
            val u = if (attempt == 1) user else user + "\n\n(Your previous reply was not valid JSON. Reply with ONLY the JSON object described, with no text before or after it.)"
            val r = llm.generate(LlmRequest(sys, u, json = true, maxTokens = maxTokens, temperature = 0.1), cancel, trace)
            last = r
            if (r.truncated) return JsonResult(null, r, truncated = true, parseFailed = false)
            val o = JsonUtil.extractObject(r.text)
            if (o != null) return JsonResult(o, r, false, false)
            trace.note("The AI model's answer was not valid JSON (attempt $attempt).")
        }
        return JsonResult(null, last, false, true)
    }

    // ------------------------------------------------------------------ plain refinement
    private fun refineOne(
        sys: String, text: String, cancel: CancelToken, trace: Trace, depth: Int = 0,
    ): Pair<String, Boolean> {
        val r = llm.generate(LlmRequest(sys, text, json = false, maxTokens = 8192, temperature = 0.2), cancel, trace)
        if (r.truncated && depth < 3 && text.length > 300) {
            val halves = Segmenter.split(text, text.length / 2 + 40)
            if (halves.size > 1) {
                var all = true
                val outs = halves.map { h -> val (t, ok) = refineOne(sys, h.text, cancel, trace, depth + 1); all = all && ok; t }
                return Segmenter.join(halves, outs) to all
            }
        }
        trace.use("${r.provider} (${r.model})", 1)
        return stripWrappingQuotes(r.text, text) to !r.truncated
    }

    fun refinePlain(
        kind: Prompts.Refine, text: String, lang: Lang, opts: Options, glossary: List<GlossaryEntry>,
        cancel: CancelToken, progress: (String) -> Unit,
    ): ScholarResult {
        require(!kind.json)
        val trace = Trace()
        trace.statusSink = progress
        val relevant = glossary.filter { it.term(lang).isNotBlank() && Scripts.nfc(text).contains(Scripts.nfc(it.term(lang)), ignoreCase = lang == Lang.EN) }
        val sys = Prompts.refineSystem(kind, lang, lang, relevant)
        val segs = Segmenter.split(Scripts.nfc(text), 2400)
        val outs = ArrayList<String>()
        var complete = true
        for ((i, s) in segs.withIndex()) {
            cancel.check()
            progress("Working on part ${i + 1} of ${segs.size}…")
            val (t, ok) = refineOne(sys, s.text, cancel, trace)
            outs.add(t); complete = complete && ok
        }
        var result = Segmenter.join(segs, outs)
        val qc = QcReport()
        qc.info("Revised by ${trace.used.keys.joinToString(", ").ifBlank { "the AI model" }} — ${segs.size} part(s).")
        if (trace.retries > 0 || trace.failovers > 0) qc.info("Temporary problems handled automatically: ${trace.retries} retry attempt(s), ${trace.failovers} switch(es) to another provider.")
        if (complete && outs.all { it.isNotBlank() }) qc.pass("Every part was returned in full (no part was cut off or empty).")
        else qc.fail("Some part of the answer was cut off or empty; please split the text and run it again.")
        val pIn = Segmenter.paragraphCount(text); val pOut = Segmenter.paragraphCount(result)
        if (pIn == pOut) qc.pass("Paragraph breaks preserved ($pIn).") else qc.warn("Paragraph count changed: $pIn → $pOut.")
        val inScript = Scripts.dominant(text); val outScript = Scripts.dominant(result)
        if (inScript == outScript) qc.pass("The revised text is in the same script as your text.") else qc.warn("The revised text is in a different script from your text.")
        if (numerals(text).sorted() == numerals(result).sorted()) { if (numerals(text).isNotEmpty()) qc.pass("Numbers unchanged.") }
        else qc.warn("Numbers differ between your text and the revision; please check them.")
        val (removed, added, total) = TextDiff.wordChanges(text, result)
        if (removed >= 0) {
            val pct = if (total == 0) 0 else removed * 100 / total
            qc.info("Words changed: $removed of $total original words replaced or removed, $added new word(s) ($pct%).")
            if (kind == Prompts.Refine.CORRECT_GRAMMAR && pct > 35) qc.warn("More than a third of the words changed — this goes beyond light correction; please read it carefully.")
            if (removed == 0 && added == 0) qc.info("No changes were made: the model found the text already correct.")
        }
        val ratio = result.length.toDouble() / maxOf(1, text.length)
        val lo = if (kind == Prompts.Refine.SIMPLIFY) 0.3 else 0.5; val hi = if (kind == Prompts.Refine.SIMPLIFY) 1.6 else 1.8
        if (ratio !in lo..hi) qc.warn("The revision is ${(ratio * 100).toInt()}% of the original length — check that nothing was dropped or added.")
        if (lang == Lang.EN && opts.britishSpelling) {
            val r = Spelling.toBritish(result); result = r.text
            if (r.changed > 0) qc.info("British spelling applied by word list: ${r.changed} word(s) changed.")
        }
        val missingTerms = relevant.filter { !Scripts.nfc(result).contains(Scripts.nfc(it.term(lang)), ignoreCase = lang == Lang.EN) }
        if (relevant.isNotEmpty()) {
            if (missingTerms.isEmpty()) qc.pass("Glossary terms in your text were kept (${relevant.size}).")
            else qc.warn("Glossary term(s) no longer present after revision: ${missingTerms.joinToString(", ") { it.term(lang) }}.")
        }
        qc.addStandingNotes(true, trace)
        return ScholarResult(result, null, qc, trace = trace)
    }

    fun refineAndTranslate(
        text: String, lang: Lang, target: Lang, opts: Options, glossary: List<GlossaryEntry>,
        cancel: CancelToken, progress: (String) -> Unit,
    ): ScholarResult {
        val ts = translation ?: throw EngineException(FailKind.UNSUPPORTED, "No translation service is set up. Open Settings.")
        progress("Step 1 of 2 — refining the text…")
        val step1 = refinePlain(Prompts.Refine.REFINE_TRANSLATE, text, lang, opts, glossary, cancel, progress)
        progress("Step 2 of 2 — translating…")
        val job = ts.newJob(step1.text ?: text, Direction(lang, target), opts, glossary)
        val tr = ts.run(job, cancel, progress)
        val qc = QcReport()
        qc.info("Step 1 — refinement:")
        step1.qc.items.filter { (it.status != Qc.INFO || !it.text.startsWith("Not checked")) && !LocalChecks.isStanding(it.text) }.forEach { qc.items.add(it) }
        qc.info("Step 2 — translation:")
        tr.qc.items.filter { !it.text.startsWith("Not checked") && !LocalChecks.isStanding(it.text) }.forEach { qc.items.add(it) }
        qc.addStandingNotes(true, if (step1.trace.onDevice) step1.trace else tr.trace)
        return ScholarResult(tr.output, null, qc, refinedText = step1.text, trace = tr.trace)
    }

    // ------------------------------------------------------------------ JSON refinement kinds
    fun refineStructured(
        kind: Prompts.Refine, text: String, lang: Lang, out: Lang, opts: Options, glossary: List<GlossaryEntry>,
        cancel: CancelToken, progress: (String) -> Unit,
    ): ScholarResult {
        require(kind.json)
        val trace = Trace()
        trace.statusSink = progress
        val sys = Prompts.refineSystem(kind, lang, out, glossary.filter { it.term(lang).isNotBlank() && Scripts.nfc(text).contains(Scripts.nfc(it.term(lang))) })
        val segs = Segmenter.split(Scripts.nfc(text), 1800)
        val qc = QcReport()
        val sections = ArrayList<Section>()
        var allParsed = true; var anyTrunc = false
        val corrected = ArrayList<String>()
        val corrections = ArrayList<Block.Entry>(); var correctionsFound = 0; var correctionsListed = 0
        val altBlocks = ArrayList<Block>(); var altCount = 0; var altSameAsInput = 0
        val issueBlocks = ArrayList<Block>(); var issuesListed = 0; var issuesLocated = 0
        val sentenceBlocks = ArrayList<Block>(); val overall = ArrayList<String>()
        val alts = ArrayList<String>()
        for ((i, s) in segs.withIndex()) {
            cancel.check()
            progress("Working on part ${i + 1} of ${segs.size}…")
            val r = jsonCall(sys, s.text, cancel, trace, 8192)
            if (r.truncated) { anyTrunc = true; continue }
            val o = r.obj
            if (o == null) { allParsed = false; continue }
            when (kind) {
                Prompts.Refine.EXPLAIN -> {
                    corrected.add(JsonUtil.str(o, "corrected").ifBlank { s.text })
                    for (c in JsonUtil.objList(o, "corrections")) {
                        val orig = JsonUtil.str(c, "original"); val fixed = JsonUtil.str(c, "corrected")
                        correctionsListed++
                        val found = orig.isNotBlank() && Scripts.nfc(text).contains(Scripts.nfc(orig))
                        if (found) correctionsFound++
                        corrections.add(Block.Entry(
                            head = "$orig  →  $fixed",
                            sub = JsonUtil.str(c, "category"),
                            lines = listOf("Reason" to JsonUtil.str(c, "reason")) + if (found) emptyList() else listOf("Check" to "These exact words were not found in your text."),
                            uncertain = JsonUtil.str(c, "confidence") == "uncertain" || !found))
                    }
                }
                Prompts.Refine.ALTERNATIVES -> {
                    val list = JsonUtil.objList(o, "alternatives")
                    if (segs.size == 1) {
                        for (a in list) {
                            altCount++
                            val t = JsonUtil.str(a, "text")
                            if (fold(t) == fold(text)) altSameAsInput++
                            alts.add(t)
                            altBlocks.add(Block.Entry(head = JsonUtil.str(a, "label").ifBlank { "Alternative $altCount" }, lines = listOf("Text" to t, "Change" to JsonUtil.str(a, "note"))))
                        }
                    } else {
                        // long text: take the first alternative of each part as a running version
                        list.forEachIndexed { k, a -> if (k < 3) { while (alts.size <= k) alts.add(""); alts[k] = (alts[k] + " " + JsonUtil.str(a, "text")).trim() } }
                    }
                }
                Prompts.Refine.GRAMMAR_ANALYSIS -> {
                    overall.add(JsonUtil.str(o, "overall"))
                    for (c in JsonUtil.objList(o, "issues")) {
                        val q = JsonUtil.str(c, "quote")
                        issuesListed++
                        val found = q.isNotBlank() && Scripts.nfc(text).contains(Scripts.nfc(q))
                        if (found) issuesLocated++
                        issueBlocks.add(Block.Entry(
                            head = q, sub = JsonUtil.str(c, "category"),
                            lines = listOf("Why" to JsonUtil.str(c, "explanation"), "Suggestion" to JsonUtil.str(c, "suggestion")) + if (found) emptyList() else listOf("Check" to "These exact words were not found in your text."),
                            uncertain = JsonUtil.str(c, "confidence") == "uncertain" || !found))
                    }
                    for (c in JsonUtil.objList(o, "sentences")) sentenceBlocks.add(Block.Entry(head = JsonUtil.str(c, "text"), lines = listOf("Analysis" to JsonUtil.str(c, "analysis"))))
                }
                else -> {}
            }
        }
        qc.info("Analysed by ${trace.used.keys.joinToString(", ").ifBlank { "the AI model" }} — ${segs.size} part(s).")
        if (trace.retries > 0 || trace.failovers > 0) qc.info("Temporary problems handled automatically: ${trace.retries} retry attempt(s), ${trace.failovers} switch(es) to another provider.")
        if (anyTrunc) qc.fail("The AI model's answer was cut off for part of the text; split the text and run it again.")
        if (!allParsed) qc.fail("The AI model's answer could not be read as structured data for part of the text.") else if (!anyTrunc) qc.pass("The structured answer was read successfully (${segs.size} part(s)).")
        var mainText: String? = null
        when (kind) {
            Prompts.Refine.EXPLAIN -> {
                var c = corrected.joinToString("\n\n")
                if (lang == Lang.EN && opts.britishSpelling) c = Spelling.toBritish(c).text
                mainText = c
                sections.add(Section("Corrected text", listOf(Block.Para(c, sanskrit = lang == Lang.SA))))
                sections.add(Section("Corrections (${corrections.size})", if (corrections.isEmpty()) listOf(Block.Para("No corrections were needed.")) else corrections))
                if (correctionsListed > 0) {
                    if (correctionsFound == correctionsListed) qc.pass("All $correctionsListed listed correction(s) quote words that really occur in your text.")
                    else qc.warn("${correctionsListed - correctionsFound} of $correctionsListed listed correction(s) quote words that do not occur in your text; they are marked as uncertain.")
                }
                val (rem, add, tot) = TextDiff.wordChanges(text, c)
                if (rem >= 0) qc.info("Words changed in the corrected text: $rem of $tot replaced or removed, $add new.")
                if (numerals(text).sorted() != numerals(c).sorted()) qc.warn("Numbers differ between your text and the corrected text; please check them.")
            }
            Prompts.Refine.ALTERNATIVES -> {
                if (segs.size > 1) {
                    alts.forEachIndexed { k, t -> if (t.isNotBlank()) { altCount++; altBlocks.add(Block.Entry(head = "Alternative ${k + 1}", lines = listOf("Text" to t))) } }
                }
                sections.add(Section("Alternative rewritings", if (altBlocks.isEmpty()) listOf(Block.Para("No alternatives were returned.")) else altBlocks))
                if (altCount >= 3) qc.pass("$altCount alternatives were returned.") else qc.warn("Only $altCount alternative(s) were returned.")
                if (altSameAsInput > 0) qc.warn("$altSameAsInput alternative(s) are identical to your original text apart from spacing.")
                val bad = alts.filter { numerals(it).sorted() != numerals(text).sorted() }.size
                if (numerals(text).isNotEmpty()) { if (bad == 0) qc.pass("Numbers are unchanged in every alternative.") else qc.warn("$bad alternative(s) change or drop numbers.") }
            }
            Prompts.Refine.GRAMMAR_ANALYSIS -> {
                if (overall.any { it.isNotBlank() }) sections.add(Section("Overall assessment", overall.filter { it.isNotBlank() }.map { Block.Para(it) }))
                sections.add(Section("Issues found (${issueBlocks.size})", if (issueBlocks.isEmpty()) listOf(Block.Para("No grammatical issues were reported.")) else issueBlocks))
                if (sentenceBlocks.isNotEmpty()) sections.add(Section("Sentence structure", sentenceBlocks))
                if (issuesListed > 0) {
                    if (issuesLocated == issuesListed) qc.pass("All $issuesListed quoted passage(s) really occur in your text.")
                    else qc.warn("${issuesListed - issuesLocated} of $issuesListed quoted passage(s) do not occur in your text; they are marked as uncertain.")
                }
            }
            else -> {}
        }
        qc.addStandingNotes(true, trace)
        return ScholarResult(mainText, Document(sections, qc), qc, trace = trace)
    }

    // ------------------------------------------------------------------ Sanskrit: verse analysis
    fun splitVerses(text: String): List<String> = OfflineTools.splitVerses(text)

    private fun wordEntry(w: JSONObject): Block.Entry {
        val word = JsonUtil.str(w, "word")
        val devWord = if (Scripts.dominant(word) == Script.DEVANAGARI) word else Translit.normaliseSanskritInput(word).devanagari
        val iast = if (Scripts.dominant(devWord) == Script.DEVANAGARI) Translit.devanagariToIast(devWord) else JsonUtil.str(w, "iast")
        val cat = JsonUtil.str(w, "category"); val lemma = JsonUtil.str(w, "lemma")
        val tags = listOf(JsonUtil.str(w, "vibhakti"), JsonUtil.str(w, "vacana"), JsonUtil.str(w, "linga")).filter { it.isNotBlank() && it != "—" && it != "-" }
        val conf = JsonUtil.str(w, "confidence")
        return Block.Entry(
            head = word, sub = iast,
            lines = listOf(
                "Meaning" to JsonUtil.str(w, "pratipadartha"),
                "Stem / root" to listOf(lemma, cat).filter { it.isNotBlank() }.joinToString(" · "),
                "Verb / participle" to JsonUtil.str(w, "verb_info"),
                "Role" to JsonUtil.str(w, "relation"),
                "Note" to JsonUtil.str(w, "note"),
            ),
            tags = tags + if (conf == "probable") listOf("probable") else emptyList(),
            uncertain = conf == "uncertain",
        )
    }

    private fun samasaEntry(s: JSONObject) = Block.Entry(
        head = JsonUtil.str(s, "compound"), sub = JsonUtil.str(s, "type"),
        lines = listOf("Vigraha" to JsonUtil.str(s, "vigraha"), "Meaning" to JsonUtil.str(s, "meaning")),
        uncertain = JsonUtil.str(s, "confidence") == "uncertain")

    private fun lgString(pattern: String) = OfflineTools.lgString(pattern)

    private fun checkWords(words: List<JSONObject>, qc: QcReport) {
        if (words.isEmpty()) { qc.fail("No word-by-word analysis was returned."); return }
        val nominal = words.filter { JsonUtil.str(it, "category").lowercase().let { c -> c.contains("noun") || c.contains("adjective") || c.contains("pronoun") || c.contains("numeral") } }
        val incomplete = nominal.count { JsonUtil.str(it, "vibhakti").isBlank() || JsonUtil.str(it, "vacana").isBlank() || JsonUtil.str(it, "linga").isBlank() }
        if (nominal.isNotEmpty()) {
            if (incomplete == 0) qc.pass("Every noun, adjective and pronoun (${nominal.size}) has vibhakti, vacana and liṅga stated.")
            else qc.warn("$incomplete of ${nominal.size} nominal forms lack vibhakti, vacana or liṅga.")
        }
        val verbs = words.filter { JsonUtil.str(it, "category").lowercase().let { c -> c.contains("verb") || c.contains("participle") } }
        val verbMissing = verbs.count { JsonUtil.str(it, "verb_info").isBlank() }
        if (verbs.isNotEmpty()) {
            if (verbMissing == 0) qc.pass("Every verb or participle (${verbs.size}) has its root and ending analysed.")
            else qc.warn("$verbMissing of ${verbs.size} verbal forms lack root/ending details.")
        }
        val unc = words.count { JsonUtil.str(it, "confidence") == "uncertain" }
        if (unc > 0) qc.warn("The model marked $unc word(s) as uncertain (shown with a ⚠ marker).")
        else qc.info("The model marked no word as uncertain; this is its own judgement, not a verification.")
    }

    private fun attributionCheck(allText: String, original: String, qc: QcReport) {
        val found = HISTORICAL_NAMES.filter { allText.contains(it, ignoreCase = true) && !original.contains(it, ignoreCase = true) }.distinct()
        if (found.isEmpty()) qc.pass("The generated text names no historical scholar or commentator.")
        else qc.warn("The generated text mentions ${found.joinToString(", ")}. The app cannot verify any such attribution — treat it as unverified, and do not cite it as that author's view.")
    }

    fun analyseSloka(
        text: String, out: Lang, cancel: CancelToken, progress: (String) -> Unit,
    ): ScholarResult {
        val trace = Trace()
        trace.statusSink = progress
        val verses = splitVerses(text)
        val qc = QcReport()
        val sections = ArrayList<Section>()
        if (verses.isEmpty()) throw EngineException(FailKind.BAD_REQUEST, "Please enter a Sanskrit verse.")
        qc.info("Analysed by the AI model; metre and IAST were also computed by the app itself. ${verses.size} verse(s).")
        var allText = StringBuilder()
        val sys = Prompts.slokaSystem(out)
        for ((vi, verse) in verses.withIndex()) {
            cancel.check()
            progress("Analysing verse ${vi + 1} of ${verses.size}…")
            val prefix = if (verses.size > 1) "Verse ${vi + 1}: " else ""
            val conv = Translit.normaliseSanskritInput(Scripts.nfc(verse))
            val dev = conv.devanagari
            val scan = Prosody.scan(dev)
            val r = jsonCall(sys, Prompts.slokaUser(dev), cancel, trace)
            val head = ArrayList<Block>()
            head.add(Block.Para(verse.trim(), sanskrit = true))
            if (conv.converted) head.add(Block.Para("Devanagari (converted by the app): $dev", sanskrit = true))
            head.add(Block.Para("IAST (computed by the app): ${Translit.devanagariToIast(dev)}"))
            sections.add(Section("${prefix}Original verse", head))
            if (r.truncated) { qc.fail("${prefix}The AI model's answer was cut off; please try the verse again."); sections.add(Section("${prefix}Analysis", listOf(Block.Para("The answer was cut off. Try again, or analyse fewer verses at a time.", uncertain = true)))); continue }
            val o = r.obj
            if (o == null) {
                qc.fail("${prefix}The AI model's answer could not be read as structured data.")
                sections.add(Section("${prefix}Raw answer from the AI model (unstructured)", listOf(Block.Para(r.reply?.text ?: "", uncertain = true))))
                continue
            }
            qc.pass("${prefix}Structured answer read successfully (${r.reply?.model}).")
            allText.append(o.toString()).append('\n')

            // echo check
            val echo = JsonUtil.str(o, "verse_devanagari")
            fun core(s: String) = s.filter { it.isLetter() || Character.getType(it) == Character.NON_SPACING_MARK.toInt() || Character.getType(it) == Character.COMBINING_SPACING_MARK.toInt() }
            if (echo.isNotBlank()) {
                if (core(Scripts.nfc(echo)) == core(dev)) qc.pass("${prefix}The model's copy of the verse matches your text exactly.")
                else qc.warn("${prefix}The model's copy of the verse differs from your text; the analysis may be of a slightly different reading. Model's copy: $echo")
            }
            // padaccheda
            val pada = JsonUtil.strList(o, "padaccheda")
            sections.add(Section("${prefix}Padaccheda", if (pada.isEmpty()) listOf(Block.Para("Not returned.", uncertain = true)) else pada.map { Block.Para(it, sanskrit = true) }))
            if (pada.isNotEmpty()) {
                if (scan.padaCount > 0 && pada.size == scan.padaCount) qc.pass("${prefix}Padaccheda has ${pada.size} pāda(s), matching the app's own pāda count.")
                else qc.info("${prefix}Padaccheda has ${pada.size} line(s); the app's pāda count is ${scan.padaCount}.")
            }
            // words
            val words = JsonUtil.objList(o, "words")
            sections.add(Section("${prefix}Pratipadārtha and grammatical analysis (${words.size} words)", if (words.isEmpty()) listOf(Block.Para("Not returned.", uncertain = true)) else words.map { wordEntry(it) }))
            checkWords(words, qc)
            val inputTokens = dev.split(Regex("[\\s।॥|]+")).count { it.isNotBlank() && !it.all { c -> c.isDigit() || c in '०'..'९' } }
            qc.info("${prefix}Your verse has $inputTokens space-separated token(s); the analysis lists ${words.size} word(s) after sandhi and compound handling.")
            // samasa
            val sam = JsonUtil.objList(o, "samasa")
            sections.add(Section("${prefix}Samāsa analysis", if (sam.isEmpty()) listOf(Block.Para("No compounds reported.")) else sam.map { samasaEntry(it) }))
            // anvaya, bhavartha, tatparya
            val anvaya = JsonUtil.str(o, "anvaya")
            sections.add(Section("${prefix}Anvaya", listOf(Block.Para(anvaya.ifBlank { "Not returned." }, sanskrit = true, uncertain = anvaya.isBlank())) +
                if (anvaya.isNotBlank() && Scripts.dominant(anvaya) == Script.DEVANAGARI) listOf(Block.Para("IAST (computed by the app): " + Translit.devanagariToIast(anvaya))) else emptyList()))
            sections.add(Section("${prefix}Bhāvārtha", listOf(Block.Para(JsonUtil.str(o, "bhavartha").ifBlank { "Not returned." }))))
            sections.add(Section("${prefix}Tātparya", listOf(Block.Para(JsonUtil.str(o, "tatparya").ifBlank { "Not returned." }))))
            // chandas
            val ch = JsonUtil.obj(o, "chandas")
            val chName = JsonUtil.str(ch, "name")
            val chBlocks = ArrayList<Block>()
            chBlocks.add(Block.Para(
                if (chName.isBlank()) "The AI model did not name a metre." else "AI model's identification: $chName" +
                    (JsonUtil.str(ch, "evidence").takeIf { it.isNotBlank() }?.let { " — $it" } ?: "") +
                    (JsonUtil.str(ch, "confidence").takeIf { it.isNotBlank() }?.let { " (${it})" } ?: ""),
                uncertain = chName.isBlank() || JsonUtil.str(ch, "confidence") == "uncertain"))
            val scanLines = scan.patterns.mapIndexed { k, p -> "Pāda ${k + 1}: ${scan.syllableCounts[k]} syllables  ${lgString(p)}" }
            chBlocks.add(Block.Entry(
                head = "App's own metrical scan" + (scan.name?.let { " → $it" } ?: ""),
                lines = scanLines.map { "" to it } + listOf("Result" to scan.detail),
                uncertain = !scan.exact))
            sections.add(Section("${prefix}Chandas", chBlocks))
            if (scan.padaCount > 0) {
                val a = fold(chName); val b = fold(scan.name ?: "")
                when {
                    scan.name == null && chName.isBlank() -> qc.info("${prefix}Neither the model nor the app's scan identified a metre.")
                    chName.isBlank() -> qc.info("${prefix}The model named no metre; the app's scan suggests ${scan.name}.")
                    scan.name == null -> qc.warn("${prefix}The model says “$chName”, but the app's scan found no exact standard pattern. Treat the metre as unconfirmed.")
                    a.contains(b.take(6)) || b.contains(a.take(6)) -> qc.pass("${prefix}The model's metre (“$chName”) agrees with the app's own syllable scan (${scan.name}).")
                    else -> qc.warn("${prefix}The model says “$chName” but the app's syllable scan gives ${scan.name}. Check the metre yourself.")
                }
            }
            // alankara
            val al = JsonUtil.objList(o, "alankara")
            sections.add(Section("${prefix}Alaṅkāra", if (al.isEmpty()) listOf(Block.Para("No figure of speech was clearly identified.")) else al.map {
                Block.Entry(head = JsonUtil.str(it, "name"), lines = listOf("Reason" to JsonUtil.str(it, "explanation")), uncertain = JsonUtil.str(it, "confidence") == "uncertain") }))
            // translation
            sections.add(Section("${prefix}Translation (${out.english})", listOf(Block.Para(JsonUtil.str(o, "translation").ifBlank { "Not returned." }))))
            val unc = JsonUtil.strList(o, "uncertainties")
            if (unc.isNotEmpty()) sections.add(Section("${prefix}Points of uncertainty (reported by the model)", unc.map { Block.Para(it, uncertain = true) }))
        }
        attributionCheck(allText.toString(), text, qc)
        if (trace.retries > 0 || trace.failovers > 0) qc.info("Temporary problems handled automatically: ${trace.retries} retry attempt(s), ${trace.failovers} switch(es) to another provider.")
        qc.addStandingNotes(true, trace)
        return ScholarResult(null, Document(sections, qc), qc, trace = trace)
    }

    // ------------------------------------------------------------------ Sanskrit: prose analysis
    fun analyseProse(text: String, out: Lang, cancel: CancelToken, progress: (String) -> Unit): ScholarResult {
        val trace = Trace()
        trace.statusSink = progress
        val conv = Translit.normaliseSanskritInput(Scripts.nfc(text))
        val dev = conv.devanagari
        val chunks = Segmenter.split(dev, 700)
        val sys = Prompts.proseSystem(out)
        val qc = QcReport()
        val sections = ArrayList<Section>()
        val head = ArrayList<Block>()
        head.add(Block.Para(text.trim(), sanskrit = true))
        if (conv.converted) head.add(Block.Para("Devanagari (converted by the app): $dev", sanskrit = true))
        sections.add(Section("Original passage", head))
        qc.info("Analysed by the AI model in ${chunks.size} part(s); IAST was computed by the app.")
        var sentenceNo = 0; var anyFail = false; val overall = ArrayList<String>(); val unc = ArrayList<String>()
        val allText = StringBuilder()
        var words = 0; var wordsIncompleteNominal = 0; var uncertainWords = 0
        for ((ci, ch) in chunks.withIndex()) {
            cancel.check()
            progress("Analysing part ${ci + 1} of ${chunks.size}…")
            val r = jsonCall(sys, Prompts.proseUser(ch.text), cancel, trace)
            if (r.truncated) { anyFail = true; qc.fail("Part ${ci + 1}: the AI model's answer was cut off."); sections.add(Section("Part ${ci + 1} (not analysed)", listOf(Block.Para(ch.text, sanskrit = true, uncertain = true)))); continue }
            val o = r.obj
            if (o == null) { anyFail = true; qc.fail("Part ${ci + 1}: the answer could not be read as structured data."); sections.add(Section("Part ${ci + 1} — raw answer from the AI model (unstructured)", listOf(Block.Para(r.reply?.text ?: "", uncertain = true)))); continue }
            allText.append(o.toString())
            val sentences = JsonUtil.objList(o, "sentences")
            if (sentences.isEmpty()) { anyFail = true; qc.warn("Part ${ci + 1}: no sentences were returned.") }
            for (s in sentences) {
                sentenceNo++
                val blocks = ArrayList<Block>()
                val st = JsonUtil.str(s, "text")
                blocks.add(Block.Para(st, sanskrit = true))
                if (Scripts.dominant(st) == Script.DEVANAGARI) blocks.add(Block.Para("IAST (computed by the app): " + Translit.devanagariToIast(st)))
                val ws = JsonUtil.objList(s, "words")
                words += ws.size
                uncertainWords += ws.count { JsonUtil.str(it, "confidence") == "uncertain" }
                wordsIncompleteNominal += ws.count { w -> val c = JsonUtil.str(w, "category").lowercase(); (c.contains("noun") || c.contains("adjective") || c.contains("pronoun")) && (JsonUtil.str(w, "vibhakti").isBlank() || JsonUtil.str(w, "vacana").isBlank() || JsonUtil.str(w, "linga").isBlank()) }
                blocks.addAll(ws.map { wordEntry(it) })
                blocks.addAll(JsonUtil.objList(s, "samasa").map { samasaEntry(it) })
                val syn = JsonUtil.str(s, "syntax"); if (syn.isNotBlank()) blocks.add(Block.Entry(head = "Syntax", lines = listOf("" to syn)))
                val an = JsonUtil.str(s, "anvaya"); if (an.isNotBlank()) blocks.add(Block.Entry(head = "Anvaya", lines = listOf("" to an)))
                blocks.add(Block.Entry(head = "Meaning", lines = listOf("" to JsonUtil.str(s, "meaning"))))
                blocks.add(Block.Entry(head = "Translation (${out.english})", lines = listOf("" to JsonUtil.str(s, "translation"))))
                sections.add(Section("Sentence $sentenceNo", blocks))
            }
            JsonUtil.str(o, "overall_meaning").takeIf { it.isNotBlank() }?.let { overall.add(it) }
            unc.addAll(JsonUtil.strList(o, "uncertainties"))
        }
        if (overall.isNotEmpty()) sections.add(Section("Overall meaning", overall.map { Block.Para(it) }))
        if (unc.isNotEmpty()) sections.add(Section("Points of uncertainty (reported by the model)", unc.map { Block.Para(it, uncertain = true) }))
        if (!anyFail) qc.pass("Structured answers read successfully for all ${chunks.size} part(s).")
        qc.info("$sentenceNo sentence(s) and $words word entries analysed.")
        if (words > 0) {
            if (wordsIncompleteNominal == 0) qc.pass("Every noun, adjective and pronoun has vibhakti, vacana and liṅga stated.")
            else qc.warn("$wordsIncompleteNominal nominal form(s) lack vibhakti, vacana or liṅga.")
            if (uncertainWords > 0) qc.warn("The model marked $uncertainWords word(s) as uncertain (shown with a ⚠ marker).")
        }
        attributionCheck(allText.toString(), text, qc)
        if (trace.retries > 0 || trace.failovers > 0) qc.info("Temporary problems handled automatically: ${trace.retries} retry attempt(s), ${trace.failovers} switch(es) to another provider.")
        qc.addStandingNotes(true, trace)
        return ScholarResult(null, Document(sections, qc), qc, trace = trace)
    }

    // ------------------------------------------------------------------ Sanskrit-to-Sanskrit commentary
    fun commentary(text: String, part: Prompts.CommentaryPart, cancel: CancelToken, progress: (String) -> Unit): ScholarResult {
        val trace = Trace()
        trace.statusSink = progress
        val conv = Translit.normaliseSanskritInput(Scripts.nfc(text))
        val dev = conv.devanagari
        val chunks = Segmenter.split(dev, 900)
        val sys = Prompts.commentarySystem(part)
        val qc = QcReport()
        val sections = ArrayList<Section>()
        val head = ArrayList<Block>(); head.add(Block.Para(text.trim(), sanskrit = true))
        if (conv.converted) head.add(Block.Para("Devanagari (converted by the app): $dev", sanskrit = true))
        sections.add(Section("Original text", head))
        val paraphrase = ArrayList<String>(); val grammar = ArrayList<Block>(); val wordsB = ArrayList<Block>(); val unc = ArrayList<String>()
        var anyFail = false; val allText = StringBuilder(); var cited = 0; var citedFound = 0
        val devNoSpace = dev.filter { !it.isWhitespace() }
        for ((ci, ch) in chunks.withIndex()) {
            cancel.check()
            progress("Writing commentary, part ${ci + 1} of ${chunks.size}…")
            val r = jsonCall(sys, Prompts.commentaryUser(ch.text), cancel, trace)
            if (r.truncated) { anyFail = true; qc.fail("Part ${ci + 1}: the AI model's answer was cut off."); continue }
            val o = r.obj
            if (o == null) { anyFail = true; qc.fail("Part ${ci + 1}: the answer could not be read as structured data."); sections.add(Section("Part ${ci + 1} — raw answer from the AI model (unstructured)", listOf(Block.Para(r.reply?.text ?: "", uncertain = true)))); continue }
            allText.append(o.toString())
            JsonUtil.str(o, "paraphrase").takeIf { it.isNotBlank() }?.let { paraphrase.add(it) }
            for (g in JsonUtil.objList(o, "grammar")) {
                val p = JsonUtil.str(g, "point"); cited++
                val stem = p.filter { it.isLetter() || Character.getType(it) == Character.NON_SPACING_MARK.toInt() || Character.getType(it) == Character.COMBINING_SPACING_MARK.toInt() }
                if (stem.isNotEmpty() && (devNoSpace.contains(stem.trimEnd('्')) )) citedFound++
                grammar.add(Block.Entry(head = p, lines = listOf("" to JsonUtil.str(g, "explanation")), uncertain = JsonUtil.str(g, "confidence") == "uncertain"))
            }
            for (w in JsonUtil.objList(o, "words")) {
                val wd = JsonUtil.str(w, "word"); cited++
                val stem = wd.filter { it.isLetter() || Character.getType(it) == Character.NON_SPACING_MARK.toInt() || Character.getType(it) == Character.COMBINING_SPACING_MARK.toInt() }
                if (stem.isNotEmpty() && devNoSpace.contains(stem.trimEnd('्'))) citedFound++
                val iast = if (Scripts.dominant(wd) == Script.DEVANAGARI) Translit.devanagariToIast(wd) else ""
                wordsB.add(Block.Entry(head = wd, sub = iast, lines = listOf("अर्थः" to JsonUtil.str(w, "artha")), uncertain = JsonUtil.str(w, "confidence") == "uncertain"))
            }
            unc.addAll(JsonUtil.strList(o, "uncertainties"))
        }
        val wantP = part == Prompts.CommentaryPart.PARAPHRASE || part == Prompts.CommentaryPart.ALL
        val wantG = part == Prompts.CommentaryPart.GRAMMAR || part == Prompts.CommentaryPart.ALL
        val wantW = part == Prompts.CommentaryPart.WORDS || part == Prompts.CommentaryPart.ALL
        if (wantP) sections.add(Section("सरलसंस्कृतव्याख्या — Simple Sanskrit paraphrase", if (paraphrase.isEmpty()) listOf(Block.Para("Not returned.", uncertain = true)) else paraphrase.map { Block.Para(it, sanskrit = true) } +
            paraphrase.filter { Scripts.dominant(it) == Script.DEVANAGARI }.map { Block.Para("IAST (computed by the app): " + Translit.devanagariToIast(it)) }))
        if (wantG) sections.add(Section("व्याकरणटिप्पणी — Grammatical commentary", if (grammar.isEmpty()) listOf(Block.Para("Not returned.", uncertain = true)) else grammar))
        if (wantW) sections.add(Section("पदार्थः — Word-by-word meanings in Sanskrit", if (wordsB.isEmpty()) listOf(Block.Para("Not returned.", uncertain = true)) else wordsB))
        if (unc.isNotEmpty()) sections.add(Section("Points of uncertainty (reported by the model)", unc.map { Block.Para(it, uncertain = true) }))
        sections.add(Section("Note on authorship", listOf(Block.Para("This commentary was generated by an AI model for this session. It is not the commentary of any historical ācārya and should not be cited as such."))))
        qc.info("Written by the AI model in ${chunks.size} part(s); IAST was computed by the app.")
        if (!anyFail) qc.pass("Structured answers read successfully for all ${chunks.size} part(s).")
        val missing = ArrayList<String>()
        if (wantP && paraphrase.isEmpty()) missing.add("paraphrase"); if (wantG && grammar.isEmpty()) missing.add("grammatical commentary"); if (wantW && wordsB.isEmpty()) missing.add("word meanings")
        if (missing.isEmpty()) qc.pass("All requested parts were returned.") else qc.warn("Not returned: ${missing.joinToString(", ")}.")
        if (cited > 0) {
            if (citedFound * 2 >= cited) qc.info("$citedFound of $cited cited words/points occur verbatim in your text (the rest may be sandhi-split forms).")
            else qc.warn("Only $citedFound of $cited cited words/points occur verbatim in your text; some may be sandhi-split forms, but check that the commentary is about your passage.")
        }
        attributionCheck(allText.toString(), text, qc)
        if (trace.retries > 0 || trace.failovers > 0) qc.info("Temporary problems handled automatically: ${trace.retries} retry attempt(s), ${trace.failovers} switch(es) to another provider.")
        qc.addStandingNotes(true, trace)
        return ScholarResult(null, Document(sections, qc), qc, trace = trace)
    }
}
