package org.tribhasa.app.ui

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.text.TextUtils
import org.tribhasa.app.App
import org.tribhasa.app.core.History
import org.tribhasa.app.core.HistoryEntry
import org.tribhasa.app.core.Lang
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything the scholar has translated, refined or analysed, kept on this phone. */
class HistoryScreen(private val ctx: Context, private val host: Host) : Screen {
    override val title = "History"
    private val scroll = page(ctx)
    override val view: View = scroll.first
    private val col = scroll.second
    private val search = Ui.input(ctx, "Search the history", 1, singleLine = true)
    private val list = LinearLayout(ctx)
    private val more = Ui.button(ctx, "Show more", primary = false) { shown += PAGE; render() }
    private val empty = Ui.text(ctx, "", 15f, Pal.inkSoft)
    private val clearBtn = Ui.button(ctx, "Clear all history", primary = false) { confirmClear() }
    private var entries: List<HistoryEntry> = emptyList()
    private var shown = PAGE
    private val fmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("en", "IN"))

    init {
        list.orientation = LinearLayout.VERTICAL
        col.add(Ui.text(ctx, "Every finished translation, refinement and analysis is kept here on this phone, with your original text and the result stored separately. Nothing is limited or expires.", 14f, Pal.inkSoft), bottom = 12)
        col.add(search, bottom = 12)
        col.add(list)
        col.add(more, top = 4, bottom = 8)
        empty.setPadding(ctx.dp(4), ctx.dp(8), ctx.dp(4), ctx.dp(8))
        col.add(empty, bottom = 8)
        col.add(clearBtn)
        search.onChange { shown = PAGE; render() }
        reload(); render()
    }

    override fun onShow() { reload(); render() }

    private fun reload() { entries = App.store.history() }

    private fun stamp(e: HistoryEntry): String = if (e.time > 0) fmt.format(Date(e.time)) else ""

    private fun render() {
        list.removeAllViews()
        val q = search.text?.toString() ?: ""
        val found = History.search(entries, q)
        for (e in found.take(shown)) list.add(card(e), bottom = 8)
        more.show(found.size > shown)
        more.text = "Show more (${found.size - shown} left)"
        empty.text = when {
            entries.isEmpty() -> "Nothing here yet. Finished translations, refinements and analyses appear here automatically."
            found.isEmpty() -> "No entry matches “$q”."
            else -> "Showing ${minOf(shown, found.size)} of ${found.size} entr${if (found.size == 1) "y" else "ies"}${if (q.isNotBlank()) " matching “$q”" else ""}."
        }
        clearBtn.show(entries.isNotEmpty())
    }

    private fun card(e: HistoryEntry): View {
        val c = Ui.card(ctx)
        c.isClickable = true
        c.setOnClickListener { open(e) }
        c.add(Ui.text(ctx, "${e.kind.label} · ${e.title}", 15f, Pal.primary, bold = true))
        c.add(Ui.text(ctx, stamp(e), 12f, Pal.inkSoft), bottom = 6)
        c.add(Ui.label(ctx, "Original"), top = 2)
        c.add(preview(e.input))
        c.add(Ui.label(ctx, "Result"), top = 8)
        c.add(preview(e.output))
        if (e.warnings > 0) c.add(Ui.text(ctx, "⚠ ${e.warnings} point(s) flagged in its report", 12f, Pal.warn, bold = true), top = 8)
        return c
    }

    private fun preview(text: String) = Ui.text(ctx, History.preview(text, 140), 14f, Pal.ink).also {
        it.maxLines = 2
        it.ellipsize = TextUtils.TruncateAt.END
    }

    private fun open(e: HistoryEntry) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(8))
        box.add(Ui.text(ctx, "${e.kind.label} · ${e.title}", 16f, Pal.primary, bold = true))
        box.add(Ui.text(ctx, stamp(e), 12f, Pal.inkSoft))
        box.add(Ui.label(ctx, "Original text"), top = 14, bottom = 4)
        box.add(Ui.selectable(ctx, e.input, 16f))
        box.add(Ui.label(ctx, "Result"), top = 14, bottom = 4)
        box.add(Ui.selectable(ctx, e.output, 16f))
        if (e.madeWith.isNotBlank()) box.add(Ui.text(ctx, "Made with: ${e.madeWith}", 13f, Pal.inkSoft), top = 12)
        if (e.warnings > 0) box.add(Ui.text(ctx, "⚠ ${e.warnings} point(s) were flagged in its Quality Control Report when it was made.", 13f, Pal.warn), top = 6)
        val sv = ScrollView(ctx); sv.addView(box)
        val dlg = AlertDialog.Builder(ctx).setView(sv).setPositiveButton("Close", null).create()

        val r1 = hrow(ctx)
        r1.addSide(Ui.chip(ctx, "Copy original") { Ui.copy(ctx, e.input, "Original copied") }, right = 8)
        r1.addSide(Ui.chip(ctx, "Copy result") { Ui.copy(ctx, e.output, "Result copied") })
        box.add(r1, top = 16)
        val r2 = hrow(ctx)
        val canReopen = e.kind == HistoryEntry.Kind.TRANSLATION && Lang.fromName(e.from) != null && Lang.fromName(e.to) != null
        if (canReopen) r2.addSide(Ui.chip(ctx, "Open in Translate") { dlg.dismiss(); reopen(e) }, right = 8)
        r2.addSide(Ui.chip(ctx, "Delete") {
            App.store.saveHistory(History.remove(App.store.history(), e.id)); dlg.dismiss(); reload(); render()
        })
        box.add(r2, top = 8)
        dlg.show()
    }

    private fun reopen(e: HistoryEntry) {
        val m = App.translate
        if (m.running) { Ui.toast(ctx, "A translation is running; wait for it to finish first."); return }
        m.src = Lang.fromName(e.from) ?: m.src
        m.tgt = Lang.fromName(e.to) ?: m.tgt
        if (m.src == m.tgt) m.tgt = Lang.values().first { it != m.src }
        m.input = e.input; m.output = e.output
        m.qc = null; m.job = null; m.jobKey = ""; m.missing = emptyList(); m.error = null; m.status = ""
        App.store.setPref("t_src", m.src.name); App.store.setPref("t_tgt", m.tgt.name)
        host.openTranslate()
    }

    private fun confirmClear() {
        AlertDialog.Builder(ctx).setTitle("Clear all history?")
            .setMessage("All ${entries.size} saved entries will be removed from this phone. This cannot be undone. Your glossary is not touched.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ -> App.store.saveHistory(emptyList()); reload(); render() }
            .show()
    }

    private companion object { const val PAGE = 40 }
}
