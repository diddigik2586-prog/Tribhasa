package org.tribhasa.app.core

import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Why a browser sign-in did not finish. A user cancelling is reported as [EngineException] with [FailKind.CANCELLED],
 * like every other cancelled task, so it is not an error.
 */
class SignInException(val why: Why, message: String, val detail: String? = null) : Exception(message) {
    enum class Why { DENIED, TIMEOUT, BROWSER, NETWORK, REJECTED, LISTENER }
}

/** PKCE (RFC 7636) with the S256 method. */
object Pkce {
    private val b64 = Base64.getUrlEncoder().withoutPadding()

    private fun random(bytes: Int, rnd: SecureRandom): String {
        val b = ByteArray(bytes); rnd.nextBytes(b)
        return b64.encodeToString(b)
    }

    /** 43 characters from the unreserved set, as RFC 7636 section 4.1 requires (32 random bytes). */
    fun newVerifier(rnd: SecureRandom = SecureRandom()): String = random(32, rnd)

    /** Unguessable value that ties the browser's reply to this attempt. */
    fun newState(rnd: SecureRandom = SecureRandom()): String = random(24, rnd)

    /** BASE64URL(SHA256(ASCII(verifier))) without padding. */
    fun challenge(verifier: String): String =
        b64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))
}

/**
 * A tiny web server that listens on this phone only (127.0.0.1, a port chosen by the system) for the one request the
 * browser makes when OpenRouter sends the user back. OpenRouter documents that "localhost callbacks are supported on any port".
 *
 * It answers only `GET /callback`, only with a Host header naming the loopback address and its own port, and it
 * accepts a code only together with the unguessable `state` it handed out. It never repeats anything it received.
 */
class LoopbackReceiver(private val expectedState: String, bindTo: InetAddress = InetAddress.getByName("127.0.0.1")) : Closeable {
    sealed class Callback {
        class Code(val code: String) : Callback()
        object Denied : Callback()
    }

    private val server = ServerSocket(0, 8, bindTo)
    private val results = LinkedBlockingQueue<Callback>()
    private val active = AtomicInteger(0)
    @Volatile private var closed = false

    val port: Int get() = server.localPort
    val callbackUrl: String get() = "http://localhost:$port/callback"

    fun start(): LoopbackReceiver {
        val t = Thread({ acceptLoop() }, "tribhasa-signin")
        t.isDaemon = true
        t.start()
        return this
    }

    private fun acceptLoop() {
        while (!closed) {
            val s = try { server.accept() } catch (e: IOException) { return }
            if (active.incrementAndGet() > MAX_CONNECTIONS) {
                active.decrementAndGet(); closeQuietly(s); continue
            }
            val t = Thread({
                try { serve(s) } catch (_: Exception) { } finally { active.decrementAndGet(); closeQuietly(s) }
            }, "tribhasa-signin-conn")
            t.isDaemon = true
            t.start()
        }
    }

    /** Waits for the browser's reply. Throws [EngineException] (CANCELLED) when cancelled, [SignInException] (TIMEOUT) when time runs out. */
    fun await(timeoutMs: Long, cancel: CancelToken): Callback {
        val end = System.nanoTime() + timeoutMs * 1_000_000
        while (true) {
            cancel.check()
            val leftMs = (end - System.nanoTime()) / 1_000_000
            if (leftMs <= 0) throw SignInException(SignInException.Why.TIMEOUT, "The sign-in was not completed in time.")
            val r = results.poll(minOf(leftMs, 250L), TimeUnit.MILLISECONDS)
            if (r != null) return r
        }
    }

    override fun close() {
        closed = true
        try { server.close() } catch (_: IOException) {}
    }

    private fun serve(s: Socket) {
        s.soTimeout = READ_TIMEOUT_MS
        val head = readHead(s.getInputStream()) ?: return
        val out = s.getOutputStream()
        val lines = head.split("\r\n")
        val parts = lines[0].split(" ")
        if (parts.size < 2 || parts[0] != "GET") { reply(out, 405, "text/plain; charset=utf-8", "Method not allowed."); return }
        val host = lines.drop(1).firstOrNull { it.startsWith("host:", ignoreCase = true) }?.substringAfter(':')?.trim()?.lowercase()
        if (host != "localhost:$port" && host != "127.0.0.1:$port" && host != "[::1]:$port") {
            reply(out, 400, "text/plain; charset=utf-8", "Wrong address."); return
        }
        val target = parts[1]
        val path = target.substringBefore('?')
        if (path != "/callback") { reply(out, 404, "text/plain; charset=utf-8", "Not found."); return }
        val q = parseQuery(target.substringAfter('?', ""))
        val code = q["code"]
        val state = q["state"]
        val stateOk = state != null && sameText(state, expectedState)
        if (code != null) {
            if (!stateOk || code.isBlank() || code.length > MAX_CODE_CHARS) {
                reply(out, 400, "text/plain; charset=utf-8", "This sign-in reply does not belong to this app."); return
            }
            reply(out, 200, "text/html; charset=utf-8", PAGE_OK)
            results.add(Callback.Code(code))
        } else {
            // OpenRouter sends no code (and, as documented, no state) when the user declines.
            if (state != null && !stateOk) { reply(out, 400, "text/plain; charset=utf-8", "This sign-in reply does not belong to this app."); return }
            reply(out, 200, "text/html; charset=utf-8", PAGE_DENIED)
            results.add(Callback.Denied)
        }
    }

    private fun readHead(input: InputStream): String? {
        val buf = java.io.ByteArrayOutputStream()
        var last4 = 0
        while (buf.size() < MAX_HEAD_BYTES) {
            val b = try { input.read() } catch (e: IOException) { return null }
            if (b < 0) return null
            buf.write(b)
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) return String(buf.toByteArray(), Charsets.ISO_8859_1).trimEnd('\r', '\n')
        }
        return null
    }

    private fun reply(out: OutputStream, status: Int, type: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val reason = when (status) { 200 -> "OK"; 400 -> "Bad Request"; 404 -> "Not Found"; 405 -> "Method Not Allowed"; else -> "Error" }
        val head = "HTTP/1.1 $status $reason\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\n" +
            "Cache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nX-Content-Type-Options: nosniff\r\n" +
            "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1)); out.write(bytes); out.flush()
    }

    private fun closeQuietly(s: Socket) { try { s.close() } catch (_: IOException) {} }

    companion object {
        const val MAX_CONNECTIONS = 16
        const val READ_TIMEOUT_MS = 3_000
        const val MAX_HEAD_BYTES = 8 * 1024
        const val MAX_CODE_CHARS = 2048

        /** The page the browser shows. It is fixed text: nothing from the request is ever put into it. */
        private fun page(heading: String, line: String) =
            "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
                "<title>Tribhāṣā</title><style>body{font-family:sans-serif;margin:0;padding:32px 22px;background:#fbf7ef;color:#231f20;line-height:1.5}" +
                "h1{color:#2e2a6b;font-size:26px;margin:0 0 4px}h2{font-size:19px;margin:18px 0 8px}p{font-size:17px}" +
                "a.b{display:inline-block;margin-top:14px;padding:14px 22px;border-radius:26px;background:#2e2a6b;color:#fff;text-decoration:none;font-weight:bold}</style></head>" +
                "<body><h1>Tribhāṣā</h1><h2>$heading</h2><p>$line</p>" +
                "<a class=\"b\" href=\"tribhasa://connected\">Return to Tribhāṣā</a>" +
                "<p style=\"font-size:14px;color:#5e5650\">If the button does nothing, switch back to the Tribhāṣā app yourself. You may close this page.</p>" +
                "<script>setTimeout(function(){location.href='tribhasa://connected'},700)</script></body></html>"

        val PAGE_OK = page("Authorised", "OpenRouter has sent you back. The app is finishing the sign-in now; return to Tribhāṣā to see the result.")
        val PAGE_DENIED = page("Sign-in not completed", "OpenRouter did not authorise the app, so nothing was saved. Return to Tribhāṣā if you wish to try again.")

        fun parseQuery(q: String): Map<String, String> {
            val m = LinkedHashMap<String, String>()
            if (q.isEmpty()) return m
            for (pair in q.split('&')) {
                if (pair.isEmpty()) continue
                val k = pair.substringBefore('=')
                val v = pair.substringAfter('=', "")
                try {
                    val key = URLDecoder.decode(k, "UTF-8")
                    if (key !in m) m[key] = URLDecoder.decode(v, "UTF-8")
                } catch (_: IllegalArgumentException) { }
            }
            return m
        }

        /** Compares without stopping at the first difference. */
        fun sameText(a: String, b: String): Boolean =
            MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
    }
}

/**
 * OpenRouter's documented sign-in flow (OAuth with PKCE): the browser asks the user to sign in and authorise;
 * OpenRouter sends the browser back to a one-time address on this phone with a short-lived code; the app swaps
 * the code (plus its secret verifier) for an API key that belongs to the user's own account. The user never sees or types a key.
 */
object OpenRouterAuth {
    const val AUTH_URL = "https://openrouter.ai/auth"
    const val EXCHANGE_URL = "https://openrouter.ai/api/v1/auth/keys"
    const val KEY_LABEL = "Tribhasa Android app"
    /** OpenRouter codes expire after 10 minutes; the wait ends a little earlier. */
    const val WAIT_MS = 9L * 60_000

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun authorizeUrl(callbackUrl: String, challenge: String, state: String, label: String = KEY_LABEL, base: String = AUTH_URL): String =
        base + "?callback_url=" + enc(callbackUrl) + "&code_challenge=" + enc(challenge) + "&code_challenge_method=S256" +
            "&state=" + enc(state) + "&key_label=" + enc(label)

    /** Swaps the one-time code for the user's key. The key is never put into an error message. */
    fun exchange(code: String, verifier: String, cancel: CancelToken, url: String = EXCHANGE_URL): String {
        val body = org.json.JSONObject().put("code", code).put("code_verifier", verifier).put("code_challenge_method", "S256").toString()
        val resp = try {
            Http.request("POST", url, emptyMap(), body, cancel, readTimeoutMs = 30_000)
        } catch (e: EngineException) {
            if (e.kind == FailKind.CANCELLED) throw e
            throw SignInException(SignInException.Why.NETWORK, "OpenRouter could not be reached to finish signing in. Check the internet connection and try again.", e.detail)
        }
        if (resp.code !in 200..299) {
            val why = when (resp.code) {
                403 -> "OpenRouter did not accept the sign-in code (it may have expired or already been used). Please connect again."
                400 -> "OpenRouter did not accept the sign-in request. Please connect again."
                405 -> "OpenRouter does not allow this kind of sign-in at the moment."
                429 -> "OpenRouter is limiting sign-ins right now. Wait a minute and connect again."
                in 500..599 -> "OpenRouter is temporarily unavailable. Try again shortly."
                else -> "OpenRouter answered with an unexpected error (code ${resp.code})."
            }
            throw SignInException(SignInException.Why.REJECTED, why, "HTTP ${resp.code}: " + JsonUtil.errorMessage(resp.body).take(200))
        }
        val key = JsonUtil.str(JsonUtil.parseObject(resp.body), "key").trim()
        if (key.isEmpty() || key.length > 512 || key.any { it.isWhitespace() })
            throw SignInException(SignInException.Why.REJECTED, "OpenRouter's reply did not contain a usable key. Please connect again.", "HTTP ${resp.code}, no usable key field")
        return key
    }

    /**
     * Runs the whole sign-in and returns the key. [open] must start the browser on the given address and say whether it could.
     * Blocks until the user finishes, declines, cancels, or the time runs out; call it off the main thread.
     */
    fun signIn(
        open: (String) -> Boolean,
        cancel: CancelToken,
        progress: (String) -> Unit = {},
        authBase: String = AUTH_URL,
        exchangeUrl: String = EXCHANGE_URL,
        waitMs: Long = WAIT_MS,
        rnd: SecureRandom = SecureRandom(),
    ): String {
        val verifier = Pkce.newVerifier(rnd)
        val state = Pkce.newState(rnd)
        val rx = try { LoopbackReceiver(state).start() } catch (e: IOException) {
            throw SignInException(SignInException.Why.LISTENER, "This phone did not let the app wait for OpenRouter's reply, so automatic sign-in is not possible here.", e.toString())
        }
        return rx.use { r ->
            val url = authorizeUrl(r.callbackUrl, Pkce.challenge(verifier), state, base = authBase)
            progress("Opening your browser…")
            if (!open(url)) throw SignInException(SignInException.Why.BROWSER, "No web browser could be opened on this phone.")
            progress("Sign in on the OpenRouter page that opened, then tap Authorize. Nothing needs to be copied.")
            val cb = r.await(waitMs, cancel)
            if (cb !is LoopbackReceiver.Callback.Code)
                throw SignInException(SignInException.Why.DENIED, "The sign-in was not authorised, so nothing was saved.")
            progress("Finishing the sign-in…")
            exchange(cb.code, verifier, cancel, exchangeUrl)
        }
    }
}
