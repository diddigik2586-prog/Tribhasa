package org.tribhasa.app.core

import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class LlmRequest(
    val system: String,
    val user: String,
    val json: Boolean = false,
    val maxTokens: Int = 8192,
    val temperature: Double = 0.2,
)

data class LlmReply(
    val text: String,
    val truncated: Boolean,
    val model: String,
    val provider: String,
    val latencyMs: Long = 0,
    val completionTokens: Int = -1,
    /** Things the user should know about how this answer was made (for example "the GPU could not be used"). They become warnings in the report. */
    val notes: List<String> = emptyList(),
)

interface LlmProvider {
    val id: String
    val label: String
    /** Providers that share one account share its allowance and its key: a used-up allowance or a refused key is the same for all of them. */
    val account: String get() = id
    fun generate(req: LlmRequest, cancel: CancelToken): LlmReply
    /** Providers that can say what they are doing (loading a model, writing the answer) override this; the others ignore [status]. */
    fun generate(req: LlmRequest, cancel: CancelToken, status: (String) -> Unit): LlmReply = generate(req, cancel)
}

/** Every configured service failed; carries each one's reason in plain words. */
class ServiceFailure(val failures: List<Pair<String, EngineException>>) : Exception(
    failures.joinToString("\n") { "• ${it.first}: ${it.second.message}" }
) {
    val kinds: Set<FailKind> get() = failures.map { it.second.kind }.toSet()
    val allCancelled: Boolean get() = failures.isNotEmpty() && failures.all { it.second.kind == FailKind.CANCELLED }
}

// ---------------------------------------------------------------------------------------------
// Open-weight models through an OpenAI-compatible chat API (OpenRouter by default).
//
// The app never contains a key. The key is the user's own: normally handed to the app by OpenRouter's sign-in
// (OpenRouterAuth), or typed under Advanced in Settings, or, in production, the token of the owner's own secure
// backend that holds the real key. It is stored encrypted on the phone.
// ---------------------------------------------------------------------------------------------
class OpenAiCompatProvider(
    private val apiKey: String,
    model: String,
    private val baseUrl: String = Models.OPENROUTER_BASE,
    private val allowPaid: Boolean = false,
    private val denyDataCollection: Boolean = false,
    private val think: Models.Think = Models.Think.DEFAULT,
) : LlmProvider {
    override val id = "openai-compat"
    override val account: String = "api:$baseUrl"
    val model: String = model.trim()
    override val label: String = if (baseUrl.startsWith(Models.OPENROUTER_BASE)) "OpenRouter" else "AI service (${hostOf(baseUrl)})"

    private fun headers() = mapOf("Authorization" to "Bearer $apiKey")

    /** How many chat requests have really been sent (each one counts against a free daily allowance). */
    val requestsSent = java.util.concurrent.atomic.AtomicInteger(0)

    /** The hard stop that keeps the app on free models unless the user has switched paid models on. */
    private fun checkAllowed() {
        if (model.isBlank()) throw EngineException(FailKind.UNSUPPORTED, "No AI model is chosen. Open Settings and choose one.")
        if (!Models.validId(model)) throw EngineException(FailKind.UNSUPPORTED, "The model name “$model” is not valid. Open Settings and correct it.")
        if (!allowPaid && !Models.isFree(model))
            throw EngineException(FailKind.UNSUPPORTED, "“$model” is not a free model, and “Allow paid models” is off. Open Settings to choose a free model (its name ends in :free) or to allow paid models.")
    }

    fun buildBody(req: LlmRequest): JSONObject {
        val body = JSONObject()
            .put("model", model)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", req.system))
                .put(JSONObject().put("role", "user").put("content", req.user)))
            .put("max_tokens", req.maxTokens)
            .put("temperature", req.temperature)
            .put("stream", false)
        // response_format is deliberately NOT sent: many hosts reject it. JSON is asked for in the prompt and
        // read leniently (code fences and surrounding words are tolerated).
        think.effort?.let { body.put("reasoning", JSONObject().put("effort", it)) }
        if (denyDataCollection) body.put("provider", JSONObject().put("data_collection", "deny"))
        return body
    }

    override fun generate(req: LlmRequest, cancel: CancelToken): LlmReply {
        checkAllowed()
        requestsSent.incrementAndGet()
        val t0 = System.nanoTime()
        val resp = Http.request("POST", "$baseUrl/chat/completions", headers(), buildBody(req).toString(), cancel)
        val ms = (System.nanoTime() - t0) / 1_000_000
        if (resp.code !in 200..299) throw mapError(resp.code, resp.body, resp.retryAfterMs)
        return parseReply(resp, ms)
    }

    private fun parseReply(resp: HttpResponse, ms: Long): LlmReply {
        val o = JsonUtil.parseObject(resp.body)
            ?: throw EngineException(FailKind.BAD_RESPONSE, "$label sent a reply that could not be read.", resp.code, detail = resp.body.take(300))
        // OpenRouter can answer HTTP 200 and still report a failure inside the body.
        if (o.has("error") && !o.isNull("error")) throw bodyError(o)
        val choices = JsonUtil.objList(o, "choices")
        if (choices.isEmpty()) throw EngineException(FailKind.BAD_RESPONSE, "$label returned no answer.", resp.code, detail = resp.body.take(300))
        val c = choices[0]
        if (c.has("error") && !c.isNull("error")) throw bodyError(c)
        val finish = JsonUtil.str(c, "finish_reason")
        if (finish == "content_filter")
            throw EngineException(FailKind.BLOCKED, "The hosting service declined to answer for this text (content filter).")
        if (finish == "error")
            throw EngineException(FailKind.BAD_RESPONSE, "The hosting service stopped with an error before finishing the answer.", resp.code)
        val text = stripThinking(contentText(JsonUtil.obj(c, "message")))
        val served = JsonUtil.str(o, "model").ifBlank { model }
        val usage = JsonUtil.obj(o, "usage")
        val tokens = if (usage != null && usage.has("completion_tokens") && !usage.isNull("completion_tokens")) usage.optInt("completion_tokens", -1) else -1
        if (text.isBlank()) {
            if (finish == "length")
                throw EngineException(FailKind.BAD_REQUEST, "The model used its whole output allowance for thinking and gave no answer. Lower “Thinking” in Settings, or use a shorter text.", resp.code)
            throw EngineException(FailKind.BAD_RESPONSE, "$label returned an empty answer.", resp.code)
        }
        return LlmReply(text, truncated = finish == "length", model = served, provider = label, latencyMs = ms, completionTokens = tokens)
    }

    private fun bodyError(o: JSONObject): EngineException {
        val err = JsonUtil.obj(o, "error")
        val code = err?.optInt("code", 502) ?: 502
        return mapError(if (code in 400..599) code else 502, o.toString(), 0)
    }

    private fun mapError(code: Int, body: String, retryAfterMs: Long): EngineException {
        val msg = JsonUtil.errorMessage(body)
        val low = msg.lowercase()
        val host = hostNote(body)
        val tail = (if (msg.isNotBlank()) " ($msg)" else "") + host
        val det = body.take(400)
        return when (code) {
            401 -> EngineException(FailKind.AUTH, "$label rejected the API key$tail", code, detail = det)
            402 -> EngineException(FailKind.QUOTA, "$label reports that the account has insufficient credits (error 402)$tail. Free models still need the balance to be zero or above.", code, detail = det)
            403 -> if (low.contains("moderation") || low.contains("flagged"))
                EngineException(FailKind.BLOCKED, "$label declined this text because it was flagged by moderation$tail", code, detail = det)
            else EngineException(FailKind.AUTH, "$label rejected the key or its permission$tail", code, detail = det)
            404 -> EngineException(FailKind.UNSUPPORTED, "$label has no host for “$model” right now. Free variants are sometimes withdrawn or renamed, or your data-policy setting excludes every host. Open Settings and choose another model.$tail", code, detail = det)
            408 -> EngineException(FailKind.TIMEOUT, "$label timed out$tail", code, detail = det)
            429 -> {
                val daily = low.contains("per-day") || low.contains("per day") || low.contains("daily")
                if (daily) EngineException(FailKind.QUOTA, "The daily free-model allowance on $label is used up. It is 50 requests a day until the account has bought at least 10 credits, then 1,000$tail", code, detail = det)
                else EngineException(FailKind.RATE_LIMIT, "$label is limiting requests right now (free models allow 20 a minute)$tail", code, if (retryAfterMs > 0) retryAfterMs else 15_000, det)
            }
            502 -> EngineException(FailKind.SERVER, "The model's host is down or sent an invalid answer (error 502)$tail", code, retryAfterMs, det)
            503 -> if (low.contains("routing") || low.contains("requirements") || low.contains("no available"))
                EngineException(FailKind.UNSUPPORTED, "No host for “$model” meets your settings right now (error 503)$tail. Try another model, or switch off “Avoid hosts that keep or train on my text”.", code, detail = det)
            else EngineException(FailKind.SERVER, "$label is temporarily unavailable (error 503)$tail", code, retryAfterMs, det)
            else -> Http.failure(HttpResponse(code, body, retryAfterMs), label)
        }
    }

    // ---- public catalogue and key status (used by Settings and the model comparison) ----

    /** The service's public model list. Needs no credit; the key is sent only because some services require it. */
    fun listModels(cancel: CancelToken): List<Models.Listed> {
        val resp = Http.request("GET", "$baseUrl/models", headers(), null, cancel, readTimeoutMs = 45_000)
        if (resp.code !in 200..299) throw mapError(resp.code, resp.body, resp.retryAfterMs)
        val o = JsonUtil.parseObject(resp.body) ?: throw EngineException(FailKind.BAD_RESPONSE, "$label sent a model list that could not be read.")
        return JsonUtil.objList(o, "data").mapNotNull { m ->
            val id = JsonUtil.str(m, "id")
            if (id.isBlank()) null else {
                val pr = JsonUtil.obj(m, "pricing")
                Models.Listed(id, JsonUtil.str(m, "name").ifBlank { id }, m.optInt("context_length", 0), JsonUtil.str(pr, "prompt"), JsonUtil.str(pr, "completion"))
            }
        }
    }

    /** What the service says about the key (label, credits, free-tier flag, daily free-model counter if shown). */
    fun keyStatus(cancel: CancelToken): String {
        val resp = Http.request("GET", "$baseUrl/key", headers(), null, cancel, readTimeoutMs = 30_000)
        if (resp.code !in 200..299) throw mapError(resp.code, resp.body, resp.retryAfterMs)
        val o = JsonUtil.parseObject(resp.body) ?: return ""
        val d = JsonUtil.obj(o, "data") ?: o
        val parts = ArrayList<String>()
        val want = listOf("label", "is_free_tier", "usage", "limit", "limit_remaining")
        for (k in want) if (d.has(k) && !d.isNull(k)) parts.add("$k: ${d.opt(k)}")
        val keys = d.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in want || d.isNull(k)) continue
            val v = d.opt(k)
            if ((k.contains("daily") || k.contains("free")) && (v is Number || v is Boolean)) parts.add("$k: $v")
        }
        return parts.joinToString("\n")
    }

    companion object {
        private fun hostOf(u: String) = try { URL(u).host } catch (_: Exception) { u.take(40) }

        /** Content may be a string or a list of {type:"text", text:"…"} parts. */
        fun contentText(msg: JSONObject?): String {
            val v = msg?.opt("content")
            return when (v) {
                is String -> v
                is JSONArray -> (0 until v.length()).joinToString("") { i ->
                    val p = v.opt(i)
                    if (p is JSONObject) { val t = JsonUtil.str(p, "type"); if (t.isEmpty() || t == "text") JsonUtil.str(p, "text") else "" } else p?.toString() ?: ""
                }
                else -> ""
            }
        }

        private val THINK_BLOCK = Regex("(?is)<think(?:ing)?>.*?</think(?:ing)?>")
        private val THINK_OPEN = Regex("(?is)<think(?:ing)?>")
        private val THINK_STRAY_CLOSE = Regex("(?is)^.*?</think(?:ing)?>")

        /** Removes visible reasoning that some hosts put inside the answer. An unfinished thought is dropped. */
        fun stripThinking(s: String): String {
            var t = THINK_BLOCK.replace(s, "")
            val open = THINK_OPEN.find(t)
            if (open != null) t = t.substring(0, open.range.first)
            t = THINK_STRAY_CLOSE.replace(t, "")
            return t.trim()
        }

        private fun hostNote(body: String): String {
            val o = JsonUtil.parseObject(body) ?: return ""
            val md = JsonUtil.obj(JsonUtil.obj(o, "error"), "metadata") ?: return ""
            val p = JsonUtil.str(md, "provider_name")
            return if (p.isNotBlank()) " [host: $p]" else ""
        }
    }
}

/** Stands in for a provider that cannot be built (for example a saved address that is not https), so the user is told why. */
class BrokenProvider(private val why: String) : LlmProvider {
    override val id = "broken"
    override val label = "AI service"
    override fun generate(req: LlmRequest, cancel: CancelToken): LlmReply = throw EngineException(FailKind.UNSUPPORTED, why)
}

/** Tries providers in order; each is retried for temporary failures, then the next one is used. */
class LlmRouter(private val providers: List<LlmProvider>, private val retry: RetryPolicy = RetryPolicy()) {
    val isEmpty get() = providers.isEmpty()
    val labels get() = providers.map { it.label }

    fun generate(req: LlmRequest, cancel: CancelToken, trace: Trace): LlmReply {
        if (providers.isEmpty()) throw EngineException(FailKind.UNSUPPORTED, "The AI model is not connected yet. Open Settings and tap “Connect”.")
        val failures = ArrayList<Pair<String, EngineException>>()
        val spentAccounts = HashSet<String>()
        for ((idx, p) in providers.withIndex()) {
            if (p.account in spentAccounts) {
                // The same account has just been refused (allowance used up, or key refused): another model on it would only be refused too and use a request.
                trace.note("${p.label} was not tried: the same account was just refused.")
                continue
            }
            try {
                val out = retry.run(cancel, onRetry = { a, e, w ->
                    trace.retries++
                    trace.note("${p.label}: ${e.message} Trying again in ${(w + 500) / 1000}s (attempt ${a + 1}).")
                }) { p.generate(req, cancel, trace.statusSink) }
                val r = out.value
                trace.use("${p.label} (${r.model})", 1)
                if (p.id == LocalLlmProvider.ID) { trace.onDevice = true; trace.onDeviceLabel = r.model; r.notes.forEach { trace.flag(it) } }
                if (idx > 0) trace.failovers++
                return r
            } catch (e: AttemptsExhausted) {
                if (e.kind == FailKind.CANCELLED) throw e.last
                failures.add(p.label to e.last)
                if (e.kind == FailKind.QUOTA || e.kind == FailKind.AUTH) spentAccounts.add(p.account)
                trace.note("${p.label} could not be used: ${e.last.message}")
            } catch (e: EngineException) {
                if (e.kind == FailKind.CANCELLED) throw e
                failures.add(p.label to e)
                if (e.kind == FailKind.QUOTA || e.kind == FailKind.AUTH) spentAccounts.add(p.account)
                trace.note("${p.label} could not be used: ${e.message}")
            }
        }
        throw ServiceFailure(failures)
    }
}
