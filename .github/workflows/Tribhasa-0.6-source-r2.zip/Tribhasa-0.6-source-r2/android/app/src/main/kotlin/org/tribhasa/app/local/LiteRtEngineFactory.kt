package org.tribhasa.app.local

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import org.tribhasa.app.core.LocalBackend
import org.tribhasa.app.core.NativeEngine
import org.tribhasa.app.core.NativeEngineFactory
import org.tribhasa.app.core.NativeFailure
import org.tribhasa.app.core.NativeListener
import org.tribhasa.app.core.NativeTurn
import java.util.concurrent.CancellationException

/**
 * The only file that touches Google's LiteRT-LM library (com.google.ai.edge.litertlm:litertlm-android, Apache-2.0).
 *
 * Everything around it (loading once, one task at a time, cancelling, stalls, memory, honest messages) is in
 * core/LocalModelRuntime.kt and is tested on a computer with a stand-in engine. THIS FILE CAN ONLY BE TRIED ON A PHONE.
 * It was type-checked against the library's published v0.18.0 source; it has not been run.
 *
 * What it does, in the library's terms: build an Engine from the model file (CPU, or GPU when asked), keep it, and for each
 * task create a fresh Conversation (system text + one user message), stream the pieces back, and close the Conversation.
 */
class LiteRtEngineFactory : NativeEngineFactory {
    override fun open(modelPath: String, backend: LocalBackend, contextTokens: Int, cacheDir: String): NativeEngine {
        var engine: Engine? = null
        try {
            val config = EngineConfig(
                modelPath = modelPath,
                backend = if (backend == LocalBackend.GPU) Backend.GPU() else Backend.CPU(),
                maxNumTokens = contextTokens,
                cacheDir = cacheDir,
            )
            engine = Engine(config)
            engine.initialize()   // slow (seconds to tens of seconds); the runtime calls this off the main thread
            return LiteRtEngine(engine)
        } catch (t: Throwable) {
            try { if (engine != null && engine.isInitialized()) engine.close() } catch (_: Throwable) {}
            throw NativeFailure(classifyLoad(t), describe(t), t)
        }
    }

    private fun classifyLoad(t: Throwable): NativeFailure.Kind {
        if (t is OutOfMemoryError) return NativeFailure.Kind.OUT_OF_MEMORY
        val m = (t.message ?: "").lowercase()
        return if (m.contains("out of memory") || m.contains("bad_alloc") || m.contains("cannot allocate") || m.contains("resource_exhausted") || m.contains("oom"))
            NativeFailure.Kind.OUT_OF_MEMORY else NativeFailure.Kind.LOAD
    }

    private fun describe(t: Throwable): String = (t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName).take(300)
}

private class LiteRtEngine(private val engine: Engine) : NativeEngine {
    override fun start(system: String, user: String, maxOutputTokens: Int, temperature: Double, listener: NativeListener): NativeTurn {
        val conversation: Conversation = try {
            engine.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(system),
                    samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = temperature.coerceAtLeast(0.0)),
                    maxOutputToken = maxOutputTokens.coerceAtLeast(1),
                )
            )
        } catch (t: Throwable) { throw NativeFailure(NativeFailure.Kind.OTHER, t.message ?: t.javaClass.simpleName, t) }

        val turn = object : NativeTurn {
            override fun cancel() { try { if (conversation.isAlive) conversation.cancelProcess() } catch (_: Throwable) {} }
            override fun close() { try { if (conversation.isAlive) conversation.close() } catch (_: Throwable) {} }
        }
        try {
            conversation.sendMessageAsync(Message.user(user), object : MessageCallback {
                override fun onMessage(message: Message) {
                    val piece = message.contents.toString()   // only the text parts; "thinking" channels are kept apart by the library
                    if (piece.isNotEmpty()) listener.onPiece(piece)
                }
                override fun onDone() { listener.onDone() }
                override fun onError(throwable: Throwable) { listener.onError(classifyRun(throwable)) }
            }, maxOutputToken = maxOutputTokens.coerceAtLeast(1))
        } catch (t: Throwable) {
            turn.close()
            throw NativeFailure(NativeFailure.Kind.OTHER, t.message ?: t.javaClass.simpleName, t)
        }
        return turn
    }

    override fun close() { try { if (engine.isInitialized()) engine.close() } catch (_: Throwable) {} }

    private fun classifyRun(t: Throwable): NativeFailure {
        val text = (t.message ?: t.javaClass.simpleName).take(300)
        val m = text.lowercase()
        val kind = when {
            t is CancellationException -> NativeFailure.Kind.CANCELLED
            t is OutOfMemoryError || m.contains("out of memory") || m.contains("bad_alloc") || m.contains("resource_exhausted") -> NativeFailure.Kind.OUT_OF_MEMORY
            m.contains("maximum number of tokens") || m.contains("too long") || m.contains("max_num_tokens") || m.contains("exceed") -> NativeFailure.Kind.CONTEXT_FULL
            else -> NativeFailure.Kind.OTHER
        }
        return NativeFailure(kind, text, t)
    }
}
