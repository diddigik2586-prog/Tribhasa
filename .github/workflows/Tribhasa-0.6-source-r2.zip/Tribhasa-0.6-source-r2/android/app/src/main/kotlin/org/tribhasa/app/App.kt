package org.tribhasa.app

import android.content.Context
import android.net.ConnectivityManager
import android.os.Handler
import android.os.Looper
import org.tribhasa.app.core.*
import org.tribhasa.app.local.Local
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

data class UiError(
    val message: String,
    val canRetry: Boolean = true,
    val needsSettings: Boolean = false,
    val detail: String? = null,
)

open class TaskModel {
    var running = false
    var status = ""
    var error: UiError? = null
    var cancel: CancelToken? = null
    var listener: (() -> Unit)? = null
    fun changed() { listener?.invoke() }
}

class TranslateModel : TaskModel() {
    var src = Lang.SA
    var tgt = Lang.EN
    var input = ""
    var output = ""
    var qc: QcReport? = null
    var job: TranslationJob? = null
    var jobKey = ""
    var missing: List<GlossaryEntry> = emptyList()
    var view = Translit.SanskritView.DEVANAGARI
    var hasRun = false
}

class RefineModel : TaskModel() {
    var lang = Lang.EN
    var out = Lang.KN
    var tool = Prompts.Refine.CORRECT_GRAMMAR
    var input = ""
    var text: String? = null
    var refined: String? = null
    var doc: Document? = null
    var qc: QcReport? = null
}

class AnalyseModel : TaskModel() {
    enum class Mode(val label: String, val blurb: String) {
        SLOKA("Śloka analysis", "Padaccheda, pratipadārtha, grammar, samāsa, anvaya, bhāvārtha, tātparya, chandas, alaṅkāra"),
        PROSE("Prose analysis", "Sentences, word meanings, forms, compounds, syntax, anvaya and translation"),
        COMMENTARY("Sanskrit-to-Sanskrit commentary", "Explanation in Sanskrit: paraphrase, grammar, word meanings"),
    }
    var mode = Mode.SLOKA
    var out = Lang.EN
    var part = Prompts.CommentaryPart.ALL
    var input = ""
    var doc: Document? = null
    var qc: QcReport? = null
}

/** The one-time browser sign-in to OpenRouter. The model lives here so a screen can be rebuilt while the browser is open. */
class ConnectModel : TaskModel() {
    var lastOutcome = ""
    var lastWasSuccess = false
}

class CompareModel : TaskModel() {
    var task = ModelCompare.Task.TRANSLATE
    var dir = Direction(Lang.SA, Lang.EN)
    var out = Lang.EN
    var input = ""
    var loaded = false
    val selected = LinkedHashSet<String>()
    val custom = ArrayList<String>()
    val results = ArrayList<ModelCompare.Outcome>()
    var resultTask = ModelCompare.Task.TRANSLATE
    var resultInput = ""
}

object App {
    lateinit var store: Store
    private lateinit var appCtx: Context
    private var initialised = false
    val exec: ExecutorService = Executors.newCachedThreadPool()
    private val main = Handler(Looper.getMainLooper())
    var policy: UsagePolicy = FreeTestingPolicy

    // The state of each task lives here, not in a screen, so a screen can be rebuilt (rotation, returning from the browser) at any time.
    var translate = TranslateModel(); private set
    var refine = RefineModel(); private set
    var analyse = AnalyseModel(); private set
    var compare = CompareModel(); private set
    var connect = ConnectModel(); private set

    /** Where the one-time sign-in goes. These are OpenRouter's own addresses; only the automated tests point them elsewhere. */
    var signInPage: String = OpenRouterAuth.AUTH_URL
    var signInExchange: String = OpenRouterAuth.EXCHANGE_URL

    fun init(ctx: Context) {
        if (initialised) return
        appCtx = ctx.applicationContext
        store = Store(appCtx)
        Local.init(appCtx, store)
        initialised = true
    }

    /** For the automated tests only: forgets everything held in memory so each test starts like a fresh install. The app never calls this. */
    fun resetForTests(ctx: Context) {
        synchronized(this) { cached = null; cachedCreds = null }
        translate = TranslateModel(); refine = RefineModel(); analyse = AnalyseModel(); compare = CompareModel(); connect = ConnectModel()
        policy = FreeTestingPolicy
        signInPage = OpenRouterAuth.AUTH_URL; signInExchange = OpenRouterAuth.EXCHANGE_URL
        Local.resetForTests()
        initialised = false
        init(ctx)
    }

    fun ui(r: () -> Unit) { main.post(r) }

    // ---- services (cached while the saved keys are unchanged, so Bhashini's route lookup is reused) ----
    class Services(val creds: Credentials, val llm: LlmRouter, val translation: TranslationService, val scholar: ScholarService)

    private var cachedCreds: Credentials? = null
    private var cached: Services? = null

    @Synchronized
    fun services(): Services {
        val c = store.credentials()
        val old = cached
        if (old != null && c == cachedCreds) return old
        // With the source "on this phone" the router holds only the on-device model; the online services are not even built.
        val llm = ServiceFactory.llmRouter(c, local = Local.runtime)
        val tr = ServiceFactory.translation(c, llm = llm)
        val s = Services(c, llm, tr, ScholarService(llm, tr))
        cached = s; cachedCreds = c
        return s
    }

    fun isCancelled(e: Throwable): Boolean = when (e) {
        is EngineException -> e.kind == FailKind.CANCELLED
        is AttemptsExhausted -> e.kind == FailKind.CANCELLED
        is ServiceFailure -> e.allCancelled
        else -> false
    }

    fun describeSignIn(e: SignInException): UiError {
        val tail = when (e.why) {
            SignInException.Why.TIMEOUT -> " Tap Connect to try again. Keep Tribhāṣā open in the background while you sign in."
            SignInException.Why.DENIED, SignInException.Why.NETWORK, SignInException.Why.REJECTED -> " Tap Connect to try again."
            SignInException.Why.BROWSER, SignInException.Why.LISTENER -> " Under Advanced in Settings you can enter an OpenRouter key by hand instead."
        }
        return UiError(e.message + tail, true, false, e.detail)
    }

    /**
     * Runs [work] off the main thread and reports back on the main thread.
     * The model keeps the status, the error and the cancel handle, so a screen can be rebuilt at any time.
     */
    fun <T> launch(m: TaskModel, first: String, work: (CancelToken, (String) -> Unit) -> T, done: (T) -> Unit) {
        if (m.running) return
        val cancel = CancelToken()
        m.cancel = cancel; m.running = true; m.error = null; m.status = first
        m.changed()
        exec.execute {
            try {
                if (!policy.mayRun()) throw EngineException(FailKind.BLOCKED, "This build is not allowed to run right now.")
                // A progress line can reach the main thread after the task has already finished or been cancelled (the model reports
                // from its own thread). It is ignored then, so it cannot overwrite "Cancelled" or an error.
                val r = work(cancel) { msg -> ui { if (m.cancel === cancel && m.running) { m.status = msg; m.changed() } } }
                policy.recordSuccess()
                ui { m.running = false; m.status = ""; try { done(r) } catch (x: Throwable) { m.error = describe(x) }; m.changed() }
            } catch (e: Throwable) {
                val cancelled = isCancelled(e)
                val err = if (cancelled) null else describe(e)
                ui {
                    m.running = false
                    if (cancelled) { m.status = "Cancelled. Your text is kept."; m.error = null } else { m.status = ""; m.error = err }
                    m.changed()
                }
            }
        }
    }

    /** Saves a finished task to the history, off the main thread. */
    fun record(e: HistoryEntry) {
        exec.execute {
            try { store.addHistory(e) } catch (x: Throwable) {
                ui { try { android.widget.Toast.makeText(appCtx, "Could not save this to the history.", android.widget.Toast.LENGTH_LONG).show() } catch (_: Throwable) {} }
            }
        }
    }

    /**
     * Starts OpenRouter's sign-in: opens the browser, waits for it to send the user back to this phone, swaps the code for
     * the user's key and stores it encrypted. The Settings screen listens to [connect] and redraws as it changes.
     */
    fun beginConnect() {
        val m = connect
        if (m.running) return
        m.lastOutcome = ""; m.lastWasSuccess = false
        launch(m, "Opening your browser…", { cancel, progress ->
            OpenRouterAuth.signIn(open = { url -> openInBrowser(url) }, cancel = cancel, progress = progress, authBase = signInPage, exchangeUrl = signInExchange)
        }) { key ->
            store.setLlmKeyFromSignIn(key)
            if (store.credentials().llmModel.isBlank()) store.setLlmModel(Models.DEFAULT_MODEL)
            m.lastOutcome = "Connected. The app now holds its own OpenRouter key, ${store.llmKeyProtectionText()}. You did not have to copy anything."
            m.lastWasSuccess = true
        }
    }

    private fun openInBrowser(url: String): Boolean = try {
        val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        appCtx.startActivity(i)
        true
    } catch (e: Exception) { false }

    fun cancelConnect() { connect.cancel?.cancel() }

    fun hasAnyTranslator(c: Credentials) = if (c.aiSource == AiSource.LOCAL) true else c.hasBhashini || c.hasCloudflare || c.hasLlm

    /** Why the AI cannot be used right now, in words the user can act on; null when it can. */
    fun aiBlockReason(c: Credentials): String? =
        if (c.aiSource == AiSource.LOCAL) Local.runtime.unavailableReason()
        else if (!c.hasLlm) "This tool needs the AI model. Open Settings and tap “Connect” (a one-time sign-in), or switch “Where the AI runs” to “On this phone”."
        else null

    /** Only the on-phone source: the reason the model is not ready (not downloaded, unfinished, damaged); null otherwise. */
    fun localBlockReason(c: Credentials): String? = if (c.aiSource == AiSource.LOCAL) Local.runtime.unavailableReason() else null

    fun hasAi(c: Credentials) = aiBlockReason(c) == null

    /** True when the phone is offline AND the chosen AI source needs the internet. On this phone, being offline does not matter. */
    fun offlineBlocksAi(c: Credentials = store.credentials()): Boolean = c.aiSource == AiSource.ONLINE && isOffline()

    fun isOffline(): Boolean = try {
        val cm = appCtx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.activeNetwork == null
    } catch (e: Exception) { false }

    // ---- crash log (shown on next start so problems can be reported precisely) ----
    private fun crashFile() = File(appCtx.filesDir, "last_crash.txt")

    private var crashHandlerInstalled = false

    /** Once per process: the activity is rebuilt on rotation, and each rebuild must not wrap the handler once more. */
    @Synchronized
    fun installCrashHandler() {
        if (crashHandlerInstalled) return
        crashHandlerInstalled = true
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
                crashFile().writeText("Tribhāṣā build $BUILD_LABEL\nThread: ${t.name}\n\n$sw")
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    fun takeCrashReport(): String? = try {
        val f = crashFile()
        if (f.exists()) { val s = f.readText(); f.delete(); s } else null
    } catch (e: Exception) { null }

    fun logCrash(e: Throwable) {
        try {
            val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
            crashFile().writeText("Tribhāṣā build $BUILD_LABEL (handled error)\n\n$sw")
        } catch (_: Throwable) {}
    }

    const val BUILD_LABEL = "0.6 on-device (6)"

    // ---- friendly error text ----
    fun describe(e: Throwable): UiError {
        when (e) {
            is ServiceFailure -> {
                val auth = e.kinds.contains(FailKind.AUTH)
                val quota = e.kinds.contains(FailKind.QUOTA)
                val unsupported = e.kinds.contains(FailKind.UNSUPPORTED)
                val local = e.kinds.contains(FailKind.LOCAL)
                val tail = when {
                    local -> "\n\nYour text is kept and nothing was sent anywhere. Close other apps and press Retry. Settings → “AI model on this phone” shows the model's state."
                    auth -> "\n\nA key looks wrong or lacks permission. Check it in Settings."
                    quota -> "\n\nA free allowance is used up for now; it normally renews daily. Your text is kept, so you can press Retry later."
                    unsupported -> if (store.credentials().aiSource == AiSource.LOCAL) "\n\nOpen Settings → “AI model on this phone”." else "\n\nThis direction needs a different service. See Settings."
                    else -> "\n\nYour text is kept. Press Retry in a moment."
                }
                return UiError("The translation could not be completed:\n${e.message}$tail", true, auth || unsupported, e.failures.joinToString("\n") { "${it.first}: ${it.second.detail ?: it.second.message}" })
            }
            is SignInException -> return describeSignIn(e)
            is AttemptsExhausted -> return describe(e.last)
            is EngineException -> {
                val settings = e.kind == FailKind.AUTH || (e.kind == FailKind.UNSUPPORTED && (e.message ?: "").contains("Settings"))
                val tail = when (e.kind) {
                    FailKind.AUTH -> " Check the key in Settings."
                    FailKind.QUOTA -> " Your text is kept; press Retry later."
                    FailKind.NETWORK, FailKind.TIMEOUT, FailKind.SERVER, FailKind.RATE_LIMIT -> " Your text is kept; press Retry."
                    FailKind.LOCAL -> " Your text is kept and nothing was sent anywhere."
                    else -> ""
                }
                return UiError((e.message ?: "Something went wrong.") + tail, e.kind != FailKind.UNSUPPORTED || !settings, settings, e.detail)
            }
            else -> {
                logCrash(e)
                return UiError("Something unexpected went wrong (${e.javaClass.simpleName}: ${e.message}). Your text is kept. If this repeats, open Settings → “Last error report” and send it to the developer.", true, false, e.toString())
            }
        }
    }
}
