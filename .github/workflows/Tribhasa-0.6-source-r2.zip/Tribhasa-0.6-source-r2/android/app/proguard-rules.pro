# Release builds are not shrunk at the moment (isMinifyEnabled = false), so nothing here is active yet.
# If shrinking is ever switched on, the model library must be kept as it is: it calls its own native code by name.
-keep class com.google.ai.edge.litertlm.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
