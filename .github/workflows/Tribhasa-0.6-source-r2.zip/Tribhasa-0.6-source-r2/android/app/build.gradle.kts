import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val configuredApiBaseUrl = (project.findProperty("tribhasaApiBaseUrl") as? String) ?: ""

android {
    namespace = "org.tribhasa.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "org.tribhasa.app"
        minSdk = 26
        // Deliberately 34, not 36: from 35 on Android forces edge-to-edge drawing on every app, which this view-based UI has
        // not been designed or tested for. Moving the target up is a separate, visible UI task (see docs/CHANGES_0.6.md).
        targetSdk = 34
        versionCode = 6
        versionName = "0.6.0-dev"
        buildConfigField("String", "API_BASE_URL", "\"$configuredApiBaseUrl\"")
        buildConfigField("boolean", "IS_TESTING_BUILD", "true")
        // LiteRT-LM ships its native engine per CPU type. Only 64-bit ARM (almost every phone made since about 2017) is
        // included: it keeps the APK small and a 2.6 GB model is not usable on a 32-bit phone or an x86 emulator anyway.
        ndk { abiFilters += "arm64-v8a" }
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        debug {
            // A different application id from the signed APK delivered earlier (org.tribhasa.app), so installing this testing
            // build never replaces or conflicts with it.
            applicationIdSuffix = ".dev"
            versionNameSuffix = "-dev"
        }
        release {
            isMinifyEnabled = false
            buildConfigField("boolean", "IS_TESTING_BUILD", "true")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    // The model runtime: Google's LiteRT-LM (Apache-2.0). It runs a downloaded .litertlm model on the phone itself.
    // This is the only third-party library in the app.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")

    // For the unit tests only. Android's own org.json is a stub on a computer, so the real one is added for tests.
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}

// The core checks (src/test/kotlin) run as one JUnit test. More memory and UTF-8 output, and the whole list of checks in the log.
tasks.withType<Test>().configureEach {
    maxHeapSize = "1g"
    jvmArgs("-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-Dstderr.encoding=UTF-8")
    testLogging {
        showStandardStreams = true
        events("failed")
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
}
