plugins {
    id("com.android.application") version "8.13.2" apply false
    // 2.4.x is needed because Google's LiteRT-LM library (litertlm-android 0.18.0) is compiled with Kotlin 2.4 and older
    // compilers refuse to read it. The Compose plugin is gone: the app now uses the plain Android views it already used for
    // every screen, so nothing needs Compose.
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
}
