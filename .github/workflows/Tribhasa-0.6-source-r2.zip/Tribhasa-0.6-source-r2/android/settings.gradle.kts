pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
// Plain ASCII on purpose: the folder and build names are used by tools that do not all cope with the macron and dot-below
// letters. The app's visible name (Tribhāṣā) is set in res/values/strings.xml and is not affected.
rootProject.name = "Tribhasa"
include(":app")
