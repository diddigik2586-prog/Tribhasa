# Changelog

## 2026-10-20 — 0.6 on-device AI (versionCode 6)
- The AI now runs on the phone by default: Google's LiteRT-LM runtime (`litertlm-android:0.18.0`, Apache-2.0) with the Gemma 4 E2B
  model (Apache-2.0, 2.59 GB), downloaded once from its publisher on first use. No API key, account, paid service or hosting is required.
- Download manager: resumable, Wi-Fi only by default, free-space check, SHA-256 check, retry, pause/cancel, check-the-file, delete; a
  foreground-service notification with Pause. After the download, tasks run without internet.
- No silent fallback: in on-phone mode the online services are never constructed. Unsupported tasks, failures and low-confidence
  results are reported; every on-device result carries "Low confidence by default … not tested with a Sanskrit evaluation set".
- All six directions, refinement, śloka / prose / grammatical analysis and commentary, glossary, history and the offline metre check
  are kept. Online engines (IndicTrans2 services, OpenRouter models, model comparison) remain as an optional, labelled choice.
- Build rewritten: Kotlin 2.4.21, AGP 8.13.2, no Compose, targetSdk 34, arm64-v8a. Workflow extended (model-source check, build, upload, unit tests).
- Fixed: a late progress line could overwrite "Cancelled"; doubled "(not IndicTrans2)" label; wrapping quotes around a plain answer.
- Tests: core 573 checks and headless UI 498 checks pass on a computer; type-check against the real library sources passes.
  **No Gradle build, APK, device test, real download or real inference has been done.** See `docs/TEST_REPORT_0.6.md`.
- r2 (build hardening, still 0.6): fixed a possible crash when the download notification service was stopped before it had started
  in the foreground (`DownloadService`); a Pause tap can no longer throw; Google's library is now touched only when the model is first
  loaded, not while the app starts (`LocalModelController`). The workflow now also works when the whole project is uploaded as ONE
  .zip file (no unpacking on the phone), writes the reason into the run page when a build fails, and can prepare a DRAFT release
  (never published automatically). Build and test steps moved into `tools/ci/*.sh`. Added a Kannada phone guide
  (`docs/KANNADA_PHONE_GUIDE.md`).
- Stale design documents replaced (they described Compose, a FastAPI backend and Sarvam).

## 2026-10-19 / 2026-10-20 — 0.2 to 0.5 (recorded afterwards)
- The Compose skeleton was inspected and replaced by a view-based app (no Compose or AndroidX), because Gradle and its hosts could not be reached to build Compose.
- Six directions, refinement tools, śloka / prose analysis, commentary, glossary, history, offline metre, model comparison and a one-time OpenRouter sign-in were built
  against mock services, with JVM and headless-UI tests. A signed 0.5 APK was produced with a hand-assembled toolchain (not Gradle).
- The unused FastAPI/Sarvam backend was retired. See `docs/history/TEST_REPORT_0.5.md`.

## 2026-10-18 — Initial verified workspace checkpoint
- Confirmed no prior Android source project or checkpoint documents were available in the runtime/library search.
- Added initial Kotlin/Compose app scaffold: language selectors, direction swap, mode selector, input, processing state, results and QC surfaces, copy actions, clear action, and exact creator attribution.
- Added backend request contract and an opt-in Sarvam Translate adapter (disabled by default; secret via environment only).
- Added generic provider eligibility/retry/failover routing and simulation tests.
- Added project continuity, architecture, setup, decision, task, test and release records.
- No Android build, APK, AAB, deployed backend, physical device test, or real provider request has been completed in this checkpoint.
- Backend validation: 12 automated tests passed, including simulated 429/timeout/503 failover and a simulated 429→success retry; Python compileall passed. No real AI provider was called.


## 2026-10-18
- Recovered the actual project from the Library source ZIP and re-ran backend tests: 12 passed.
- Added a GitHub Actions workflow to build the debug APK and upload it as a workflow artifact; it is not yet executed.
- Updated build status and resume instructions to record missing Android tooling and blocked network DNS.
